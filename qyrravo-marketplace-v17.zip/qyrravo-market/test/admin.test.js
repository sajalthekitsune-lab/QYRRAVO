'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');

before(h.boot); after(h.shutdown);
let mod, admin;
before(async () => { mod = await h.staff('Mod', 'moderator'); admin = await h.staff('Admin', 'admin'); });

test('every admin endpoint refuses anonymous users, buyers, sellers and (for money/settings) moderators', async () => {
  const gets = ['/api/admin/overview', '/api/admin/users', '/api/admin/sellers', '/api/admin/settings', '/api/admin/finance', '/api/admin/orders', '/api/admin/payments', '/api/admin/payouts', '/api/admin/refunds', '/api/admin/disputes', '/api/admin/audit', '/api/admin/errors', '/api/admin/webhooks', '/api/admin/emails'];
  const buyer = await h.register('Buyer'); const seller = await h.makeSeller('Seller');
  for (const u of gets) {
    assert.equal((await new h.Client().get(u)).status, 401, 'anon ' + u);
    assert.equal((await buyer.get(u)).status, 403, 'buyer ' + u);
    assert.equal((await seller.get(u)).status, 403, 'seller ' + u);
    assert.equal((await mod.get(u)).status, 403, 'moderator ' + u);
    assert.equal((await admin.get(u)).status, 200, 'admin ' + u);
  }
  for (const [m, u] of [['patch', '/api/admin/settings'], ['post', '/api/admin/payouts'], ['post', '/api/admin/categories'], ['post', '/api/admin/users/1/suspend']]) {
    assert.equal((await buyer[m](u, {})).status, 403, 'buyer ' + u);
    assert.equal((await mod[m](u, {})).status, 403, 'moderator ' + u);
  }
  // moderation endpoints are closed to buyers and sellers
  assert.equal((await buyer.get('/api/mod/queue')).status, 403);
  assert.equal((await seller.get('/api/mod/queue')).status, 403);
});

test('limits are admin-configurable on the server and take effect for new listings', async () => {
  const s = await h.makeSeller('Lim');
  const big = await s.post('/api/seller/products', h.productBody({ price: '800' }));
  assert.ok([400, 409].includes(big.status) && /limit/i.test(JSON.stringify(big.body)), 'Free limit $500: ' + JSON.stringify(big.body));
  const bad = await admin.patch('/api/admin/settings', { commission_bps: 99999 });
  assert.equal(bad.status, 400);
  const unk = await admin.patch('/api/admin/settings', { admin_secret: 'x' });
  assert.equal(unk.status, 400);
  const plans = (await admin.get('/api/admin/settings')).body.plans;
  const free = plans.find((p) => p.id === 'free');
  const up = await admin.patch('/api/admin/plans/free', { maxItemUsdMinor: 100000 });
  assert.equal(up.status, 200, JSON.stringify(up.body));
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '800' }))).status, 201);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '1200' }))).status, 409, 'new $1,000 limit');
  await admin.patch('/api/admin/plans/free', { maxItemUsdMinor: 50000 });
  assert.ok(h.db.get("SELECT 1 AS x FROM audit_logs WHERE action LIKE 'plan.%' OR action LIKE 'settings.%'"), 'changes are audit-logged');
});

test('commission is a placeholder until an admin confirms it; changes are logged and apply to new orders only', async () => {
  const st = (await admin.get('/api/admin/settings')).body.settings;
  assert.equal(st.commission_is_placeholder, true);
  const r = await admin.patch('/api/admin/settings', { commission_bps: 700, confirmCommission: true });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const st2 = (await admin.get('/api/admin/settings')).body.settings;
  assert.equal(st2.commission_bps, 700); assert.equal(st2.commission_is_placeholder, false);
  assert.ok(h.db.get("SELECT 1 AS x FROM audit_logs WHERE action = 'settings.changed' OR action LIKE 'settings%'"));
  await admin.patch('/api/admin/settings', { commission_bps: 500 });
});

test('admin: suspend/restore user, role changes, categories and prohibited items, audit trail', async () => {
  const u = await h.register('Target');
  assert.equal((await admin.post('/api/admin/users/' + u.user.id + '/role', { role: 'admin' })).status, 403);
  assert.equal((await admin.post('/api/admin/users/' + u.user.id + '/role', { role: 'moderator' })).status, 200);
  assert.equal((await u.get('/api/mod/queue')).status, 200);
  assert.equal((await admin.post('/api/admin/users/' + u.user.id + '/role', { role: 'buyer' })).status, 200);
  assert.equal((await u.get('/api/mod/queue')).status, 403);
  assert.equal((await admin.post('/api/admin/users/' + u.user.id + '/suspend', { reason: 'testing suspension' })).status, 200);
  assert.equal((await u.get('/api/me')).body.user, null);
  assert.equal((await admin.post('/api/admin/users/' + u.user.id + '/restore', {})).status, 200);
  const cat = await admin.post('/api/admin/categories', { name: 'Test Category X' });
  assert.equal(cat.status, 200);
  assert.equal((await admin.post('/api/admin/categories', { name: 'Test Category X' })).status, 409);
  const kw = await admin.post('/api/admin/prohibited', { keyword: 'zzfakeitem', reason: 'Used in tests' });
  assert.equal(kw.status, 200);
  const s = await h.makeSeller('Kw');
  const c = await s.post('/api/seller/products', h.productBody({ name: 'zzfakeitem special', description: 'Some very ordinary description for a product.' }));
  assert.equal(c.status, 201);
  const audit = (await admin.get('/api/admin/audit')).body;
  assert.ok(JSON.stringify(audit).includes('user.role_changed'));
  assert.ok(!JSON.stringify(audit).match(/scrypt|password_hash/i), 'audit log never contains secrets');
});

test('seller suspension hides all of a seller\'s listings and blocks new orders', async () => {
  const s = await h.makeSeller('Susp'); h.setPayoutVerified(s.user.id);
  const p = await h.approved(s, mod, {});
  assert.equal((await new h.Client().get('/api/products/' + p.id)).status, 200);
  assert.equal((await admin.post('/api/admin/sellers/' + s.user.id + '/suspend', { reason: 'policy violation test' })).status, 200);
  assert.equal((await new h.Client().get('/api/products/' + p.id)).status, 404);
  const b = await h.register('SuspBuyer');
  const r = await b.post('/api/checkout', { sellerId: s.user.id, items: [{ productId: p.id, quantity: 1 }], shipping: { name: 'A B', line1: '1 Road', city: 'Doha', country: 'QA' }, idempotencyKey: 'idem-susp-0001' });
  assert.equal(r.status, 409);
  assert.equal((await admin.post('/api/admin/sellers/' + s.user.id + '/restore', {})).status, 200);
  assert.equal((await new h.Client().get('/api/products/' + p.id)).status, 200);
});

test('webhook endpoint hardening: GET not allowed, oversize body refused, unknown event ignored safely', async () => {
  assert.equal((await new h.Client().get('/api/webhooks/payments')).status >= 400, true);
  const big = Buffer.alloc(300 * 1024, 'a');
  const r = await new h.Client().req('POST', '/api/webhooks/payments', big, { raw: true, noCsrf: true, headers: { 'content-type': 'application/json' } });
  assert.ok([400, 413].includes(r.status));
  const u = await h.webhook(new h.Client(), 'something.unknown', { a: 1 });
  assert.ok([200, 400].includes(u.status));
});
