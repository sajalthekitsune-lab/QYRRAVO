'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');

before(h.boot); after(h.shutdown);

test('register, session, /me and logout', async () => {
  const c = await h.register('Alice');
  const me = await c.get('/api/me');
  assert.equal(me.body.user.role, 'buyer');
  assert.equal(me.body.user.email, c.email);
  assert.ok(!JSON.stringify(me.body).includes('password'));
  await c.post('/api/auth/logout');
  c.csrf = '';
  const after = await c.get('/api/me');
  assert.equal(after.body.user, null);
});

test('password policy and duplicate email', async () => {
  const c = new h.Client();
  const weak = await c.post('/api/auth/register', { email: 'weak@example.test', password: 'short', displayName: 'Weak', country: 'QA', acceptTerms: true });
  assert.equal(weak.status, 400); assert.equal(weak.body.error.code, 'weak_password');
  const noTerms = await c.post('/api/auth/register', { email: 'nt@example.test', password: 'correct-horse-battery', displayName: 'NT', country: 'QA', acceptTerms: false });
  assert.equal(noTerms.status, 400);
  const a = await h.register('Dup');
  const dup = await new h.Client().post('/api/auth/register', { email: a.email.toUpperCase(), password: 'correct-horse-battery', displayName: 'Dup2', country: 'QA', acceptTerms: true });
  assert.equal(dup.status, 409);
});

test('login errors do not reveal whether the account exists; password is hashed', async () => {
  const a = await h.register('Bob');
  const c = new h.Client();
  const wrongPw = await c.post('/api/auth/login', { email: a.email, password: 'wrong-password-123' });
  const noUser = await c.post('/api/auth/login', { email: 'nobody@example.test', password: 'wrong-password-123' });
  assert.equal(wrongPw.status, 401); assert.equal(noUser.status, 401);
  assert.equal(wrongPw.body.error.message, noUser.body.error.message);
  const row = h.db.get('SELECT password_hash FROM users WHERE email = ?', a.email);
  assert.ok(row.password_hash.startsWith('scrypt$')); assert.ok(!row.password_hash.includes('correct-horse'));
  const ok = await c.post('/api/auth/login', { email: a.email, password: 'correct-horse-battery' });
  assert.equal(ok.status, 200);
});

test('session cookie is HttpOnly + SameSite and only its hash is stored', async () => {
  const r = await fetch(h.baseUrl() + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'cookie@example.test', password: 'correct-horse-battery', displayName: 'Cookie', country: 'QA', acceptTerms: true }) });
  const sc = r.headers.getSetCookie().find((c) => c.startsWith('qy_sid='));
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Lax/);
  const token = decodeURIComponent(sc.split(';')[0].slice(7));
  assert.equal(h.db.get('SELECT COUNT(*) AS n FROM sessions WHERE token_hash = ?', token).n, 0, 'raw token must not be stored');
  assert.equal(h.db.get('SELECT COUNT(*) AS n FROM sessions WHERE token_hash = ?', require('node:crypto').createHash('sha256').update(token).digest('hex')).n, 1);
});

test('forgot password gives the same answer for unknown emails; reset token is single-use', async () => {
  const a = await h.register('Carol');
  const c = new h.Client();
  const known = await c.post('/api/auth/forgot', { email: a.email });
  const unknown = await c.post('/api/auth/forgot', { email: 'ghost@example.test' });
  assert.equal(known.body.message, unknown.body.message);
  // token only exists in the outbox email body, never in the API response
  const mail = h.db.get("SELECT body FROM email_outbox WHERE to_email = ? AND template = 'reset_password' ORDER BY id DESC", a.email);
  const token = /reset\?token=([\w-]+)/.exec(mail.body)[1];
  const bad = await c.post('/api/auth/reset', { token: 'x'.repeat(30), password: 'another-long-password' });
  assert.equal(bad.status, 400);
  const good = await c.post('/api/auth/reset', { token, password: 'another-long-password' });
  assert.equal(good.status, 200);
  const again = await c.post('/api/auth/reset', { token, password: 'yet-another-password' });
  assert.equal(again.status, 400);
  assert.equal((await new h.Client().post('/api/auth/login', { email: a.email, password: 'another-long-password' })).status, 200);
});

test('email verification link works once and emails are never reported as sent without a provider', async () => {
  const a = await h.register('Dave', { verify: false });
  assert.equal(a.user.emailVerified, false);
  const mail = h.db.get("SELECT * FROM email_outbox WHERE to_email = ? AND template = 'verify_email'", a.email);
  assert.ok(mail); assert.notEqual(mail.status, 'sent');
  const token = /verify\?token=([\w-]+)/.exec(mail.body)[1];
  assert.equal((await new h.Client().post('/api/auth/verify', { token })).status, 200);
  assert.equal((await new h.Client().post('/api/auth/verify', { token })).status, 400);
  assert.equal((await a.get('/api/me')).body.user.emailVerified, true);
});

test('CSRF: state-changing request without the token is blocked; cross-site Origin is blocked', async () => {
  const a = await h.register('Eve');
  const noTok = await a.req('PATCH', '/api/account', { displayName: 'Evil' }, { noCsrf: true });
  assert.equal(noTok.status, 403);
  const wrongOrigin = await a.req('PATCH', '/api/account', { displayName: 'Evil' }, { headers: { origin: 'https://evil.example' } });
  assert.equal(wrongOrigin.status, 403);
  const ok = await a.patch('/api/account', { displayName: 'Eve2' });
  assert.equal(ok.status, 200);
});

test('anonymous users cannot reach protected endpoints; buyers cannot reach seller/mod/admin endpoints', async () => {
  const anon = new h.Client();
  for (const u of ['/api/orders', '/api/wishlist', '/api/seller/me', '/api/mod/queue', '/api/admin/overview']) assert.equal((await anon.get(u)).status, 401, u);
  const buyer = await h.register('Frank');
  assert.equal((await buyer.get('/api/seller/me')).status, 403);
  assert.equal((await buyer.get('/api/mod/queue')).status, 403);
  for (const u of ['/api/admin/overview', '/api/admin/users', '/api/admin/settings', '/api/admin/finance', '/api/admin/audit', '/api/admin/payouts']) assert.equal((await buyer.get(u)).status, 403, u);
  assert.equal((await buyer.patch('/api/admin/settings', { commission_bps: 0 })).status, 403);
});

test('moderators cannot use admin-only permissions; admins cannot grant admin through the API', async () => {
  const mod = await h.staff('Mona', 'moderator');
  assert.equal((await mod.get('/api/mod/queue')).status, 200);
  for (const u of ['/api/admin/settings', '/api/admin/finance', '/api/admin/users', '/api/admin/payouts', '/api/admin/audit']) assert.equal((await mod.get(u)).status, 403, u);
  const admin = await h.staff('Adam', 'admin');
  const victim = await h.register('Gina');
  const r = await admin.post('/api/admin/users/' + victim.user.id + '/role', { role: 'admin' });
  assert.equal(r.status, 403);
  const ok = await admin.post('/api/admin/users/' + victim.user.id + '/role', { role: 'moderator' });
  assert.equal(ok.status, 200);
  assert.equal((await admin.post('/api/admin/users/' + admin.user.id + '/role', { role: 'buyer' })).status, 403);
  assert.ok(h.db.get("SELECT 1 AS x FROM audit_logs WHERE action = 'user.role_changed'"));
});

test('suspended users lose access immediately', async () => {
  const admin = await h.staff('Ann', 'admin');
  const u = await h.register('Hank');
  assert.equal((await u.get('/api/me')).body.user.id, u.user.id);
  assert.equal((await admin.post('/api/admin/users/' + u.user.id + '/suspend', { reason: 'testing suspension' })).status, 200);
  assert.equal((await u.get('/api/me')).body.user, null);
  assert.equal((await new h.Client().post('/api/auth/login', { email: u.email, password: 'correct-horse-battery' })).status, 403);
});

test('input validation: bad JSON, wrong content-type, oversized body', async () => {
  const c = new h.Client();
  const bad = await c.req('POST', '/api/auth/login', '{bad', { raw: true, headers: { 'content-type': 'application/json' } });
  assert.equal(bad.status, 400);
  const big = await c.req('POST', '/api/auth/login', Buffer.alloc(300 * 1024, 97), { raw: true, headers: { 'content-type': 'application/json' } });
  assert.ok([413, 400].includes(big.status));
});
