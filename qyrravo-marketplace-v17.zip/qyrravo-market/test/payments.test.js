'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
const money = require('../server/money');
const { addDays } = require('../server/util');

before(h.boot); after(h.shutdown);
let mod, admin;
before(async () => { mod = await h.staff('Mod', 'moderator'); admin = await h.staff('Admin', 'admin'); });

const wh = (type, data, o) => h.webhook(new h.Client(), type, data, o);

// ---------- pure money maths ----------
test('money: parsing, minor units, commission rounding, conversions', () => {
  assert.equal(money.parseMajor('49.99', 'USD'), 4999);
  assert.equal(money.parseMajor('1,250', 'USD'), 125000);
  assert.equal(money.parseMajor('10', 'JPY'), 10);
  assert.equal(money.parseMajor('1.5', 'KWD'), 1500);
  assert.throws(() => money.parseMajor('1.999', 'USD'));
  assert.throws(() => money.parseMajor('-5', 'USD'));
  assert.throws(() => money.parseMajor('abc', 'USD'));
  assert.throws(() => money.parseMajor('0', 'USD'));
  assert.equal(money.commission(10000, 500), 500);          // 5%
  assert.equal(money.commission(999, 500), 50);             // 49.95 rounds half up
  assert.equal(money.commission(100, 500, 30), 35);         // + fixed
  assert.equal(money.commission(10, 500, 300), 10);         // never more than the base
  assert.equal(money.toUsdMinor(36400, 'QAR', 3.64), 10000);
  assert.equal(money.fromUsdMinor(10000, 'QAR', 3.64), 36400);
  assert.match(money.format(4999, 'USD'), /49\.99/);
  assert.equal(money.proportional(500, 5000, 10000), 250);
});

// ---------- subscriptions ----------
async function premiumStart(seller) {
  const r = await seller.post('/api/seller/subscription/checkout');
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return r.body;
}
test('Premium: checkout alone changes nothing; only a verified, matching webhook activates it', async () => {
  const s = await h.makeSeller('Prem');
  const co = await premiumStart(s);
  assert.ok(co.checkoutUrl);
  let v = (await s.get('/api/seller/subscription')).body;
  assert.equal(v.effectivePlan, 'free');
  // unsigned / forged webhook
  assert.equal((await wh('payment.succeeded', { payment_id: co.paymentId, amount_minor: co.amountMinor, currency: co.currency }, { badSig: true })).status, 400);
  assert.equal((await new h.Client().req('POST', '/api/webhooks/payments', Buffer.from('{}'), { raw: true, noCsrf: true, headers: { 'content-type': 'application/json' } })).status, 400);
  // an old (replayed) signature is rejected
  assert.equal((await wh('payment.succeeded', { payment_id: co.paymentId, amount_minor: co.amountMinor, currency: co.currency }, { t: Math.floor(Date.now() / 1000) - 3600 })).status, 400);
  // the seller cannot call the simulator for someone else's payment
  const other = await h.makeSeller('Prem2');
  assert.equal((await other.post('/api/test-pay/' + co.paymentId + '/complete', {})).status, 404);
  // right signature but WRONG amount: rejected, not activated, admin alerted
  const bad = await wh('payment.succeeded', { payment_id: co.paymentId, amount_minor: 1, currency: co.currency });
  assert.equal(h.db.get("SELECT status FROM payments WHERE id = ?", co.paymentId).status, 'pending', 'payment stays pending after a mismatch');
  assert.ok(h.db.get("SELECT 1 AS x FROM notifications n JOIN users u ON u.id = n.user_id WHERE u.role = 'admin' AND n.type LIKE '%payment%'") || h.db.get("SELECT 1 AS x FROM webhook_events WHERE status = 'rejected'"), 'mismatch is recorded / admins alerted (status ' + bad.status + ')');
  v = (await s.get('/api/seller/subscription')).body;
  assert.equal(v.effectivePlan, 'free', 'amount mismatch must not activate Premium');
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE kind='subscription_payment'").n, 0);
  // correct event
  const id = 'evt_dup_1';
  const good = await wh('payment.succeeded', { payment_id: co.paymentId, amount_minor: co.amountMinor, currency: co.currency }, { id });
  assert.equal(good.status, 200);
  v = (await s.get('/api/seller/subscription')).body;
  assert.equal(v.effectivePlan, 'premium');
  assert.equal(v.limits.maxItemUsdMinor, 1000000);
  // exact duplicate delivery: no second ledger entry, no period extension
  const end1 = v.subscription.currentPeriodEnd;
  const dup = await wh('payment.succeeded', { payment_id: co.paymentId, amount_minor: co.amountMinor, currency: co.currency }, { id });
  assert.equal(dup.status, 200); assert.equal(dup.body.duplicate, true);
  // same payment under a new event id is also harmless
  await wh('payment.succeeded', { payment_id: co.paymentId, amount_minor: co.amountMinor, currency: co.currency });
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE kind='subscription_payment'").n, 1);
  assert.equal((await s.get('/api/seller/subscription')).body.subscription.currentPeriodEnd, end1);
  assert.equal((await s.post('/api/seller/subscription/checkout')).status, 409, 'already premium');
});

test('Premium: cancel keeps access until period end; expiry pauses (never deletes) over-limit listings; renewal brings them back', async () => {
  const s = await h.makeSeller('Exp');
  const co = await premiumStart(s);
  await s.post('/api/test-pay/' + co.paymentId + '/complete', {});
  const a = await h.approved(s, mod, { name: 'Gaming laptop RTX', description: 'Excellent condition gaming laptop with box and charger included.', price: '2500' });
  assert.equal((await new h.Client().get('/api/products/' + a.id)).status, 200);
  const c = await s.post('/api/seller/subscription/cancel');
  assert.equal(c.status, 200);
  assert.equal(c.body.subscription.subscription.cancelAtPeriodEnd, true);
  assert.equal((await s.get('/api/seller/subscription')).body.effectivePlan, 'premium');
  // force the period to end, run the job
  h.db.run("UPDATE subscriptions SET current_period_end = ? WHERE user_id = ?", addDays(new Date().toISOString(), -1), s.user.id);
  h.jobs.runAll();
  assert.equal((await s.get('/api/seller/subscription')).body.effectivePlan, 'free');
  assert.equal((await new h.Client().get('/api/products/' + a.id)).status, 404, 'hidden while over the Free limit');
  assert.ok(h.db.get('SELECT id FROM products WHERE id = ? AND deleted_at IS NULL', a.id), 'not deleted');
  assert.equal((await s.get('/api/seller/products/' + a.id)).status, 200, 'seller still sees it');
  assert.ok(h.db.get("SELECT 1 AS x FROM notifications WHERE user_id = ? AND type = 'subscription_expired'", s.user.id));
  // renew
  const co2 = await premiumStart(s);
  await s.post('/api/test-pay/' + co2.paymentId + '/complete', {});
  assert.equal((await new h.Client().get('/api/products/' + a.id)).status, 200, 'comes back by itself');
});

test('Premium: failed payment never activates; failed renewal does not extend the period', async () => {
  const s = await h.makeSeller('Fail');
  const co = await premiumStart(s);
  await s.post('/api/test-pay/' + co.paymentId + '/complete', { outcome: 'failed' });
  assert.equal((await s.get('/api/seller/subscription')).body.effectivePlan, 'free');
  assert.equal(h.db.get("SELECT status FROM payments WHERE id = ?", co.paymentId).status, 'failed');
  const co2 = await premiumStart(s);
  await s.post('/api/test-pay/' + co2.paymentId + '/complete', {});
  const end = (await s.get('/api/seller/subscription')).body.subscription.currentPeriodEnd;
  await s.post('/api/test-pay/subscription/renew', { outcome: 'failed' });
  assert.equal((await s.get('/api/seller/subscription')).body.subscription.currentPeriodEnd, end);
  await s.post('/api/test-pay/subscription/renew', {});
  assert.ok((await s.get('/api/seller/subscription')).body.subscription.currentPeriodEnd > end, 'successful renewal extends');
});

test('simulator routes are 404 when not in test mode', async () => {
  const config = require('../server/config');
  const s = await h.makeSeller('NoSim');
  const co = await premiumStart(s);
  const prev = config.paymentMode; config.paymentMode = 'live';
  try { assert.equal((await s.post('/api/test-pay/' + co.paymentId + '/complete', {})).status, 404); } finally { config.paymentMode = prev; }
});

// ---------- orders, commissions, refunds, payouts ----------
async function shop(name, over) {
  const s = await h.makeSeller(name);
  h.setPayoutVerified(s.user.id);
  const p = await h.approved(s, mod, { price: '100.00', quantity: 5, ...over });
  return { s, id: p.id };
}
const addr = { name: 'Buyer One', line1: '12 West Bay Street', city: 'Doha', country: 'QA' };
let n = 0;
async function buy(buyer, seller, id, qty = 1, key) {
  return buyer.post('/api/checkout', { sellerId: seller.user.id, items: [{ productId: id, quantity: qty }], shipping: addr, idempotencyKey: key || 'idem-key-' + (++n) + '-' + Math.random() });
}
async function pay(buyer, order) {
  const r = await buyer.post('/api/test-pay/' + order.payment.id + '/complete', {});
  assert.equal(r.status, 200, JSON.stringify(r.body));
}

test('checkout: pending money is not income; payment confirmation (webhook) marks the order paid and accrues commission', async () => {
  const { s, id } = await shop('Sel1');
  const b = await h.register('Buyer1');
  const r = await buy(b, s, id, 2, 'idem-fixed-1');
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const o = r.body.order;
  assert.equal(o.status, 'pending_payment');
  assert.equal(o.totalMinor, 2 * 10000 + 500); // 2 x 100.00 + 5.00 shipping
  // double click / retry: same order
  const again = await buy(b, s, id, 2, 'idem-fixed-1');
  assert.equal(again.body.order.id, o.id); assert.equal(again.body.replay, true);
  assert.equal(h.db.get('SELECT COUNT(*) AS n FROM orders WHERE buyer_id = ?', b.user.id).n, 1);
  // stock is reserved, not sold
  assert.equal(h.db.get('SELECT quantity, quantity_reserved FROM products WHERE id = ?', id).quantity_reserved, 2);
  const fin0 = (await admin.get('/api/admin/finance')).body;
  assert.ok(fin0.pendingNotIncome.some((p) => p.kind === 'order' && p.totalMinor === o.totalMinor), 'pending order payment is listed as pending, not income');
  await pay(b, o);
  const paid = (await b.get('/api/orders/' + o.id)).body.order;
  assert.equal(paid.status, 'paid');
  const c = h.db.get('SELECT * FROM commissions WHERE order_id = ?', o.id);
  assert.equal(c.amount_minor, 1000); // 5% of 200.00 items
  assert.equal(h.db.get("SELECT COALESCE(SUM(amount_minor),0) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'commission_earned'", o.id).n, 0, 'commission is not earned until completion');
  assert.equal(h.db.get('SELECT quantity FROM products WHERE id = ?', id).quantity, 3);
});

test('order state machine: ship -> deliver -> complete; commission earned and seller balance only then; illegal moves rejected', async () => {
  const { s, id } = await shop('Sel2');
  const b = await h.register('Buyer2');
  const o = (await buy(b, s, id, 1)).body.order;
  assert.equal((await s.post('/api/seller/orders/' + o.id + '/ship', { tracking: 'X1' })).status >= 400, true, 'cannot ship an unpaid order');
  await pay(b, o);
  assert.equal((await b.post('/api/orders/' + o.id + '/confirm-delivery')).status >= 400, true, 'cannot confirm before shipping');
  const sh = await s.post('/api/seller/orders/' + o.id + '/ship', { tracking: 'QA123456' });
  assert.equal(sh.status, 200, JSON.stringify(sh.body));
  const other = await h.makeSeller('Sel2b');
  assert.ok((await other.post('/api/seller/orders/' + o.id + '/ship', {})).status >= 400, 'other sellers cannot touch this order');
  let bal = (await s.get('/api/seller/finance')).body.balances.find((x) => x.currency === 'USD');
  assert.equal(bal.availableMinor, 0); assert.ok(bal.pendingMinor > 0);
  const done = await b.post('/api/orders/' + o.id + '/confirm-delivery');
  assert.equal(done.status, 200, JSON.stringify(done.body));
  const st = (await b.get('/api/orders/' + o.id)).body.order.status;
  assert.ok(['delivered', 'completed'].includes(st));
  h.db.run("UPDATE orders SET delivered_at = ? WHERE id = ?", addDays(new Date().toISOString(), -30), o.id);
  h.jobs.runAll();
  assert.equal((await b.get('/api/orders/' + o.id)).body.order.status, 'completed');
  assert.equal(h.db.get("SELECT amount_minor AS a FROM ledger_entries WHERE order_id = ? AND kind = 'commission_earned'", o.id).a, 500);
  bal = (await s.get('/api/seller/finance')).body.balances.find((x) => x.currency === 'USD');
  assert.equal(bal.availableMinor, 10000 + 500 - 500); // items + shipping - commission
  // run jobs again: nothing doubles
  h.jobs.runAll();
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'commission_earned'", o.id).n, 1);
});

test('stock: cannot oversell; unpaid reservations expire and release stock; buyers cannot see others\' orders', async () => {
  const { s, id } = await shop('Sel3', { quantity: 1 });
  const b1 = await h.register('B3a'); const b2 = await h.register('B3b');
  const o1 = (await buy(b1, s, id, 1)).body.order;
  const r2 = await buy(b2, s, id, 1);
  assert.equal(r2.status, 409);
  assert.equal((await b2.get('/api/orders/' + o1.id)).status, 404);
  h.db.run("UPDATE orders SET expires_at = ? WHERE id = ?", addDays(new Date().toISOString(), -1), o1.id);
  h.jobs.runAll();
  assert.equal((await b1.get('/api/orders/' + o1.id)).body.order.status, 'cancelled');
  assert.equal(h.db.get('SELECT quantity_reserved AS q FROM products WHERE id = ?', id).q, 0);
  assert.equal((await buy(b2, s, id, 1)).status, 200);
});

test('checkout guards: own listing, unverified buyer, seller without payout set-up, wrong country, anonymous', async () => {
  const { s, id } = await shop('Sel4');
  assert.equal((await buy(s, s, id)).status, 409);
  const unv = await h.register('Unv', { verify: false });
  assert.equal((await buy(unv, s, id)).status, 409);
  const b = await h.register('B4');
  const bad = await b.post('/api/checkout', { sellerId: s.user.id, items: [{ productId: id, quantity: 1 }], shipping: { ...addr, country: 'JP' }, idempotencyKey: 'idem-jp-1111' });
  assert.equal(bad.status, 409);
  assert.equal((await new h.Client().post('/api/checkout', {})).status, 401);
  const s2 = await h.makeSeller('Sel4b');
  const p2 = await h.approved(s2, mod, {});
  const r = await buy(b, s2, p2.id);
  assert.equal(r.status, 409); assert.equal(r.body.error.code, 'seller_not_ready');
  // tampered price / quantity in the request is ignored/rejected
  const t = await b.post('/api/checkout', { sellerId: s.user.id, items: [{ productId: id, quantity: 1, priceMinor: 1 }], shipping: addr, idempotencyKey: 'idem-tamper-1' });
  assert.equal(t.body.order.totalMinor, 10500);
  assert.equal((await buy(b, s, id, 0)).status, 400);
});

test('refunds: only booked when the provider confirms; commission reversed proportionally; no over-refund', async () => {
  const { s, id } = await shop('Sel5');
  const b = await h.register('B5');
  const o = (await buy(b, s, id, 2)).body.order;     // items 200.00 + 5.00 shipping
  await pay(b, o);
  const over = await admin.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: o.totalMinor + 1, reason: 'too much' });
  assert.ok(over.status >= 400);
  const r = await admin.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 10250, reason: 'half back' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'refund'", o.id).n, 0, 'not booked before confirmation');
  const sim = await admin.post('/api/admin/refunds/' + r.body.refund.id + '/simulate', {});
  assert.equal(sim.status, 200, JSON.stringify(sim.body));
  assert.equal(h.db.get("SELECT amount_minor AS a FROM ledger_entries WHERE order_id = ? AND kind = 'refund'", o.id).a, 10250);
  await admin.post('/api/admin/refunds/' + r.body.refund.id + '/simulate', {}); // duplicate confirmation
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'refund'", o.id).n, 1);
  assert.ok((await admin.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 10251, reason: 'again' })).status >= 400, 'remaining is only 10250');
  const r2 = await admin.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 10250, reason: 'rest' });
  await admin.post('/api/admin/refunds/' + r2.body.refund.id + '/simulate', {});
  assert.equal((await b.get('/api/orders/' + o.id)).body.order.status, 'refunded');
  assert.equal(h.db.get("SELECT COALESCE(SUM(amount_minor),0) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'commission_reversal'", o.id).n, 0, 'nothing was earned yet, so nothing to reverse');
  assert.ok(!(await b.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 1 })).body.order, 'buyers cannot refund');
  assert.equal((await b.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 1 })).status, 403);
});

test('refund after completion reverses commission proportionally (cumulative, never more than earned)', async () => {
  const { s, id } = await shop('Sel9');
  const b = await h.register('B9');
  const o = (await buy(b, s, id, 2)).body.order;      // items 20000 + ship 500; commission 1000
  await pay(b, o);
  await s.post('/api/seller/orders/' + o.id + '/ship', { tracking: 'T9' });
  await b.post('/api/orders/' + o.id + '/confirm-delivery');
  h.db.run("UPDATE orders SET delivered_at = ? WHERE id = ?", addDays(new Date().toISOString(), -30), o.id); h.jobs.runAll();
  const rev = () => h.db.get("SELECT COALESCE(SUM(amount_minor),0) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'commission_reversal'", o.id).n;
  const earned = h.db.get("SELECT amount_minor AS a FROM ledger_entries WHERE order_id = ? AND kind = 'commission_earned'", o.id).a;
  assert.equal(earned, 1000);
  const r1 = await admin.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 10250, reason: 'half' });
  await admin.post('/api/admin/refunds/' + r1.body.refund.id + '/simulate', {});
  assert.ok(Math.abs(rev() - 500) <= 1, 'about half of the commission reversed, got ' + rev());
  const r2 = await admin.post('/api/admin/orders/' + o.id + '/refund', { amountMinor: 10250, reason: 'rest' });
  await admin.post('/api/admin/refunds/' + r2.body.refund.id + '/simulate', {});
  assert.equal(rev(), 1000, 'fully refunded order -> all commission reversed, exactly');
  const bal = (await s.get('/api/seller/finance')).body.balances.find((x) => x.currency === 'USD');
  assert.equal(bal.availableMinor, 0);
});

test('seller cancel after payment requests a full refund; failed refund leaves the order unchanged', async () => {
  const { s, id } = await shop('Sel6');
  const b = await h.register('B6');
  const o = (await buy(b, s, id, 1)).body.order; await pay(b, o);
  const c = await s.post('/api/seller/orders/' + o.id + '/cancel', { reason: 'Out of stock actually' });
  assert.equal(c.status, 200, JSON.stringify(c.body));
  assert.equal((await b.get('/api/orders/' + o.id)).body.order.status, 'paid');
  await admin.post('/api/admin/refunds/' + c.body.refund.id + '/simulate', { outcome: 'failed' });
  assert.equal((await b.get('/api/orders/' + o.id)).body.order.status, 'paid');
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE order_id = ? AND kind = 'refund'", o.id).n, 0);
});

test('payouts: only verified sellers, only earned money, no double payout, marked paid by webhook only', async () => {
  const { s, id } = await shop('Sel7');
  const b = await h.register('B7');
  const o = (await buy(b, s, id, 1)).body.order; await pay(b, o);
  await s.post('/api/seller/orders/' + o.id + '/ship', { tracking: 'T1' });
  await b.post('/api/orders/' + o.id + '/confirm-delivery');
  h.db.run("UPDATE orders SET delivered_at = ? WHERE id = ?", addDays(new Date().toISOString(), -30), o.id); h.jobs.runAll();
  const mk = (a) => a.post('/api/admin/payouts', { sellerId: s.user.id, currency: 'USD' });
  assert.equal((await b.post('/api/admin/payouts', { sellerId: s.user.id, currency: 'USD' })).status, 403);
  assert.equal((await mod.post('/api/admin/payouts', { sellerId: s.user.id, currency: 'USD' })).status, 403);
  const p = await mk(admin);
  assert.equal(p.status, 200, JSON.stringify(p.body));
  assert.equal(p.body.payout.amountMinor, 10000);
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE kind = 'payout' AND payout_id = ?", p.body.payout.id).n, 0, 'not paid until the provider says so');
  assert.equal((await mk(admin)).status, 409, 'nothing left to pay out');
  const fin = (await s.get('/api/seller/finance')).body.balances.find((x) => x.currency === 'USD');
  assert.equal(fin.availableMinor, 0); assert.equal(fin.inProgressMinor, 10000);
  await admin.post('/api/admin/payouts/' + p.body.payout.id + '/simulate', {});
  assert.equal(h.db.get('SELECT status FROM payouts WHERE id = ?', p.body.payout.id).status, 'paid');
  await admin.post('/api/admin/payouts/' + p.body.payout.id + '/simulate', {});
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE kind = 'payout' AND payout_id = ?", p.body.payout.id).n, 1);
  // unverified seller
  const u = await h.makeSeller('Sel7u');
  assert.equal((await admin.post('/api/admin/payouts', { sellerId: u.user.id, currency: 'USD' })).status, 409);
});

test('disputes hold earnings; admin resolves', async () => {
  const { s, id } = await shop('Sel8');
  const b = await h.register('B8');
  const o = (await buy(b, s, id, 1)).body.order; await pay(b, o);
  const d = await b.post('/api/orders/' + o.id + '/dispute', { reason: 'The item never arrived at all.' });
  assert.equal(d.status, 200, JSON.stringify(d.body));
  assert.equal(d.body.order.status, 'disputed');
  assert.equal((await b.post('/api/orders/' + o.id + '/dispute', { reason: 'Second dispute attempt here.' })).status, 409);
  const list = (await admin.get('/api/admin/disputes')).body.disputes;
  assert.ok(list.some((x) => x.orderId === o.id));
  assert.equal((await b.get('/api/admin/disputes')).status, 403);
});

test('finance summary: per-currency, revenue = confirmed subscriptions + earned commission only', async () => {
  const f = (await admin.get('/api/admin/finance')).body;
  assert.equal(f.commissionIsPlaceholder, true);
  for (const row of f.ledger) {
    assert.equal(row.confirmedRevenue, row.subscriptionPayments - row.subscriptionRefunds + row.commissionsEarned - row.commissionReversals);
    assert.equal(row.netPlatformRevenue, row.confirmedRevenue - row.processingFees);
  }
  assert.equal((await new h.Client().get('/api/admin/finance')).status, 401);
  assert.equal((await mod.get('/api/admin/finance')).status, 403);
});
