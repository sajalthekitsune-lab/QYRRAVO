'use strict';
process.env.OWNER_EMAIL = 'owner@example.test';
process.env.OWNER_PASSWORD = 'owner-password-for-tests';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
before(async () => { await h.boot(); });
after(h.shutdown);

async function loginOwner() { const c = new h.Client(); const r = await c.post('/api/auth/login', { email: 'owner@example.test', password: 'owner-password-for-tests' }); assert.equal(r.status, 200, r.text); return c; }

test('owner account: QYRRAVO 👑, admin, owner flag, free VIP', async () => {
  const o = await loginOwner();
  const me = await o.get('/api/me');
  assert.equal(me.body.user.displayName, 'QYRRAVO 👑'); assert.equal(me.body.user.isOwner, true); assert.equal(me.body.user.role, 'admin');
  const plan = await o.get('/api/seller/subscription');
  assert.equal(plan.body.effectivePlan, 'vip');
  const cfg = await new h.Client().get('/api/config');
  assert.equal(cfg.body.site.owner.name, 'Sajal Dhungana'); assert.ok(cfg.body.site.owner.id);
  assert.ok(!JSON.stringify(cfg.body.site).includes('5519'));
});
test('nobody else can use the crown or the QYRRAVO name', async () => {
  const c = new h.Client();
  const r = await c.post('/api/auth/register', { email: 'x1@example.test', password: 'correct-horse-battery', displayName: 'QYRRAVO 👑', country: 'QA', acceptTerms: true });
  assert.equal(r.status, 400);
  const r2 = await c.post('/api/auth/register', { email: 'x2@example.test', password: 'correct-horse-battery', displayName: 'Q Y R R A V O', country: 'QA', acceptTerms: true });
  assert.equal(r2.status, 400);
});
test('only the owner can make or remove admins; owner cannot be changed', async () => {
  const o = await loginOwner(); const u = await h.register('Pal'); const a = await h.staff('Adm', 'admin');
  assert.equal((await a.post('/api/admin/users/' + u.user.id + '/role', { role: 'admin' })).status, 403);
  assert.equal((await o.post('/api/admin/users/' + u.user.id + '/role', { role: 'admin' })).status, 200);
  assert.equal((await a.post('/api/admin/users/' + u.user.id + '/role', { role: 'buyer' })).status, 403);
  assert.equal((await o.post('/api/admin/users/' + u.user.id + '/role', { role: 'buyer' })).status, 200);
  const ownerId = (await o.get('/api/me')).body.user.id;
  assert.equal((await a.post('/api/admin/users/' + ownerId + '/role', { role: 'buyer' })).status, 403);
  assert.equal((await a.post('/api/admin/users/' + ownerId + '/suspend', { reason: 'nope nope' })).status, 403);
});
test('admin can grant a plan, verify email, edit and delete other sellers\' listings', async () => {
  const o = await loginOwner(); const s = await h.makeSeller('Vendor'); const b = await h.register('Plain');
  const g = await o.post('/api/admin/users/' + s.user.id + '/plan', { planId: 'premium', days: 30 }); assert.equal(g.status, 200, g.text);
  assert.equal((await s.get('/api/seller/subscription')).body.effectivePlan, 'premium');
  assert.equal((await b.post('/api/admin/users/' + s.user.id + '/plan', { planId: 'vip' })).status, 403);
  const p = await s.post('/api/seller/products', h.productBody({ name: 'Original name' })); assert.equal(p.status, 201, p.text);
  const id = p.body.product.id;
  assert.equal((await s.patch('/api/admin/products/' + id, { name: 'Hacked' })).status, 403);
  const e = await o.patch('/api/admin/products/' + id, { name: 'Edited by owner', quantity: 2 }); assert.equal(e.status, 200, e.text);
  assert.equal((await s.get('/api/seller/products/' + id)).body.product.name, 'Edited by owner');
  const l = await o.get('/api/admin/products?q=edited'); assert.equal(l.body.products.length, 1);
  assert.equal((await o.del('/api/admin/products/' + id)).status, 400); // reason required
  const d = await o.req('DELETE', '/api/admin/products/' + id, { reason: 'Rule break' }); assert.equal(d.status, 200, d.text);
  assert.equal((await s.get('/api/seller/products/' + id)).status, 404);
});
test('assistant answers every question (built-in) and never invents contact info', async () => {
  const c = new h.Client();
  const a = await c.post('/api/assistant', { messages: [{ role: 'user', content: 'How do I buy something?' }] });
  assert.equal(a.status, 200); assert.match(a.body.reply, /qyrravo@gmail\.com/);
  const z = await c.post('/api/assistant', { messages: [{ role: 'user', content: 'zzz qqq unknown' }] });
  assert.equal(z.status, 200); assert.match(z.body.reply, /qyrravo@gmail\.com/);
  assert.equal((await c.post('/api/assistant', { messages: [] })).status, 400);
});
test('admin can delete an account and the email can be reused', async () => {
  const o = await loginOwner(); const u = await h.register('Gone');
  assert.equal((await o.post('/api/admin/users/' + u.user.id + '/delete')).status, 200);
  const r = await new h.Client().post('/api/auth/register', { email: u.email, password: 'correct-horse-battery', displayName: 'Back Again', country: 'QA', acceptTerms: true });
  assert.equal(r.status, 200, r.text);
  const ownerId = (await o.get('/api/me')).body.user.id;
  assert.equal((await o.post('/api/admin/users/' + ownerId + '/delete')).status, 403);
});
test('purchase request needs one contact + confirmed address; staff can verify the address', async () => {
  const o = await loginOwner(); const s = await h.makeSeller('Shop2'); const b = await h.register('Buyer2');
  const pr = await s.post('/api/seller/products', h.productBody()); const id = pr.body.product.id;
  h.db.run("UPDATE products SET status = 'approved', approved_at = ? WHERE id = ?", new Date().toISOString(), id);
  const body = { items: [{ productId: id, quantity: 1 }], contactKind: 'phone', contactValue: '+974 5555 1234', name: 'Bob B', line1: '12 West Bay Street', city: 'Doha', country: 'QA', confirmAddress: true };
  assert.equal((await new h.Client().post('/api/purchase-requests', body)).status, 401);
  assert.equal((await b.post('/api/purchase-requests', { ...body, contactValue: 'abc' })).status, 400);
  assert.equal((await b.post('/api/purchase-requests', { ...body, confirmAddress: false })).status, 400);
  assert.equal((await b.post('/api/purchase-requests', { ...body, line1: '' })).status, 400);
  const ok = await b.post('/api/purchase-requests', body); assert.equal(ok.status, 200, ok.text);
  const list = await o.get('/api/admin/purchase-requests'); const r = list.body.requests.find((x) => x.id === ok.body.id);
  assert.equal(r.addressStatus, 'unverified');
  assert.equal((await b.get('/api/admin/purchase-requests')).status, 403);
  await o.post('/api/admin/purchase-requests/' + r.id, { addressStatus: 'verified' });
  assert.equal((await o.get('/api/admin/purchase-requests')).body.requests.find((x) => x.id === r.id).addressStatus, 'verified');
});
