'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
before(async () => { await h.boot(); });
after(h.shutdown);

test('only admins create polls; everyone sees them; one vote each; most votes wins', async () => {
  const adm = await h.staff('PA', 'admin'); const a = await h.register('Va'); const b = await h.register('Vb'); const c = await h.register('Vc');
  assert.equal((await a.post('/api/admin/polls', { question: 'Best colour?', options: ['Red', 'Blue'] })).status, 403);
  assert.equal((await adm.post('/api/admin/polls', { question: 'Best colour?', options: ['Red'] })).status, 400);
  const mk = await adm.post('/api/admin/polls', { question: 'Best colour?', options: ['Red', 'Blue'], days: 3 }); assert.equal(mk.status, 200, mk.text);
  const anon = await new h.Client().get('/api/polls'); assert.equal(anon.body.polls[0].options.length, 2);
  const [red, blue] = anon.body.polls[0].options; const pid = mk.body.id;
  assert.equal((await new h.Client().post('/api/polls/' + pid + '/vote', { optionId: red.id })).status, 401);
  assert.equal((await a.post('/api/polls/' + pid + '/vote', { optionId: blue.id })).status, 200);
  assert.equal((await a.post('/api/polls/' + pid + '/vote', { optionId: red.id })).status, 409);
  await b.post('/api/polls/' + pid + '/vote', { optionId: blue.id }); await c.post('/api/polls/' + pid + '/vote', { optionId: red.id });
  assert.equal((await adm.post('/api/admin/polls/' + pid + '/close')).status, 200);
  const p = (await a.get('/api/polls')).body.polls[0];
  assert.equal(p.total, 3); assert.equal(p.options.find((o) => o.label === 'Blue').winner, true); assert.equal(p.options.find((o) => o.label === 'Red').winner, false); assert.equal(p.myVote, blue.id);
  assert.equal((await c.post('/api/polls/' + pid + '/vote', { optionId: red.id })).status, 409);
});
test('giveaway: enter once, admin draws a winner from entrants', async () => {
  const adm = await h.staff('EA', 'admin'); const a = await h.register('Ea'); const b = await h.register('Eb');
  assert.equal((await a.post('/api/admin/events', { title: 'Free headphones', description: 'Win a pair!', prize: 'JBL headphones' })).status, 403);
  const mk = await adm.post('/api/admin/events', { title: 'Free headphones', description: 'Win a pair!', prize: 'JBL headphones', days: 2 }); assert.equal(mk.status, 200, mk.text);
  assert.equal((await adm.post('/api/admin/events/' + mk.body.id + '/draw')).status, 409); // nobody entered
  await a.post('/api/events/' + mk.body.id + '/enter'); await a.post('/api/events/' + mk.body.id + '/enter'); await b.post('/api/events/' + mk.body.id + '/enter');
  const ev = (await a.get('/api/events')).body.events.find((e) => e.id === mk.body.id); assert.equal(ev.entries, 2); assert.equal(ev.entered, true);
  const d = await adm.post('/api/admin/events/' + mk.body.id + '/draw'); assert.equal(d.status, 200, d.text); assert.ok(d.body.winner);
  assert.equal((await adm.post('/api/admin/events/' + mk.body.id + '/draw')).status, 409);
  assert.equal((await a.post('/api/events/' + mk.body.id + '/enter')).status, 409);
});
