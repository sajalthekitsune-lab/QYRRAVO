'use strict';
// The three seller plans: Free $0 (max $100), Premium $20 (max $10,000), VIP $100 (max $100,000);
// each seller can have ONE item for sale at a time; selling it frees the slot.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');

before(async () => { await h.boot(); h.strictPlanLimits(); });
after(h.shutdown);
let mod, admin;
before(async () => { mod = await h.staff('Mod', 'moderator'); admin = await h.staff('Admin', 'admin'); });

const wh = (type, data, o) => h.webhook(new h.Client(), type, data, o);
async function subscribe(seller, planId) {
  const r = await seller.post('/api/seller/subscription/checkout', { planId });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const w = await wh('payment.succeeded', { payment_id: r.body.paymentId, amount_minor: r.body.amountMinor, currency: r.body.currency });
  assert.equal(w.status, 200);
  return r.body;
}
const addr = { name: 'Buyer One', line1: '12 West Bay Street', city: 'Doha', country: 'QA' };
async function sell(s, id) {
  const b = await h.register('Buyer');
  const r = await b.post('/api/checkout', { sellerId: s.user.id, items: [{ productId: id, quantity: 1 }], shipping: addr, idempotencyKey: 'idem-' + Math.random() });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const p = await b.post('/api/test-pay/' + r.body.order.payment.id + '/complete', {});
  assert.equal(p.status, 200);
}

test('plans are seeded: Free $0/$100, Premium $20/$10,000, VIP $100/$100,000, one item at a time each', async () => {
  const cfg = (await new h.Client().get('/api/config')).body;
  const by = Object.fromEntries(cfg.plans.map((p) => [p.id, p]));
  assert.deepEqual([by.free.priceMinor, by.free.maxItemUsdMinor], [0, 10000]);
  assert.deepEqual([by.premium.priceMinor, by.premium.maxItemUsdMinor], [2000, 1000000]);
  assert.deepEqual([by.vip.priceMinor, by.vip.maxItemUsdMinor], [10000, 10000000]);
  for (const id of ['free', 'premium', 'vip']) { assert.equal(by[id].maxActiveListings, 1); assert.equal(by[id].maxQuantity, 1); }
});

test('Free: one item for sale at a time; selling it frees the slot for the next one', async () => {
  const s = await h.makeSeller('One'); h.setPayoutVerified(s.user.id);
  const first = await h.approved(s, mod, { price: '100.00', quantity: 1 });
  // a second listing can be drafted, but cannot be submitted while the first is for sale
  const second = await s.post('/api/seller/products', h.productBody({ price: '90.00', quantity: 1 }));
  assert.equal(second.status, 201);
  const id2 = second.body.product.id;
  await s.upload('/api/seller/products/' + id2 + '/images?kind=main', h.FXU('photo.jpg'));
  await s.post('/api/seller/products/' + id2 + '/verification-code');
  await s.upload('/api/seller/products/' + id2 + '/images?kind=verification', h.FXU('photo.jpg'));
  const blocked = await s.post('/api/seller/products/' + id2 + '/submit', { submitKey: 'key-second-1' });
  assert.equal(blocked.status, 409); assert.equal(blocked.body.error.code, 'listing_limit');
  assert.equal((await s.get('/api/seller/subscription')).body.activeListings, 1);
  // the first item sells (paid -> quantity 0)
  await sell(s, first.id);
  assert.equal(h.db.get('SELECT quantity FROM products WHERE id = ?', first.id).quantity, 0);
  assert.equal((await s.get('/api/seller/subscription')).body.activeListings, 0);
  assert.equal((await new h.Client().get('/api/products/' + first.id)).status, 404, 'a sold-out item leaves the public marketplace');
  const ok = await s.post('/api/seller/products/' + id2 + '/submit', { submitKey: 'key-second-2' });
  assert.equal(ok.status, 200, JSON.stringify(ok.body));
});

test('withdrawing or deleting an item also frees the slot; drafts and rejected items never count', async () => {
  const s = await h.makeSeller('Free2');
  const p = await h.submitted(s, { price: '50.00', quantity: 1 });
  assert.equal((await s.get('/api/seller/subscription')).body.activeListings, 1);
  const reject = await mod.post('/api/mod/products/' + p.id + '/decision', { decision: 'reject', reason: 'Photo is blurry and unreadable.' });
  assert.equal(reject.status, 200, JSON.stringify(reject.body));
  assert.equal((await s.get('/api/seller/subscription')).body.activeListings, 0, 'rejected does not occupy the slot');
  const d = await s.post('/api/seller/products', h.productBody({ price: '20.00', quantity: 1 }));
  assert.equal(d.status, 201);
  assert.equal((await s.get('/api/seller/subscription')).body.activeListings, 0, 'a draft does not occupy the slot');
});

test('quantity per listing follows the plan (1 by default) and is checked on create, edit and submit', async () => {
  const s = await h.makeSeller('Qty');
  const r = await s.post('/api/seller/products', h.productBody({ price: '20.00', quantity: 3 }));
  assert.equal(r.status, 409); assert.equal(r.body.error.code, 'quantity_limit');
  const ok = await s.post('/api/seller/products', h.productBody({ price: '20.00', quantity: 1 }));
  assert.equal(ok.status, 201);
  assert.equal((await s.patch('/api/seller/products/' + ok.body.product.id, { quantity: 2 })).status, 409);
});

test('Premium ($20): up to $10,000 per item, still one item at a time; VIP ($100): up to $100,000', async () => {
  const s = await h.makeSeller('Tier');
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '150' }))).body.error.code, 'plan_limit');
  const co = await subscribe(s, 'premium');
  assert.equal(co.amountMinor, 2000);
  let v = (await s.get('/api/seller/subscription')).body;
  assert.equal(v.effectivePlan, 'premium'); assert.equal(v.limits.maxItemUsdMinor, 1000000);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '10000', quantity: 1 }))).status, 201);
  const over = await s.post('/api/seller/products', h.productBody({ price: '10000.01', quantity: 1 }));
  assert.equal(over.status, 409); assert.equal(over.body.error.details.nextPlan.id, 'vip');
  // upgrade to VIP: only after the verified webhook
  const up = await s.post('/api/seller/subscription/checkout', { planId: 'vip' });
  assert.equal(up.status, 200); assert.equal(up.body.amountMinor, 10000);
  assert.equal((await s.get('/api/seller/subscription')).body.effectivePlan, 'premium', 'checkout alone does not upgrade');
  const wrong = await wh('payment.succeeded', { payment_id: up.body.paymentId, amount_minor: 2000, currency: up.body.currency });
  assert.equal((await s.get('/api/seller/subscription')).body.effectivePlan, 'premium', 'a payment of the wrong amount does not upgrade');
  await wh('payment.succeeded', { payment_id: up.body.paymentId, amount_minor: up.body.amountMinor, currency: up.body.currency });
  v = (await s.get('/api/seller/subscription')).body;
  assert.equal(v.effectivePlan, 'vip'); assert.equal(v.limits.maxItemUsdMinor, 10000000);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '100000', quantity: 1 }))).status, 201);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '100000.01', quantity: 1 }))).body.error.code, 'price_over_platform_max');
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM ledger_entries WHERE kind = 'subscription_payment'").n >= 2, true);
});

test('cannot "downgrade" while a higher plan is running; same plan twice is refused', async () => {
  const s = await h.makeSeller('Down');
  await subscribe(s, 'vip');
  const d = await s.post('/api/seller/subscription/checkout', { planId: 'premium' });
  assert.equal(d.status, 409); assert.equal(d.body.error.code, 'downgrade_not_supported');
  const same = await s.post('/api/seller/subscription/checkout', { planId: 'vip' });
  assert.equal(same.status, 409); assert.equal(same.body.error.code, 'already_subscribed');
  assert.equal((await s.post('/api/seller/subscription/checkout', { planId: 'free' })).status, 409);
  assert.equal((await s.post('/api/seller/subscription/checkout', { planId: 'gold' })).status, 409);
});

test('when VIP ends, items above the Free limit are paused (hidden), never deleted', async () => {
  const s = await h.makeSeller('Lapse');
  await subscribe(s, 'vip');
  const p = await h.approved(s, mod, { price: '5000', quantity: 1 });
  assert.equal((await new h.Client().get('/api/products/' + p.id)).status, 200);
  h.db.run("UPDATE subscriptions SET current_period_end = ? WHERE user_id = ?", new Date(Date.now() - 1000).toISOString(), s.user.id);
  h.jobs.runAll();
  assert.equal((await new h.Client().get('/api/products/' + p.id)).status, 404, 'hidden after the plan ended');
  assert.ok(h.db.get('SELECT 1 AS x FROM products WHERE id = ? AND deleted_at IS NULL', p.id), 'not deleted');
});

test('admin can change plan prices and limits, but limits must stay in order Free <= Premium <= VIP', async () => {
  const bad = await admin.patch('/api/admin/plans/premium', { maxItemUsdMinor: 5000 });
  assert.equal(bad.status, 400);
  const bad2 = await admin.patch('/api/admin/plans/vip', { maxItemUsdMinor: 500000 });
  assert.equal(bad2.status, 400);
  const bad3 = await admin.patch('/api/admin/plans/free', { maxItemUsdMinor: 2000000 });
  assert.equal(bad3.status, 400);
  const ok = await admin.patch('/api/admin/plans/vip', { priceMinor: 9900, maxActiveListings: 2 });
  assert.equal(ok.status, 200);
  const cfg = (await new h.Client().get('/api/config')).body;
  assert.equal(cfg.plans.find((p) => p.id === 'vip').priceMinor, 9900);
  assert.equal(cfg.plans.find((p) => p.id === 'vip').maxActiveListings, 2);
  await admin.patch('/api/admin/plans/vip', { priceMinor: 10000, maxActiveListings: 1 });
  const s = await h.makeSeller('NoAdmin');
  assert.equal((await s.patch('/api/admin/plans/free', { maxItemUsdMinor: 20000 })).status, 403);
});
