'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
before(async () => { await h.boot(); });
after(h.shutdown);
const owner = async (n) => { const c = await h.staff(n, 'admin'); h.db.run('UPDATE users SET is_owner = 1 WHERE id = ?', c.user.id); return c; };

test('only the owner can create codes; admins and users cannot', async () => {
  const adm = await h.staff('RA', 'admin'); const u = await h.register('Ru'); const own = await owner('RO');
  for (const c of [adm, u]) assert.equal((await c.post('/api/owner/codes', { reward: 'x1', dollars: 5 })).status, 403);
  assert.equal((await adm.get('/api/owner/codes')).status, 403);
  assert.equal((await new h.Client().post('/api/owner/codes', { reward: 'x1', dollars: 5 })).status, 401);
  assert.equal((await own.post('/api/owner/codes', { reward: 'Gift', dollars: 0 })).status, 400);
  const r = await own.post('/api/owner/codes', { reward: 'Gift', dollars: 12.5 }); assert.equal(r.status, 200, r.text); assert.match(r.body.code, /^QYR[A-Z0-9]-/);
});
test('redeeming adds Q Coins once, honours uses, expiry and disabling', async () => {
  const own = await owner('RO2'); const a = await h.register('Ra'); const b = await h.register('Rb');
  const { body } = await own.post('/api/owner/codes', { reward: 'Ten bucks', dollars: 10 });
  assert.equal((await a.post('/api/redeem', { code: 'nonsense-code-123' })).status, 400);
  const ok = await a.post('/api/redeem', { code: body.code.toLowerCase() }); assert.equal(ok.status, 200, ok.text); assert.equal(ok.body.coins, 1000); assert.equal(ok.body.balance, 1000);
  assert.equal((await a.post('/api/redeem', { code: body.code })).status, 409);
  assert.equal((await b.post('/api/redeem', { code: body.code })).status, 409); // single use, already taken
  assert.equal((await a.get('/api/wallet')).body.coins, 1000);
  const multi = (await own.post('/api/owner/codes', { reward: 'Multi', dollars: 1, maxUses: 2 })).body;
  assert.equal((await a.post('/api/redeem', { code: multi.code })).status, 200); assert.equal((await b.post('/api/redeem', { code: multi.code })).status, 200);
  const c = await h.register('Rc'); assert.equal((await c.post('/api/redeem', { code: multi.code })).status, 409);
  const off = (await own.post('/api/owner/codes', { reward: 'Off', dollars: 1 })).body; const row = (await own.get('/api/owner/codes')).body.codes.find((x) => x.code === off.code);
  await own.post('/api/owner/codes/' + row.id + '/toggle'); assert.equal((await c.post('/api/redeem', { code: off.code })).status, 400);
  const exp = (await own.post('/api/owner/codes', { reward: 'Old', dollars: 1 })).body; h.db.run("UPDATE redeem_codes SET expires_at = '2000-01-01T00:00:00.000Z' WHERE code = ?", exp.code);
  assert.equal((await c.post('/api/redeem', { code: exp.code })).status, 400);
});
test('giveaway prize code is made for the winner only', async () => {
  const own = await owner('RO3'); const adm = await h.staff('RA3', 'admin'); const w = await h.register('Rw'); const x = await h.register('Rx');
  assert.equal((await adm.post('/api/admin/events', { title: 'Big giveaway', description: 'Win it all', prize: 'Credit', codeDollars: 5 })).status, 403);
  const ev = await own.post('/api/admin/events', { title: 'Code giveaway', description: 'Enter to win', prize: '$5 credit', codeDollars: 5, codeReward: 'Five dollar credit', days: 1 }); assert.equal(ev.status, 200, ev.text);
  await w.post('/api/events/' + ev.body.id + '/enter');
  assert.equal((await own.post('/api/admin/events/' + ev.body.id + '/draw')).status, 200);
  const mine = (await w.get('/api/wallet')).body.myCodes; assert.equal(mine.length, 1); assert.equal(mine[0].coins, 500);
  assert.equal((await x.get('/api/wallet')).body.myCodes.length, 0);
  assert.equal((await x.post('/api/redeem', { code: mine[0].code })).status, 400); // someone else cannot use it
  assert.equal((await w.post('/api/redeem', { code: mine[0].code })).status, 200);
  assert.equal((await w.get('/api/wallet')).body.coins, 500);
});
