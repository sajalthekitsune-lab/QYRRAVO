'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
process.env.GAME_COINS_PER_HOUR = '60';   // the older tests exercise the optional time pay
before(async () => { await h.boot(); });
after(h.shutdown);
const rewind = (sid, ms) => h.db.run('UPDATE game_sessions SET last_beat_ms = last_beat_ms - ? WHERE id = ?', ms, sid);

test('time is measured by the server: needs sign-in, verified email, one live session, and no instant payouts', async () => {
  assert.equal((await new h.Client().post('/api/game/start')).status, 401);
  const unv = await h.register('GmUnv', { verify: false }); assert.equal((await unv.post('/api/game/start')).status, 403);
  const u = await h.register('GmA'); const s1 = await u.post('/api/game/start'); assert.equal(s1.status, 200, s1.text);
  const sid = s1.body.sessionId;
  const quick = await u.post('/api/game/beat', { sessionId: sid, active: true }); assert.equal(quick.body.earned, 0); assert.equal(quick.body.secondsToday, 0); // spamming beats pays nothing
  rewind(sid, 15000); const b = await u.post('/api/game/beat', { sessionId: sid, active: true }); assert.equal(b.status, 200, b.text); assert.ok(b.body.secondsToday >= 14 && b.body.secondsToday <= 20);
  rewind(sid, 15000); const idle = await u.post('/api/game/beat', { sessionId: sid, active: false }); assert.equal(idle.body.secondsToday, b.body.secondsToday); // idle time is not paid
  const s2 = await u.post('/api/game/start'); assert.equal((await u.post('/api/game/beat', { sessionId: sid, active: true })).status, 409); // old tab loses
  assert.equal((await u.post('/api/game/beat', { sessionId: s2.body.sessionId, active: true })).status, 200);
});
test('1 Q per minute: 60 seconds = 1 Q; daily cap and global budget hold', async () => {
  const u = await h.register('GmB'); const sid = (await u.post('/api/game/start')).body.sessionId;
  let last; for (let i = 0; i < 6; i++) { rewind(sid, 20000); last = await u.post('/api/game/beat', { sessionId: sid, active: true }); }
  assert.equal(last.status, 200, last.text); assert.ok(last.body.secondsToday >= 100 && last.body.secondsToday <= 120);
  assert.equal(last.body.coinsToday, Math.floor(last.body.secondsToday / 60)); assert.equal(last.body.balance, last.body.coinsToday);
  assert.equal(h.db.get("SELECT COUNT(*) AS n FROM coin_ledger WHERE user_id = ? AND reason LIKE 'Game rewards%'", u.user.id).n, 1); // one tidy ledger line per day
  h.db.run('UPDATE game_progress SET seconds = 28790 WHERE user_id = ?', u.user.id);
  rewind(sid, 20000); const cap = await u.post('/api/game/beat', { sessionId: sid, active: true }); assert.equal(cap.body.secondsToday, 28800);
  rewind(sid, 20000); const more = await u.post('/api/game/beat', { sessionId: sid, active: true }); assert.equal(more.body.secondsToday, 28800); assert.equal(more.body.remainingSeconds, 0);
  // global budget
  const v = await h.register('GmC'); const vs = (await v.post('/api/game/start')).body.sessionId;
  h.db.run('INSERT OR REPLACE INTO game_budget (day, coins) VALUES (?, 50000)', new Date().toISOString().slice(0, 10));
  rewind(vs, 20000); const nb = await v.post('/api/game/beat', { sessionId: vs, active: true }); assert.equal(nb.body.balance, 0); assert.equal(nb.body.budgetLeft, false);
});

test('takedowns pay 5 Q each, limited per beat and per day, and only while active', async () => {
  h.db.run('DELETE FROM game_budget'); const u = await h.register('GmK'); const sid = (await u.post('/api/game/start')).body.sessionId;
  rewind(sid, 15000); const a = await u.post('/api/game/beat', { sessionId: sid, active: true, kills: 2 }); assert.equal(a.body.killsToday, 2); assert.equal(a.body.balance, 10 + Math.floor(a.body.secondsToday / 60));
  rewind(sid, 15000); const b = await u.post('/api/game/beat', { sessionId: sid, active: true, kills: 999 }); assert.equal(b.body.killsToday, 5); // at most 3 per beat
  for (let i = 0; i < 12; i++) { rewind(sid, 15000); await u.post('/api/game/beat', { sessionId: sid, active: true, kills: 3 }); }
  const st = await u.get('/api/game/status'); assert.ok(st.body.killsToday <= 20); assert.equal(st.body.killCoinsLeft, 100 - st.body.killsToday * 5);
  rewind(sid, 15000); const idle = await u.post('/api/game/beat', { sessionId: sid, active: false, kills: 3 }); assert.equal(idle.body.killsToday, st.body.killsToday); // idle beats pay nothing
  const m = await u.get('/api/me'); assert.equal(m.body.user.coins, idle.body.balance);
});

test('laps: 20 Q per lap, only after enough real active play, with a daily limit', async () => {
  delete process.env.GAME_COINS_PER_HOUR; h.db.run('DELETE FROM game_budget');
  try {
    const u = await h.register('GmLap'); const uid = u.user.id; const sid = (await u.post('/api/game/start')).body.sessionId;
    const claim = async () => { rewind(sid, 9000); return u.post('/api/game/beat', { sessionId: sid, active: false, laps: 1 }); };
    const early = await claim(); assert.equal(early.body.lapEarned, 0); assert.equal(early.body.lapDenied, 'too_fast'); assert.equal(early.body.balance, 0);
    rewind(sid, 15000); const t = await u.post('/api/game/beat', { sessionId: sid, active: true }); assert.equal(t.status, 200, t.text); assert.equal(t.body.balance, 0); // no pay for time itself
    h.db.run('UPDATE game_lap SET active_seconds = 480 WHERE user_id = ?', uid);
    const ok = await claim(); assert.equal(ok.body.lapEarned, 20); assert.equal(ok.body.balance, 20); assert.equal(ok.body.lapsToday, 1);
    const again = await claim(); assert.equal(again.body.lapEarned, 0); assert.equal(again.body.balance, 20); // the same play time cannot pay twice
    for (let i = 0; i < 20; i++) { h.db.run('UPDATE game_lap SET active_seconds = 480 WHERE user_id = ?', uid); await claim(); }
    const st = await claim(); assert.equal(st.body.lapsToday, 12); assert.equal(st.body.balance, 240);
  } finally { process.env.GAME_COINS_PER_HOUR = '60'; }
});

test('the Tesla Roadster costs 30,000 Q, is charged on the server, and can only be bought once', async () => {
  const u = await h.register('GmTesla');
  const poor = await u.post('/api/game/buy-car', { car: 'tesla' }); assert.equal(poor.status, 409);
  const bad = await u.post('/api/game/buy-car', { car: 'nope' }); assert.equal(bad.status, 400);
  h.db.run('UPDATE users SET coins = 31500 WHERE id = ?', u.user.id);
  const ok = await u.post('/api/game/buy-car', { car: 'tesla' }); assert.equal(ok.status, 200, ok.text); assert.equal(ok.body.balance, 1500); assert.deepEqual(ok.body.cars, ['tesla']);
  const again = await u.post('/api/game/buy-car', { car: 'tesla' }); assert.equal(again.status, 409); assert.equal((await u.get('/api/me')).body.user.coins, 1500);
  assert.equal((await new h.Client().post('/api/game/buy-car', { car: 'tesla' })).status, 401);
});

test('luxury cars cost 1,000 to 10,000 Q and are charged on the server', async () => {
  const lux = require('../public/data/luxury-cars.json'); assert.equal(lux.length, 20); assert.equal(lux[0].price, 1000); assert.equal(lux[19].price, 10000); assert.equal(lux[19].kmh, 10000); assert.equal(lux[0].kmh, 900);
  const u = await h.register('GmLux'); h.db.run('UPDATE users SET coins = 12000 WHERE id = ?', u.user.id);
  const top = await u.post('/api/game/buy-car', { car: 'lx20' }); assert.equal(top.status, 200, top.text); assert.equal(top.body.balance, 2000);
  const cheap = await u.post('/api/game/buy-car', { car: 'lx01' }); assert.equal(cheap.body.balance, 1000); assert.deepEqual(cheap.body.cars.sort(), ['lx01', 'lx20']);
  assert.equal((await u.post('/api/game/buy-car', { car: 'lx19' })).status, 409);   // 1,000 Q is not enough for a 9,500 Q car
});
