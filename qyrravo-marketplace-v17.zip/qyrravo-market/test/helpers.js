'use strict';
// Shared test harness: boots the real server on a random port with a throw-away database and upload folder.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qy-test-'));
Object.assign(process.env, { QY_NO_DOTENV: '1', DATABASE_PATH: path.join(dir, 'test.db'), UPLOAD_DIR: path.join(dir, 'uploads'), PAYMENT_MODE: 'test', PAYMENT_PROVIDER: 'test', NODE_ENV: 'test', RATE_LIMIT_SCALE: '1000', APP_URL: 'http://localhost:3000' });

const { createApp } = require('../server/index');
const db = require('../server/db');
const jobs = require('../server/jobs');
const testProvider = require('../server/payments/test');

const FX = (n) => fs.readFileSync(path.join(__dirname, 'fixtures', n));
let app, base;
const baseUrl = () => base;
let booting = null;
// Most tests need sellers with several listings; production defaults (1 item at a time, 1 unit) are tested in plans.test.js.
function relaxPlanLimits() { db.run('UPDATE plans SET max_active_listings = 50, max_quantity = 100'); }
function strictPlanLimits() { db.run('UPDATE plans SET max_active_listings = 1, max_quantity = 1'); }
function boot() { if (!booting) booting = (async () => { app = createApp(); const port = await app.listen(0); relaxPlanLimits(); base = 'http://127.0.0.1:' + port; })(); return booting; }
async function shutdown() { await app.close(); fs.rmSync(dir, { recursive: true, force: true }); }

class Client {
  constructor() { this.cookie = ''; this.csrf = ''; this.origin = 'http://localhost:3000'; }
  async req(method, url, body, o = {}) {
    await boot();
    const headers = { ...(o.headers || {}) };
    if (this.cookie) headers.cookie = this.cookie;
    if (this.csrf && !o.noCsrf) headers['x-csrf-token'] = this.csrf;
    if (method !== 'GET' && !headers.origin) headers.origin = this.origin;
    let payload;
    if (o.raw) payload = body; else if (body !== undefined && method !== 'GET') { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
    const r = await fetch(base + url, { method, headers, body: payload });
    for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) { const kv = c.split(';')[0]; if (kv.startsWith('qy_sid=')) this.cookie = kv.endsWith('=') ? '' : kv; }
    const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch (e) { /* not json */ }
    if (json && json.csrfToken) this.csrf = json.csrfToken;
    return { status: r.status, body: json, text, headers: r.headers };
  }
  get(u, o) { return this.req('GET', u, undefined, o); }
  post(u, b, o) { return this.req('POST', u, b === undefined ? {} : b, o); }
  patch(u, b, o) { return this.req('PATCH', u, b, o); }
  del(u, o) { return this.req('DELETE', u, undefined, o); }
  upload(u, buf, type) { return this.req('POST', u, buf, { raw: true, headers: { 'content-type': type || (buf[0] === 0x89 ? 'image/png' : 'image/jpeg') } }); }
}

let n = 0;
async function register(name = 'User', o = {}) {
  n++;
  const c = new Client();
  const email = name.toLowerCase().replace(/\W/g, '') + n + '_' + Date.now() + '@example.test';
  const r = await c.post('/api/auth/register', { email, password: 'correct-horse-battery', displayName: name + ' Tester', country: o.country || 'QA', acceptTerms: true });
  if (r.status !== 200) throw new Error('register failed ' + r.text);
  c.user = r.body.user; c.email = email;
  if (o.verify !== false) db.run('UPDATE users SET email_verified_at = ? WHERE id = ?', new Date().toISOString(), c.user.id);
  return c;
}
async function staff(name, role) {
  const c = await register(name);
  db.run('UPDATE users SET role = ? WHERE id = ?', role, c.user.id); // staff roles are created server-side only, never through the API
  return c;
}
async function makeSeller(name = 'Seller', o = {}) {
  const c = await register(name, o);
  const r = await c.post('/api/seller/onboard', { shopName: name + ' Shop ' + c.user.id, country: o.country || 'QA', agreeSellerTerms: true, confirmAdult: true });
  if (r.status !== 200) throw new Error('onboard failed ' + r.text);
  return c;
}
function setPayoutVerified(userId) { db.run("UPDATE seller_profiles SET payout_status = 'verified', provider_account_ref = 'test_acct_' || user_id WHERE user_id = ?", userId); }
function productBody(over = {}) {
  const cat = db.get('SELECT id FROM categories WHERE parent_id IS NULL ORDER BY id').id;
  return { name: 'Test widget ' + Math.random().toString(36).slice(2, 7), description: 'A perfectly honest description of this widget, long enough.', category: cat, condition: 'new', price: '49.99', currency: 'USD', quantity: 3, sellerCountry: 'QA', shipsTo: ['QA', 'AE', 'SA'], dispatchDays: 2, shippingFee: '5.00', returnsType: 'returns_accepted', returnsDays: 14, ...over };
}
// unique-bytes copy of a fixture (so duplicate detection only triggers where a test shares it on purpose)
function FXU(name) {
  const out = path.join(dir, 'u' + (++n) + '.jpg');
  execFileSync('python3', ['-c', 'import sys,random\nfrom PIL import Image,ImageDraw\nr=random.Random(sys.argv[2]);im=Image.new("RGB",(900,700),(r.randint(0,255),r.randint(0,255),r.randint(0,255)));d=ImageDraw.Draw(im)\nfor i in range(50):\n x=r.randint(0,700);y=r.randint(0,500);d.rectangle([x,y,x+r.randint(20,190),y+r.randint(20,190)],outline=(r.randint(0,255),r.randint(0,255),r.randint(0,255)),width=4)\nim.save(sys.argv[1],"JPEG")', out, String(Math.random())]);
  return fs.readFileSync(out);
}
// Draft -> main photo -> verification code -> verification photo -> submit
async function submitted(seller, over = {}) {
  const c = await seller.post('/api/seller/products', productBody(over));
  if (c.status !== 201) throw new Error('create failed ' + c.text);
  const id = c.body.product.id;
  const main = await seller.upload('/api/seller/products/' + id + '/images?kind=main', FXU('photo.jpg'));
  if (main.status !== 201) throw new Error('main upload ' + main.text);
  const code = await seller.post('/api/seller/products/' + id + '/verification-code');
  const v = await seller.upload('/api/seller/products/' + id + '/images?kind=verification', FXU('photo.jpg'));
  if (v.status !== 201) throw new Error('verification upload ' + v.text);
  const s = await seller.post('/api/seller/products/' + id + '/submit', { submitKey: 'key-' + id + '-' + Math.random().toString(36).slice(2) });
  if (s.status !== 200) throw new Error('submit failed ' + s.text);
  return { id, code: code.body.verification.code, product: s.body.product, prohibitedHits: s.body.prohibitedHits, response: s.body };
}
async function approved(seller, mod, over = {}) {
  const p = await submitted(seller, over);
  const a = await mod.post('/api/mod/products/' + p.id + '/decision', { decision: 'approve', codeSeen: p.code });
  if (a.status !== 200) throw new Error('approve failed ' + a.text);
  return p;
}
// Sends a SIGNED simulated provider webhook through the real endpoint. o: { id, badSig, t }
function webhook(client, type, data, o = {}) {
  const raw = Buffer.from(JSON.stringify({ id: o.id || 'evt_' + Math.random().toString(36).slice(2), type, data }));
  const sig = o.badSig ? 't=' + Math.floor(Date.now() / 1000) + ',v1=' + '0'.repeat(64) : testProvider.sign(raw.toString('utf8'), o.t);
  return client.req('POST', '/api/webhooks/payments', raw, { raw: true, noCsrf: true, headers: { 'content-type': 'application/json', 'x-qy-signature': sig } });
}
module.exports = { relaxPlanLimits, strictPlanLimits, boot, shutdown, baseUrl, Client, register, staff, makeSeller, setPayoutVerified, productBody, submitted, approved, webhook, FX, FXU, db, jobs };
