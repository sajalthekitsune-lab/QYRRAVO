'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');

before(h.boot); after(h.shutdown);
let mod; let admin;
before(async () => { mod = await h.staff('Mod', 'moderator'); admin = await h.staff('Admin', 'admin'); });

test('seller onboarding requires verified email, terms and a unique shop name', async () => {
  const u = await h.register('Unver', { verify: false });
  assert.equal((await u.post('/api/seller/onboard', { shopName: 'Shop One', country: 'QA', agreeSellerTerms: true, confirmAdult: true })).status, 409);
  const v = await h.register('Ver');
  assert.equal((await v.post('/api/seller/onboard', { shopName: 'Shop One', country: 'QA', agreeSellerTerms: false, confirmAdult: true })).status, 400);
  assert.equal((await v.post('/api/seller/onboard', { shopName: 'Shop One', country: 'QA', agreeSellerTerms: true })).status, 400);
  assert.equal((await v.post('/api/seller/onboard', { shopName: 'QYRRAVO Official', country: 'QA', agreeSellerTerms: true, confirmAdult: true })).status, 400);
  assert.equal((await v.post('/api/seller/onboard', { shopName: 'Shop One', country: 'QA', agreeSellerTerms: true, confirmAdult: true })).status, 200);
  const w = await h.register('Ver2');
  assert.equal((await w.post('/api/seller/onboard', { shopName: 'shop one', country: 'QA', agreeSellerTerms: true, confirmAdult: true })).status, 409);
  assert.equal((await v.get('/api/me')).body.user.role, 'seller');
});

test('Free plan: $100 limit enforced on the server (create, edit, submit); platform max is the highest plan limit', async () => {
  const s = await h.makeSeller('Limit');
  const ok = await s.post('/api/seller/products', h.productBody({ price: '100.00' }));
  assert.equal(ok.status, 201);
  const over = await s.post('/api/seller/products', h.productBody({ price: '100.01' }));
  assert.equal(over.status, 409); assert.equal(over.body.error.code, 'plan_limit'); assert.equal(over.body.error.details.upgrade, true);
  const id = ok.body.product.id;
  assert.equal((await s.patch('/api/seller/products/' + id, { price: '900', currency: 'USD' })).status, 409);
  const way = await s.post('/api/seller/products', h.productBody({ price: '100000.01' }));
  assert.equal(way.body.error.code, 'price_over_platform_max');
  // currency conversion is applied before checking: 400 QAR is about $110 -> over the free limit
  const qar = await s.post('/api/seller/products', h.productBody({ price: '400', currency: 'QAR' }));
  assert.equal(qar.status, 409);
  const qarOk = await s.post('/api/seller/products', h.productBody({ price: '360', currency: 'QAR' }));
  assert.equal(qarOk.status, 201); assert.equal(qarOk.body.product.price.usdMinor, Math.round(36000 / 3.64));
});

test('Premium: limit rises to $10,000 only while a subscription is active (set by webhook, never by the client)', async () => {
  const s = await h.makeSeller('Prem');
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '2500' }))).status, 409);
  // the client cannot self-upgrade
  assert.equal((await s.patch('/api/seller/profile', { plan: 'premium' })).status, 400);
  const r = await s.post('/api/seller/subscription/checkout');
  assert.equal(r.status, 200);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '2500' }))).status, 409, 'still free until the webhook arrives');
  const pay = h.db.get("SELECT * FROM payments WHERE kind = 'subscription' ORDER BY id DESC");
  const w = await h.webhook(s, 'payment.succeeded', { payment_id: pay.id, amount_minor: pay.amount_minor, currency: pay.currency });
  assert.equal(w.status, 200);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '10000' }))).status, 201);
  assert.equal((await s.post('/api/seller/products', h.productBody({ price: '100000.01' }))).status, 409);
});

test('images: only real JPEG/PNG/WebP; EXIF/GPS stripped; tiny and fake files rejected', async () => {
  const s = await h.makeSeller('Img');
  const p = (await s.post('/api/seller/products', h.productBody())).body.product;
  const url = '/api/seller/products/' + p.id + '/images?kind=main';
  assert.equal((await s.upload(url, h.FX('fake.jpg'))).status, 400);
  assert.equal((await s.upload(url, h.FX('tiny.jpg'))).body.error.code, 'image_too_small');
  assert.equal((await s.upload(url, Buffer.from('GIF89a' + 'x'.repeat(100)))).status, 400);
  const up = await s.upload('/api/seller/products/' + p.id + '/images?kind=extra', h.FX('photo-exif.jpg'));
  assert.equal(up.status, 201);
  const row = h.db.get('SELECT file_key FROM product_images WHERE id = ?', up.body.image.id);
  const stored = require('fs').readFileSync(require('path').join(process.env.UPLOAD_DIR, row.file_key));
  assert.ok(!stored.includes(Buffer.from('SecretCameraMaker')), 'EXIF must be stripped');
  assert.ok(!/Exif/.test(stored.subarray(0, 200).toString('latin1')));
  assert.equal(stored[0], 0xff);
  assert.equal((await s.upload(url, h.FX('photo.png'))).status, 201);
  assert.equal((await s.upload('/api/seller/products/' + p.id + '/images?kind=bogus', h.FX('photo.png'))).status, 400);
});

test('verification photo flow: code is server-made, expires, is tied to one listing; only moderators ever see the photo', async () => {
  const s = await h.makeSeller('Ver');
  const other = await h.makeSeller('Other');
  const p = (await s.post('/api/seller/products', h.productBody())).body.product;
  const noCode = await s.upload('/api/seller/products/' + p.id + '/images?kind=verification', h.FX('photo.jpg'));
  assert.equal(noCode.body.error.code, 'no_code');
  const c1 = (await s.post('/api/seller/products/' + p.id + '/verification-code')).body.verification.code;
  assert.match(c1, /^QY-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
  const c2 = (await s.post('/api/seller/products/' + p.id + '/verification-code')).body.verification.code;
  assert.notEqual(c1, c2);
  assert.equal(h.db.get("SELECT status FROM verification_submissions WHERE code = ?", c1).status, 'superseded');
  // another seller cannot touch this listing
  assert.equal((await other.post('/api/seller/products/' + p.id + '/verification-code')).status, 404);
  assert.equal((await other.upload('/api/seller/products/' + p.id + '/images?kind=verification', h.FX('photo.jpg'))).status, 404);
  const v = await s.upload('/api/seller/products/' + p.id + '/images?kind=verification', h.FX('photo.jpg'));
  assert.equal(v.status, 201);
  // verification photo is never public, not even to other users; owner and moderators can see it
  assert.equal((await new h.Client().get(v.body.image.url)).status, 404);
  assert.equal((await other.get(v.body.image.url)).status, 404);
  assert.equal((await s.get(v.body.image.url)).status, 200);
  assert.equal((await mod.get(v.body.image.url)).status, 200);
  // expiry
  h.db.run("UPDATE verification_submissions SET code_expires_at = ? WHERE code = ?", new Date(Date.now() - 1000).toISOString(), c2);
  const late = await s.upload('/api/seller/products/' + p.id + '/images?kind=verification', h.FX('photo.jpg'));
  assert.equal(late.body.error.code, 'code_expired');
});

test('submit: needs everything; double-click does not create a second submission; seller cannot approve own listing', async () => {
  const s = await h.makeSeller('Sub');
  const p = (await s.post('/api/seller/products', { name: 'Half done' })).body.product;
  const inc = await s.post('/api/seller/products/' + p.id + '/submit', { submitKey: 'abcdefgh1' });
  assert.equal(inc.status, 400); assert.equal(inc.body.error.code, 'incomplete');
  assert.ok(inc.body.error.details.missing.length >= 5);
  const { id, code } = await h.submitted(s);
  const first = h.db.get('SELECT submit_key FROM products WHERE id = ?', id).submit_key;
  const again = await s.post('/api/seller/products/' + id + '/submit', { submitKey: first });
  assert.equal(again.status, 200); assert.equal(again.body.replay, true);
  assert.equal(h.db.get('SELECT COUNT(*) AS n FROM verification_submissions WHERE product_id = ? AND status = ?', id, 'submitted').n, 1);
  // locked while under review
  assert.equal((await s.patch('/api/seller/products/' + id, { name: 'Changed name now' })).status, 409);
  // seller (not staff) cannot call moderation
  assert.equal((await s.post('/api/mod/products/' + id + '/decision', { decision: 'approve', codeSeen: code })).status, 403);
  // not public yet
  assert.equal((await new h.Client().get('/api/products/' + id)).status, 404);
  assert.equal((await new h.Client().get('/api/products')).body.products.filter((x) => x.id === id).length, 0);
});

test('moderation: code must match what the moderator types; approval publishes; decisions are logged; every status shows correctly', async () => {
  const s = await h.makeSeller('Mdr');
  const { id, code } = await h.submitted(s);
  const q = await mod.get('/api/mod/queue');
  assert.ok(q.body.queue.some((x) => x.id === id));
  const detail = await mod.get('/api/mod/products/' + id);
  assert.ok(!JSON.stringify(detail.body).includes(code), 'expected code must not be sent to the moderator browser');
  assert.ok(detail.body.images.some((i) => i.kind === 'verification'));
  assert.equal((await mod.post('/api/mod/products/' + id + '/decision', { decision: 'start_review' })).body.status, 'under_review');
  const wrong = await mod.post('/api/mod/products/' + id + '/decision', { decision: 'approve', codeSeen: 'QY-AAAA-BBBB' });
  assert.equal(wrong.body.error.code, 'code_mismatch');
  assert.equal((await new h.Client().get('/api/products/' + id)).status, 404);
  assert.equal((await mod.post('/api/mod/products/' + id + '/decision', { decision: 'request_more', reason: '' })).status, 400);
  const more = await mod.post('/api/mod/products/' + id + '/decision', { decision: 'request_more', reason: 'Please show the charger label too.' });
  assert.equal(more.body.status, 'more_info_required');
  const sv = (await s.get('/api/seller/products/' + id)).body.product;
  assert.equal(sv.status, 'more_info_required'); assert.match(sv.statusReason, /label/);
  // seller fixes and resubmits with the same code
  assert.equal((await s.post('/api/seller/products/' + id + '/submit', { submitKey: 'resubmit-1' })).status, 200);
  const ok = await mod.post('/api/mod/products/' + id + '/decision', { decision: 'approve', codeSeen: ' qy-' + code.slice(3).toLowerCase() + ' ', reason: 'Matches' });
  assert.equal(ok.body.status, 'approved');
  const pub = await new h.Client().get('/api/products/' + id);
  assert.equal(pub.status, 200);
  assert.equal(pub.body.product.photoReview.label, 'Listing photos reviewed');
  assert.ok(!JSON.stringify(pub.body).includes(code));
  assert.ok(pub.body.product.images.every((i) => i.kind !== 'verification'));
  const hist = (await mod.get('/api/mod/products/' + id)).body.history.map((x) => x.decision);
  for (const d of ['start_review', 'flag', 'request_more', 'approve']) assert.ok(hist.includes(d), d);
  assert.ok(h.db.get("SELECT 1 AS x FROM audit_logs WHERE action = 'moderation.approve'"));
  // buyer-visible image of public listing works anonymously
  assert.equal((await new h.Client().get(pub.body.product.images[0].url)).status, 200);
});

test('rejection and suspension remove listings from public view; edits after approval need re-review', async () => {
  const s = await h.makeSeller('Rej');
  const a = await h.approved(s, mod);
  assert.equal((await new h.Client().get('/api/products/' + a.id)).status, 200);
  const susp = await mod.post('/api/mod/products/' + a.id + '/decision', { decision: 'suspend', reason: 'Report confirmed by moderator' });
  assert.equal(susp.body.status, 'suspended');
  assert.equal((await new h.Client().get('/api/products/' + a.id)).status, 404);
  assert.equal((await s.patch('/api/seller/products/' + a.id, { name: 'Sneaky rename now' })).status, 409);
  const b = await h.approved(s, mod);
  const edit = await s.patch('/api/seller/products/' + b.id, { description: 'Completely different description for the item.' });
  assert.equal(edit.body.product.status, 'draft'); assert.equal(edit.body.product.resetToDraft, true);
  assert.equal((await new h.Client().get('/api/products/' + b.id)).status, 404);
  const c = await h.approved(s, mod);
  const price = await s.patch('/api/seller/products/' + c.id, { price: '40', currency: 'USD' });
  assert.equal(price.body.product.status, 'approved', 'price changes do not need photo re-review');
  const d = await h.submitted(s);
  const rj = await mod.post('/api/mod/products/' + d.id + '/decision', { decision: 'reject', reason: 'Photo does not show the item.' });
  assert.equal(rj.body.status, 'rejected');
  assert.equal((await new h.Client().get('/api/products/' + d.id)).status, 404);
});

test('prohibited keywords and duplicate photos flag a listing for extra scrutiny', async () => {
  const s = await h.makeSeller('Flag');
  const { id, code } = await h.submitted(s, { name: 'Counterfeit designer bag', description: 'A bag that looks just like the real one from the shop.' });
  const d = (await mod.get('/api/mod/products/' + id)).body;
  assert.equal(d.product.flagged, true); assert.ok(d.prohibitedHits.includes('counterfeit'));
  const noReason = await mod.post('/api/mod/products/' + id + '/decision', { decision: 'approve', codeSeen: code });
  assert.equal(noReason.status, 400);
  // identical photo on another seller's listing is flagged
  const shared = h.FXU('photo.jpg');
  const s2 = await h.makeSeller('Flag2');
  const p = (await s2.post('/api/seller/products', h.productBody())).body.product;
  await s2.upload('/api/seller/products/' + p.id + '/images?kind=main', shared);
  assert.equal(h.db.get('SELECT flagged FROM products WHERE id = ?', p.id).flagged, 0);
  const s3 = await h.makeSeller('Flag3');
  const p3 = (await s3.post('/api/seller/products', h.productBody())).body.product;
  await s3.upload('/api/seller/products/' + p3.id + '/images?kind=main', shared);
  assert.equal(h.db.get('SELECT flagged FROM products WHERE id = ?', p3.id).flagged, 1);
});

test('a moderator cannot review their own listing; sellers only see their own drafts', async () => {
  const a = await h.makeSeller('Own1'); const b = await h.makeSeller('Own2');
  const x = (await a.post('/api/seller/products', h.productBody())).body.product;
  assert.equal((await b.get('/api/seller/products/' + x.id)).status, 404);
  assert.equal((await b.patch('/api/seller/products/' + x.id, { name: 'Hijacked name' })).status, 404);
  assert.equal((await b.del('/api/seller/products/' + x.id)).status, 404);
  assert.equal((await b.get('/api/seller/products')).body.products.length, 0);
  assert.equal((await new h.Client().get('/api/products/' + x.id)).status, 404);
});

test('catalogue search, filters, sorting and seller profile only expose approved listings', async () => {
  const s = await h.makeSeller('Cat');
  const a = await h.approved(s, mod, { name: 'Zebra widget alpha', price: '20' });
  const b = await h.approved(s, mod, { name: 'Zebra widget beta', price: '80' });
  await h.submitted(s, { name: 'Zebra widget hidden' });
  const anon = new h.Client();
  const r = await anon.get('/api/products?q=zebra&sort=price_desc');
  assert.deepEqual(r.body.products.map((p) => p.id), [b.id, a.id]);
  assert.equal((await anon.get('/api/products?q=zebra&max=50')).body.total, 1);
  assert.equal((await anon.get('/api/products?q=zebra&shipsTo=AE')).body.total, 2);
  assert.equal((await anon.get('/api/products?q=zebra&shipsTo=JP')).body.total, 0);
  assert.equal((await anon.get("/api/products?q=%25%27%3B%20DROP%20TABLE%20products%3B--")).status, 200);
  const sp = await anon.get('/api/sellers/' + s.user.id);
  assert.equal(sp.body.products.length, 2);
  assert.equal(sp.body.seller.verification.identityVerified, false);
  assert.ok(!('email' in sp.body.seller));
  // suspending the seller hides everything
  assert.equal((await admin.post('/api/admin/sellers/' + s.user.id + '/suspend', { reason: 'testing hide' })).status, 200);
  assert.equal((await anon.get('/api/products?q=zebra')).body.total, 0);
  assert.equal((await anon.get('/api/sellers/' + s.user.id)).status, 404);
});

test('the owner and staff can review and approve their own listings', async () => {
  const s = await h.makeSeller('SelfRev');
  const own = await h.submitted(s);
  assert.equal((await s.post('/api/mod/products/' + own.id + '/decision', { decision: 'approve', codeSeen: own.code })).status, 403);   // an ordinary seller cannot
  h.db.run("UPDATE users SET role = 'moderator' WHERE id = ?", s.user.id);
  const ok = await s.post('/api/mod/products/' + own.id + '/decision', { decision: 'approve', codeSeen: own.code });
  assert.equal(ok.status, 200, ok.text);
  assert.equal(h.db.get('SELECT status FROM products WHERE id = ?', own.id).status, 'approved');
});
