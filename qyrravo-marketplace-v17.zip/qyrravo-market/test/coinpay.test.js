'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
before(async () => { await h.boot(); });
after(h.shutdown);
const addr = { contactKind: 'email', contactValue: 'b@example.com', name: 'Buyer Name', line1: '12 Test Street', city: 'Doha', country: 'QA', confirmAddress: true };

async function liveItem(coins = true, cash = true) {
  const seller = await h.makeSeller('CSeller'); h.setPayoutVerified(seller.user.id); const mod = await h.staff('CMod' + Math.random().toString(36).slice(2, 6), 'moderator'); const p = await h.approved(seller, mod, {});
  h.db.run('UPDATE products SET accepts_cash = ?, accepts_coins = ? WHERE id = ?', cash ? 1 : 0, coins ? 1 : 0, p.id); h.db.run('UPDATE users SET is_owner = 1 WHERE id = ?', seller.user.id); // only staff/owner may sell for coins
  return { seller, id: p.id, usd: h.db.get('SELECT price_usd_minor AS c FROM products WHERE id = ?', p.id).c };
}
test('buying with Q Coins holds coins, then staff pay the seller; refunds work once', async () => {
  const it = await liveItem(); const buyer = await h.register('CBuyer'); h.db.run('UPDATE users SET coins = ? WHERE id = ?', it.usd + 5000, buyer.user.id);
  const pub = await new h.Client().get('/api/products/' + it.id); assert.equal(pub.body.product.payment.coins, true); assert.equal(pub.body.product.payment.coinPrice, it.usd);
  const bad1 = await buyer.post('/api/purchase-requests', { ...addr, paymentMethod: 'coins', items: [{ productId: it.id, quantity: 1 }] }); assert.equal(bad1.status, 200, bad1.text);
  const held = bad1.body.coins; assert.ok(held >= it.usd);
  assert.equal(h.db.get('SELECT coins FROM users WHERE id = ?', buyer.user.id).coins, it.usd + 5000 - held);
  const adm = await h.staff('CAdm', 'admin'); const rid = bad1.body.id;
  assert.equal((await adm.post('/api/admin/purchase-requests/' + rid, { coinsAction: 'release' })).status, 409); // address not verified yet
  await adm.post('/api/admin/purchase-requests/' + rid, { addressStatus: 'verified' });
  assert.equal((await adm.post('/api/admin/purchase-requests/' + rid, { coinsAction: 'release' })).status, 200);
  assert.equal(h.db.get('SELECT coins FROM users WHERE id = ?', it.seller.user.id).coins, held);
  assert.equal((await adm.post('/api/admin/purchase-requests/' + rid, { coinsAction: 'release' })).status, 409); // cannot pay twice
  assert.equal((await adm.post('/api/admin/purchase-requests/' + rid, { coinsAction: 'refund' })).status, 409);
});
test('not enough coins, cash-only items, own items, and cancelling', async () => {
  const it = await liveItem(); const poor = await h.register('CPoor');
  assert.equal((await poor.post('/api/purchase-requests', { ...addr, paymentMethod: 'coins', items: [{ productId: it.id, quantity: 1 }] })).status, 409);
  const cashOnly = await liveItem(false, true); const rich = await h.register('CRich'); h.db.run('UPDATE users SET coins = 999999 WHERE id = ?', rich.user.id);
  assert.equal((await rich.post('/api/purchase-requests', { ...addr, paymentMethod: 'coins', items: [{ productId: cashOnly.id, quantity: 1 }] })).status, 400);
  const coinOnly = await liveItem(true, false);
  assert.equal((await rich.post('/api/purchase-requests', { ...addr, paymentMethod: 'cash', items: [{ productId: coinOnly.id, quantity: 1 }] })).status, 400);
  assert.equal((await it.seller.post('/api/purchase-requests', { ...addr, paymentMethod: 'coins', items: [{ productId: it.id, quantity: 1 }] })).status, 400);
  const before = h.db.get('SELECT coins FROM users WHERE id = ?', rich.user.id).coins;
  const r = await rich.post('/api/purchase-requests', { ...addr, paymentMethod: 'coins', items: [{ productId: it.id, quantity: 1 }] }); assert.equal(r.status, 200, r.text);
  assert.equal((await new h.Client().post('/api/purchase-requests/' + r.body.id + '/cancel')).status, 401);
  assert.equal((await poor.post('/api/purchase-requests/' + r.body.id + '/cancel')).status, 404);
  assert.equal((await rich.post('/api/purchase-requests/' + r.body.id + '/cancel')).status, 200);
  assert.equal(h.db.get('SELECT coins FROM users WHERE id = ?', rich.user.id).coins, before);
  assert.equal((await rich.post('/api/purchase-requests/' + r.body.id + '/cancel')).status, 409);
  assert.equal((await rich.get('/api/purchase-requests/mine')).body.requests[0].state, 'refunded');
});
test('only staff, admins and the owner can sell for Q Coins; anyone can buy', async () => {
  const regular = await h.makeSeller('CSeller2');
  assert.equal((await regular.post('/api/seller/products', { name: 'Coin lamp', acceptsCash: false, acceptsCoins: false })).status, 400);
  const no = await regular.post('/api/seller/products', { name: 'Coin lamp', acceptsCash: true, acceptsCoins: true }); assert.equal(no.status, 403, no.text);
  const cashOk = await regular.post('/api/seller/products', { name: 'Cash lamp', acceptsCash: true, acceptsCoins: false }); assert.equal(cashOk.status, 201, cashOk.text);
  const upg = await regular.patch('/api/seller/products/' + cashOk.body.product.id, { acceptsCash: true, acceptsCoins: true }); assert.equal(upg.status, 403);
  const staffSeller = await h.makeSeller('CSeller3'); h.db.run("UPDATE users SET role = 'moderator' WHERE id = ?", staffSeller.user.id);
  const yes = await staffSeller.post('/api/seller/products', { name: 'Staff lamp', acceptsCash: true, acceptsCoins: true }); assert.equal(yes.status, 201, yes.text); assert.equal(yes.body.product.acceptsCoins, true);
});
test('buy Q Coins by email request: owner delivers once; owner can gift by email', async () => {
  const own = await h.staff('GOwn', 'admin'); h.db.run('UPDATE users SET is_owner = 1 WHERE id = ?', own.user.id);
  const adm = await h.staff('GAdm', 'admin'); const u = await h.register('GUser');
  assert.equal((await u.post('/api/coin-requests', { coins: 50 })).status, 400);
  assert.equal((await u.post('/api/coin-requests', { coins: 1050 })).status, 400);
  const r = await u.post('/api/coin-requests', { coins: 1000 }); assert.equal(r.status, 200, r.text);
  assert.equal(h.db.get('SELECT coins FROM users WHERE id = ?', u.user.id).coins, 0); // nothing before payment
  assert.equal((await adm.post('/api/owner/coin-requests/' + r.body.id + '/deliver')).status, 403);
  assert.equal((await u.post('/api/owner/coin-requests/' + r.body.id + '/deliver')).status, 403);
  assert.equal((await own.post('/api/owner/coin-requests/' + r.body.id + '/deliver')).status, 200);
  assert.equal(h.db.get('SELECT coins FROM users WHERE id = ?', u.user.id).coins, 1000);
  assert.equal((await own.post('/api/owner/coin-requests/' + r.body.id + '/deliver')).status, 409);
  assert.equal((await own.post('/api/owner/gift', { email: u.user.email, dollars: 2.5, note: 'hi' })).status, 200);
  assert.equal(h.db.get('SELECT coins FROM users WHERE id = ?', u.user.id).coins, 1250);
  assert.equal((await adm.post('/api/owner/gift', { email: u.user.email, dollars: 5 })).status, 403);
  assert.equal((await own.post('/api/owner/gift', { email: 'nobody@example.com', dollars: 5 })).status, 404);
  assert.equal((await own.post('/api/owner/gift', { email: u.user.email, dollars: -1 })).status, 400);
});
test('plan descriptions promise 10 and 100 identical units', async () => {
  const f = (id) => JSON.parse(h.db.get('SELECT features FROM plans WHERE id = ?', id).features).join(' ');
  assert.match(f('premium'), /10 identical units/); assert.match(f('vip'), /100 identical units/);
});
