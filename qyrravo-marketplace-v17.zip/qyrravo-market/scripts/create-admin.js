'use strict';
// Usage: node scripts/create-admin.js <email> [moderator|admin]   (password is read from ADMIN_PASSWORD or prompted)
// Admin accounts can ONLY be created here, on the server - never through the website.
const readline = require('readline');
const db = require('../server/db');
const auth = require('../server/auth');
const { seed } = require('../server/seed');
const { isEmail, nowIso } = require('../server/util');

async function ask(q) {
  if (process.env.ADMIN_PASSWORD) return process.env.ADMIN_PASSWORD;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((r) => rl.question(q, (a) => { rl.close(); r(a); }));
}
(async () => {
  const email = String(process.argv[2] || '').trim().toLowerCase();
  const role = process.argv[3] || 'admin';
  if (!isEmail(email) || !['admin', 'moderator'].includes(role)) { console.error('Usage: node scripts/create-admin.js <email> [admin|moderator]'); process.exit(1); }
  db.open(); seed();
  const pw = await ask('Password (min 10 chars; it will be visible while typing): ');
  auth.checkPassword(pw, email);
  const hash = await auth.hashPassword(pw);
  const t = nowIso();
  const existing = db.get('SELECT id FROM users WHERE email = ?', email);
  if (existing) db.run('UPDATE users SET role = ?, password_hash = ?, status = ?, email_verified_at = COALESCE(email_verified_at, ?), updated_at = ? WHERE id = ?', role, hash, 'active', t, t, existing.id);
  else db.run("INSERT INTO users (email, password_hash, display_name, role, country, status, email_verified_at, terms_accepted_at, created_at, updated_at) VALUES (?,?,?,?,?, 'active', ?, ?, ?, ?)", email, hash, role === 'admin' ? 'Administrator' : 'Moderator', role, 'QA', t, t, t, t);
  console.log((existing ? 'Updated ' : 'Created ') + role + ' account for ' + email);
  db.close();
})().catch((e) => { console.error(e.message); process.exit(1); });
