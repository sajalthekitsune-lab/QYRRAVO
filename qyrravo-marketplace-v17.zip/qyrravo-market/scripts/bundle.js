'use strict';
// Builds ONE file (qyrravo.js) containing the whole app. Run it with:  node qyrravo.js
// On first start it unpacks itself into ./qyrravo-app/ and starts the server. Data goes in ./qyrravo-data/.
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const root = path.join(__dirname, '..');
const skip = new Set(['node_modules', 'data', 'uploads', 'test', 'e2e', '.git']);
const files = {};
(function walk(d, rel = '') {
  for (const n of fs.readdirSync(d)) {
    if (skip.has(n) && !rel || n === '.env' || n.endsWith('.zip') || n === 'qyrravo.js') continue;
    const p = path.join(d, n), r = rel ? rel + '/' + n : n;
    if (fs.statSync(p).isDirectory()) walk(p, r); else files[r] = fs.readFileSync(p).toString('base64');
  }
})(root);
const payload = zlib.gzipSync(Buffer.from(JSON.stringify(files))).toString('base64');
const out = `#!/usr/bin/env node
'use strict';
// QYRRAVO - the whole marketplace in one file. Needs Node 22.13+.   Run:  node qyrravo.js
// Admin account:  node qyrravo.js create-admin you@example.com admin
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const PAYLOAD = '${payload}';
const dir = path.join(process.cwd(), 'qyrravo-app');
const stamp = ${JSON.stringify(Date.now().toString(36))};
if (!fs.existsSync(path.join(dir, '.stamp')) || fs.readFileSync(path.join(dir, '.stamp'), 'utf8') !== stamp) {
  const files = JSON.parse(zlib.gunzipSync(Buffer.from(PAYLOAD, 'base64')).toString());
  for (const [r, b] of Object.entries(files)) { const p = path.join(dir, r); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, Buffer.from(b, 'base64')); }
  fs.writeFileSync(path.join(dir, '.stamp'), stamp);
  console.log('Unpacked app into ' + dir);
}
const data = path.join(process.cwd(), 'qyrravo-data'); fs.mkdirSync(data, { recursive: true });
process.env.DATABASE_PATH = process.env.DATABASE_PATH || path.join(data, 'qyrravo.db');
process.env.UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(data, 'uploads');
process.env.QY_ENV_FILE = process.env.QY_ENV_FILE || path.join(process.cwd(), '.env');
process.chdir(dir);
const cmd = process.argv[2];
if (cmd === 'create-admin') { process.argv.splice(2, 1); require(path.join(dir, 'scripts/create-admin.js')); }
else if (cmd === 'fetch-rates') require(path.join(dir, 'scripts/fetch-rates.js'));
else { process.env.QY_BUNDLE = '1'; require(path.join(dir, 'server/index.js')); }
`;
fs.writeFileSync(path.join(root, 'qyrravo.js'), out);
console.log('qyrravo.js', (out.length / 1024).toFixed(0) + ' KB,', Object.keys(files).length, 'files');
