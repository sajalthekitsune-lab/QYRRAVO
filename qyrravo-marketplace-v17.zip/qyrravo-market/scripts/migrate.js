'use strict';
const db = require('../server/db');
const { seed } = require('../server/seed');
db.open(); seed();
console.log('Database is up to date.');
db.close();
