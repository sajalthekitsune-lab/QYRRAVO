'use strict';
// Fetches exchange rates for the supported currencies from a public rates API and stores them with their source and time.
// Needs outbound internet. Default source: open.er-api.com (free, no key). Run it daily (cron) - rates older than FX_MAX_AGE are marked stale in the UI.
const db = require('../server/db');
const settings = require('../server/settings');
const { seed } = require('../server/seed');
const { nowIso } = require('../server/util');
(async () => {
  db.open(); seed();
  const url = process.env.FX_URL || 'https://open.er-api.com/v6/latest/USD';
  const r = await fetch(url);
  if (!r.ok) throw new Error('Rate provider responded ' + r.status);
  const j = await r.json();
  const rates = j.rates || j.conversion_rates;
  if (!rates) throw new Error('Unexpected response shape');
  const wanted = new Set([...settings.get('supported_currencies'), ...settings.COUNTRIES.map((c) => c.currency)]);
  let n = 0;
  for (const c of wanted) {
    if (c === 'USD' || !(rates[c] > 0)) continue;
    const pegged = db.get("SELECT 1 AS x FROM fx_rates WHERE currency = ? AND source LIKE 'peg:%'", c);
    if (pegged) continue; // official pegs are kept as pegs
    db.run('INSERT INTO fx_rates (currency, rate_per_usd, source, fetched_at) VALUES (?,?,?,?) ON CONFLICT(currency) DO UPDATE SET rate_per_usd=excluded.rate_per_usd, source=excluded.source, fetched_at=excluded.fetched_at', c, rates[c], 'api:' + new URL(url).host, nowIso()); n++;
  }
  console.log('Stored ' + n + ' rates from ' + url);
  db.close();
})().catch((e) => { console.error('Rate fetch failed:', e.message); process.exit(1); });
