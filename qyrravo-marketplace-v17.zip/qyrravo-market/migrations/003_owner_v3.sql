-- v3: one protected owner account, manual plan grants by staff.
ALTER TABLE users ADD COLUMN is_owner INTEGER NOT NULL DEFAULT 0;
