-- Premium sellers can stock up to 10 identical units of their one listing, VIP up to 100.
UPDATE plans SET max_quantity = 10 WHERE id = 'premium' AND max_quantity = 1;
UPDATE plans SET max_quantity = 100 WHERE id = 'vip' AND max_quantity = 1;
UPDATE plans SET features = REPLACE(features, '1 item for sale at a time, priced up to $10,000', '1 listing at a time with up to 10 identical units in stock, priced up to $10,000') WHERE id = 'premium';
UPDATE plans SET features = REPLACE(features, '1 item for sale at a time, priced up to $100,000', '1 listing at a time with up to 100 identical units in stock, priced up to $100,000') WHERE id = 'vip';
