-- Only the owner, admins and moderators may sell items for Q Coins.
UPDATE products SET accepts_coins = 0, accepts_cash = 1
 WHERE accepts_coins = 1 AND seller_id NOT IN (SELECT id FROM users WHERE role IN ('admin','moderator') OR is_owner = 1);
