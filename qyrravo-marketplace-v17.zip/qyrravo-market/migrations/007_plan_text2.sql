UPDATE plans SET features = replace(features, 'Seller dashboard, friends and chat', 'Seller dashboard');
