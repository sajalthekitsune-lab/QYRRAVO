CREATE TABLE user_cars (user_id INTEGER NOT NULL REFERENCES users(id), car TEXT NOT NULL, bought_at TEXT NOT NULL, PRIMARY KEY (user_id, car));
