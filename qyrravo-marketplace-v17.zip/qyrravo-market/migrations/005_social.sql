-- v4: follow, friends, direct messages, blocks.
CREATE TABLE follows (
  follower_id INTEGER NOT NULL REFERENCES users(id),
  followee_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  PRIMARY KEY (follower_id, followee_id)
);
CREATE INDEX idx_follows_followee ON follows(followee_id);
CREATE TABLE friendships (
  id INTEGER PRIMARY KEY,
  user_a INTEGER NOT NULL REFERENCES users(id),   -- always the smaller id
  user_b INTEGER NOT NULL REFERENCES users(id),
  requested_by INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL CHECK (status IN ('pending','accepted')),
  created_at TEXT NOT NULL,
  UNIQUE (user_a, user_b)
);
CREATE TABLE messages (
  id INTEGER PRIMARY KEY,
  sender_id INTEGER NOT NULL REFERENCES users(id),
  recipient_id INTEGER NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL,
  read_at TEXT
);
CREATE INDEX idx_msg_pair ON messages(sender_id, recipient_id, id);
CREATE INDEX idx_msg_recipient ON messages(recipient_id, read_at);
CREATE TABLE blocks (
  blocker_id INTEGER NOT NULL REFERENCES users(id),
  blocked_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  PRIMARY KEY (blocker_id, blocked_id)
);
-- which sellers a purchase request involves: pressing Buy on someone's item opens chat with that seller
CREATE TABLE purchase_request_sellers (
  request_id INTEGER NOT NULL REFERENCES purchase_requests(id),
  seller_id INTEGER NOT NULL REFERENCES users(id),
  PRIMARY KEY (request_id, seller_id)
);
