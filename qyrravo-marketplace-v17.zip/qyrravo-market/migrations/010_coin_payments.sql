ALTER TABLE products ADD COLUMN accepts_cash INTEGER NOT NULL DEFAULT 1;
ALTER TABLE products ADD COLUMN accepts_coins INTEGER NOT NULL DEFAULT 0;
ALTER TABLE purchase_requests ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'cash';
ALTER TABLE purchase_requests ADD COLUMN coins_amount INTEGER NOT NULL DEFAULT 0;
ALTER TABLE purchase_requests ADD COLUMN coins_state TEXT NOT NULL DEFAULT 'none';
ALTER TABLE purchase_requests ADD COLUMN seller_id INTEGER;
