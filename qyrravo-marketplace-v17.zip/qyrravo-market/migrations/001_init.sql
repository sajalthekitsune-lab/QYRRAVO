-- QYRRAVO marketplace schema (SQLite). All money is stored as INTEGER minor units
-- (cents, fils, ...) next to a currency code. Never use floating point for money.

CREATE TABLE roles (
  name TEXT PRIMARY KEY,
  description TEXT NOT NULL
);
CREATE TABLE permissions (
  name TEXT PRIMARY KEY,
  description TEXT NOT NULL
);
CREATE TABLE role_permissions (
  role TEXT NOT NULL REFERENCES roles(name),
  permission TEXT NOT NULL REFERENCES permissions(name),
  PRIMARY KEY (role, permission)
);

CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'buyer' REFERENCES roles(name),
  country TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','deleted')),
  suspended_reason TEXT,
  email_verified_at TEXT,
  terms_accepted_at TEXT,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT
);

CREATE TABLE sessions (
  id INTEGER PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip TEXT,
  user_agent TEXT
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE auth_tokens (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('verify_email','reset_password')),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE seller_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  shop_name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  bio TEXT,
  country TEXT NOT NULL,
  contact_email TEXT,
  contact_note TEXT,
  -- payout onboarding is set ONLY from provider confirmation (webhook) or an admin in test mode
  payout_status TEXT NOT NULL DEFAULT 'not_started' CHECK (payout_status IN ('not_started','pending','verified','rejected')),
  provider_account_ref TEXT,
  seller_status TEXT NOT NULL DEFAULT 'active' CHECK (seller_status IN ('active','suspended')),
  suspended_reason TEXT,
  agreed_seller_terms_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE categories (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  parent_id INTEGER REFERENCES categories(id),
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE prohibited_items (
  id INTEGER PRIMARY KEY,
  keyword TEXT NOT NULL UNIQUE COLLATE NOCASE,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  seller_id INTEGER NOT NULL REFERENCES users(id),
  category_id INTEGER REFERENCES categories(id),
  subcategory_id INTEGER REFERENCES categories(id),
  name TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  brand TEXT,
  model TEXT,
  condition TEXT CHECK (condition IN ('new','used','refurbished')),
  price_minor INTEGER,
  currency TEXT,
  price_usd_minor INTEGER,         -- price converted to USD at the time it was saved (for plan limits and filters)
  fx_rate REAL,                    -- units of `currency` per 1 USD that was used
  fx_source TEXT,
  fx_at TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  quantity_reserved INTEGER NOT NULL DEFAULT 0,
  seller_country TEXT,
  ships_to TEXT NOT NULL DEFAULT '[]',   -- JSON array of ISO country codes, or ["WORLD"] (seller-declared)
  dispatch_days INTEGER,
  shipping_fee_minor INTEGER NOT NULL DEFAULT 0,   -- flat fee per line item, in the listing currency
  shipping_notes TEXT,
  returns_type TEXT CHECK (returns_type IN ('returns_accepted','exchange_only','no_returns')),
  returns_days INTEGER,
  returns_notes TEXT,
  specs TEXT NOT NULL DEFAULT '[]',      -- JSON array of {k,v}
  reference_info TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','submitted','under_review','more_info_required','approved','rejected','suspended')),
  status_reason TEXT,
  flagged INTEGER NOT NULL DEFAULT 0,
  flag_reason TEXT,
  submit_key TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  submitted_at TEXT,
  approved_at TEXT,
  deleted_at TEXT
);
CREATE INDEX idx_products_seller ON products(seller_id);
CREATE INDEX idx_products_status ON products(status, deleted_at);
CREATE INDEX idx_products_cat ON products(category_id);

CREATE TABLE product_images (
  id INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('main','extra','verification')),
  file_key TEXT NOT NULL UNIQUE,
  mime TEXT NOT NULL,
  bytes INTEGER NOT NULL,
  width INTEGER,
  height INTEGER,
  sha256 TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  submission_id INTEGER,
  uploaded_at TEXT NOT NULL
);
CREATE INDEX idx_images_product ON product_images(product_id);
CREATE INDEX idx_images_sha ON product_images(sha256);

CREATE TABLE verification_submissions (
  id INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id),
  seller_id INTEGER NOT NULL REFERENCES users(id),
  code TEXT NOT NULL UNIQUE,
  code_issued_at TEXT NOT NULL,
  code_expires_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('code_issued','submitted','under_review','more_info_required','approved','rejected','superseded','expired')),
  submitted_at TEXT,
  reviewer_id INTEGER REFERENCES users(id),
  reviewed_at TEXT
);
CREATE INDEX idx_vs_product ON verification_submissions(product_id);

CREATE TABLE verification_decisions (
  id INTEGER PRIMARY KEY,
  submission_id INTEGER REFERENCES verification_submissions(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  moderator_id INTEGER NOT NULL REFERENCES users(id),
  decision TEXT NOT NULL CHECK (decision IN ('start_review','approve','reject','request_more','flag','unflag','suspend')),
  reason TEXT,
  code_seen TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_vd_product ON verification_decisions(product_id);

CREATE TABLE plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  max_item_price_usd_minor INTEGER NOT NULL,
  features TEXT NOT NULL DEFAULT '[]',
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE subscriptions (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id),
  plan_id TEXT NOT NULL REFERENCES plans(id),
  status TEXT NOT NULL CHECK (status IN ('pending','active','past_due','canceled','expired')),
  current_period_start TEXT,
  current_period_end TEXT,
  cancel_at_period_end INTEGER NOT NULL DEFAULT 0,
  provider TEXT,
  provider_subscription_ref TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE payment_customers (
  user_id INTEGER NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL,
  customer_ref TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, provider)
);

CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  order_no TEXT NOT NULL UNIQUE,
  buyer_id INTEGER NOT NULL REFERENCES users(id),
  seller_id INTEGER NOT NULL REFERENCES users(id),
  currency TEXT NOT NULL,
  items_total_minor INTEGER NOT NULL,
  shipping_minor INTEGER NOT NULL,
  total_minor INTEGER NOT NULL,
  commission_bps INTEGER NOT NULL,
  commission_fixed_minor INTEGER NOT NULL,
  commission_minor INTEGER NOT NULL,
  commission_reversed_minor INTEGER NOT NULL DEFAULT 0,
  refunded_minor INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('pending_payment','payment_failed','paid','shipped','delivered','completed','cancelled','refunded','disputed')),
  ship_name TEXT NOT NULL,
  ship_line1 TEXT NOT NULL,
  ship_line2 TEXT,
  ship_city TEXT NOT NULL,
  ship_region TEXT,
  ship_postal TEXT,
  ship_country TEXT NOT NULL,
  ship_phone TEXT,
  tracking TEXT,
  idempotency_key TEXT NOT NULL,
  payout_id INTEGER,
  expires_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  paid_at TEXT,
  shipped_at TEXT,
  delivered_at TEXT,
  completed_at TEXT,
  cancelled_at TEXT,
  UNIQUE (buyer_id, idempotency_key)
);
CREATE INDEX idx_orders_buyer ON orders(buyer_id);
CREATE INDEX idx_orders_seller ON orders(seller_id);
CREATE INDEX idx_orders_status ON orders(status);

CREATE TABLE order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  name_snapshot TEXT NOT NULL,
  unit_price_minor INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  shipping_minor INTEGER NOT NULL DEFAULT 0,
  image_id INTEGER
);
CREATE INDEX idx_oi_order ON order_items(order_id);

CREATE TABLE payments (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('subscription','order')),
  user_id INTEGER NOT NULL REFERENCES users(id),
  order_id INTEGER REFERENCES orders(id),
  subscription_id INTEGER REFERENCES subscriptions(id),
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','succeeded','failed','canceled','partially_refunded','refunded')),
  provider TEXT NOT NULL,
  provider_payment_ref TEXT UNIQUE,
  idempotency_key TEXT NOT NULL UNIQUE,
  checkout_url TEXT,
  provider_fee_minor INTEGER,
  refunded_minor INTEGER NOT NULL DEFAULT 0,
  failure_reason TEXT,
  created_at TEXT NOT NULL,
  confirmed_at TEXT
);
CREATE INDEX idx_payments_order ON payments(order_id);

CREATE TABLE webhook_events (
  id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL,
  event_id TEXT NOT NULL,
  type TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('processing','processed','ignored','error')),
  error TEXT,
  received_at TEXT NOT NULL,
  processed_at TEXT,
  UNIQUE (provider, event_id)
);

CREATE TABLE refunds (
  id INTEGER PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id),
  payment_id INTEGER NOT NULL REFERENCES payments(id),
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('requested','succeeded','failed')),
  requested_by INTEGER REFERENCES users(id),
  provider_refund_ref TEXT UNIQUE,
  created_at TEXT NOT NULL,
  confirmed_at TEXT
);

CREATE TABLE commissions (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id),
  seller_id INTEGER NOT NULL REFERENCES users(id),
  currency TEXT NOT NULL,
  base_minor INTEGER NOT NULL,
  bps INTEGER NOT NULL,
  fixed_minor INTEGER NOT NULL,
  amount_minor INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('accrued','earned','voided')),
  created_at TEXT NOT NULL,
  earned_at TEXT
);

CREATE TABLE payouts (
  id INTEGER PRIMARY KEY,
  seller_id INTEGER NOT NULL REFERENCES users(id),
  currency TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('requested','processing','paid','failed','canceled')),
  provider TEXT,
  provider_payout_ref TEXT UNIQUE,
  idempotency_key TEXT NOT NULL UNIQUE,
  created_by INTEGER REFERENCES users(id),
  failure_reason TEXT,
  created_at TEXT NOT NULL,
  paid_at TEXT
);

-- The ledger is the single source of truth for money that has actually been CONFIRMED.
-- Pending payments never appear here. Each entry has a unique idempotency_key, which makes
-- duplicate commission / payout / refund entries impossible.
CREATE TABLE ledger_entries (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN (
    'subscription_payment','subscription_refund',
    'order_gross','refund','chargeback',
    'commission_earned','commission_reversal',
    'seller_payable_earned','seller_payable_reversal',
    'processing_fee','payout')),
  currency TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  seller_id INTEGER REFERENCES users(id),
  order_id INTEGER REFERENCES orders(id),
  payment_id INTEGER REFERENCES payments(id),
  refund_id INTEGER REFERENCES refunds(id),
  payout_id INTEGER REFERENCES payouts(id),
  subscription_id INTEGER REFERENCES subscriptions(id),
  idempotency_key TEXT NOT NULL UNIQUE,
  memo TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_ledger_seller ON ledger_entries(seller_id, currency);
CREATE INDEX idx_ledger_kind ON ledger_entries(kind, currency);

-- Seller balances are COMPUTED from the ledger and the payouts table (never stored as editable numbers).
CREATE VIEW seller_balances AS
SELECT
  s.seller_id AS seller_id,
  s.currency AS currency,
  COALESCE(SUM(CASE WHEN s.kind = 'seller_payable_earned' THEN s.amount_minor END), 0)
   - COALESCE(SUM(CASE WHEN s.kind = 'seller_payable_reversal' THEN s.amount_minor END), 0) AS earned_net_minor
FROM ledger_entries s
WHERE s.seller_id IS NOT NULL
GROUP BY s.seller_id, s.currency;

CREATE TABLE reports (
  id INTEGER PRIMARY KEY,
  reporter_id INTEGER NOT NULL REFERENCES users(id),
  target_type TEXT NOT NULL CHECK (target_type IN ('product','seller')),
  target_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  details TEXT,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','dismissed','actioned')),
  handled_by INTEGER REFERENCES users(id),
  handled_note TEXT,
  handled_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE disputes (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  opened_by INTEGER REFERENCES users(id),
  source TEXT NOT NULL CHECK (source IN ('buyer','provider')),
  provider_dispute_ref TEXT UNIQUE,
  reason TEXT NOT NULL,
  amount_minor INTEGER,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved_buyer','resolved_seller','won','lost','closed')),
  resolution_note TEXT,
  resolved_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL,
  resolved_at TEXT
);

CREATE TABLE wishlist (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, product_id)
);

CREATE TABLE notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  dedupe_key TEXT UNIQUE,
  read_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_notif_user ON notifications(user_id, read_at);

-- Emails are recorded here. status 'sent' only if a real provider accepted the message.
CREATE TABLE email_outbox (
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  template TEXT,
  status TEXT NOT NULL CHECK (status IN ('queued','sent','not_configured','failed')),
  error TEXT,
  created_at TEXT NOT NULL,
  sent_at TEXT
);

CREATE TABLE audit_logs (
  id INTEGER PRIMARY KEY,
  actor_id INTEGER REFERENCES users(id),
  actor_role TEXT,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  detail TEXT,
  ip TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_created ON audit_logs(created_at);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_by INTEGER REFERENCES users(id),
  updated_at TEXT NOT NULL
);

CREATE TABLE fx_rates (
  currency TEXT PRIMARY KEY,
  rate_per_usd REAL NOT NULL CHECK (rate_per_usd > 0),
  source TEXT NOT NULL,
  fetched_at TEXT NOT NULL
);

CREATE TABLE error_log (
  id INTEGER PRIMARY KEY,
  level TEXT NOT NULL,
  message TEXT NOT NULL,
  route TEXT,
  created_at TEXT NOT NULL
);
