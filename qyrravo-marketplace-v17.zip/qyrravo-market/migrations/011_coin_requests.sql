CREATE TABLE coin_requests (
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  coins INTEGER NOT NULL, usd_cents INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','delivered','cancelled')),
  created_at TEXT NOT NULL, done_at TEXT
);
CREATE INDEX idx_coinreq_user ON coin_requests(user_id, status);
