CREATE TABLE game_sessions (
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  started_at TEXT NOT NULL, last_beat_ms INTEGER NOT NULL, live INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX idx_gamesess_user ON game_sessions(user_id, live);
CREATE TABLE game_progress (
  user_id INTEGER NOT NULL REFERENCES users(id), day TEXT NOT NULL,
  seconds INTEGER NOT NULL DEFAULT 0, carry INTEGER NOT NULL DEFAULT 0, coins INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);
CREATE TABLE game_budget (day TEXT PRIMARY KEY, coins INTEGER NOT NULL DEFAULT 0);
