ALTER TABLE users ADD COLUMN coins INTEGER NOT NULL DEFAULT 0;
CREATE TABLE redeem_codes (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, reward TEXT NOT NULL,
  value_cents INTEGER NOT NULL, coins INTEGER NOT NULL,
  max_uses INTEGER NOT NULL DEFAULT 1, uses INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT, assigned_user_id INTEGER REFERENCES users(id), event_id INTEGER REFERENCES events(id),
  active INTEGER NOT NULL DEFAULT 1, created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE code_redemptions (
  code_id INTEGER NOT NULL REFERENCES redeem_codes(id), user_id INTEGER NOT NULL REFERENCES users(id),
  coins INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (code_id, user_id)
);
CREATE TABLE coin_ledger (
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), delta INTEGER NOT NULL,
  reason TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX idx_ledger_user ON coin_ledger(user_id, id);
ALTER TABLE events ADD COLUMN prize_code_cents INTEGER;
ALTER TABLE events ADD COLUMN prize_code_reward TEXT;
