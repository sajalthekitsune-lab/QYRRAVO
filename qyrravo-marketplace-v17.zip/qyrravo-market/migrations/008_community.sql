CREATE TABLE events (
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL, prize TEXT NOT NULL,
  ends_at TEXT NOT NULL, winner_id INTEGER REFERENCES users(id), drawn_at TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, deleted_at TEXT
);
CREATE TABLE event_entries (
  event_id INTEGER NOT NULL REFERENCES events(id), user_id INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
  PRIMARY KEY (event_id, user_id)
);
CREATE TABLE polls (
  id INTEGER PRIMARY KEY, question TEXT NOT NULL, ends_at TEXT NOT NULL, closed_at TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, deleted_at TEXT
);
CREATE TABLE poll_options (id INTEGER PRIMARY KEY, poll_id INTEGER NOT NULL REFERENCES polls(id), label TEXT NOT NULL, position INTEGER NOT NULL);
CREATE TABLE poll_votes (
  poll_id INTEGER NOT NULL REFERENCES polls(id), user_id INTEGER NOT NULL REFERENCES users(id),
  option_id INTEGER NOT NULL REFERENCES poll_options(id), created_at TEXT NOT NULL,
  PRIMARY KEY (poll_id, user_id)
);
