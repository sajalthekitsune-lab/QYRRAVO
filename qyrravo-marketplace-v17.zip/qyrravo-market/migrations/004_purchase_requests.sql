CREATE TABLE purchase_requests (
  id INTEGER PRIMARY KEY,
  buyer_id INTEGER NOT NULL REFERENCES users(id),
  summary TEXT NOT NULL,
  contact_kind TEXT NOT NULL CHECK (contact_kind IN ('phone','email')),
  contact_value TEXT NOT NULL,
  name TEXT NOT NULL,
  line1 TEXT NOT NULL,
  line2 TEXT,
  city TEXT NOT NULL,
  region TEXT,
  postal TEXT,
  country TEXT NOT NULL,
  address_status TEXT NOT NULL DEFAULT 'unverified' CHECK (address_status IN ('unverified','verified','rejected')),
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','handled')),
  created_at TEXT NOT NULL
);
CREATE INDEX idx_pr_buyer ON purchase_requests(buyer_id);
