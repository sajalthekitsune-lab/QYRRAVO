-- Plans v2: three plans (Free / Premium / VIP), per-plan limits for items for sale at once and units per listing,
-- and each subscription payment remembers which plan it buys (so Premium -> VIP upgrades are exact).
ALTER TABLE plans ADD COLUMN max_active_listings INTEGER NOT NULL DEFAULT 1;
ALTER TABLE plans ADD COLUMN max_quantity INTEGER NOT NULL DEFAULT 1;
ALTER TABLE payments ADD COLUMN plan_id TEXT;
-- Move databases that still have the original v1 defaults to the new defaults (untouched admin edits are left alone).
UPDATE plans SET max_item_price_usd_minor = 10000,
  features = '["1 item for sale at a time, priced up to $100","Every listing passes photo review","Seller dashboard and order management"]'
  WHERE id = 'free' AND max_item_price_usd_minor = 50000;
UPDATE plans SET price_minor = 2000,
  features = '["1 item for sale at a time, priced up to $10,000","Every listing passes photo review","Seller dashboard and order management","Cancel any time - keeps the plan until the paid period ends"]'
  WHERE id = 'premium' AND price_minor = 1000;
