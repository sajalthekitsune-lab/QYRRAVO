UPDATE plans SET features = replace(features, 'Seller dashboard and order management', 'Seller dashboard, friends and chat');
