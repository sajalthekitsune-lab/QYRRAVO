'use strict';
// End-to-end browser test (headless Chromium via Playwright). Boots a throw-away server and clicks through the whole marketplace.
// Run: NODE_PATH=<dir containing playwright> node --disable-warning=ExperimentalWarning e2e/run.js [screenshotDir]
const path = require('path');
const fs = require('fs');
process.env.OWNER_EMAIL = 'owner@example.test'; process.env.OWNER_PASSWORD = 'owner-password-for-tests';
const H = require('../test/helpers');
const { chromium } = require('playwright');
const shots = process.argv[2] || path.join(require('os').tmpdir(), 'qy-shots');
fs.mkdirSync(shots, { recursive: true });
const fx = (n) => path.join(__dirname, '..', 'test', 'fixtures', n);
const problems = []; let steps = 0;
const ok = (c, m) => { steps++; if (!c) { problems.push(m); console.log('  ✗ ' + m); } else console.log('  ✓ ' + m); };

(async () => {
  await H.boot(); const base = H.baseUrl();
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM || undefined, args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const mk = async (opts = {}) => { const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, permissions: ['camera'], ...opts }); const page = await ctx.newPage(); await page.route('http://localhost:3000/**', (r) => r.fulfill({ status: 302, headers: { location: r.request().url().replace('http://localhost:3000', base) } })); page.on('pageerror', (e) => problems.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d/.test(m.text())) problems.push('console: ' + m.text()); }); page.on('response', async (r) => { if (r.status() >= 400 && process.env.QY_DEBUG) console.log('   [http ' + r.status() + '] ' + r.request().method() + ' ' + r.url().replace(base, '') + ' ' + (await r.text().catch(() => '')).slice(0, 160)); if (r.status() >= 500) problems.push('HTTP ' + r.status() + ' ' + r.url()); }); return { ctx, page }; };
  const snap = (p, n) => p.screenshot({ path: path.join(shots, n + '.png') });
  const toast = async (p, re) => p.waitForSelector('#toasts .toast', { timeout: 6000 }).then(async () => re.test(await p.locator('#toasts').innerText())).catch(() => false);

  // ---- staff accounts (created server side) ----
  const mod = await H.staff('Mod', 'moderator'); const adm = await H.staff('Admin', 'admin');
  const MODMAIL = mod.email, ADMMAIL = adm.email;

  // ---- seller journey ----
  console.log('Seller journey');
  const S = await mk(); const sp = S.page;
  await sp.goto(base + '/'); await sp.waitForSelector('.hero2');
  ok(!(await sp.locator('#test-banner').isVisible()), 'no top banner is shown');
  ok((await sp.locator('select[aria-label=Country] option').count()) > 190, 'country picker lists all countries');
  await snap(sp, '01-home');
  await sp.goto(base + '/#/register');
  await sp.fill('#displayName', 'Sally Seller'); const sEmail = 'sally' + Date.now() + '@example.test'; await sp.fill('#email', sEmail); await sp.fill('#password', 'correct horse battery 9');
  await sp.selectOption('#country', 'QA'); await sp.check('input[name=acceptTerms]'); await sp.click('button.primary');
  await sp.waitForSelector('text=Sally', { timeout: 8000 }).catch(() => {});
  const u = H.db.get('SELECT id FROM users WHERE email = ?', sEmail); ok(!!u, 'registered via the form');
  H.db.run('UPDATE users SET email_verified_at = ? WHERE id = ?', new Date().toISOString(), u.id); // stands in for clicking the emailed link
  await sp.goto(base + '/#/verify?token=bogus'); await sp.waitForSelector('text=Link not valid'); ok(true, 'bad verification link is handled');
  await sp.reload(); await sp.goto(base + '/#/sell'); await sp.waitForSelector('#shopName');
  await sp.fill('#shopName', 'Sally Gadgets'); await sp.check('input[name=agree]'); await sp.check('input[name=adult]'); await sp.click('form.panel button.primary');
  await sp.waitForSelector('text=Overview', { timeout: 8000 }); ok(/dashboard/.test(sp.url()), 'seller onboarding completes');
  await snap(sp, '02-dashboard');
  await snap(sp, '03-finance');

  // product form
  await sp.goto(base + '/#/dashboard/products/new'); await sp.waitForSelector('#name');
  await sp.fill('#name', 'Brass desk lamp'); await sp.selectOption('#category', { index: 1 }); await sp.fill('#description', 'A heavy brass desk lamp in good working order, small scratch on base.'); await sp.click('text=Save and continue');
  await sp.waitForSelector('#price'); ok(/products\/\d+/.test(sp.url()), 'step 1 saves a draft and updates the URL');
  await sp.fill('#price', '150'); await sp.click('text=Save and continue');
  await sp.waitForSelector('.field-error, #toasts .toast', { timeout: 5000 }); await sp.waitForTimeout(300); const lm = await sp.locator('#toasts, .field-error').allInnerTexts(); ok(/limit|\$100|price/i.test(lm.join(' ')), 'Free plan $100 limit message shown in the UI');
  await sp.fill('#price', '85.50'); await sp.click('text=Save and continue');
  await sp.waitForSelector('text=Main photo'); await snap(sp, '04-photos');
  await sp.setInputFiles('input[type=file] >> nth=0', fx('photo-exif.jpg')); await sp.waitForSelector('.imgs img', { timeout: 8000 }); ok(true, 'main photo uploaded');
  // camera: back and front
  await sp.locator('button:has-text("Take photo with camera")').nth(1).click(); await sp.waitForSelector('video.cam'); await sp.waitForFunction(() => { const v = document.querySelector('video.cam'); return v && v.videoWidth > 0; }, null, { timeout: 8000 }); await snap(sp, '04b-camera');
  await sp.click('text=Front camera'); await sp.waitForFunction(() => { const v = document.querySelector('video.cam'); return v && v.videoWidth > 0; }, null, { timeout: 8000 });
  await sp.click('text=Back camera'); await sp.waitForFunction(() => { const v = document.querySelector('video.cam'); return v && v.videoWidth > 0 && !document.querySelector('.modal .btn.primary').disabled; }, null, { timeout: 8000 });
  await sp.click('text=● Take photo'); await sp.waitForFunction(() => document.querySelectorAll('.imgs img').length >= 2, null, { timeout: 10000 }); ok(true, 'photo taken with the camera (back) and uploaded');
  ok(await sp.evaluate(() => !document.querySelector('.modal')), 'camera dialog closes after the photo');
  await sp.locator('button:has-text("Take photo with camera")').nth(1).click(); await sp.waitForSelector('video.cam'); await sp.click('text=Front camera'); await sp.waitForFunction(() => { const v = document.querySelector('video.cam'); return v && v.videoWidth > 0 && !document.querySelector('.modal .btn.primary').disabled; }, null, { timeout: 8000 }); await sp.click('text=● Take photo'); await sp.waitForFunction(() => document.querySelectorAll('.imgs img').length >= 3, null, { timeout: 10000 }); ok(true, 'photo taken with the front camera and uploaded');
  await sp.click('text=Continue →'); await sp.waitForSelector('text=Get my verification code'); await sp.click('text=Get my verification code'); await sp.waitForTimeout(1200); await snap(sp, 'dbg-code'); await sp.waitForSelector('.code');
  const code = (await sp.locator('.code').innerText()).trim(); ok(/^QY-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code), 'verification code displayed: ' + code);
  await snap(sp, '05-verification');
  await sp.setInputFiles('input[type=file]', fx('photo2.jpg')); await sp.waitForSelector('.imgs img', { timeout: 8000 });
  await sp.click('text=Continue →'); await sp.waitForSelector('text=Submit for review'); await snap(sp, '06-preview');
  await sp.click('button:has-text("Submit for review")'); await sp.waitForSelector('text=Listings', { timeout: 8000 });
  const prod = H.db.get('SELECT * FROM products WHERE name = ?', 'Brass desk lamp'); ok(prod && prod.status === 'submitted', 'listing submitted for review');
  ok((await new H.Client().get('/api/products/' + prod.id)).status === 404, 'submitted listing is not public');

  // ---- moderator ----
  console.log('Moderator journey');
  const M = await mk(); const mp = M.page;
  await mp.goto(base + '/#/login'); await mp.fill('#email', MODMAIL); await mp.fill('#password', 'correct-horse-battery'); await mp.click('button.primary');
  await mp.waitForSelector('text=Moderation'); await mp.goto(base + '/#/mod'); await mp.waitForSelector('text=Brass desk lamp'); await snap(mp, '07-mod-queue');
  await mp.click('text=Open'); await mp.waitForSelector('text=Verification photo'); await snap(mp, '08-mod-review');
  await mp.click('text=Start review'); await mp.waitForSelector('text=Approve…'); await mp.click('text=Approve…'); await mp.fill('#codeSeen', 'QY-WRNG-CODE'); await mp.click('.modal button.primary');
  await mp.waitForSelector('#toasts .toast, .field-error'); ok(/does not match/i.test(await mp.locator('body').innerText()), 'wrong code is refused in the UI');
  await mp.fill('#codeSeen', code.toLowerCase()); await mp.click('.modal button.primary'); await mp.waitForTimeout(800);
  ok(H.db.get('SELECT status FROM products WHERE id = ?', prod.id).status === 'approved', 'moderator approves with the correct code');
  await mp.goto(base + '/#/admin'); await mp.waitForSelector('text=No access'); ok(true, 'moderator is denied the admin area');

  // ---- buyer ----
  console.log('Buyer journey');
  const B = await mk(); const bp = B.page;
  await bp.goto(base + '/#/register'); const bEmail = 'bob' + Date.now() + '@example.test';
  await bp.fill('#displayName', 'Bob Buyer'); await bp.fill('#email', bEmail); await bp.fill('#password', 'correct horse battery 9'); await bp.selectOption('#country', 'QA'); await bp.check('input[name=acceptTerms]'); await bp.click('button.primary'); await bp.waitForSelector('text=Bob');
  H.db.run('UPDATE users SET email_verified_at = ? WHERE email = ?', new Date().toISOString(), bEmail); await bp.reload();
  await bp.goto(base + '/#/browse'); await bp.waitForSelector('.card h3 a >> text=Brass desk lamp'); await snap(bp, '09-browse');
  ok(await bp.locator('.card .pricetag').first().isVisible(), 'every listing card shows a price tag');
  await bp.click('.card h3 a >> text=Brass desk lamp'); await bp.waitForSelector('text=Listing photos reviewed'); await snap(bp, '10-product');
  await bp.click('button:has-text("Buy this item")'); await bp.waitForSelector('.modal input[name=contact]'); await snap(bp, '12-buy-form');
  await bp.click('.modal button.primary'); await bp.waitForTimeout(500);
  ok(H.db.get('SELECT COUNT(*) AS n FROM purchase_requests').n === 0, 'a request without contact/address/confirmation is not accepted');
  await bp.fill('.modal input[name=contact]', 'bob@gmail.com'); await bp.check('.modal input[value=email]'); await bp.fill('.modal input[name=line1]', '12 West Bay Street'); await bp.fill('.modal input[name=city]', 'Doha'); await bp.check('.modal input[name=confirm]');
  await bp.click('.modal button.primary'); await bp.waitForSelector('.modal textarea', { timeout: 8000 }); await snap(bp, '13-send-email');
  const pr = H.db.get('SELECT * FROM purchase_requests ORDER BY id DESC'); ok(pr && pr.contact_kind === 'email' && pr.address_status === 'unverified', 'purchase request saved with one contact and an unverified address');
  ok((await bp.locator('.modal textarea').inputValue()).includes('how to pay'), 'the email asks how to pay');
  await bp.keyboard.press('Escape');

  // ---- admin ----
  console.log('Admin journey');
  const A = await mk(); const ap = A.page;
  await ap.goto(base + '/#/login'); await ap.fill('#email', ADMMAIL); await ap.fill('#password', 'correct-horse-battery'); await ap.click('button.primary'); await ap.waitForSelector('text=Admin');
  for (const t of ['overview', 'users', 'sellers', 'settings', 'categories', 'finance', 'orders', 'disputes', 'audit', 'errors', 'emails']) {
    await ap.goto(base + '/#/admin/' + t); await ap.waitForSelector('.tabs a[aria-current=page]', { timeout: 6000 }); await ap.waitForTimeout(250);
    const bad = await ap.locator('.errorbox').count(); ok(bad === 0, 'admin tab "' + t + '" renders'); if (t === 'settings' || t === 'finance' || t === 'overview') await snap(ap, '16-admin-' + t);
  }

  // ---- misc pages, mobile ----
  console.log('Other pages + mobile');
  for (const r of ['/#/legal', '/#/legal/terms', '/#/legal/commission', '/#/about', '/#/compare', '/#/wishlist', '/#/nope']) { await bp.goto(base + r); await bp.waitForSelector('main > *'); ok((await bp.locator('.errorbox').count()) === 0, 'page ' + r + ' renders'); }
  const MB = await mk({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }); const mb = MB.page;
  for (const [n, r] of [['home', '/'], ['browse', '/#/browse'], ['product', '/#/p/' + prod.id], ['sell', '/#/sell']]) {
    await mb.goto(base + r); await mb.waitForTimeout(700);
    const over = await mb.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok(over <= 2, 'mobile ' + n + ' has no horizontal scroll (overflow ' + over + 'px)'); await snap(mb, '20-mobile-' + n);
  }
  // ---- v3: owner, crown, email purchases, help bot, admin tools ----
  console.log('Owner, crown, email purchase, assistant');
  const OW = await mk(); const op = OW.page;
  await op.route('**/api/config', async (route) => { const r = await route.fetch(); const j = await r.json(); j.payment.checkoutAvailable = false; j.payment.mode = 'off'; await route.fulfill({ response: r, json: j }); });
  await op.goto(base + '/#/login'); await op.waitForSelector('#email');
  await op.fill('#email', 'owner@example.test'); await op.fill('#password', 'owner-password-for-tests'); await op.click('button.primary');
  await op.waitForSelector('.top .crown', { timeout: 8000 }).catch(() => {});
  ok(await op.locator('.top .crown').count() > 0, 'owner header shows QYRRAVO with a crown');
  ok(await op.locator('.top .mini-avatar').count() > 0, 'owner header shows the logo avatar');
  await op.locator('.top .crown').click(); await op.waitForSelector('.owner-card');
  ok((await op.locator('.owner-card').innerText()).includes('Sajal Dhungana'), 'clicking the crown shows the owner card');
  await op.keyboard.press('Escape');
  ok(!(await op.locator('body').innerText()).toLowerCase().includes('test mode'), 'no "test mode" wording is shown');
  await op.goto(base + '/#/owner'); await op.waitForSelector('.owner-hero'); ok(true, 'owner profile page renders');
  H.db.run("UPDATE products SET quantity = 5, quantity_reserved = 0, status = 'approved', deleted_at = NULL WHERE id = ?", prod.id);
  await op.goto(base + '/#/p/' + prod.id); await op.waitForSelector('h1');
  await op.locator('button', { hasText: 'Buy this item' }).click(); await op.waitForSelector('.modal input[name=contact]');
  await snap(op, '19-buy-form');
  await op.fill('.modal input[name=contact]', '+974 5555 1234'); await op.fill('.modal input[name=line1]', '12 West Bay Street'); await op.fill('.modal input[name=city]', 'Doha'); await op.check('.modal input[name=confirm]');
  await op.locator('.modal button.primary').click(); await op.waitForSelector('.modal textarea');
  ok((await op.locator('.modal').innerText()).includes('qyrravo@gmail.com'), 'Buy collects contact + address, then shows an email to qyrravo@gmail.com');
  ok((await op.locator('.modal a.btn.primary').getAttribute('href')).startsWith('https://mail.google.com/'), 'the email button opens Gmail');
  await snap(op, '20-email-prompt'); await op.keyboard.press('Escape');
  await op.goto(base + '/#/dashboard/plan'); await op.waitForSelector('text=VIP');
  ok((await op.locator('main').innerText()).includes('VIP plan for free'), 'admins see VIP is free');
  await op.locator('#qy-assistant .ai-fab').click(); await op.fill('.ai-form input', 'how do I buy a plan?'); await op.press('.ai-form input', 'Enter');
  await op.waitForFunction(() => document.querySelectorAll('.ai-msg.bot').length >= 2 && !document.querySelector('.ai-msg.bot:last-child').textContent.includes('…'), null, { timeout: 8000 }).catch(() => {});
  ok((await op.locator('.ai-log').innerText()).includes('qyrravo@gmail.com'), 'help bot replies');
  await snap(op, '21-assistant');
  await op.goto(base + '/#/game'); await op.waitForSelector('.gcanvas'); await op.click('.gcar[data-car=royale]'); await op.click('.goverlay .btn.primary'); await op.keyboard.down('w'); await op.waitForTimeout(3500);
  const gm = await op.evaluate(() => { const g = window.__qyGame; return g ? { sp: Math.hypot(g.car.vx, g.car.vz), sid: !!g.sessionId, fin: Number.isFinite(g.car.x + g.car.z + g.car.yaw) } : null; });
  ok((await op.locator('a.qchip[href="#/redeem"]').count()) === 1, 'header shows the Q Coin counter linking to the shop'); ok(await op.evaluate(() => window.__qyGame.carId) === 'royale', 'chosen car is used');
  ok(!!gm && gm.fin, 'car state stays valid at hyper speed'); ok(!!gm && gm.sp > 5, 'driving game: car accelerates (' + (gm && gm.sp.toFixed(1)) + ' m/s)'); await snap(op, '23-game'); await op.keyboard.up('w');
  // staff-only F1 car + flying (the e2e owner is staff)
  const fly = await op.evaluate(async () => { const g = window.__qyGame, w = (ms) => new Promise((r) => setTimeout(r, ms)); const had = g.hasRoyale; window.dispatchEvent(new KeyboardEvent('keydown', { key: 'f' })); await w(1500); const alt = g.car.alt, fl = g.flying; window.dispatchEvent(new KeyboardEvent('keydown', { key: 'f' })); await w(2500); return { had, alt, fl, after: g.flying ? 999 : 0 }; });
  ok(fly.had, 'staff see the hidden F1 car in the garage'); ok(fly.fl && fly.alt > 1 && fly.after < fly.alt, 'staff can fly with F and toggle it off (alt ' + fly.alt.toFixed(1) + ')');
  const lapRes = await op.evaluate(async () => { const g = window.__qyGame, w = (ms) => new Promise((r) => setTimeout(r, ms)); const l0 = g.lapN; g.car.vx = g.car.vz = 0; const hop = async (k) => { const q = g.P[g.cpAt(k)]; g.car.x = q[0]; g.car.z = q[1]; g.car.idx = g.cpAt(k); await w(600); };
    await hop(3); const skipped = g.nextCp; for (let k = 1; k < g.CPN; k++) await hop(k); const afterAll = g.nextCp; await hop(0); return { l0, l1: g.lapN, skipped, afterAll }; });
  ok(lapRes.skipped === 1, 'skipping checkpoints does not count'); ok(lapRes.afterAll === 12 && lapRes.l1 === lapRes.l0 + 1, 'a lap needs every checkpoint in order, then the finish');
  const hyp = await op.evaluate(async () => { const g = window.__qyGame, w = (ms) => new Promise((r) => setTimeout(r, ms)); { const i0 = g.car.idx, A = g.P[i0], B2 = g.P[(i0 + 1) % g.N]; g.car.yaw = Math.atan2(B2[0] - A[0], B2[1] - A[1]); } g.car.vx = 2000 * Math.sin(g.car.yaw); g.car.vz = 2000 * Math.cos(g.car.yaw); g.keys.add('up'); await w(2500); g.keys.delete('up'); return { fin: Number.isFinite(g.car.x + g.car.z), idx: g.car.idx, sp: Math.hypot(g.car.vx, g.car.vz), lat: Math.abs(g.car.z) }; });
  ok(hyp.fin && hyp.sp > 1000 && hyp.lat < 40, 'F1 stays on the straight road at ' + Math.round(hyp.sp * 3.6) + ' km/h (idx ' + hyp.idx + ')');
  for (const t of ['users', 'listings']) { await op.goto(base + '/#/admin/' + t); await op.waitForSelector('main table, main .empty', { timeout: 6000 }).catch(() => {}); ok((await op.locator('.errorbox').count()) === 0, 'admin tab "' + t + '" renders for owner'); }

  // ---- v5: polls, events, wiki ----
  console.log('Polls, events, wiki');
  await op.goto(base + '/#/polls'); await op.waitForSelector('form.panel');
  await op.fill('input[name=question]', 'Which category next?'); await op.fill('textarea[name=options]', 'Books\nSports\nToys'); await op.click('form.panel button.primary'); await op.waitForSelector('.popt.votable');
  await bp.goto(base + '/#/polls'); await bp.waitForSelector('.popt.votable');
  ok((await bp.locator('form.panel').count()) === 0, 'normal users cannot see the create-poll form');
  await bp.locator('.popt.votable').first().click(); await bp.waitForSelector('text=your vote'); ok(true, 'a user can vote and sees the result');
  await snap(bp, '24-poll');
  await op.goto(base + '/#/events'); await op.waitForSelector('form.panel');
  await op.fill('input[name=title]', 'Free headphones'); await op.fill('input[name=prize]', 'JBL headphones'); await op.fill('textarea[name=description]', 'Enter to win a pair of headphones.'); await op.click('form.panel button.primary'); await op.waitForSelector('.event');
  await bp.goto(base + '/#/events'); await bp.waitForSelector('text=Enter giveaway'); await bp.click('text=Enter giveaway'); await bp.waitForSelector('text=You are entered');
  await op.reload(); await op.waitForSelector('text=Draw winner'); op.once('dialog', (d) => d.accept()); await op.click('text=Draw winner'); await op.waitForSelector('text=Winner:');
  ok(true, 'owner drew a giveaway winner'); await snap(op, '25-events');
  await bp.goto(base + '/#/wiki'); await bp.waitForSelector('.wiki-sec'); ok((await bp.locator('body').innerText()).includes('Sajal Dhungana'), 'wiki shows everything about the owner'); await snap(bp, '26-wiki');
  await op.goto(base + '/#/redeem'); await op.waitForSelector('.owner-codes'); await op.fill('input[name=reward]', 'E2E gift'); await op.fill('form:has(input[name=reward]) input[name=dollars]', '3'); await op.click('.owner-codes form:has(input[name=reward]) button.primary');
  await op.waitForSelector('.owner-codes tbody tr'); const rcode = (await op.locator('.owner-codes tbody code').first().innerText()).trim(); await snap(op, '27-redeem-owner');
  await bp.goto(base + '/#/redeem'); await bp.waitForSelector('.wallet'); ok(await bp.locator('.owner-codes').count() === 0, 'buyers do not see the owner code tools');
  await bp.fill('input[name=code]', rcode); await bp.click('.rform button'); await bp.waitForSelector('text=Redeemed code'); ok((await bp.locator('.wbal').innerText()).includes('300'), 'redeeming adds Q Coins to the wallet'); await snap(bp, '28-redeem-wallet');
  await bp.goto(base + '/#/redeem'); await bp.waitForSelector('.pack'); await bp.locator('.pack').first().click(); await bp.waitForSelector('.modal textarea'); await snap(bp, '28b-buy-coins-email'); ok(H.db.get("SELECT COUNT(*) AS n FROM coin_requests WHERE status = 'pending'").n === 1, 'asking to buy Q Coins saves a request'); await bp.reload();
  const bCoins = () => H.db.get('SELECT coins FROM users WHERE email = ?', bEmail).coins; const before = bCoins(); ok(true, 'coins are not added before the owner confirms payment');
  await op.reload(); await op.waitForSelector('text=Coin purchase requests'); op.once('dialog', (dl) => dl.accept()); await op.click('text=Payment received: add coins'); await op.waitForTimeout(700); ok(bCoins() === before + 500, 'owner confirms payment and the coins arrive'); await snap(op, '28c-owner-coin-requests');
  // ---- v8: pay with Q Coins ----
  H.db.run("UPDATE users SET role = 'moderator' WHERE id = ?", prod.seller_id); H.db.run('UPDATE products SET accepts_coins = 1, quantity = 5, quantity_reserved = 0, status = \'approved\', deleted_at = NULL WHERE id = ?', prod.id); const bu = H.db.get('SELECT id FROM users WHERE email = ?', bEmail); H.db.run('UPDATE users SET coins = 100000 WHERE id = ?', bu.id);
  await bp.goto(base + '/#/p/' + prod.id); await bp.waitForSelector('.pricetag.coin'); await snap(bp, '29-product-coins');
  await bp.click('button:has-text("Buy this item")'); await bp.waitForSelector('.paysel'); await bp.check('.paysel input[value=coins]'); await snap(bp, '30-pay-choice');
  await bp.fill('.modal input[name=contact]', 'bob@gmail.com'); await bp.check('.modal input[value=email]'); await bp.fill('.modal input[name=line1]', '12 West Bay Street'); await bp.fill('.modal input[name=city]', 'Doha'); await bp.check('.modal input[name=confirm]');
  await bp.click('.modal button.primary'); await bp.waitForSelector('text=Order placed', { timeout: 8000 });
  const cr = H.db.get("SELECT * FROM purchase_requests WHERE payment_method = 'coins' ORDER BY id DESC"); ok(cr && cr.coins_state === 'held' && H.db.get('SELECT coins FROM users WHERE id = ?', bu.id).coins === 100000 - cr.coins_amount, 'paying with Q Coins holds the coins'); await snap(bp, '31-coin-order');
  await bp.goto(base + '/#/redeem'); await bp.waitForSelector('text=My Q Coins purchases'); await snap(bp, '32-wallet-purchases');

  await browser.close(); await H.shutdown();
  console.log('\n' + steps + ' checks, ' + problems.length + ' problem(s)');
  problems.forEach((p) => console.log(' - ' + p));
  process.exit(problems.length ? 1 : 0);
})().catch(async (e) => { console.error('E2E crashed:', e.message.split('\n').slice(0, 6).join('\n')); problems.forEach((p) => console.log(' - ' + p)); process.exit(2); });
