'use strict';
// Bug crawler: visits every page as different users on desktop + mobile, reports console errors, bad text, overflow, dead links.
process.env.OWNER_EMAIL = 'owner@example.test'; process.env.OWNER_PASSWORD = 'owner-password-for-tests';
const fs = require('fs'); const path = require('path');
const H = require('../test/helpers'); const { chromium } = require('playwright');
const shots = '/tmp/crawl'; fs.mkdirSync(shots, { recursive: true });
const found = [];
(async () => {
  await H.boot(); const base = H.baseUrl();
  const seller = await H.makeSeller('Crawler'); const buyer = await H.register('Buyer');
  const pr = await seller.post('/api/seller/products', H.productBody({ name: 'Crawl lamp' })); const pid = pr.body.product.id;
  H.db.run("UPDATE products SET status='approved', approved_at=? WHERE id=?", new Date().toISOString(), pid);
  await buyer.post('/api/follow/' + seller.user.id);
  const browser = await chromium.launch();
  const who = { anon: null, buyer: [buyer.email, 'correct-horse-battery'], owner: ['owner@example.test', 'owner-password-for-tests'] };
  const routes = ['', 'browse', 'browse?q=lamp', 'p/' + pid, 's/' + seller.user.id, 'redeem', 'compare', 'wishlist', 'cart', 'login', 'register', 'forgot', 'sell', 'game', 'about', 'legal', 'legal/terms', 'legal/privacy', 'legal/commission', 'legal/subscription', 'owner', 'events', 'polls', 'wiki', 'account', 'notifications', 'dashboard', 'dashboard/products', 'dashboard/products/new', 'dashboard/plan', 'mod', 'admin', 'admin/requests', 'admin/users', 'admin/listings', 'admin/settings', 'admin/finance', 'admin/orders', 'nope', 'dashboard/orders'];
  for (const [name, cred] of Object.entries(who).filter(([n]) => !process.env.WHO || n === process.env.WHO)) for (const mobile of [false, true]) {
    const ctx = await browser.newContext(mobile ? { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true } : { viewport: { width: 1280, height: 800 } });
    const page = await ctx.newPage();
    await page.route('http://localhost:3000/**', (r) => r.fulfill({ status: 302, headers: { location: r.request().url().replace('http://localhost:3000', base) } }));
    let cur = '';
    const log = (m) => found.push(`[${name}${mobile ? '/mobile' : ''}] #/${cur}: ${m}`);
    page.on('pageerror', (e) => log('JS error: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d/.test(m.text())) log('console: ' + m.text().slice(0, 150)); });
    page.on('response', (r) => { if (r.status() >= 500) log('HTTP ' + r.status() + ' ' + r.url()); });
    await page.goto(base + '/'); await page.waitForSelector('#top .wrap');
    if (cred) { await page.goto(base + '/#/login'); await page.fill('#email', cred[0]); await page.fill('#password', cred[1]); await page.click('button.primary'); await page.waitForTimeout(800); }
    for (const r of routes) {
      cur = r; await page.goto(base + '/#/' + r); await page.waitForTimeout(450);
      const txt = await page.locator('body').innerText();
      for (const bad of ['undefined', '[object', 'NaN', 'test mode', 'TEST MODE', 'simulator', 'Simulate', 'PLACEHOLDER', 'null']) if (txt.includes(bad)) log('page contains "' + bad + '"');
      const over = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); if (over > 2) log('horizontal overflow ' + over + 'px');
      const err = await page.locator('.errorbox').count(); if (err) log('error box: ' + (await page.locator('.errorbox').first().innerText()).slice(0, 120));
      const broken = await page.evaluate(() => [...document.images].filter((i) => i.complete && i.naturalWidth === 0).map((i) => i.src.slice(-40))); if (broken.length) log('broken images ' + broken.join(','));
      const hrefs = await page.evaluate(() => [...document.querySelectorAll('a[href^="#/"]')].map((a) => a.getAttribute('href').slice(2).split('?')[0]));
      for (const h of new Set(hrefs)) { const ok = /^(|browse|p\/\d+|s\/\d+|redeem|compare|wishlist|cart|login|register|forgot|reset|verify|account|sell|game|dashboard(\/.*)?|mod(\/\d+)?|admin(\/[a-z-]+)?|legal(\/[a-z-]+)?|about|notifications|owner|events|polls|wiki|orders(\/\d+)?)$/.test(h); if (!ok) log('dead link #/' + h); }
      if (!mobile || r === '' || r === 'p/' + pid) await page.screenshot({ path: path.join(shots, `${name}${mobile ? '-m' : ''}-${r.replace(/[^a-z0-9]+/gi, '_') || 'home'}.png`) });
    }
    await ctx.close();
  }
  await browser.close(); await H.shutdown();
  const uniq = [...new Set(found)]; console.log(uniq.join('\n') || 'no problems found'); console.log('\n' + uniq.length + ' findings');
})().catch((e) => { console.error('crawl crashed', e.message); process.exit(2); });
