'use strict';
// Idempotent reference data: roles, permissions, plans, categories, prohibited keywords, pegged FX rates.
// This inserts NO users, NO products, NO orders and NO fake statistics.
const db = require('./db');
const { nowIso } = require('./util');

const ROLES = {
  buyer: 'Registered buyer',
  seller: 'Seller (can list products)',
  moderator: 'Moderator (reviews listings and reports)',
  admin: 'Administrator (full access, separate protected permissions)',
};
const PERMS = {
  'product.review': 'Review submitted listings and photos',
  'report.handle': 'Handle product and seller reports',
  'seller.manage': 'Suspend or restore sellers',
  'user.manage': 'Manage users and roles',
  'settings.manage': 'Change fees, plans, limits, countries and currencies',
  'category.manage': 'Manage categories and prohibited items',
  'finance.view': 'View finance summaries and payment records',
  'refund.issue': 'Issue refunds',
  'payout.manage': 'Create and manage seller payouts',
  'dispute.handle': 'Resolve disputes',
  'audit.view': 'View audit logs and error monitoring',
  'content.manage': 'Create events, giveaways and polls',
  'product.manage': 'Edit or delete any seller listing',
};
const ROLE_PERMS = {
  moderator: ['product.review', 'report.handle'],
  admin: Object.keys(PERMS),
};

const CATEGORIES = [
  ['gaming', 'Gaming', ['Consoles', 'Controllers', 'Headsets', 'PC gaming', 'Games']],
  ['phones', 'Smartphones', ['Phones', 'Cases and covers', 'Chargers', 'Tablets']],
  ['royal', 'Royal & Luxury', ['Watches', 'Jewellery', 'Pens and writing', 'Leather goods']],
  ['budget', 'Cheap Finds', ['Under $25', 'Home basics', 'Everyday items']],
  ['lookalike', 'Looks Expensive, Costs Less', ['Watches', 'Home decor', 'Accessories']],
  ['giftcards', 'Gift Cards', ['Digital gift cards', 'Physical gift cards']],
  ['tech', 'Tech Accessories', ['Chargers', 'Cables', 'Laptop accessories', 'Audio']],
  ['home', 'Home & Desk', ['Lighting', 'Organisers', 'Decor']],
  ['carry', 'Everyday Carry', ['Wallets', 'Bags', 'Tools']],
  ['travel', 'Travel', ['Luggage', 'Packing', 'Travel accessories']],
];

const PROHIBITED = [
  ['firearm', 'Weapons and weapon parts are not allowed.'],
  ['ammunition', 'Weapons and ammunition are not allowed.'],
  ['explosive', 'Explosives are not allowed.'],
  ['narcotic', 'Illegal drugs are not allowed.'],
  ['cocaine', 'Illegal drugs are not allowed.'],
  ['heroin', 'Illegal drugs are not allowed.'],
  ['counterfeit', 'Counterfeit goods are not allowed.'],
  ['fake designer', 'Counterfeit goods are not allowed.'],
  ['stolen', 'Stolen goods are not allowed.'],
  ['alcohol', 'Alcohol cannot be sold on QYRRAVO.'],
  ['pork', 'Pork products cannot be sold on QYRRAVO.'],
  ['gambling', 'Gambling items are not allowed.'],
  ['prescription drug', 'Prescription medicines are not allowed.'],
];

// Currencies that are officially pegged to the US dollar. Rates are labelled as pegs so the UI can say so.
// Verify these against the central bank before relying on them. All other rates come from scripts/fetch-rates.js.
const PEGS = [['QAR', 3.64], ['AED', 3.6725], ['SAR', 3.75]];

function seed() {
  const t = nowIso();
  db.tx(() => {
    for (const [n, d] of Object.entries(ROLES)) db.run('INSERT OR IGNORE INTO roles (name, description) VALUES (?,?)', n, d);
    for (const [n, d] of Object.entries(PERMS)) db.run('INSERT OR IGNORE INTO permissions (name, description) VALUES (?,?)', n, d);
    for (const [r, ps] of Object.entries(ROLE_PERMS)) for (const p of ps) db.run('INSERT OR IGNORE INTO role_permissions (role, permission) VALUES (?,?)', r, p);

    const PLANS = [
      ['free', 'Free Seller', 0, 10000, 1, ['1 item for sale at a time, priced up to $100', 'Every listing passes photo review', 'Seller dashboard']],
      ['premium', 'Premium Seller', 2000, 1000000, 2, ['1 listing at a time with up to 10 identical units in stock, priced up to $10,000', 'Every listing passes photo review', 'Seller dashboard', 'Cancel any time - keeps the plan until the paid period ends']],
      ['vip', 'VIP Seller', 10000, 10000000, 3, ['1 listing at a time with up to 100 identical units in stock, priced up to $100,000', 'Every listing passes photo review', 'Seller dashboard', 'Cancel any time - keeps the plan until the paid period ends']],
    ];
    const QTY = { free: 1, premium: 10, vip: 100 };
    for (const [id, name, price, max, order, feats] of PLANS) {
      db.run('INSERT OR IGNORE INTO plans (id, name, price_minor, currency, max_item_price_usd_minor, features, active, sort, updated_at) VALUES (?,?,?,?,?,?,1,?,?)', id, name, price, 'USD', max, JSON.stringify(feats), order, t);
      db.run('UPDATE plans SET max_quantity = ? WHERE id = ? AND max_quantity = 1 AND ? > 1', QTY[id], id, QTY[id]); // only fixes untouched defaults
    }

    let sort = 0;
    for (const [slug, name, subs] of CATEGORIES) {
      db.run('INSERT OR IGNORE INTO categories (slug, name, parent_id, active, sort) VALUES (?,?,NULL,1,?)', slug, name, sort++);
      const parent = db.get('SELECT id FROM categories WHERE slug = ?', slug).id;
      let ss = 0;
      for (const s of subs) {
        const sslug = slug + '-' + s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
        db.run('INSERT OR IGNORE INTO categories (slug, name, parent_id, active, sort) VALUES (?,?,?,1,?)', sslug, s, parent, ss++);
      }
    }
    for (const [k, r] of PROHIBITED) db.run('INSERT OR IGNORE INTO prohibited_items (keyword, reason, created_at) VALUES (?,?,?)', k, r, t);
    for (const [c, r] of PEGS) db.run('INSERT OR IGNORE INTO fx_rates (currency, rate_per_usd, source, fetched_at) VALUES (?,?,?,?)', c, r, 'peg:official-usd-peg (verify)', t);
  });
}
module.exports = { seed, PERMS };
