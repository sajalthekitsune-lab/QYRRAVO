'use strict';
const config = require('../config');
const db = require('../db');
const settings = require('../settings');
const auth = require('../auth');
const listings = require('../listings');
const subscriptions = require('../subscriptions');
const { api, rateAllowed } = require('../http');
const { sendEmail, notify } = require('../notify');
const { audit } = require('../audit');
const { noImpersonation, HttpError, bad, conflict, notFound, text, int, isEmail, nowIso, addMs, randomToken, safeEqual } = require('../util');

const DUMMY_HASH = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$' + Buffer.alloc(64).toString('base64');

function publicUser(u) { return { id: u.id, email: u.email, displayName: u.displayName, role: u.role, isOwner: !!u.isOwner, country: u.country, emailVerified: u.emailVerified }; }

function sendVerification(userId, email, name) {
  const token = auth.createAuthToken(userId, 'verify_email', 48 * 3600e3);
  sendEmail(userId, email, '[QYRRAVO] Verify your email address', 'Hi ' + name + ',\n\nPlease confirm your email address to finish setting up your QYRRAVO account:\n\n' + config.appUrl + '/#/verify?token=' + token + '\n\nThis link works for 48 hours. If you did not create an account, ignore this email.', 'verify_email');
}

api.post('/api/auth/register', { rate: 'auth' }, async (ctx) => {
  const b = ctx.body;
  if (!rateAllowed('reg:' + ctx.ip, 10, 3600e3)) throw new HttpError(429, 'rate_limited', 'Too many sign-ups from this network. Try again later.');
  const email = text(b.email, { min: 3, max: 254, field: 'Email' }).toLowerCase();
  if (!isEmail(email)) throw bad('validation', 'Enter a valid email address.', { field: 'email' });
  auth.checkPassword(b.password, email);
  const displayName = noImpersonation(text(b.displayName, { min: 2, max: 60, field: 'Name' }));
  const country = String(b.country || '').toUpperCase();
  if (!settings.get('enabled_countries').includes(country)) throw bad('validation', 'Choose your country.', { field: 'country' });
  if (b.acceptTerms !== true) throw bad('validation', 'You must accept the Terms of Service and Privacy Policy.', { field: 'acceptTerms' });
  if (db.get('SELECT 1 AS x FROM users WHERE email = ?', email)) throw conflict('email_taken', 'An account with this email already exists. Try signing in.');
  const hash = await auth.hashPassword(b.password);
  const t = nowIso();
  const id = db.run("INSERT INTO users (email, password_hash, display_name, role, country, terms_accepted_at, created_at, updated_at) VALUES (?,?,?, 'buyer', ?, ?, ?, ?)", email, hash, displayName, country, t, t, t).id;
  sendVerification(id, email, displayName);
  const s = auth.createSession(id, ctx.ip, ctx.req.headers['user-agent']);
  ctx.setCookie('qy_sid', s.token, { maxAgeSec: config.sessionDays * 86400 });
  audit({ id, role: 'buyer' }, 'user.registered', 'user', id, null, ctx.ip);
  return { user: { id, email, displayName, role: 'buyer', country, emailVerified: false }, csrfToken: s.csrf, message: config.emailProvider === 'none' ? 'Account created. To get verified, email ' + config.supportEmail + ' from this address and the owner will verify you.' : 'Account created. Check your email to verify your address.' };
});

api.post('/api/auth/login', { rate: 'auth' }, async (ctx) => {
  const email = String(ctx.body.email || '').trim().toLowerCase();
  const password = String(ctx.body.password || '');
  if (!rateAllowed('login:' + email, 20, 15 * 60e3)) throw new HttpError(429, 'rate_limited', 'Too many sign-in attempts. Please wait a few minutes.');
  const u = db.get('SELECT * FROM users WHERE email = ?', email);
  const ok = await auth.verifyPassword(password, u ? u.password_hash : DUMMY_HASH); // same cost whether or not the user exists
  const fail = () => new HttpError(401, 'invalid_credentials', 'Invalid email or password.');
  if (!u || !ok) {
    if (u) {
      const n = u.failed_logins + 1;
      db.run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', n, n >= 12 ? addMs(nowIso(), 15 * 60e3) : u.locked_until, u.id);
    }
    throw fail();
  }
  if (u.locked_until && u.locked_until > nowIso()) throw new HttpError(429, 'account_locked', 'Too many failed attempts. Try again in a few minutes.');
  if (u.status === 'suspended') throw new HttpError(403, 'account_suspended', 'This account has been suspended. Contact ' + config.supportEmail + ' if you think this is a mistake.');
  if (u.status !== 'active') throw fail();
  db.run('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ? WHERE id = ?', nowIso(), u.id);
  const s = auth.createSession(u.id, ctx.ip, ctx.req.headers['user-agent']);
  ctx.setCookie('qy_sid', s.token, { maxAgeSec: config.sessionDays * 86400 });
  return { user: { id: u.id, email: u.email, displayName: u.display_name, role: u.role, isOwner: !!u.is_owner, country: u.country, emailVerified: !!u.email_verified_at }, csrfToken: s.csrf };
});

api.post('/api/auth/logout', (ctx) => {
  const m = /qy_sid=([^;]+)/.exec(ctx.req.headers.cookie || '');
  if (m) auth.destroySession(decodeURIComponent(m[1]));
  ctx.setCookie('qy_sid', '', { clear: true });
  return {};
});

api.get('/api/me', (ctx) => {
  if (!ctx.user) return { user: null };
  const u = ctx.user;
  const sp = db.get('SELECT * FROM seller_profiles WHERE user_id = ?', u.id);
  const unread = db.get('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL', u.id).n;
  return {
    user: { ...publicUser(u), coins: (db.get('SELECT coins FROM users WHERE id = ?', u.id) || { coins: 0 }).coins }, csrfToken: ctx.session.csrf, unreadNotifications: unread,
    permissions: db.all('SELECT permission FROM role_permissions WHERE role = ?', u.role).map((r) => r.permission),
    seller: sp ? { shopName: sp.shop_name, country: sp.country, status: sp.seller_status, payoutStatus: sp.payout_status, plan: listings.limitsFor(u.id).planId } : null,
  };
});

api.post('/api/auth/verify', { rate: 'auth' }, (ctx) => {
  const uid = auth.consumeAuthToken(ctx.body.token, 'verify_email');
  db.run('UPDATE users SET email_verified_at = COALESCE(email_verified_at, ?), updated_at = ? WHERE id = ?', nowIso(), nowIso(), uid);
  audit({ id: uid, role: 'user' }, 'user.email_verified', 'user', uid, null, ctx.ip);
  return { verified: true };
});

api.post('/api/auth/resend-verification', { rate: 'auth', auth: true }, (ctx) => {
  if (ctx.user.emailVerified) return { alreadyVerified: true };
  if (!rateAllowed('resend:' + ctx.user.id, 3, 3600e3)) throw new HttpError(429, 'rate_limited', 'Please wait before requesting another email.');
  sendVerification(ctx.user.id, ctx.user.email, ctx.user.displayName);
  return { sent: true };
});

api.post('/api/auth/forgot', { rate: 'auth' }, (ctx) => {
  const email = String(ctx.body.email || '').trim().toLowerCase();
  if (isEmail(email) && rateAllowed('forgot:' + email, 3, 3600e3)) {
    const u = db.get("SELECT * FROM users WHERE email = ? AND status = 'active'", email);
    if (u) {
      const token = auth.createAuthToken(u.id, 'reset_password', 3600e3);
      sendEmail(u.id, u.email, '[QYRRAVO] Reset your password', 'Use this link to choose a new password (valid for 1 hour):\n\n' + config.appUrl + '/#/reset?token=' + token + '\n\nIf you did not ask for this, you can ignore this email.', 'reset_password');
    }
  }
  // identical response whether or not the account exists (no account enumeration)
  return { message: 'If an account exists for that email, a reset link has been sent.' };
});

api.post('/api/auth/reset', { rate: 'auth' }, async (ctx) => {
  const uid = auth.consumeAuthToken(ctx.body.token, 'reset_password');
  const u = db.get('SELECT * FROM users WHERE id = ?', uid);
  auth.checkPassword(ctx.body.password, u.email);
  db.run('UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = NULL, updated_at = ? WHERE id = ?', await auth.hashPassword(ctx.body.password), nowIso(), uid);
  auth.destroyAllSessions(uid);
  audit({ id: uid, role: u.role }, 'user.password_reset', 'user', uid, null, ctx.ip);
  return { reset: true };
});

api.patch('/api/account', { auth: true }, (ctx) => {
  const sets = []; const vals = [];
  if (ctx.body.displayName !== undefined) { sets.push('display_name = ?'); vals.push(noImpersonation(text(ctx.body.displayName, { min: 2, max: 60, field: 'Name' }), ctx.user)); }
  if (ctx.body.country !== undefined) {
    const c = String(ctx.body.country).toUpperCase();
    if (!settings.get('enabled_countries').includes(c)) throw bad('validation', 'Choose a supported country.', { field: 'country' });
    sets.push('country = ?'); vals.push(c);
  }
  if (!sets.length) throw bad('validation', 'Nothing to update.');
  db.run('UPDATE users SET ' + sets.join(', ') + ', updated_at = ? WHERE id = ?', ...vals, nowIso(), ctx.user.id);
  const u = db.get('SELECT * FROM users WHERE id = ?', ctx.user.id);
  return { user: { id: u.id, email: u.email, displayName: u.display_name, role: u.role, country: u.country, emailVerified: !!u.email_verified_at } };
});

api.post('/api/account/password', { auth: true, rate: 'auth' }, async (ctx) => {
  const u = db.get('SELECT * FROM users WHERE id = ?', ctx.user.id);
  if (!(await auth.verifyPassword(String(ctx.body.current || ''), u.password_hash))) throw new HttpError(403, 'invalid_credentials', 'Your current password is not correct.');
  auth.checkPassword(ctx.body.password, u.email);
  db.run('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', await auth.hashPassword(ctx.body.password), nowIso(), u.id);
  auth.destroyAllSessions(u.id);
  const s = auth.createSession(u.id, ctx.ip, ctx.req.headers['user-agent']);
  ctx.setCookie('qy_sid', s.token, { maxAgeSec: config.sessionDays * 86400 });
  return { changed: true, csrfToken: s.csrf };
});

// Right to erasure (within limits): personal details are anonymised; order/payment records stay as required for accounting and disputes.
api.post('/api/account/delete', { auth: true, rate: 'auth' }, async (ctx) => {
  const u = db.get('SELECT * FROM users WHERE id = ?', ctx.user.id);
  if (u.role === 'admin' || u.role === 'moderator') throw conflict('staff_account', 'Staff accounts must be removed by another administrator.');
  if (!(await auth.verifyPassword(String(ctx.body.password || ''), u.password_hash))) throw new HttpError(403, 'invalid_credentials', 'Your password is not correct.');
  const open = db.get("SELECT COUNT(*) AS n FROM orders WHERE (buyer_id = ? OR seller_id = ?) AND status IN ('pending_payment','paid','shipped','delivered','disputed')", u.id, u.id).n;
  if (open) throw conflict('open_orders', 'You still have open orders. Finish or cancel them first.');
  const owed = db.get("SELECT COALESCE(SUM(earned_net_minor),0) AS s FROM seller_balances WHERE seller_id = ?", u.id).s;
  if (owed > 0) throw conflict('balance_outstanding', 'You still have earnings that have not been paid out. Ask for a payout first.');
  db.tx(() => {
    db.run("UPDATE products SET status = CASE WHEN status = 'approved' THEN 'suspended' ELSE status END, deleted_at = ?, updated_at = ? WHERE seller_id = ?", nowIso(), nowIso(), u.id);
    db.run("UPDATE users SET status = 'deleted', email = ?, display_name = 'Deleted user', password_hash = ?, country = NULL, email_verified_at = NULL, updated_at = ? WHERE id = ?", 'deleted-' + u.id + '@deleted.invalid', 'x', nowIso(), u.id);
    db.run('DELETE FROM sessions WHERE user_id = ?', u.id);
    db.run('DELETE FROM notifications WHERE user_id = ?', u.id);
    db.run('DELETE FROM wishlist WHERE user_id = ?', u.id);
    db.run("UPDATE seller_profiles SET seller_status = 'suspended', bio = NULL, contact_email = NULL, contact_note = NULL WHERE user_id = ?", u.id);
    audit(ctx.user, 'user.deleted', 'user', u.id, null, ctx.ip);
  });
  ctx.setCookie('qy_sid', '', { clear: true });
  return { deleted: true };
});

// ---- notifications ----
api.get('/api/notifications', { auth: true }, (ctx) => {
  const rows = db.all('SELECT id, type, title, body, link, read_at, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50', ctx.user.id);
  return { notifications: rows, unread: db.get('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL', ctx.user.id).n };
});
api.post('/api/notifications/read', { auth: true }, (ctx) => {
  if (ctx.body.all) db.run('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', nowIso(), ctx.user.id);
  else if (Array.isArray(ctx.body.ids)) for (const id of ctx.body.ids.slice(0, 100)) db.run('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL', nowIso(), int(id, { min: 1 }), ctx.user.id);
  return {};
});

// ---- wishlist ----
api.get('/api/wishlist', { auth: true }, (ctx) => {
  const pub = listings.publicWhere('p');
  const rows = db.all(`${listings.SELECT_PUBLIC} JOIN wishlist w ON w.product_id = p.id WHERE w.user_id = ? AND ${pub.sql} ORDER BY w.created_at DESC`, ctx.user.id, ...pub.params);
  return { products: rows.map(listings.toPublic) };
});
api.post('/api/wishlist', { auth: true }, (ctx) => {
  const pid = int(ctx.body.productId, { min: 1, field: 'productId' });
  const pub = listings.publicWhere('p');
  if (!db.get(`SELECT 1 AS x FROM products p WHERE p.id = ? AND ${pub.sql}`, pid, ...pub.params)) throw notFound('That listing is not available.');
  db.run('INSERT OR IGNORE INTO wishlist (user_id, product_id, created_at) VALUES (?,?,?)', ctx.user.id, pid, nowIso());
  return {};
});
api.post('/api/wishlist/merge', { auth: true }, (ctx) => {
  const pub = listings.publicWhere('p');
  for (const raw of (Array.isArray(ctx.body.ids) ? ctx.body.ids : []).slice(0, 100)) {
    const pid = parseInt(raw, 10);
    if (Number.isInteger(pid) && db.get(`SELECT 1 AS x FROM products p WHERE p.id = ? AND ${pub.sql}`, pid, ...pub.params)) db.run('INSERT OR IGNORE INTO wishlist (user_id, product_id, created_at) VALUES (?,?,?)', ctx.user.id, pid, nowIso());
  }
  return {};
});
api.delete('/api/wishlist/:productId', { auth: true }, (ctx) => {
  db.run('DELETE FROM wishlist WHERE user_id = ? AND product_id = ?', ctx.user.id, int(ctx.params.productId, { min: 1 }));
  return {};
});

// ---- reports ----
api.post('/api/reports', { auth: true }, (ctx) => {
  const type = ctx.body.targetType;
  if (!['product', 'seller'].includes(type)) throw bad('validation', 'Unknown report type.', { field: 'targetType' });
  const id = int(ctx.body.targetId, { min: 1, field: 'targetId' });
  const exists = type === 'product' ? db.get('SELECT 1 AS x FROM products WHERE id = ?', id) : db.get('SELECT 1 AS x FROM seller_profiles WHERE user_id = ?', id);
  if (!exists) throw notFound('Nothing to report.');
  if (db.get("SELECT COUNT(*) AS n FROM reports WHERE reporter_id = ? AND created_at > ?", ctx.user.id, addMs(nowIso(), -86400e3)).n >= 20) throw new HttpError(429, 'rate_limited', 'You have sent many reports today. Please wait.');
  db.run('INSERT INTO reports (reporter_id, target_type, target_id, reason, details, created_at) VALUES (?,?,?,?,?,?)', ctx.user.id, type, id,
    text(ctx.body.reason, { min: 3, max: 120, field: 'Reason' }), text(ctx.body.details, { max: 1000, field: 'Details', multiline: true, required: false }) || null, nowIso());
  return { reported: true };
});

module.exports = { publicUser };
