'use strict';
const db = require('../db');
const settings = require('../settings');
const webhooks = require('../payments/webhooks');
const sim = require('../payments/simulate');
const { api } = require('../http');
const { conflict, notFound, int } = require('../util');

// Real provider webhooks arrive here. No cookie/CSRF: authenticity comes ONLY from the provider's signature.
api.post('/api/webhooks/payments', { raw: true, noCsrf: true, noOriginCheck: true, rate: 'webhook', maxBytes: 256 * 1024 }, (ctx) => {
  const r = webhooks.receive(ctx.raw, ctx.req.headers);
  return { received: true, duplicate: !!r.duplicate };
});

// ---------------- TEST-MODE SIMULATOR (404 unless PAYMENT_MODE=test) ----------------
function ownPayment(ctx) {
  sim.assertSimulator();
  const p = db.get('SELECT * FROM payments WHERE id = ? AND user_id = ?', int(ctx.params.id, { min: 1 }), ctx.user.id);
  if (!p) throw notFound('Payment not found.');
  return p;
}
// NOTE: fixed-path routes must be registered before the '/:id' routes or ':id' would swallow them.
api.post('/api/test-pay/onboarding/complete', { auth: 'seller' }, (ctx) => {
  sim.assertSimulator();
  if (!db.get('SELECT 1 AS x FROM seller_profiles WHERE user_id = ?', ctx.user.id)) throw notFound('No seller profile.');
  return { result: sim.emit('seller.onboarding', { seller_id: ctx.user.id, status: ctx.body.outcome === 'rejected' ? 'rejected' : 'verified', account_ref: 'test_acct_' + ctx.user.id }) };
});
api.get('/api/test-pay/:id', { auth: true }, (ctx) => {
  const p = ownPayment(ctx);
  return { simulator: true, payment: { id: p.id, kind: p.kind, status: p.status, amountMinor: p.amount_minor, currency: p.currency } };
});
api.post('/api/test-pay/:id/complete', { auth: true }, (ctx) => {
  const p = ownPayment(ctx);
  if (p.status !== 'pending') throw conflict('not_pending', 'This payment is already ' + p.status + '.');
  const ok = ctx.body.outcome !== 'failed';
  const r = sim.emit(ok ? 'payment.succeeded' : 'payment.failed', ok
    ? { payment_id: p.id, amount_minor: p.amount_minor, currency: p.currency, provider_payment_ref: p.provider_payment_ref }
    : { payment_id: p.id, reason: 'Declined in simulator' });
  return { result: r, note: 'TEST MODE: no real money moved. The result went through the signed-webhook path.' };
});
api.post('/api/test-pay/subscription/renew', { auth: 'seller' }, (ctx) => {
  sim.assertSimulator();
  const sub = db.get('SELECT * FROM subscriptions WHERE user_id = ?', ctx.user.id);
  const plan = sub && settings.getPlan(sub.plan_id);
  if (!sub || !plan || plan.id === 'free') throw conflict('no_subscription', 'Start a paid plan first.');
  const failed = ctx.body.outcome === 'failed';
  return { result: sim.emit(failed ? 'subscription.payment_failed' : 'subscription.renewed', { subscription_id: sub.id, amount_minor: plan.price_minor, currency: plan.currency, provider_payment_ref: 'test_renew_' + Date.now() + '_' + sub.id }) };
});

module.exports = {};
