'use strict';
// Purchase requests: a buyer asks to buy items. We keep ONE contact (phone OR email) and a delivery address,
// and staff mark the address verified after contacting the buyer.
const db = require('../db');
const settings = require('../settings');
const money = require('../money');
const listings = require('../listings');
const { api } = require('../http');
const { audit } = require('../audit');
const { notify } = require('../notify');
const { bad, text, int, oneOf, isEmail, nowIso, notFound, conflict, forbidden } = require('../util');

api.post('/api/purchase-requests', { auth: true }, (ctx) => {
  const b = ctx.body;
  const kind = oneOf(b.contactKind, ['phone', 'email'], 'contact type');
  let value = String(b.contactValue || '').trim();
  if (kind === 'email') { value = value.toLowerCase(); if (!isEmail(value)) throw bad('validation', 'Enter a valid email address.', { field: 'contactValue' }); }
  else if (!/^\+?[0-9][0-9 ()-]{5,19}$/.test(value)) throw bad('validation', 'Enter a valid phone number with country code, e.g. +974 5xxx xxxx.', { field: 'contactValue' });
  if (b.confirmAddress !== true) throw bad('validation', 'Please confirm that the address is correct.', { field: 'confirmAddress' });
  const name = text(b.name, { min: 2, max: 80, field: 'Full name' });
  const line1 = text(b.line1, { min: 5, max: 120, field: 'Address' });
  const line2 = text(b.line2, { max: 120, field: 'Address line 2', required: false });
  const city = text(b.city, { min: 2, max: 80, field: 'City' });
  const region = text(b.region, { max: 80, field: 'Region', required: false });
  const postal = text(b.postal, { max: 20, field: 'Postal code', required: false });
  const country = oneOf(String(b.country || '').toUpperCase(), settings.COUNTRIES.map((c) => c.code), 'country');
  const items = Array.isArray(b.items) ? b.items.slice(0, 20) : [];
  if (!items.length) throw bad('validation', 'Nothing to buy.');
  const method = oneOf(b.paymentMethod || 'cash', ['cash', 'coins'], 'payment method');
  const pw = listings.publicWhere('p');
  const sellerIds = new Set(); let coins = 0;
  const lines = items.map((i) => {
    const id = int(i.productId, { min: 1, field: 'item' }); const qty = int(i.quantity || 1, { min: 1, max: 99, field: 'quantity' });
    const p = db.get(`SELECT p.id, p.seller_id, p.name, p.price_minor, p.currency, p.price_usd_minor, p.shipping_fee_minor, p.fx_rate, p.accepts_cash, p.accepts_coins, (SELECT CASE WHEN role IN ('admin','moderator') OR is_owner = 1 THEN 1 ELSE 0 END FROM users WHERE id = p.seller_id) AS seller_staff, sp.shop_name FROM products p LEFT JOIN seller_profiles sp ON sp.user_id = p.seller_id WHERE p.id = ? AND ${pw.sql}`, id, ...pw.params);
    if (!p) throw bad('unavailable', 'One of the items is no longer available.');
    sellerIds.add(p.seller_id);
    if (method === 'cash' && !p.accepts_cash) throw bad('payment', '"' + p.name + '" is paid in Q Coins only. Choose Q Coins to buy it.');
    let extra = '';
    if (method === 'coins') {
      if (!p.accepts_coins || !p.seller_staff) throw bad('payment', '"' + p.name + '" does not accept Q Coins. Pay with cash instead.');
      if (p.seller_id === ctx.user.id) throw bad('own_item', 'You cannot buy your own item.');
      const ship = p.shipping_fee_minor ? money.toUsdMinor(p.shipping_fee_minor, p.currency, p.fx_rate || 1) : 0; // 1 cent = 1 Q Coin
      const c = p.price_usd_minor * qty + ship; coins += c; extra = ' = ' + c + ' Q Coins' + (ship ? ' (incl. ' + ship + ' shipping)' : '');
    }
    return '#' + p.id + ' ' + p.name + ' x ' + qty + ' - ' + (method === 'cash' ? money.format(p.price_minor * qty, p.currency) : extra.slice(3)) + ' (seller: ' + p.shop_name + ')';
  });
  if (method === 'coins' && sellerIds.size !== 1) throw bad('one_seller', 'Pay with Q Coins for one seller at a time.');
  const sellerId = [...sellerIds][0];
  const summary = lines.join('\n') + (method === 'coins' ? '\nPAID WITH Q COINS: ' + coins + ' (held until delivery is confirmed)' : '');
  const r = db.tx(() => {
    if (method === 'coins') {
      const hold = db.run('UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?', coins, ctx.user.id, coins);
      if (!hold.changes) throw conflict('insufficient', 'You need ' + coins + ' Q Coins but you have ' + db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id).coins + '. Redeem a code to get more.');
    }
    const ins = db.run('INSERT INTO purchase_requests (buyer_id, summary, contact_kind, contact_value, name, line1, line2, city, region, postal, country, created_at, payment_method, coins_amount, coins_state, seller_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', ctx.user.id, summary, kind, value, name, line1, line2 || null, city, region || null, postal || null, country, nowIso(), method, method === 'coins' ? coins : 0, method === 'coins' ? 'held' : 'none', sellerId);
    if (method === 'coins') db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', ctx.user.id, -coins, 'Held for purchase #' + ins.id, nowIso());
    return ins;
  });
  if (method === 'coins') notify(sellerId, 'order', 'New Q Coins order', 'Someone bought from you with Q Coins (request #' + r.id + '). QYRRAVO will verify the address and tell you when to send it. You are paid when delivery is confirmed.', '/dashboard');
  audit(ctx.user, 'purchase_request.created', 'purchase_request', r.id, null, ctx.ip);
  return { id: r.id, summary, paymentMethod: method, coins };
});

const STATE_TEXT = { held: 'Coins held until delivery', released: 'Paid to seller', refunded: 'Refunded to you', none: '' };
api.get('/api/purchase-requests/mine', { auth: true }, (ctx) => ({
  requests: db.all("SELECT * FROM purchase_requests WHERE buyer_id = ? AND payment_method = 'coins' ORDER BY id DESC LIMIT 50", ctx.user.id).map((r) => ({
    id: r.id, summary: r.summary, coins: r.coins_amount, state: r.coins_state, stateText: STATE_TEXT[r.coins_state], addressStatus: r.address_status, createdAt: r.created_at,
    canCancel: r.coins_state === 'held' && r.address_status !== 'verified' })),
}));
api.post('/api/purchase-requests/:id/cancel', { auth: true }, (ctx) => {
  const r = db.get('SELECT * FROM purchase_requests WHERE id = ? AND buyer_id = ?', int(ctx.params.id, { min: 1 }), ctx.user.id);
  if (!r) throw notFound('Request not found.');
  if (r.address_status === 'verified') throw conflict('too_late', 'The address was already verified. Email qyrravo@gmail.com to cancel this order.');
  if (!refund(r, 'You cancelled purchase #' + r.id)) throw conflict('state', 'This order has no coins on hold.');
  audit(ctx.user, 'purchase_request.cancelled', 'purchase_request', r.id, null, ctx.ip);
  return {};
});
// returns true if coins were refunded (exactly once)
function refund(r, reason) {
  return db.tx(() => {
    const m = db.run("UPDATE purchase_requests SET coins_state = 'refunded', status = 'handled' WHERE id = ? AND coins_state = 'held'", r.id);
    if (!m.changes) return false;
    db.run('UPDATE users SET coins = coins + ? WHERE id = ?', r.coins_amount, r.buyer_id);
    db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', r.buyer_id, r.coins_amount, 'Refund: ' + reason, nowIso());
    return true;
  });
}
function release(r) {
  return db.tx(() => {
    const m = db.run("UPDATE purchase_requests SET coins_state = 'released', status = 'handled' WHERE id = ? AND coins_state = 'held'", r.id);
    if (!m.changes) return false;
    db.run('UPDATE users SET coins = coins + ? WHERE id = ?', r.coins_amount, r.seller_id);
    db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', r.seller_id, r.coins_amount, 'Sale: purchase #' + r.id, nowIso());
    return true;
  });
}

const PERM = 'user.manage';
api.get('/api/admin/purchase-requests', { auth: PERM }, () => ({
  requests: db.all('SELECT r.*, u.email AS buyer_email FROM purchase_requests r JOIN users u ON u.id = r.buyer_id ORDER BY (r.status = \'new\') DESC, r.id DESC LIMIT 300').map((r) => ({
    id: r.id, buyerEmail: r.buyer_email, summary: r.summary, contactKind: r.contact_kind, contactValue: r.contact_value, name: r.name,
    address: [r.line1, r.line2, r.city, r.region, r.postal, r.country].filter(Boolean).join(', '), addressStatus: r.address_status, status: r.status, createdAt: r.created_at, paymentMethod: r.payment_method, coins: r.coins_amount, coinsState: r.coins_state })),
}));
api.post('/api/admin/purchase-requests/:id', { auth: PERM }, (ctx) => {
  const r = db.get('SELECT * FROM purchase_requests WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!r) throw notFound('Request not found.');
  if (ctx.body.addressStatus !== undefined) db.run('UPDATE purchase_requests SET address_status = ? WHERE id = ?', oneOf(ctx.body.addressStatus, ['unverified', 'verified', 'rejected'], 'addressStatus'), r.id);
  if (ctx.body.status !== undefined) db.run('UPDATE purchase_requests SET status = ? WHERE id = ?', oneOf(ctx.body.status, ['new', 'handled'], 'status'), r.id);
  if (ctx.body.coinsAction !== undefined) {
    const act = oneOf(ctx.body.coinsAction, ['release', 'refund'], 'action');
    if (r.coins_state !== 'held') throw conflict('state', 'This order has no coins on hold.');
    if (act === 'release') {
      if (r.address_status !== 'verified') throw conflict('address', 'Verify the buyer\'s address before paying the seller.');
      if (!release(r)) throw conflict('state', 'Already processed.');
      notify(r.seller_id, 'order', 'You were paid ' + r.coins_amount + ' Q Coins', 'Delivery of purchase #' + r.id + ' was confirmed. The coins are in your wallet.', '/redeem');
      notify(r.buyer_id, 'order', 'Purchase #' + r.id + ' completed', 'Delivery was confirmed and the seller was paid ' + r.coins_amount + ' Q Coins.', '/redeem');
    } else {
      if (!refund(r, 'purchase #' + r.id + ' was cancelled by QYRRAVO')) throw conflict('state', 'Already processed.');
      notify(r.buyer_id, 'order', 'Q Coins refunded', 'Purchase #' + r.id + ' was cancelled. ' + r.coins_amount + ' Q Coins are back in your wallet.', '/redeem');
    }
  }
  audit(ctx.user, 'purchase_request.updated', 'purchase_request', r.id, ctx.body, ctx.ip);
  return {};
});
