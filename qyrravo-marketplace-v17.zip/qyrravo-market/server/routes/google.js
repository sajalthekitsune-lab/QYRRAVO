'use strict';
// "Continue with Google" (OAuth 2.0 authorization-code flow). Needs GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env.
// Google has already verified the email address, so Google sign-ins are marked verified.
const crypto = require('crypto');
const config = require('../config');
const db = require('../db');
const auth = require('../auth');
const { api } = require('../http');
const { audit } = require('../audit');
const { noImpersonation, nowIso, HttpError } = require('../util');

const redirectUri = () => config.appUrl + '/api/auth/google/callback';
const back = (ctx, hash) => { ctx.res.statusCode = 302; ctx.res.setHeader('Location', config.appUrl + '/#/' + hash); ctx.res.end(); return { __handled: true }; };

api.get('/api/auth/google', { rate: 'auth' }, (ctx) => {
  if (!config.googleClientId) throw new HttpError(404, 'not_configured', 'Google sign-in is not set up yet.');
  const state = crypto.randomBytes(16).toString('hex');
  ctx.setCookie('qy_gstate', state, { maxAgeSec: 600 });
  const q = new URLSearchParams({ client_id: config.googleClientId, redirect_uri: redirectUri(), response_type: 'code', scope: 'openid email profile', state, prompt: 'select_account' });
  ctx.res.statusCode = 302; ctx.res.setHeader('Location', 'https://accounts.google.com/o/oauth2/v2/auth?' + q); ctx.res.end();
  return { __handled: true };
});

api.get('/api/auth/google/callback', { rate: 'auth' }, async (ctx) => {
  const cookie = String(ctx.req.headers.cookie || '').split(/;\s*/).find((c) => c.startsWith('qy_gstate='));
  const state = cookie ? cookie.slice(10) : '';
  if (!ctx.query.code || !state || state !== ctx.query.state) return back(ctx, 'login?error=google');
  let info;
  try {
    const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code: ctx.query.code, client_id: config.googleClientId, client_secret: config.googleClientSecret, redirect_uri: redirectUri(), grant_type: 'authorization_code' }) });
    const j = await r.json();
    if (!r.ok || !j.id_token) throw new Error('token');
    info = JSON.parse(Buffer.from(j.id_token.split('.')[1], 'base64url').toString()); // received directly from Google over TLS
    if (info.aud !== config.googleClientId || !['accounts.google.com', 'https://accounts.google.com'].includes(info.iss) || !info.email_verified || !info.email) throw new Error('claims');
  } catch (e) { return back(ctx, 'login?error=google'); }
  const email = String(info.email).toLowerCase(); const t = nowIso();
  let u = db.get('SELECT * FROM users WHERE email = ?', email);
  if (u && u.status !== 'active') return back(ctx, 'login?error=suspended');
  if (!u) {
    let name = String(info.name || email.split('@')[0]).slice(0, 60); try { name = noImpersonation(name); } catch { name = email.split('@')[0].slice(0, 40); }
    const id = db.run("INSERT INTO users (email, password_hash, display_name, role, country, status, email_verified_at, terms_accepted_at, created_at, updated_at) VALUES (?,?,?, 'buyer', NULL, 'active', ?, ?, ?, ?)", email, 'google', name, t, t, t, t).id;
    u = db.get('SELECT * FROM users WHERE id = ?', id); audit({ id, role: 'buyer' }, 'user.registered_google', 'user', id, null, ctx.ip);
  } else db.run('UPDATE users SET email_verified_at = COALESCE(email_verified_at, ?), last_login_at = ? WHERE id = ?', t, t, u.id);
  const s = auth.createSession(u.id, ctx.ip, ctx.req.headers['user-agent']);
  ctx.setCookie('qy_sid', s.token, { maxAgeSec: config.sessionDays * 86400 });
  ctx.setCookie('qy_gstate', '', { clear: true });
  return back(ctx, '');
});
