'use strict';
// Events (giveaways) and polls. Only staff with content.manage can create; everyone can read; signed-in users enter/vote once.
const crypto = require('crypto');
const db = require('../db');
const { api } = require('../http');
const { audit } = require('../audit');
const { notifyUser } = require('../notify');
const { createCode, dollarsToCents } = require('./redeem');
const { bad, forbidden, conflict, notFound, text, int, nowIso, addDays } = require('../util');

const days = (v) => int(v === undefined ? 7 : v, { min: 1, max: 90, field: 'Days' });

// ---------- events ----------
function eventView(e, me) {
  const n = db.get('SELECT COUNT(*) AS n FROM event_entries WHERE event_id = ?', e.id).n;
  const w = e.winner_id ? db.get('SELECT display_name FROM users WHERE id = ?', e.winner_id) : null;
  const status = e.drawn_at ? 'drawn' : (e.ends_at <= nowIso() ? 'ended' : 'open');
  return { id: e.id, title: e.title, description: e.description, prize: e.prize, endsAt: e.ends_at, status, entries: n, winner: w ? w.display_name : null, winnerIsMe: !!(me && e.winner_id === me.id), entered: !!(me && db.get('SELECT 1 AS x FROM event_entries WHERE event_id = ? AND user_id = ?', e.id, me.id)) };
}
api.get('/api/events', (ctx) => ({ events: db.all('SELECT * FROM events WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 50').map((e) => eventView(e, ctx.user)) }));
api.post('/api/events/:id/enter', { auth: true }, (ctx) => {
  const e = db.get('SELECT * FROM events WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
  if (!e) throw notFound('Event not found.');
  if (e.drawn_at || e.ends_at <= nowIso()) throw conflict('closed', 'This event has ended.');
  db.run('INSERT OR IGNORE INTO event_entries (event_id, user_id, created_at) VALUES (?,?,?)', e.id, ctx.user.id, nowIso());
  return eventView(e, ctx.user);
});
api.post('/api/admin/events', { auth: 'content.manage' }, (ctx) => {
  const b = ctx.body;
  const title = text(b.title, { min: 3, max: 100, field: 'Title' }), description = text(b.description, { min: 5, max: 1000, field: 'Description', multiline: true }), prize = text(b.prize, { min: 2, max: 150, field: 'Free item (prize)' });
  let codeCents = null, codeReward = null;
  if (b.codeDollars !== undefined && b.codeDollars !== '' && b.codeDollars !== null) {
    if (!ctx.user.isOwner) throw forbidden('Only the owner can attach a prize code.');
    codeCents = dollarsToCents(b.codeDollars); codeReward = text(b.codeReward || prize, { min: 2, max: 150, field: 'Code reward' });
  }
  const r = db.run('INSERT INTO events (title, description, prize, ends_at, created_by, created_at, prize_code_cents, prize_code_reward) VALUES (?,?,?,?,?,?,?,?)', title, description, prize, addDays(nowIso(), days(b.days)), ctx.user.id, nowIso(), codeCents, codeReward);
  audit(ctx.user, 'event.created', 'event', r.id, { title, prize }, ctx.ip);
  return { id: r.id };
});
api.post('/api/admin/events/:id/draw', { auth: 'content.manage' }, (ctx) => {
  const e = db.get('SELECT * FROM events WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
  if (!e) throw notFound('Event not found.');
  if (e.drawn_at) throw conflict('done', 'A winner was already drawn.');
  const entries = db.all("SELECT en.user_id FROM event_entries en JOIN users u ON u.id = en.user_id WHERE en.event_id = ? AND u.status = 'active'", e.id);
  if (!entries.length) throw conflict('no_entries', 'Nobody has entered yet.');
  const win = entries[crypto.randomInt(entries.length)].user_id; // fair random draw
  db.run('UPDATE events SET winner_id = ?, drawn_at = ? WHERE id = ?', win, nowIso(), e.id);
  audit(ctx.user, 'event.drawn', 'event', e.id, { winner: win }, ctx.ip);
  let extra = '';
  if (e.prize_code_cents) { const c = createCode({ reward: e.prize_code_reward || e.prize, cents: e.prize_code_cents, assignedUserId: win, eventId: e.id, by: ctx.user.id }); extra = ' Your prize code is ' + c.code + '. Redeem it on the Redeem page. It works only for your account.'; }
  notifyUser(win, 'event', 'You won: ' + e.prize + '!', 'You won the QYRRAVO giveaway "' + e.title + '".' + (extra || ' Email qyrravo@gmail.com to claim your prize.'), extra ? '/redeem' : '/events');
  return eventView(db.get('SELECT * FROM events WHERE id = ?', e.id), ctx.user);
});
api.delete('/api/admin/events/:id', { auth: 'content.manage' }, (ctx) => { db.run('UPDATE events SET deleted_at = ? WHERE id = ?', nowIso(), int(ctx.params.id, { min: 1 })); audit(ctx.user, 'event.deleted', 'event', ctx.params.id, null, ctx.ip); return {}; });

// ---------- polls ----------
function pollView(p, me) {
  const opts = db.all('SELECT o.id, o.label, (SELECT COUNT(*) FROM poll_votes v WHERE v.option_id = o.id) AS votes FROM poll_options o WHERE o.poll_id = ? ORDER BY o.position', p.id);
  const total = opts.reduce((a, o) => a + o.votes, 0); const closed = !!p.closed_at || p.ends_at <= nowIso();
  const top = Math.max(0, ...opts.map((o) => o.votes));
  const mine = me ? db.get('SELECT option_id FROM poll_votes WHERE poll_id = ? AND user_id = ?', p.id, me.id) : null;
  return { id: p.id, question: p.question, endsAt: p.ends_at, closed, total, myVote: mine ? mine.option_id : null,
    options: opts.map((o) => ({ id: o.id, label: o.label, votes: o.votes, percent: total ? Math.round((o.votes / total) * 100) : 0, winner: closed && top > 0 && o.votes === top })) };
}
api.get('/api/polls', (ctx) => ({ polls: db.all('SELECT * FROM polls WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 50').map((p) => pollView(p, ctx.user)) }));
api.post('/api/polls/:id/vote', { auth: true }, (ctx) => {
  const p = db.get('SELECT * FROM polls WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
  if (!p) throw notFound('Poll not found.');
  if (p.closed_at || p.ends_at <= nowIso()) throw conflict('closed', 'This poll is closed.');
  const o = db.get('SELECT id FROM poll_options WHERE id = ? AND poll_id = ?', int(ctx.body.optionId, { min: 1, field: 'option' }), p.id);
  if (!o) throw bad('validation', 'Choose one of the options.');
  if (db.get('SELECT 1 AS x FROM poll_votes WHERE poll_id = ? AND user_id = ?', p.id, ctx.user.id)) throw conflict('voted', 'You already voted in this poll.');
  db.run('INSERT INTO poll_votes (poll_id, user_id, option_id, created_at) VALUES (?,?,?,?)', p.id, ctx.user.id, o.id, nowIso());
  return pollView(p, ctx.user);
});
api.post('/api/admin/polls', { auth: 'content.manage' }, (ctx) => {
  const question = text(ctx.body.question, { min: 5, max: 200, field: 'Question' });
  const labels = (Array.isArray(ctx.body.options) ? ctx.body.options : []).map((x) => String(x).trim()).filter(Boolean);
  if (labels.length < 2 || labels.length > 10) throw bad('validation', 'Give between 2 and 10 options.', { field: 'options' });
  if (new Set(labels.map((l) => l.toLowerCase())).size !== labels.length) throw bad('validation', 'Options must be different.', { field: 'options' });
  if (labels.some((l) => l.length > 80)) throw bad('validation', 'Options must be at most 80 characters.', { field: 'options' });
  const id = db.tx(() => { const r = db.run('INSERT INTO polls (question, ends_at, created_by, created_at) VALUES (?,?,?,?)', question, addDays(nowIso(), days(ctx.body.days)), ctx.user.id, nowIso()); labels.forEach((l, i) => db.run('INSERT INTO poll_options (poll_id, label, position) VALUES (?,?,?)', r.id, l, i)); return r.id; });
  audit(ctx.user, 'poll.created', 'poll', id, { question }, ctx.ip);
  return { id };
});
api.post('/api/admin/polls/:id/close', { auth: 'content.manage' }, (ctx) => { db.run('UPDATE polls SET closed_at = COALESCE(closed_at, ?) WHERE id = ?', nowIso(), int(ctx.params.id, { min: 1 })); return {}; });
api.delete('/api/admin/polls/:id', { auth: 'content.manage' }, (ctx) => { db.run('UPDATE polls SET deleted_at = ? WHERE id = ?', nowIso(), int(ctx.params.id, { min: 1 })); audit(ctx.user, 'poll.deleted', 'poll', ctx.params.id, null, ctx.ip); return {}; });
