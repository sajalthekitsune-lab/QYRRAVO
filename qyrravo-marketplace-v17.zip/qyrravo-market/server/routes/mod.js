'use strict';
const db = require('../db');
const listings = require('../listings');
const { api } = require('../http');
const { audit } = require('../audit');
const { notifyUser } = require('../notify');
const { bad, conflict, forbidden, notFound, text, int, oneOf, nowIso, parseJson } = require('../util');
const { normCode } = require('./seller');

const REVIEWABLE = ['submitted', 'under_review'];

function qrow(p) {
  const sp = db.get('SELECT shop_name, country FROM seller_profiles WHERE user_id = ?', p.seller_id);
  const main = db.get("SELECT id FROM product_images WHERE product_id = ? AND kind = 'main' ORDER BY id LIMIT 1", p.id);
  return { id: p.id, name: p.name, status: p.status, flagged: !!p.flagged, flagReason: p.flag_reason, priceMinor: p.price_minor, currency: p.currency, priceUsdMinor: p.price_usd_minor, sellerId: p.seller_id, shopName: sp && sp.shop_name, submittedAt: p.submitted_at, mainImage: main ? '/media/' + main.id : null };
}

api.get('/api/mod/queue', { auth: 'product.review' }, (ctx) => {
  const st = String(ctx.query.status || 'submitted,under_review').split(',').filter((s) => ['submitted', 'under_review', 'more_info_required', 'approved', 'rejected', 'suspended', 'draft'].includes(s));
  if (!st.length) throw bad('validation', 'Unknown status.');
  const flagged = ctx.query.flagged === '1' ? 'AND flagged = 1' : '';
  const rows = db.all(`SELECT * FROM products WHERE status IN (${st.map(() => '?').join(',')}) AND deleted_at IS NULL ${flagged} ORDER BY flagged DESC, submitted_at ASC LIMIT 200`, ...st);
  const counts = Object.fromEntries(db.all("SELECT status, COUNT(*) AS n FROM products WHERE deleted_at IS NULL GROUP BY status").map((r) => [r.status, r.n]));
  return { queue: rows.map(qrow), counts, openReports: db.get("SELECT COUNT(*) AS n FROM reports WHERE status = 'open'").n };
});

api.get('/api/mod/products/:id', { auth: 'product.review' }, (ctx) => {
  const p = db.get('SELECT * FROM products WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!p) throw notFound('Listing not found.');
  const sub = db.get("SELECT * FROM verification_submissions WHERE product_id = ? AND status IN ('submitted','under_review','more_info_required','approved','rejected') ORDER BY id DESC", p.id);
  const sp = db.get('SELECT * FROM seller_profiles WHERE user_id = ?', p.seller_id);
  const imgs = db.all('SELECT id, kind, sha256, width, height, submission_id FROM product_images WHERE product_id = ? ORDER BY id', p.id);
  const dups = [...new Set(imgs.flatMap((i) => db.all('SELECT DISTINCT p2.id FROM product_images i JOIN products p2 ON p2.id = i.product_id WHERE i.sha256 = ? AND p2.id != ? AND p2.deleted_at IS NULL', i.sha256, p.id).map((r) => r.id)))];
  return {
    product: { ...qrow(p), description: p.description, brand: p.brand, model: p.model, condition: p.condition, quantity: p.quantity, sellerCountry: p.seller_country, shipsTo: parseJson(p.ships_to, []), specs: parseJson(p.specs, []), referenceInfo: p.reference_info, returnsType: p.returns_type, categoryId: p.category_id, statusReason: p.status_reason },
    images: imgs.filter((i) => i.kind !== 'verification' || (sub && i.submission_id === sub.id)).map((i) => ({ id: i.id, kind: i.kind, url: '/media/' + i.id, width: i.width, height: i.height })),
    // The expected code is deliberately NOT sent to the browser: the moderator types what they SEE in the photo and the server compares.
    verification: sub ? { status: sub.status, submittedAt: sub.submitted_at, codeExpiresAt: sub.code_expires_at, issuedAt: sub.code_issued_at } : null,
    prohibitedHits: listings.prohibitedHits(p.name, p.description, p.brand, p.model).map((h) => h.keyword),
    duplicateOfProducts: dups,
    seller: sp ? { id: sp.user_id, shopName: sp.shop_name, country: sp.country, status: sp.seller_status, approvedListings: db.get("SELECT COUNT(*) AS n FROM products WHERE seller_id = ? AND status = 'approved' AND deleted_at IS NULL", sp.user_id).n, rejectedListings: db.get("SELECT COUNT(*) AS n FROM products WHERE seller_id = ? AND status = 'rejected'", sp.user_id).n, joinedAt: sp.created_at } : null,
    history: db.all('SELECT d.id, d.decision, d.reason, d.created_at AS createdAt, u.display_name AS moderator FROM verification_decisions d JOIN users u ON u.id = d.moderator_id WHERE d.product_id = ? ORDER BY d.id DESC', p.id),
  };
});

function log(mod, p, sub, decision, reason, codeSeen) {
  db.run('INSERT INTO verification_decisions (submission_id, product_id, moderator_id, decision, reason, code_seen, created_at) VALUES (?,?,?,?,?,?,?)', sub ? sub.id : null, p.id, mod.id, decision, reason || null, codeSeen || null, nowIso());
}

api.post('/api/mod/products/:id/decision', { auth: 'product.review' }, (ctx) => {
  const decision = oneOf(ctx.body.decision, ['start_review', 'approve', 'reject', 'request_more', 'flag', 'unflag', 'suspend'], 'decision');
  const reason = text(ctx.body.reason, { max: 1000, field: 'Reason', multiline: true, required: false });
  const out = db.tx(() => {
    const p = db.get('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
    if (!p) throw notFound('Listing not found.');
    if (p.seller_id === ctx.user.id && !(ctx.user.isOwner || ctx.user.role === 'admin' || ctx.user.role === 'moderator')) throw forbidden('You cannot review your own listing.');   // the owner and staff may review their own listings
    const sub = db.get("SELECT * FROM verification_submissions WHERE product_id = ? AND status IN ('submitted','under_review','more_info_required','approved') ORDER BY id DESC", p.id);
    const t = nowIso();
    const need = (cond, msg, code = 'bad_state') => { if (!cond) throw conflict(code, msg); };
    if (decision === 'start_review') {
      need(['submitted', 'suspended'].includes(p.status), 'Only submitted or suspended listings can enter review.');
      db.run("UPDATE products SET status = 'under_review', status_reason = NULL, updated_at = ? WHERE id = ?", t, p.id);
      if (sub) db.run("UPDATE verification_submissions SET status = 'under_review', reviewer_id = ? WHERE id = ?", ctx.user.id, sub.id);
    } else if (decision === 'approve') {
      need(REVIEWABLE.includes(p.status), 'Only listings that are submitted or under review can be approved.');
      need(sub, 'There is no verification submission for this listing.');
      if (!ctx.body.codeSeen) throw bad('validation', 'Type the verification code you can see in the photo.', { field: 'codeSeen' });
      if (normCode(ctx.body.codeSeen) !== normCode(sub.code)) {
        return { mismatch: { p, sub } }; // logged after this transaction (a throw would roll the log back)
      }
      if (reason.length < 3 && p.flagged) throw bad('validation', 'A flagged listing needs a written reason before approval.', { field: 'reason' });
      if (sub.code_expires_at < (sub.submitted_at || t)) throw conflict('code_expired', 'The code had expired when the photo was submitted. Ask the seller to start again.');
      const hits = listings.prohibitedHits(p.name, p.description, p.brand, p.model);
      if (hits.length && reason.length < 3) throw bad('validation', 'Possible prohibited item (' + hits.map((h) => h.keyword).join(', ') + '). Write a reason explaining why this is allowed.', { field: 'reason' });
      db.run("UPDATE products SET status = 'approved', status_reason = NULL, approved_at = ?, updated_at = ? WHERE id = ?", t, t, p.id);
      db.run("UPDATE verification_submissions SET status = 'approved', reviewer_id = ?, reviewed_at = ? WHERE id = ?", ctx.user.id, t, sub.id);
    } else if (decision === 'reject') {
      need(REVIEWABLE.includes(p.status), 'Only listings that are submitted or under review can be rejected.');
      if (reason.length < 5) throw bad('validation', 'Explain the rejection so the seller can fix it.', { field: 'reason' });
      db.run("UPDATE products SET status = 'rejected', status_reason = ?, updated_at = ? WHERE id = ?", reason, t, p.id);
      if (sub) db.run("UPDATE verification_submissions SET status = 'rejected', reviewer_id = ?, reviewed_at = ? WHERE id = ?", ctx.user.id, t, sub.id);
    } else if (decision === 'request_more') {
      need(REVIEWABLE.includes(p.status), 'Only listings that are submitted or under review can be sent back.');
      if (reason.length < 5) throw bad('validation', 'Tell the seller what extra information or photo you need.', { field: 'reason' });
      db.run("UPDATE products SET status = 'more_info_required', status_reason = ?, updated_at = ? WHERE id = ?", reason, t, p.id);
      if (sub) db.run("UPDATE verification_submissions SET status = 'more_info_required', reviewer_id = ?, reviewed_at = ? WHERE id = ?", ctx.user.id, t, sub.id);
    } else if (decision === 'flag') {
      if (reason.length < 3) throw bad('validation', 'Say why you are flagging this listing.', { field: 'reason' });
      db.run("UPDATE products SET flagged = 1, flag_reason = ?, updated_at = ? WHERE id = ?", reason, t, p.id);
    } else if (decision === 'unflag') {
      db.run('UPDATE products SET flagged = 0, flag_reason = NULL WHERE id = ?', p.id);
    } else if (decision === 'suspend') {
      need(['approved', 'submitted', 'under_review'].includes(p.status), 'Only live or pending listings can be suspended.');
      if (reason.length < 5) throw bad('validation', 'Give a reason for suspending the listing.', { field: 'reason' });
      db.run("UPDATE products SET status = 'suspended', status_reason = ?, updated_at = ? WHERE id = ?", reason, t, p.id);
    }
    log(ctx.user, p, sub, decision, reason, decision === 'approve' ? normCode(ctx.body.codeSeen) : null);
    audit(ctx.user, 'moderation.' + decision, 'product', p.id, { reason }, ctx.ip);
    return { p: db.get('SELECT * FROM products WHERE id = ?', p.id) };
  });
  if (out.mismatch) {
    log(ctx.user, out.mismatch.p, out.mismatch.sub, 'flag', 'Approval blocked: code typed by moderator did not match', String(ctx.body.codeSeen).slice(0, 30));
    audit(ctx.user, 'moderation.code_mismatch', 'product', out.mismatch.p.id, {}, ctx.ip);
    throw conflict('code_mismatch', 'The code you typed does not match the code issued for this listing. Check the photo again, or request more information from the seller.');
  }
  const msgs = { approve: ['Listing approved', 'Your listing is now live.'], reject: ['Listing rejected', reason], request_more: ['More information needed', reason], suspend: ['Listing suspended', reason] };
  if (msgs[decision]) notifyUser(out.p.seller_id, 'listing_' + decision, msgs[decision][0] + ': ' + out.p.name.slice(0, 60), msgs[decision][1], '/dashboard/products/' + out.p.id);
  return { status: out.p.status };
});

// ---- reports ----
api.get('/api/mod/reports', { auth: 'report.handle' }, (ctx) => {
  const status = ['open', 'dismissed', 'actioned'].includes(ctx.query.status) ? ctx.query.status : 'open';
  return { reports: db.all('SELECT r.*, u.display_name AS reporter FROM reports r JOIN users u ON u.id = r.reporter_id WHERE r.status = ? ORDER BY r.id DESC LIMIT 200', status).map((r) => ({ id: r.id, targetType: r.target_type, targetId: r.target_id, reason: r.reason, details: r.details, status: r.status, reporter: r.reporter, createdAt: r.created_at, handledNote: r.handled_note })) };
});
api.post('/api/mod/reports/:id', { auth: 'report.handle' }, (ctx) => {
  const r = db.get('SELECT * FROM reports WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!r) throw notFound('Report not found.');
  const action = oneOf(ctx.body.action, ['dismiss', 'action'], 'action');
  const note = text(ctx.body.note, { min: 3, max: 500, field: 'Note' });
  db.run('UPDATE reports SET status = ?, handled_by = ?, handled_note = ?, handled_at = ? WHERE id = ?', action === 'dismiss' ? 'dismissed' : 'actioned', ctx.user.id, note, nowIso(), r.id);
  audit(ctx.user, 'report.' + action, 'report', r.id, { note }, ctx.ip);
  return {};
});

module.exports = {};
