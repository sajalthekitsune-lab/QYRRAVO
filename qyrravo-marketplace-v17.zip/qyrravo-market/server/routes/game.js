'use strict';
// QYRRAVO Night Drive: the server measures play time itself and pays Q Coins. The browser only sends "I am active" heartbeats.
// Default: 20 Q Coins per completed lap (a lap is a ~132 km circuit, about 40 minutes), verified against real active play time, plus 5 Q per takedown (capped per day) of ACTIVE play, at most 2 hours per account per day, and a total daily budget for everyone.
const crypto = require('crypto');
const db = require('../db');
const config = require('../config');
const { api } = require('../http');
const { audit } = require('../audit');
const { bad, conflict, forbidden, nowIso } = require('../util');

const env = process.env;
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) && n >= 0 ? n : d; };
const cfg = () => ({
  enabled: env.GAME_ENABLED !== '0',
  coinsPerHour: num(env.GAME_COINS_PER_HOUR, 0),              // time pay is OFF by default; laps pay instead (set e.g. 60 for 1 Q per minute)
  lapCoins: num(env.GAME_LAP_COINS, 20),                      // Q per completed lap
  minLapSeconds: num(env.GAME_MIN_LAP_SECONDS, 480),          // active seconds the server must have seen before it pays a lap (a 132 km lap at the 800 km/h cap takes about 10 min)
  dailyLaps: num(env.GAME_DAILY_LAPS, 12),                    // most paid laps per account per day
  killCoins: num(env.GAME_KILL_COINS, 5),                     // Q per NPC takedown
  killDailyCoins: num(env.GAME_KILL_DAILY_COINS, 100),        // most Q one account can earn from takedowns per day
  dailySeconds: Math.round(num(env.GAME_DAILY_MINUTES, 480) * 60),
  teslaPrice: num(env.GAME_TESLA_PRICE, 30000),                 // Q Coins to unlock the Tesla Roadster (flying car)
  globalDailyCoins: num(env.GAME_GLOBAL_DAILY_COINS, 50000),  // everyone together: 50,000 Q = $500 per day
});
const day = () => new Date().toISOString().slice(0, 10);
const MAX_KILLS_PER_BEAT = 3, MIN_GAP_MS = 8000, MAX_CREDIT_S = 20, STALE_MS = 90000;

function state(userId) {
  const c = cfg(); const p = db.get('SELECT seconds, coins, kills, kill_coins, laps, lap_coins FROM game_progress WHERE user_id = ? AND day = ?', userId, day()) || { seconds: 0, coins: 0, kills: 0, kill_coins: 0, laps: 0, lap_coins: 0 };
  const lr = db.get('SELECT active_seconds FROM game_lap WHERE user_id = ?', userId) || { active_seconds: 0 };
  const cars = db.all('SELECT car FROM user_cars WHERE user_id = ?', userId).map((r) => r.car);
  const used = (db.get('SELECT coins FROM game_budget WHERE day = ?', day()) || { coins: 0 }).coins;
  return { cars, teslaPrice: c.teslaPrice, enabled: c.enabled, coinsPerHour: c.coinsPerHour, dollarsPerHour: c.coinsPerHour / 100, dailyMinutes: c.dailySeconds / 60, secondsToday: p.seconds, coinsToday: p.coins + p.kill_coins + p.lap_coins, lapCoins: c.lapCoins, lapsToday: p.laps, dailyLaps: c.dailyLaps, minLapSeconds: c.minLapSeconds, lapSeconds: lr.active_seconds, killsToday: p.kills, killCoins: c.killCoins, killCoinsLeft: Math.max(0, c.killDailyCoins - p.kill_coins),
    remainingSeconds: Math.max(0, c.dailySeconds - p.seconds), budgetLeft: used < c.globalDailyCoins };
}
api.get('/api/game/status', (ctx) => ({ ...state(ctx.user ? ctx.user.id : 0), signedIn: !!ctx.user, balance: ctx.user ? db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id).coins : null }));

api.post('/api/game/start', { auth: true }, (ctx) => {
  if (!cfg().enabled) throw conflict('off', 'Playing for Q Coins is switched off right now.');
  if (!ctx.user.emailVerified) throw forbidden('Verify your email to earn Q Coins while you play.');
  const id = crypto.randomBytes(16).toString('hex');
  db.tx(() => { db.run('UPDATE game_sessions SET live = 0 WHERE user_id = ? AND live = 1', ctx.user.id); db.run('INSERT INTO game_sessions (id, user_id, started_at, last_beat_ms) VALUES (?,?,?,?)', id, ctx.user.id, nowIso(), Date.now()); });
  return { sessionId: id, ...state(ctx.user.id) };
});

api.post('/api/game/beat', { auth: true }, (ctx) => {
  const c = cfg(); const sid = String(ctx.body.sessionId || '');
  const s = db.get('SELECT * FROM game_sessions WHERE id = ? AND user_id = ? AND live = 1', sid, ctx.user.id);
  if (!s) throw conflict('session', 'You are playing in another tab or this session ended. Press Start again.');
  const now = Date.now(); const gap = now - s.last_beat_ms;
  const quick = gap < MIN_GAP_MS;   // beats closer than 8 s apart pay no play time, but a finished lap can still be claimed
  if (!quick) db.run('UPDATE game_sessions SET last_beat_ms = ? WHERE id = ?', now, sid);
  if (!quick && gap > STALE_MS) { db.run('UPDATE game_sessions SET live = 0 WHERE id = ?', sid); throw conflict('session', 'Your session expired. Press Start again.'); }
  let earned = 0;
  if (!quick && c.enabled && ctx.body.active === true && ctx.user.emailVerified) {
    db.tx(() => {
      const d = day();
      db.run('INSERT OR IGNORE INTO game_progress (user_id, day) VALUES (?,?)', ctx.user.id, d);
      const p = db.get('SELECT * FROM game_progress WHERE user_id = ? AND day = ?', ctx.user.id, d);
      const secs = Math.max(0, Math.min(Math.floor(gap / 1000), MAX_CREDIT_S, c.dailySeconds - p.seconds));
      let timeCoins = 0;
      if (secs) {
      db.run('INSERT OR IGNORE INTO game_lap (user_id) VALUES (?)', ctx.user.id); db.run('UPDATE game_lap SET active_seconds = active_seconds + ? WHERE user_id = ?', secs, ctx.user.id);
      const secsPerCoin = c.coinsPerHour > 0 ? 3600 / c.coinsPerHour : Infinity;
      let carry = p.carry, coins = 0; if (c.coinsPerHour > 0) { carry += secs; coins = Math.floor(carry / secsPerCoin); carry -= Math.round(coins * secsPerCoin); }
      db.run('INSERT OR IGNORE INTO game_budget (day) VALUES (?)', d);
      const used = db.get('SELECT coins FROM game_budget WHERE day = ?', d).coins;
      coins = Math.max(0, Math.min(coins, c.globalDailyCoins - used));
      db.run('UPDATE game_progress SET seconds = seconds + ?, carry = ?, coins = coins + ? WHERE user_id = ? AND day = ?', secs, carry, coins, ctx.user.id, d);
      timeCoins = coins; }
      // takedowns: reported by the browser, so they are limited per beat and per day (the client cannot be fully trusted)
      const kills = Math.max(0, Math.min(Math.floor(Number(ctx.body.kills) || 0), MAX_KILLS_PER_BEAT)); let kc = 0;
      if (kills && secs && c.killCoins > 0) {
        db.run('INSERT OR IGNORE INTO game_budget (day) VALUES (?)', d);
        const p2 = db.get('SELECT kill_coins FROM game_progress WHERE user_id = ? AND day = ?', ctx.user.id, d); const used2 = db.get('SELECT coins FROM game_budget WHERE day = ?', d).coins + timeCoins;
        kc = Math.max(0, Math.min(kills * c.killCoins, c.killDailyCoins - p2.kill_coins, c.globalDailyCoins - used2));
        const ok = Math.floor(kc / c.killCoins); kc = ok * c.killCoins;
        if (kc > 0) db.run('UPDATE game_progress SET kills = kills + ?, kill_coins = kill_coins + ? WHERE user_id = ? AND day = ?', ok, kc, ctx.user.id, d);
      }
      const coins = timeCoins + kc;
      if (coins > 0) {
        db.run('UPDATE game_budget SET coins = coins + ? WHERE day = ?', coins, d);
        db.run('UPDATE users SET coins = coins + ? WHERE id = ?', coins, ctx.user.id);
        const reason = 'Game rewards ' + d; const row = db.get('SELECT id FROM coin_ledger WHERE user_id = ? AND reason = ?', ctx.user.id, reason);
        if (row) db.run('UPDATE coin_ledger SET delta = delta + ? WHERE id = ?', coins, row.id); else db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', ctx.user.id, coins, reason, nowIso());
        earned = coins;
      }
    });
  }
  let lapEarned = 0, lapDenied = null;
  if (c.enabled && ctx.user.emailVerified && Math.floor(Number(ctx.body.laps) || 0) >= 1) {
    db.tx(() => {
      const d = day(); db.run('INSERT OR IGNORE INTO game_progress (user_id, day) VALUES (?,?)', ctx.user.id, d); db.run('INSERT OR IGNORE INTO game_lap (user_id) VALUES (?)', ctx.user.id); db.run('INSERT OR IGNORE INTO game_budget (day) VALUES (?)', d);
      const p = db.get('SELECT laps FROM game_progress WHERE user_id = ? AND day = ?', ctx.user.id, d), lr = db.get('SELECT active_seconds FROM game_lap WHERE user_id = ?', ctx.user.id);
      const used = db.get('SELECT coins FROM game_budget WHERE day = ?', d).coins;
      const need = lapNeed(ctx, c);
      if (lr.active_seconds < need) { lapDenied = 'too_fast'; return; }
      if (p.laps >= c.dailyLaps) { lapDenied = 'daily_limit'; return; }
      const coins = Math.max(0, Math.min(c.lapCoins, c.globalDailyCoins - used)); if (coins <= 0) { lapDenied = 'budget'; return; }
      db.run('UPDATE game_lap SET active_seconds = active_seconds - ? WHERE user_id = ?', need, ctx.user.id);
      db.run('UPDATE game_progress SET laps = laps + 1, lap_coins = lap_coins + ? WHERE user_id = ? AND day = ?', coins, ctx.user.id, d);
      db.run('UPDATE game_budget SET coins = coins + ? WHERE day = ?', coins, d); db.run('UPDATE users SET coins = coins + ? WHERE id = ?', coins, ctx.user.id);
      const reason = 'Game rewards ' + d; const row = db.get('SELECT id FROM coin_ledger WHERE user_id = ? AND reason = ?', ctx.user.id, reason);
      if (row) db.run('UPDATE coin_ledger SET delta = delta + ? WHERE id = ?', coins, row.id); else db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', ctx.user.id, coins, reason, nowIso());
      lapEarned = coins;
    });
  }
  return { ...state(ctx.user.id), earned: earned + lapEarned, lapEarned, lapDenied, balance: db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id).coins };
});

// Cars for sale (the Tesla Roadster, 1,000 Q, and 20 luxury cars from 1,000 to 10,000 Q) are unlocked once by anyone. The wallet is charged here on the server.
const fs = require('fs'), path = require('path');
let LUX = []; try { LUX = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'data', 'luxury-cars.json'), 'utf8')); } catch { /* no luxury list */ }

// Active seconds a lap needs: the 132 km circuit takes longer in a slower car. Only cars the player may use count as fast.
const LAP_M = 132000;
function lapNeed(ctx, c) {
  const id = String(ctx.body.car || ''), u = ctx.user, staff = !!(u.isOwner || u.is_owner || u.role === 'admin' || u.role === 'moderator');
  let v = 800 / 3.6;
  const owns = staff || db.get('SELECT 1 AS x FROM user_cars WHERE user_id = ? AND car = ?', u.id, id);
  if (id === 'royale' && staff) v = 10000 / 3.6;
  else if (id === 'tesla' && owns) v = 20000 / 3.6;
  else { const lx = LUX.find((x) => x.id === id); if (lx && (staff || db.get('SELECT 1 AS x FROM user_cars WHERE user_id = ? AND car = ?', u.id, id))) v = lx.kmh / 3.6; }
  return Math.max(45, Math.min(c.minLapSeconds, Math.round(0.8 * LAP_M / v)));
}
const CARS_FOR_SALE = { tesla: 'Tesla Roadster', ...Object.fromEntries(LUX.map((c) => [c.id, c.name])) };
const carPrice = (id) => (id === 'tesla' ? cfg().teslaPrice : (LUX.find((c) => c.id === id) || {}).price);
api.post('/api/game/buy-car', { auth: true }, (ctx) => {
  const car = String(ctx.body.car || ''); if (!CARS_FOR_SALE[car]) throw bad('validation', 'That car is not for sale.');
  const price = carPrice(car);
  db.tx(() => {
    if (db.get('SELECT 1 AS x FROM user_cars WHERE user_id = ? AND car = ?', ctx.user.id, car)) throw conflict('owned', 'You already own the ' + CARS_FOR_SALE[car] + '.');
    const u = db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id);
    if (u.coins < price) throw conflict('coins', 'You need ' + price.toLocaleString('en-US') + ' Q Coins. You have ' + u.coins.toLocaleString('en-US') + '. Earn more in the game or buy coins in the Q Coin shop.');
    db.run('UPDATE users SET coins = coins - ? WHERE id = ?', price, ctx.user.id);
    db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', ctx.user.id, -price, 'Bought ' + CARS_FOR_SALE[car], nowIso());
    db.run('INSERT INTO user_cars (user_id, car, bought_at) VALUES (?,?,?)', ctx.user.id, car, nowIso());
  });
  return { ok: true, ...state(ctx.user.id), balance: db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id).coins };
});
