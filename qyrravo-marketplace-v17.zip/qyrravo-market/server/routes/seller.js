'use strict';
const config = require('../config');
const db = require('../db');
const settings = require('../settings');
const listings = require('../listings');
const images = require('../images');
const orders = require('../orders');
const payouts = require('../payouts');
const payments = require('../payments');
const subscriptions = require('../subscriptions');
const { api } = require('../http');
const { audit } = require('../audit');
const { notifyUser } = require('../notify');
const { noImpersonation, bad, conflict, forbidden, notFound, text, int, isEmail, nowIso, addMs, parseJson, sha256, randomToken } = require('../util');
const crypto = require('crypto');

const EDITABLE = ['draft', 'more_info_required', 'rejected', 'approved'];
const MAX_PRODUCTS = 300;

function profile(ctx) {
  const sp = db.get('SELECT * FROM seller_profiles WHERE user_id = ?', ctx.user.id);
  if (!sp) throw forbidden('Set up your seller profile first.');
  if (sp.seller_status !== 'active') throw forbidden('Your seller account is suspended. Contact ' + config.supportEmail + '.');
  return sp;
}
function myProduct(ctx, id) {
  const p = db.get('SELECT * FROM products WHERE id = ? AND seller_id = ? AND deleted_at IS NULL', int(id, { min: 1, field: 'id' }), ctx.user.id);
  if (!p) throw notFound('Listing not found.');
  return p;
}

// ---- verification codes ----
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newCode() {
  const b = crypto.randomBytes(8); let s = '';
  for (let i = 0; i < 8; i++) s += ALPHA[b[i] % ALPHA.length];
  return 'QY-' + s.slice(0, 4) + '-' + s.slice(4);
}
const normCode = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function currentSubmission(productId) {
  return db.get("SELECT * FROM verification_submissions WHERE product_id = ? AND status IN ('code_issued','submitted','under_review','more_info_required') ORDER BY id DESC", productId);
}

function view(p) {
  const imgs = listings.imagesFor(p.id, true);
  const sub = currentSubmission(p.id);
  const decisions = db.all(`SELECT d.decision, d.reason, d.created_at FROM verification_decisions d WHERE d.product_id = ? AND d.decision IN ('approve','reject','request_more','suspend') ORDER BY d.id DESC LIMIT 20`, p.id);
  return {
    id: p.id, status: p.status, statusReason: p.status_reason, flagged: !!p.flagged,
    name: p.name, description: p.description, brand: p.brand, model: p.model, condition: p.condition,
    category: p.category_id, subcategory: p.subcategory_id,
    acceptsCash: !!p.accepts_cash, acceptsCoins: !!p.accepts_coins,
    price: p.price_minor === null ? null : { minor: p.price_minor, currency: p.currency, usdMinor: p.price_usd_minor },
    quantity: p.quantity, quantityReserved: p.quantity_reserved,
    sellerCountry: p.seller_country, shipsTo: parseJson(p.ships_to, []), dispatchDays: p.dispatch_days,
    shippingFee: { minor: p.shipping_fee_minor, currency: p.currency }, shippingNotes: p.shipping_notes,
    returnsType: p.returns_type, returnsDays: p.returns_days, returnsNotes: p.returns_notes,
    specs: parseJson(p.specs, []), referenceInfo: p.reference_info,
    images: imgs.map((i) => ({ id: i.id, kind: i.kind, url: '/media/' + i.id })),
    verification: sub ? { status: sub.status, code: sub.code, expiresAt: sub.code_expires_at, expired: sub.code_expires_at < nowIso() && sub.status === 'code_issued', hasPhoto: imgs.some((i) => i.kind === 'verification' && db.get('SELECT 1 AS x FROM product_images WHERE id = ? AND submission_id = ?', i.id, sub.id)) } : null,
    decisions, createdAt: p.created_at, updatedAt: p.updated_at, submittedAt: p.submitted_at, approvedAt: p.approved_at,
    publicNow: !!db.get(`SELECT 1 AS x FROM products p WHERE p.id = ? AND ${listings.publicWhere('p').sql}`, p.id, ...listings.publicWhere('p').params),
  };
}

// ---------- onboarding / profile ----------
api.post('/api/seller/onboard', { auth: true }, (ctx) => {
  const u = ctx.user; const b = ctx.body;
  if (u.role !== 'buyer' && u.role !== 'seller' && u.role !== 'admin') throw conflict('staff_account', 'Staff accounts cannot also be sellers.');
  if (db.get('SELECT 1 AS x FROM seller_profiles WHERE user_id = ?', u.id)) throw conflict('already_seller', 'You already have a seller profile.');
  if (!u.emailVerified) throw conflict('email_unverified', 'Please verify your email address before becoming a seller.');
  if (b.agreeSellerTerms !== true) throw bad('validation', 'You must accept the Seller Agreement.', { field: 'agreeSellerTerms' });
  if (b.confirmAdult !== true) throw bad('validation', 'You must confirm that you are legally allowed to sell (18+, or acting with a parent/guardian where the law requires it) and that the items you list are yours to sell.', { field: 'confirmAdult' });
  const shopName = noImpersonation(text(b.shopName, { min: 3, max: 50, field: 'Shop name' }), u);
  if (/qyrravo/i.test(shopName) && !u.isOwner) throw bad('validation', 'Shop names cannot imply that the shop is run by QYRRAVO.', { field: 'shopName' });
  const country = String(b.country || '').toUpperCase();
  if (!settings.get('enabled_countries').includes(country)) throw bad('validation', 'Choose the country you sell from.', { field: 'country' });
  const bio = text(b.bio, { max: 600, field: 'About your shop', multiline: true, required: false });
  const contact = b.contactEmail ? String(b.contactEmail).trim().toLowerCase() : u.email;
  if (!isEmail(contact)) throw bad('validation', 'Enter a valid contact email.', { field: 'contactEmail' });
  if (db.get('SELECT 1 AS x FROM seller_profiles WHERE shop_name = ?', shopName)) throw conflict('shop_taken', 'That shop name is already taken.');
  db.tx(() => {
    db.run('INSERT INTO seller_profiles (user_id, shop_name, bio, country, contact_email, agreed_seller_terms_at, created_at) VALUES (?,?,?,?,?,?,?)', u.id, shopName, bio || null, country, contact, nowIso(), nowIso());
    db.run("UPDATE users SET role = 'seller', updated_at = ? WHERE id = ? AND role = 'buyer'", nowIso(), u.id);
    audit(u, 'seller.onboarded', 'user', u.id, { shopName, country }, ctx.ip);
  });
  return { seller: { shopName, country } };
});

api.get('/api/seller/me', { auth: 'seller' }, (ctx) => {
  const sp = profile(ctx);
  const counts = Object.fromEntries(db.all('SELECT status, COUNT(*) AS n FROM products WHERE seller_id = ? AND deleted_at IS NULL GROUP BY status', ctx.user.id).map((r) => [r.status, r.n]));
  const openOrders = db.get("SELECT COUNT(*) AS n FROM orders WHERE seller_id = ? AND status = 'paid'", ctx.user.id).n;
  return {
    profile: { shopName: sp.shop_name, bio: sp.bio, country: sp.country, contactEmail: sp.contact_email, payoutStatus: sp.payout_status, status: sp.seller_status },
    plan: subscriptions.view(ctx.user.id), counts, ordersToShip: openOrders,
    payoutCountries: settings.get('payout_countries'),
  };
});

api.patch('/api/seller/profile', { auth: 'seller' }, (ctx) => {
  const sp = profile(ctx); const b = ctx.body; const sets = []; const vals = [];
  if (b.shopName !== undefined) {
    const n = text(b.shopName, { min: 3, max: 50, field: 'Shop name' });
    if (/qyrravo/i.test(n)) throw bad('validation', 'Shop names cannot imply that the shop is run by QYRRAVO.', { field: 'shopName' });
    if (db.get('SELECT 1 AS x FROM seller_profiles WHERE shop_name = ? AND user_id != ?', n, sp.user_id)) throw conflict('shop_taken', 'That shop name is already taken.');
    sets.push('shop_name = ?'); vals.push(n);
  }
  if (b.bio !== undefined) { sets.push('bio = ?'); vals.push(text(b.bio, { max: 600, field: 'About your shop', multiline: true, required: false }) || null); }
  if (b.contactEmail !== undefined) { const e = String(b.contactEmail).trim().toLowerCase(); if (!isEmail(e)) throw bad('validation', 'Enter a valid contact email.', { field: 'contactEmail' }); sets.push('contact_email = ?'); vals.push(e); }
  if (!sets.length) throw bad('validation', 'Nothing to update.');
  db.run('UPDATE seller_profiles SET ' + sets.join(', ') + ' WHERE user_id = ?', ...vals, sp.user_id);
  return {};
});

// ---------- products ----------
api.get('/api/seller/products', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const rows = db.all('SELECT * FROM products WHERE seller_id = ? AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT 500', ctx.user.id);
  return { products: rows.map((p) => { const v = view(p); v.images = v.images.filter((i) => i.kind !== 'verification').slice(0, 1); return v; }) };
});

function applyFields(p, out) {
  const keys = Object.keys(out);
  if (!keys.length) return p;
  db.run('UPDATE products SET ' + keys.map((k) => k + ' = ?').join(', ') + ', updated_at = ? WHERE id = ?', ...keys.map((k) => out[k]), nowIso(), p.id);
  return db.get('SELECT * FROM products WHERE id = ?', p.id);
}

const canSellForCoins = (u) => !!u && (u.isOwner || u.role === 'admin' || u.role === 'moderator');
function assertCoinRights(ctx, out) {
  if (out.accepts_coins === 1 && !canSellForCoins(ctx.user)) throw forbidden('Only QYRRAVO staff, admins and the owner can sell items for Q Coins. Everyone can buy with them.');
}
api.post('/api/seller/products', { auth: 'seller' }, (ctx) => {
  const sp = profile(ctx);
  if (db.get('SELECT COUNT(*) AS n FROM products WHERE seller_id = ? AND deleted_at IS NULL', ctx.user.id).n >= MAX_PRODUCTS) throw conflict('too_many_listings', 'You have reached the maximum number of listings (' + MAX_PRODUCTS + ').');
  const out = listings.normalize(ctx.body || {});
  assertCoinRights(ctx, out);
  if (out.price_usd_minor !== undefined) listings.assertWithinPlan(ctx.user.id, out.price_usd_minor);
  if (out.quantity !== undefined) listings.assertQuantity(ctx.user.id, out.quantity);
  const id = db.tx(() => {
    const r = db.run("INSERT INTO products (seller_id, seller_country, status, created_at, updated_at) VALUES (?,?, 'draft', ?, ?)", ctx.user.id, sp.country, nowIso(), nowIso());
    applyFields({ id: r.id }, out);
    return r.id;
  });
  return { product: view(db.get('SELECT * FROM products WHERE id = ?', id)), __status: 201 };
});

api.get('/api/seller/products/:id', { auth: 'seller' }, (ctx) => { profile(ctx); return { product: view(myProduct(ctx, ctx.params.id)) }; });

api.patch('/api/seller/products/:id', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const p = myProduct(ctx, ctx.params.id);
  if (!EDITABLE.includes(p.status)) throw conflict('locked', p.status === 'suspended' ? 'This listing is suspended. Contact support.' : 'This listing is being reviewed. Withdraw it first if you need to change it.');
  const out = listings.normalize(ctx.body || {}); assertCoinRights(ctx, out);
  if (out.price_usd_minor !== undefined) listings.assertWithinPlan(ctx.user.id, out.price_usd_minor);
  if (out.quantity !== undefined) listings.assertQuantity(ctx.user.id, out.quantity);
  if (out.quantity !== undefined && out.quantity < p.quantity_reserved) throw conflict('quantity_reserved', 'Some units are reserved by buyers who are paying right now. The quantity cannot go below ' + p.quantity_reserved + '.');
  if (out.currency && p.currency && out.currency !== p.currency && db.get("SELECT 1 AS x FROM orders o JOIN order_items oi ON oi.order_id = o.id WHERE oi.product_id = ? AND o.status IN ('pending_payment','paid','shipped','delivered','disputed')", p.id)) throw conflict('open_orders', 'The currency cannot change while there are open orders for this item.');
  let reset = false;
  if (p.status === 'approved' && listings.MATERIAL.some((k) => out[k] !== undefined && String(out[k]) !== String(p[k] === null ? '' : p[k]))) {
    out.status = 'draft'; out.status_reason = 'Changed after approval. Review the verification photo and submit again.'; out.approved_at = null; reset = true;
  } else if (p.status === 'more_info_required' || p.status === 'rejected') { /* stays; seller resubmits */ }
  const fresh = db.tx(() => {
    const f = applyFields(p, out);
    if (reset) db.run("UPDATE verification_submissions SET status = 'superseded' WHERE product_id = ? AND status IN ('code_issued','submitted','under_review','more_info_required')", p.id);
    return f;
  });
  const v = view(fresh); v.resetToDraft = reset;
  return { product: v };
});

api.delete('/api/seller/products/:id', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const p = myProduct(ctx, ctx.params.id);
  if (p.quantity_reserved > 0 || db.get("SELECT 1 AS x FROM orders o JOIN order_items oi ON oi.order_id = o.id WHERE oi.product_id = ? AND o.status IN ('pending_payment','paid','shipped','delivered','disputed')", p.id)) throw conflict('open_orders', 'This item has open orders. Finish them before deleting the listing.');
  db.run('UPDATE products SET deleted_at = ?, updated_at = ? WHERE id = ?', nowIso(), nowIso(), p.id);
  audit(ctx.user, 'product.deleted', 'product', p.id, null, ctx.ip);
  return {};
});

api.post('/api/seller/products/:id/withdraw', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const p = myProduct(ctx, ctx.params.id);
  if (!['submitted', 'under_review', 'approved'].includes(p.status)) throw conflict('bad_state', 'Only submitted or approved listings can be withdrawn.');
  db.tx(() => {
    db.run("UPDATE products SET status = 'draft', status_reason = 'Withdrawn by seller', approved_at = NULL, updated_at = ? WHERE id = ?", nowIso(), p.id);
    db.run("UPDATE verification_submissions SET status = 'superseded' WHERE product_id = ? AND status IN ('code_issued','submitted','under_review','more_info_required')", p.id);
  });
  audit(ctx.user, 'product.withdrawn', 'product', p.id, null, ctx.ip);
  return { product: view(db.get('SELECT * FROM products WHERE id = ?', p.id)) };
});

// ---------- verification code ----------
api.post('/api/seller/products/:id/verification-code', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const p = myProduct(ctx, ctx.params.id);
  if (!['draft', 'more_info_required', 'rejected'].includes(p.status)) throw conflict('bad_state', 'A new code can only be requested while the listing is a draft or needs changes.');
  const ttl = settings.get('code_ttl_minutes') * 60000;
  const rec = db.tx(() => {
    db.run("UPDATE verification_submissions SET status = 'superseded' WHERE product_id = ? AND status IN ('code_issued','submitted','under_review','more_info_required')", p.id);
    for (let i = 0; i < 5; i++) {
      try {
        const code = newCode(); const t = nowIso();
        const r = db.run("INSERT INTO verification_submissions (product_id, seller_id, code, code_issued_at, code_expires_at, status) VALUES (?,?,?,?,?, 'code_issued')", p.id, ctx.user.id, code, t, addMs(t, ttl));
        return db.get('SELECT * FROM verification_submissions WHERE id = ?', r.id);
      } catch (e) { if (!/UNIQUE/.test(String(e.message))) throw e; }
    }
    throw new Error('could not generate a unique code');
  });
  return { verification: { code: rec.code, expiresAt: rec.code_expires_at, instructions: 'Write this code on paper (or show it on a screen) and photograph it next to the real item in one picture. It expires at the time shown and works for this listing only.' } };
});

// ---------- images ----------
api.post('/api/seller/products/:id/images', { auth: 'seller', raw: true, maxBytes: 8 * 1024 * 1024 + 1024, rate: 'upload' }, (ctx) => {
  profile(ctx);
  const p = myProduct(ctx, ctx.params.id);
  const kind = ctx.query.kind;
  if (!['main', 'extra', 'verification'].includes(kind)) throw bad('validation', 'kind must be main, extra or verification.', { field: 'kind' });
  if (!['draft', 'more_info_required', 'rejected', 'approved'].includes(p.status)) throw conflict('locked', 'This listing cannot be changed right now.');
  const info = images.inspect(ctx.raw, { maxBytes: settings.get('max_image_bytes'), minPx: settings.get('min_image_px') });
  const hash = sha256(info.data);
  let submissionId = null;
  if (kind === 'verification') {
    const sub = currentSubmission(p.id);
    if (!sub || sub.status !== 'code_issued') throw conflict('no_code', 'Request a verification code first.');
    if (sub.code_expires_at < nowIso()) throw conflict('code_expired', 'Your verification code expired. Request a new one and take a new photo.');
    submissionId = sub.id;
  } else if (kind === 'extra' || kind === 'main') {
    const n = db.get("SELECT COUNT(*) AS n FROM product_images WHERE product_id = ? AND kind != 'verification'", p.id).n;
    if (kind === 'extra' && n >= settings.get('max_images')) throw conflict('too_many_images', 'You can add up to ' + settings.get('max_images') + ' photos.');
  }
  const key = images.store(info);
  let imageId; const toRemove = [];
  try {
    db.tx(() => {
      if (kind === 'main' || kind === 'verification') {
        for (const old of db.all(`SELECT * FROM product_images WHERE product_id = ? AND kind = ? ${kind === 'verification' ? 'AND submission_id = ?' : ''}`, ...(kind === 'verification' ? [p.id, kind, submissionId] : [p.id, kind]))) {
          toRemove.push(old.file_key); db.run('DELETE FROM product_images WHERE id = ?', old.id);
        }
      }
      const pos = db.get('SELECT COALESCE(MAX(position),0)+1 AS n FROM product_images WHERE product_id = ?', p.id).n;
      imageId = db.run('INSERT INTO product_images (product_id, kind, file_key, mime, bytes, width, height, sha256, position, submission_id, uploaded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        p.id, kind, key, info.mime, info.data.length, info.width, info.height, hash, pos, submissionId, nowIso()).id;
      // duplicate-image detection: the same photo on another seller's listing is a strong scam signal -> flag for moderators (never auto-reject)
      const dup = db.get('SELECT p2.id FROM product_images i JOIN products p2 ON p2.id = i.product_id WHERE i.sha256 = ? AND p2.seller_id != ? AND p2.deleted_at IS NULL LIMIT 1', hash, ctx.user.id);
      if (dup) db.run("UPDATE products SET flagged = 1, flag_reason = COALESCE(flag_reason || '; ', '') || 'Photo identical to a photo on another seller''s listing' WHERE id = ?", p.id);
      if (p.status === 'approved' && kind !== 'verification') {
        db.run("UPDATE products SET status = 'draft', status_reason = 'Photos changed after approval. Review and submit again.', approved_at = NULL, updated_at = ? WHERE id = ?", nowIso(), p.id);
        db.run("UPDATE verification_submissions SET status = 'superseded' WHERE product_id = ? AND status IN ('code_issued','submitted','under_review','more_info_required')", p.id);
      }
      db.run('UPDATE products SET updated_at = ? WHERE id = ?', nowIso(), p.id);
    });
  } catch (e) { images.remove(key); throw e; }
  toRemove.forEach(images.remove);
  return { image: { id: imageId, kind, url: '/media/' + imageId, width: info.width, height: info.height }, metadataStripped: info.mime !== 'image/webp', __status: 201 };
});

api.delete('/api/seller/products/:id/images/:imageId', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const p = myProduct(ctx, ctx.params.id);
  if (!['draft', 'more_info_required', 'rejected', 'approved'].includes(p.status)) throw conflict('locked', 'This listing cannot be changed right now.');
  const img = db.get('SELECT * FROM product_images WHERE id = ? AND product_id = ?', int(ctx.params.imageId, { min: 1 }), p.id);
  if (!img) throw notFound('Image not found.');
  db.tx(() => {
    db.run('DELETE FROM product_images WHERE id = ?', img.id);
    if (p.status === 'approved' && img.kind !== 'verification') db.run("UPDATE products SET status = 'draft', status_reason = 'Photos changed after approval. Review and submit again.', approved_at = NULL WHERE id = ?", p.id);
  });
  images.remove(img.file_key);
  return {};
});

// ---------- submit for review (duplicate-submit safe) ----------
api.post('/api/seller/products/:id/submit', { auth: 'seller' }, (ctx) => {
  const sp = profile(ctx);
  if (!ctx.user.emailVerified) throw conflict('email_unverified', 'Please verify your email address before submitting listings.');
  const key = text(ctx.body.submitKey, { min: 8, max: 80, field: 'submitKey' });
  const out = db.tx(() => {
    const p = myProduct(ctx, ctx.params.id);
    if (p.submit_key === key && ['submitted', 'under_review', 'approved'].includes(p.status)) return { product: p, replay: true };
    if (!['draft', 'more_info_required', 'rejected'].includes(p.status)) throw conflict('bad_state', 'This listing cannot be submitted from its current status (' + p.status + ').');
    const sub = currentSubmission(p.id);
    const imgs = listings.imagesFor(p.id, true).map((i) => ({ ...i, sub: db.get('SELECT submission_id AS s FROM product_images WHERE id = ?', i.id).s }));
    const eligible = imgs.filter((i) => i.kind !== 'verification' || (sub && i.sub === sub.id));
    const missing = listings.missingForSubmit(p, eligible);
    if (missing.length) throw bad('incomplete', 'Please complete the listing before submitting.', { missing });
    if (!sub || !['code_issued', 'more_info_required'].includes(sub.status)) throw conflict('no_code', 'Request a verification code and add a photo that shows it.');
    if (sub.status === 'code_issued' && sub.code_expires_at < nowIso()) throw conflict('code_expired', 'Your verification code expired before you submitted. Request a new code and take a new photo.');
    listings.assertWithinPlan(ctx.user.id, p.price_usd_minor);
    listings.assertQuantity(ctx.user.id, p.quantity);
    listings.assertSlotFree(ctx.user.id, p.id);
    const hits = listings.prohibitedHits(p.name, p.description, p.brand, p.model);
    const t = nowIso();
    let flagged = p.flagged; let reason = p.flag_reason;
    if (hits.length) { flagged = 1; reason = (reason ? reason + '; ' : '') + 'Possible prohibited item: ' + hits.map((h) => h.keyword).join(', '); }
    db.run("UPDATE products SET status = 'submitted', status_reason = NULL, submit_key = ?, submitted_at = ?, flagged = ?, flag_reason = ?, updated_at = ? WHERE id = ?", key, t, flagged, reason, t, p.id);
    db.run("UPDATE verification_submissions SET status = 'submitted', submitted_at = ? WHERE id = ?", t, sub.id);
    audit(ctx.user, 'product.submitted', 'product', p.id, { flagged: !!flagged }, ctx.ip);
    return { product: db.get('SELECT * FROM products WHERE id = ?', p.id), replay: false, prohibitedHits: hits.map((h) => h.keyword) };
  });
  return { product: view(out.product), replay: out.replay, warnings: (out.prohibitedHits || []).length ? ['Your listing contains words that may be restricted. A moderator will look at it closely.'] : [] };
});

// ---------- orders ----------
api.get('/api/seller/orders', { auth: 'seller' }, (ctx) => {
  profile(ctx);
  const rows = db.all('SELECT * FROM orders WHERE seller_id = ? AND status != ? ORDER BY id DESC LIMIT 200', ctx.user.id, 'pending_payment');
  return { orders: rows.map((o) => orders.sellerView(o)) };
});
api.post('/api/seller/orders/:id/ship', { auth: 'seller' }, (ctx) => { profile(ctx); return { order: orders.view(orders.ship(ctx.user.id, int(ctx.params.id, { min: 1 }), ctx.body.tracking), true) }; });
api.post('/api/seller/orders/:id/cancel', { auth: 'seller' }, async (ctx) => {
  profile(ctx);
  const refund = await orders.sellerCancel(ctx.user.id, int(ctx.params.id, { min: 1 }), ctx.body.reason);
  return { refund: { id: refund.id, status: refund.status, amountMinor: refund.amount_minor }, message: 'A full refund was requested. The order is cancelled when the payment provider confirms it.' };
});

// ---------- finance ----------
api.get('/api/seller/finance', { auth: 'seller' }, (ctx) => {
  const sp = profile(ctx);
  return {
    payoutStatus: sp.payout_status, payoutCountries: settings.get('payout_countries'), sellerCountry: sp.country,
    balances: payouts.balances(ctx.user.id),
    payouts: db.all('SELECT id, currency, amount_minor AS amountMinor, status, created_at AS createdAt, paid_at AS paidAt FROM payouts WHERE seller_id = ? ORDER BY id DESC LIMIT 50', ctx.user.id),
    fees: { commissionPercent: settings.get('commission_bps') / 100, placeholder: !!settings.get('commission_is_placeholder'), fixedFeeUsdMinor: settings.get('commission_fixed_usd_minor'), base: settings.get('commission_base') },
    explanation: 'Pending = paid by the buyer but the order is not completed yet. Available = completed orders minus the marketplace commission, minus payouts already requested. Nothing here is income until the payment provider confirms it.',
    commissions: db.all('SELECT order_id AS orderId, currency, amount_minor AS amountMinor, status FROM commissions WHERE seller_id = ? ORDER BY id DESC LIMIT 50', ctx.user.id),
  };
});
api.post('/api/seller/payout-onboarding', { auth: 'seller' }, async (ctx) => {
  const sp = profile(ctx);
  if (!settings.get('payout_countries').includes(sp.country)) throw conflict('payouts_unavailable_country', 'Payouts are not available for sellers in your country yet. You can still prepare listings.');
  const provider = payments.requireProvider();
  if (sp.payout_status === 'verified') return { payoutStatus: 'verified' };
  let out;
  try { out = await provider.startSellerOnboarding({ seller: sp }); } catch (e) { throw conflict('onboarding_failed', 'We could not start payout set-up with the payment provider.'); }
  db.run("UPDATE seller_profiles SET payout_status = 'pending', provider_account_ref = COALESCE(?, provider_account_ref) WHERE user_id = ?", out.accountRef || null, sp.user_id);
  return { payoutStatus: 'pending', onboardingUrl: out.url || null, simulator: !!provider.isSimulator };
});

// ---------- subscription ----------
api.get('/api/seller/subscription', { auth: 'seller' }, (ctx) => { profile(ctx); return subscriptions.view(ctx.user.id); });
api.post('/api/seller/subscription/checkout', { auth: 'seller' }, async (ctx) => { profile(ctx); return subscriptions.startCheckout(ctx.user, ctx.body.planId); });
api.post('/api/seller/subscription/cancel', { auth: 'seller' }, async (ctx) => { profile(ctx); return { subscription: await subscriptions.cancel(ctx.user) }; });

module.exports = { view, newCode, normCode, currentSubmission };
