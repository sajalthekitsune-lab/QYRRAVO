'use strict';
const db = require('../db');
const settings = require('../settings');
const orders = require('../orders');
const { api } = require('../http');
const { audit } = require('../audit');
const { notifyUser } = require('../notify');
const { conflict, notFound, text, int, nowIso, addDays } = require('../util');

function mine(ctx) {
  const o = db.get('SELECT * FROM orders WHERE id = ? AND buyer_id = ?', int(ctx.params.id, { min: 1, field: 'id' }), ctx.user.id);
  if (!o) throw notFound('Order not found.');
  return o;
}
function detail(o) {
  const v = orders.view(o, false);
  const seller = db.get('SELECT shop_name, contact_email FROM seller_profiles WHERE user_id = ?', o.seller_id);
  v.seller = { id: o.seller_id, shopName: seller ? seller.shop_name : null, contactEmail: seller ? seller.contact_email : null };
  v.shipTo = { name: o.ship_name, line1: o.ship_line1, line2: o.ship_line2, city: o.ship_city, region: o.ship_region, postal: o.ship_postal, country: o.ship_country };
  const pay = db.get('SELECT id, status, amount_minor, currency, checkout_url FROM payments WHERE order_id = ? ORDER BY id DESC', o.id);
  v.payment = pay ? { id: pay.id, status: pay.status, amountMinor: pay.amount_minor, currency: pay.currency, checkoutUrl: o.status === 'pending_payment' && pay.status === 'pending' ? pay.checkout_url : null } : null;
  v.expiresAt = o.status === 'pending_payment' ? o.expires_at : null;
  v.refunds = db.all('SELECT id, amount_minor AS amountMinor, status, reason, created_at AS createdAt FROM refunds WHERE order_id = ? ORDER BY id', o.id);
  v.dispute = db.get("SELECT id, status, reason, created_at AS createdAt FROM disputes WHERE order_id = ? ORDER BY id DESC", o.id) || null;
  v.refundWindowDays = settings.get('refund_window_days');
  return v;
}

api.post('/api/checkout', { auth: true }, async (ctx) => {
  const r = await orders.checkout(ctx.user, ctx.body);
  const o = db.get('SELECT * FROM orders WHERE id = ?', r.order.id);
  return { order: detail(o), replay: !!r.replay };
});
api.get('/api/orders', { auth: true }, (ctx) => ({ orders: db.all('SELECT * FROM orders WHERE buyer_id = ? ORDER BY id DESC LIMIT 100', ctx.user.id).map(detail) }));
api.get('/api/orders/:id', { auth: true }, (ctx) => ({ order: detail(mine(ctx)) }));
api.post('/api/orders/:id/cancel', { auth: true }, (ctx) => {
  const o = mine(ctx);
  if (o.status !== 'pending_payment') throw conflict('bad_transition', 'Only unpaid orders can be cancelled here. For paid orders, contact the seller or open a dispute.');
  orders.cancelPending(o.id, 'cancelled by buyer');
  return { order: detail(db.get('SELECT * FROM orders WHERE id = ?', o.id)) };
});
api.post('/api/orders/:id/confirm-delivery', { auth: true }, (ctx) => { const o = mine(ctx); return { order: detail(orders.confirmDelivery(ctx.user.id, o.id)) }; });
api.post('/api/orders/:id/dispute', { auth: true }, (ctx) => {
  const o = mine(ctx);
  const reason = text(ctx.body.reason, { min: 10, max: 1000, field: 'What went wrong', multiline: true });
  if (!['paid', 'shipped', 'delivered', 'completed'].includes(o.status)) throw conflict('bad_transition', 'A dispute cannot be opened for this order.');
  const base = o.delivered_at || o.shipped_at || o.paid_at;
  if (base < addDays(nowIso(), -settings.get('refund_window_days') - 30)) throw conflict('window_closed', 'The dispute window for this order has closed.');
  if (db.get("SELECT 1 AS x FROM disputes WHERE order_id = ? AND status = 'open'", o.id)) throw conflict('dispute_open', 'A dispute is already open for this order.');
  db.tx(() => {
    db.run("INSERT INTO disputes (order_id, opened_by, source, reason, status, created_at) VALUES (?,?, 'buyer', ?, 'open', ?)", o.id, ctx.user.id, reason, nowIso());
    orders.setStatus(o, 'disputed');
  });
  audit(ctx.user, 'dispute.opened', 'order', o.id, null, ctx.ip);
  notifyUser(o.seller_id, 'dispute', 'Dispute opened on ' + o.order_no, 'The buyer opened a dispute. Earnings for this order are on hold while it is reviewed.', '/dashboard/orders');
  return { order: detail(db.get('SELECT * FROM orders WHERE id = ?', o.id)) };
});

module.exports = { detail };
