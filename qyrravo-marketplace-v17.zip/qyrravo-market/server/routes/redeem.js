'use strict';
// QYRRAVO Digital Code Redeem + Q Coins wallet. Only the owner can create codes. 100 Q Coins = $1.
const crypto = require('crypto');
const db = require('../db');
const { api } = require('../http');
const { audit } = require('../audit');
const { notify } = require('../notify');
const { bad, conflict, notFound, forbidden, text, int, nowIso, addDays } = require('../util');

const COINS_PER_USD = 100;
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I
const ownerOnly = (ctx) => { if (!ctx.user.isOwner) throw forbidden('Only the owner can manage codes.'); };
const norm = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const pretty = (n) => n.match(/.{1,4}/g).join('-');
function newCode() {
  for (let i = 0; i < 20; i++) {
    let s = 'QYR'; for (let j = 0; j < 12; j++) s += ALPHABET[crypto.randomInt(ALPHABET.length)];
    const c = pretty(s); if (!db.get('SELECT 1 AS x FROM redeem_codes WHERE code = ?', c)) return c;
  }
  throw new Error('could not generate a code');
}
function dollarsToCents(v) {
  const n = Number(v); if (!Number.isFinite(n) || n <= 0 || n > 100000) throw bad('validation', 'Enter a dollar amount from 0.01 to 100000.', { field: 'dollars' });
  return Math.round(n * 100);
}
// creates a code row; returns it
function createCode({ reward, cents, maxUses = 1, days = null, assignedUserId = null, eventId = null, by }) {
  const code = newCode();
  const r = db.run('INSERT INTO redeem_codes (code, reward, value_cents, coins, max_uses, expires_at, assigned_user_id, event_id, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
    code, reward, cents, Math.round(cents / 100 * COINS_PER_USD), maxUses, days ? addDays(nowIso(), days) : null, assignedUserId, eventId, by, nowIso());
  return { id: r.id, code };
}
const view = (c, full) => ({ id: c.id, code: c.code, reward: c.reward, dollars: c.value_cents / 100, coins: c.coins, maxUses: c.max_uses, uses: c.uses, expiresAt: c.expires_at, active: !!c.active, assigned: !!c.assigned_user_id, eventId: c.event_id, createdAt: c.created_at, ...(full ? { assignedTo: c.assigned_user_id ? (db.get('SELECT display_name FROM users WHERE id = ?', c.assigned_user_id) || {}).display_name : null } : {}) });

api.get('/api/wallet', { auth: true }, (ctx) => {
  const u = db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id);
  const mine = db.all('SELECT * FROM redeem_codes WHERE assigned_user_id = ? ORDER BY id DESC LIMIT 50', ctx.user.id).map((c) => ({ ...view(c), redeemed: !!db.get('SELECT 1 AS x FROM code_redemptions WHERE code_id = ? AND user_id = ?', c.id, ctx.user.id) }));
  return { coins: u.coins, dollars: u.coins / COINS_PER_USD, coinsPerUsd: COINS_PER_USD, myCodes: mine, history: db.all('SELECT delta, reason, created_at AS at FROM coin_ledger WHERE user_id = ? ORDER BY id DESC LIMIT 30', ctx.user.id) };
});

api.post('/api/redeem', { auth: true, rate: 'redeem' }, (ctx) => {
  const key = norm(ctx.body.code);
  if (key.length < 8 || key.length > 40) throw bad('validation', 'Enter your full code.', { field: 'code' });
  const c = db.all('SELECT * FROM redeem_codes').find((x) => norm(x.code) === key);
  const invalid = () => bad('invalid_code', 'That code is not valid.', { field: 'code' });
  if (!c || !c.active) throw invalid();
  if (c.assigned_user_id && c.assigned_user_id !== ctx.user.id) throw invalid(); // a prize code works only for its winner
  if (c.expires_at && c.expires_at <= nowIso()) throw bad('expired', 'That code has expired.', { field: 'code' });
  if (c.uses >= c.max_uses) throw conflict('used_up', 'That code has already been used.');
  if (db.get('SELECT 1 AS x FROM code_redemptions WHERE code_id = ? AND user_id = ?', c.id, ctx.user.id)) throw conflict('already', 'You already redeemed this code.');
  db.tx(() => {
    const upd = db.run('UPDATE redeem_codes SET uses = uses + 1 WHERE id = ? AND uses < max_uses AND active = 1', c.id);
    if (!upd.changes) throw conflict('used_up', 'That code has already been used.');
    db.run('INSERT INTO code_redemptions (code_id, user_id, coins, created_at) VALUES (?,?,?,?)', c.id, ctx.user.id, c.coins, nowIso());
    db.run('UPDATE users SET coins = coins + ? WHERE id = ?', c.coins, ctx.user.id);
    db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', ctx.user.id, c.coins, 'Redeemed code: ' + c.reward, nowIso());
  });
  const u = db.get('SELECT coins FROM users WHERE id = ?', ctx.user.id);
  return { reward: c.reward, coins: c.coins, dollars: c.value_cents / 100, balance: u.coins };
});

// ---- owner only ----
api.get('/api/owner/codes', { auth: true }, (ctx) => { ownerOnly(ctx); return { codes: db.all('SELECT * FROM redeem_codes ORDER BY id DESC LIMIT 200').map((c) => view(c, true)) }; });
api.post('/api/owner/codes', { auth: true }, (ctx) => {
  ownerOnly(ctx); const b = ctx.body;
  const reward = text(b.reward, { min: 2, max: 150, field: 'Reward' }); const cents = dollarsToCents(b.dollars);
  const maxUses = int(b.maxUses === undefined || b.maxUses === '' ? 1 : b.maxUses, { min: 1, max: 100000, field: 'Uses' });
  const days = b.days ? int(b.days, { min: 1, max: 3650, field: 'Days' }) : null;
  const c = createCode({ reward, cents, maxUses, days, by: ctx.user.id });
  audit(ctx.user, 'code.created', 'redeem_code', c.id, { reward, cents, maxUses }, ctx.ip);
  return c;
});
api.post('/api/owner/codes/:id/toggle', { auth: true }, (ctx) => { ownerOnly(ctx); const id = int(ctx.params.id, { min: 1 }); if (!db.get('SELECT 1 AS x FROM redeem_codes WHERE id = ?', id)) throw notFound('Code not found.'); db.run('UPDATE redeem_codes SET active = 1 - active WHERE id = ?', id); audit(ctx.user, 'code.toggled', 'redeem_code', id, {}, ctx.ip); return {}; });


// ---- buy Q Coins by email: the buyer files a request, pays the owner by email, the owner delivers the coins ----
const PACKS = [500, 1000, 2500, 5000, 10000]; // coins; 100 Q = $1
const mailOf = () => require('../config').supportEmail;
api.get('/api/coin-packs', () => ({ packs: PACKS.map((c) => ({ coins: c, dollars: c / COINS_PER_USD })), email: mailOf(), min: 100, max: 100000 }));
api.post('/api/coin-requests', { auth: true }, (ctx) => {
  const coins = int(ctx.body.coins, { min: 100, max: 100000, field: 'Q Coins' });
  if (coins % 100 !== 0) throw bad('validation', 'Choose a whole number of dollars (a multiple of 100 Q Coins).', { field: 'coins' });
  if (db.get("SELECT COUNT(*) AS n FROM coin_requests WHERE user_id = ? AND status = 'pending'", ctx.user.id).n >= 5) throw conflict('too_many', 'You already have 5 open requests. Wait for QYRRAVO to deliver them or email ' + mailOf() + '.');
  const r = db.run('INSERT INTO coin_requests (user_id, coins, usd_cents, created_at) VALUES (?,?,?,?)', ctx.user.id, coins, coins, nowIso()); // 1 Q = 1 cent
  audit(ctx.user, 'coin_request.created', 'coin_request', r.id, { coins }, ctx.ip);
  return { id: r.id, coins, dollars: coins / COINS_PER_USD, email: mailOf() };
});
api.get('/api/coin-requests/mine', { auth: true }, (ctx) => ({ requests: db.all('SELECT id, coins, usd_cents, status, created_at FROM coin_requests WHERE user_id = ? ORDER BY id DESC LIMIT 20', ctx.user.id).map((x) => ({ id: x.id, coins: x.coins, dollars: x.usd_cents / 100, status: x.status, createdAt: x.created_at })) }));
function credit(userId, coins, reason) {
  db.run('UPDATE users SET coins = coins + ? WHERE id = ?', coins, userId);
  db.run('INSERT INTO coin_ledger (user_id, delta, reason, created_at) VALUES (?,?,?,?)', userId, coins, reason, nowIso());
}
api.get('/api/owner/coin-requests', { auth: true }, (ctx) => { ownerOnly(ctx); return { requests: db.all("SELECT r.*, u.email, u.display_name FROM coin_requests r JOIN users u ON u.id = r.user_id ORDER BY (r.status = 'pending') DESC, r.id DESC LIMIT 200").map((x) => ({ id: x.id, email: x.email, name: x.display_name, coins: x.coins, dollars: x.usd_cents / 100, status: x.status, createdAt: x.created_at })) }; });
api.post('/api/owner/coin-requests/:id/deliver', { auth: true }, (ctx) => {
  ownerOnly(ctx); const r = db.get('SELECT * FROM coin_requests WHERE id = ?', int(ctx.params.id, { min: 1 })); if (!r) throw notFound('Request not found.');
  const ok = db.tx(() => { const m = db.run("UPDATE coin_requests SET status = 'delivered', done_at = ? WHERE id = ? AND status = 'pending'", nowIso(), r.id); if (!m.changes) return false; credit(r.user_id, r.coins, 'Bought from QYRRAVO (request #' + r.id + ')'); return true; });
  if (!ok) throw conflict('done', 'This request was already handled.');
  audit(ctx.user, 'coin_request.delivered', 'coin_request', r.id, { coins: r.coins }, ctx.ip);
  notify(r.user_id, 'order', r.coins.toLocaleString('en-US') + ' Q Coins added', 'QYRRAVO confirmed your payment. The coins are in your wallet.', '/redeem');
  return {};
});
api.post('/api/owner/coin-requests/:id/cancel', { auth: true }, (ctx) => {
  ownerOnly(ctx); const id = int(ctx.params.id, { min: 1 });
  const m = db.run("UPDATE coin_requests SET status = 'cancelled', done_at = ? WHERE id = ? AND status = 'pending'", nowIso(), id); if (!m.changes) throw conflict('done', 'This request was already handled.');
  audit(ctx.user, 'coin_request.cancelled', 'coin_request', id, null, ctx.ip); return {};
});
// owner gifts coins to any account by email
api.post('/api/owner/gift', { auth: true }, (ctx) => {
  ownerOnly(ctx);
  const email = String(ctx.body.email || '').trim().toLowerCase(); const u = db.get("SELECT id, display_name FROM users WHERE email = ? AND status != 'deleted'", email);
  if (!u) throw notFound('No account uses that email.');
  const coins = Math.round(Number(ctx.body.dollars) * COINS_PER_USD);
  if (!Number.isFinite(coins) || coins < 1 || coins > 10000000) throw bad('validation', 'Enter a gift of at least $0.01.', { field: 'dollars' });
  const note = text(ctx.body.note, { max: 120, field: 'Note', required: false });
  db.tx(() => credit(u.id, coins, 'Gift from QYRRAVO' + (note ? ': ' + note : '')));
  audit(ctx.user, 'coins.gifted', 'user', u.id, { coins, note }, ctx.ip);
  notify(u.id, 'gift', 'You got ' + coins.toLocaleString('en-US') + ' Q Coins', 'QYRRAVO sent you a gift' + (note ? ': ' + note : '') + '. It is in your wallet.', '/redeem');
  return { name: u.display_name, coins };
});

module.exports = { createCode, dollarsToCents, COINS_PER_USD };
