'use strict';
const db = require('../db');
const config = require('../config');
const settings = require('../settings');
const ledger = require('../ledger');
const orders = require('../orders');
const payouts = require('../payouts');
const payments = require('../payments');
const sim = require('../payments/simulate');
const auth = require('../auth');
const { api } = require('../http');
const { audit } = require('../audit');
const { notifyUser } = require('../notify');
const listings = require('../listings');
const { bad, conflict, forbidden, notFound, text, int, oneOf, nowIso, addDays, parseJson } = require('../util');

const limit = (ctx, d = 100) => Math.min(500, Math.max(1, parseInt(ctx.query.limit, 10) || d));

// ---------------- overview ----------------
api.get('/api/admin/overview', { auth: 'audit.view' }, () => {
  const c = (sql, ...p) => db.get(sql, ...p).n;
  return {
    users: c("SELECT COUNT(*) AS n FROM users WHERE status = 'active'"),
    sellers: c("SELECT COUNT(*) AS n FROM seller_profiles WHERE seller_status = 'active'"),
    listings: Object.fromEntries(db.all('SELECT status, COUNT(*) AS n FROM products WHERE deleted_at IS NULL GROUP BY status').map((r) => [r.status, r.n])),
    flaggedListings: c('SELECT COUNT(*) AS n FROM products WHERE flagged = 1 AND deleted_at IS NULL'),
    openReports: c("SELECT COUNT(*) AS n FROM reports WHERE status = 'open'"),
    openDisputes: c("SELECT COUNT(*) AS n FROM disputes WHERE status = 'open'"),
    ordersByStatus: Object.fromEntries(db.all('SELECT status, COUNT(*) AS n FROM orders GROUP BY status').map((r) => [r.status, r.n])),
    paidSellers: c("SELECT COUNT(*) AS n FROM subscriptions WHERE plan_id != 'free' AND status IN ('active','past_due','canceled') AND current_period_end > ?", nowIso()),
    recentErrors: c('SELECT COUNT(*) AS n FROM error_log WHERE created_at > ?', new Date(Date.now() - 86400e3).toISOString()),
    payment: { mode: config.paymentMode, provider: config.paymentProvider, simulator: !!(payments.provider() && payments.provider().isSimulator), providerImplemented: !(payments.provider() && payments.provider().notImplemented) },
    emailProvider: config.emailProvider,
    commissionIsPlaceholder: !!settings.get('commission_is_placeholder'),
  };
});

// ---------------- users & sellers ----------------
api.get('/api/admin/users', { auth: 'user.manage' }, (ctx) => {
  const q = String(ctx.query.q || '').toLowerCase().slice(0, 80).replace(/[%_]/g, '');
  const rows = db.all("SELECT id, email, display_name, role, is_owner, country, status, email_verified_at, created_at FROM users WHERE status != 'deleted' AND (? = '' OR LOWER(email) LIKE ? OR LOWER(display_name) LIKE ?) ORDER BY is_owner DESC, id DESC LIMIT ?", q, '%' + q + '%', '%' + q + '%', limit(ctx));
  return { users: rows.map((u) => {
    const sub = db.get("SELECT plan_id, current_period_end, provider FROM subscriptions WHERE user_id = ? AND plan_id != 'free' AND status IN ('active','past_due','canceled') AND current_period_end > ?", u.id, nowIso());
    return { id: u.id, email: u.email, displayName: u.display_name, role: u.role, isOwner: !!u.is_owner, country: u.country, status: u.status, emailVerified: !!u.email_verified_at, createdAt: u.created_at,
      plan: u.role === 'admin' ? 'vip (staff, free)' : (sub ? sub.plan_id + ' until ' + sub.current_period_end.slice(0, 10) + (sub.provider === 'manual' ? ' (granted)' : '') : 'free') };
  }) };
});
// Roles: only the OWNER can make someone an administrator or take that away. The owner account itself never changes.
api.post('/api/admin/users/:id/role', { auth: 'user.manage' }, (ctx) => {
  const role = oneOf(ctx.body.role, ['buyer', 'moderator', 'admin'], 'role');
  const u = db.get('SELECT * FROM users WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!u || u.status === 'deleted') throw notFound('User not found.');
  if (u.is_owner) throw forbidden('The owner account cannot be changed.');
  if (u.id === ctx.user.id) throw forbidden('You cannot change your own role.');
  if ((role === 'admin' || u.role === 'admin') && !ctx.user.isOwner) throw forbidden('Only the owner can make someone an administrator or remove an administrator.');
  const hasShop = !!db.get('SELECT 1 AS x FROM seller_profiles WHERE user_id = ?', u.id);
  if (role === 'moderator' && hasShop) throw conflict('is_seller', 'This user is a seller. Sellers cannot be moderators.');
  const finalRole = role === 'buyer' && hasShop ? 'seller' : role;
  db.run('UPDATE users SET role = ?, updated_at = ? WHERE id = ?', finalRole, nowIso(), u.id);
  audit(ctx.user, 'user.role_changed', 'user', u.id, { from: u.role, to: finalRole }, ctx.ip);
  notifyUser(u.id, 'role', 'Your account role changed', 'Your role is now: ' + finalRole + '.', '/account');
  return { role: finalRole };
});
api.post('/api/admin/users/:id/verify-email', { auth: 'user.manage' }, (ctx) => {
  const u = db.get('SELECT id FROM users WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!u) throw notFound('User not found.');
  db.run('UPDATE users SET email_verified_at = COALESCE(email_verified_at, ?), updated_at = ? WHERE id = ?', nowIso(), nowIso(), u.id);
  audit(ctx.user, 'user.email_verified_by_staff', 'user', u.id, null, ctx.ip);
  return {};
});
// Manual plan grant (used after a customer emails QYRRAVO and the payment was received outside the site). days=0 removes a granted plan.
api.post('/api/admin/users/:id/plan', { auth: 'settings.manage' }, (ctx) => {
  const u = db.get('SELECT * FROM users WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!u || u.status === 'deleted') throw notFound('User not found.');
  const planId = oneOf(ctx.body.planId, ['free', 'premium', 'vip'], 'plan');
  const t = nowIso();
  const existing = db.get('SELECT * FROM subscriptions WHERE user_id = ?', u.id);
  if (planId === 'free') {
    if (existing) db.run("UPDATE subscriptions SET plan_id = 'free', status = 'expired', current_period_end = ?, updated_at = ? WHERE id = ?", t, t, existing.id);
  } else {
    const days = int(ctx.body.days === undefined ? 30 : ctx.body.days, { min: 1, max: 3650, field: 'days' });
    const end = addDays(t, days);
    if (existing) db.run("UPDATE subscriptions SET plan_id = ?, status = 'active', provider = 'manual', current_period_start = ?, current_period_end = ?, cancel_at_period_end = 1, updated_at = ? WHERE id = ?", planId, t, end, t, existing.id);
    else db.run("INSERT INTO subscriptions (user_id, plan_id, status, provider, current_period_start, current_period_end, cancel_at_period_end, created_at, updated_at) VALUES (?,?, 'active', 'manual', ?, ?, 1, ?, ?)", u.id, planId, t, end, t, t);
  }
  audit(ctx.user, 'plan.granted', 'user', u.id, { planId, days: ctx.body.days }, ctx.ip);
  notifyUser(u.id, 'plan', 'Your plan was updated', 'Your plan is now: ' + planId + '.', '/dashboard/plan');
  return {};
});
api.post('/api/admin/users/:id/suspend', { auth: 'user.manage' }, (ctx) => {
  const u = db.get('SELECT * FROM users WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!u) throw notFound('User not found.');
  if (u.role === 'admin' || u.id === ctx.user.id) throw forbidden('This account cannot be suspended here.');
  const reason = text(ctx.body.reason, { min: 3, max: 300, field: 'Reason' });
  db.run("UPDATE users SET status = 'suspended', suspended_reason = ?, updated_at = ? WHERE id = ? AND status = 'active'", reason, nowIso(), u.id);
  auth.destroyAllSessions(u.id);
  audit(ctx.user, 'user.suspended', 'user', u.id, { reason }, ctx.ip);
  return {};
});
// Delete an account. Personal details are erased and the email is freed so it can be used to sign up again.
api.post('/api/admin/users/:id/delete', { auth: 'user.manage' }, (ctx) => {
  const u = db.get('SELECT * FROM users WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!u || u.status === 'deleted') throw notFound('User not found.');
  if (u.is_owner || u.id === ctx.user.id) throw forbidden('This account cannot be deleted.');
  if (u.role === 'admin' && !ctx.user.isOwner) throw forbidden('Only the owner can delete an administrator.');
  const open = db.get("SELECT COUNT(*) AS n FROM orders WHERE (buyer_id = ? OR seller_id = ?) AND status IN ('pending_payment','paid','shipped','delivered','disputed')", u.id, u.id).n;
  if (open) throw conflict('open_orders', 'This user has open orders. Finish or cancel them first.');
  db.tx(() => {
    db.run("UPDATE products SET status = CASE WHEN status = 'approved' THEN 'suspended' ELSE status END, deleted_at = ?, updated_at = ? WHERE seller_id = ? AND deleted_at IS NULL", nowIso(), nowIso(), u.id);
    db.run("UPDATE users SET status = 'deleted', email = ?, display_name = 'Deleted user', password_hash = 'x', country = NULL, email_verified_at = NULL, role = CASE WHEN role = 'admin' THEN 'buyer' ELSE role END, updated_at = ? WHERE id = ?", 'deleted-' + u.id + '@deleted.invalid', nowIso(), u.id);
    db.run('DELETE FROM sessions WHERE user_id = ?', u.id); db.run('DELETE FROM notifications WHERE user_id = ?', u.id); db.run('DELETE FROM wishlist WHERE user_id = ?', u.id);
    db.run("UPDATE seller_profiles SET seller_status = 'suspended', bio = NULL, contact_email = NULL WHERE user_id = ?", u.id);
    db.run("UPDATE subscriptions SET status = 'expired', updated_at = ? WHERE user_id = ?", nowIso(), u.id);
    audit(ctx.user, 'user.deleted_by_staff', 'user', u.id, { email: u.email }, ctx.ip);
  });
  return {};
});
api.post('/api/admin/users/:id/restore', { auth: 'user.manage' }, (ctx) => {
  const u = db.get('SELECT * FROM users WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!u || u.status !== 'suspended') throw conflict('bad_state', 'Only suspended accounts can be restored.');
  db.run("UPDATE users SET status = 'active', suspended_reason = NULL, updated_at = ? WHERE id = ?", nowIso(), u.id);
  audit(ctx.user, 'user.restored', 'user', u.id, null, ctx.ip);
  return {};
});

api.get('/api/admin/sellers', { auth: 'seller.manage' }, (ctx) => ({
  sellers: db.all(`SELECT sp.*, u.email, u.status AS user_status,
    (SELECT COUNT(*) FROM products p WHERE p.seller_id = sp.user_id AND p.status = 'approved' AND p.deleted_at IS NULL) AS live,
    (SELECT COUNT(*) FROM products p WHERE p.seller_id = sp.user_id AND p.deleted_at IS NULL) AS total
    FROM seller_profiles sp JOIN users u ON u.id = sp.user_id ORDER BY sp.created_at DESC LIMIT ?`, limit(ctx)).map((s) => ({
    id: s.user_id, shopName: s.shop_name, email: s.email, country: s.country, sellerStatus: s.seller_status, userStatus: s.user_status, payoutStatus: s.payout_status, live: s.live, total: s.total, createdAt: s.created_at,
  })),
}));
api.post('/api/admin/sellers/:id/suspend', { auth: 'seller.manage' }, (ctx) => {
  const reason = text(ctx.body.reason, { min: 3, max: 300, field: 'Reason' });
  const r = db.run("UPDATE seller_profiles SET seller_status = 'suspended', suspended_reason = ? WHERE user_id = ? AND seller_status = 'active'", reason, int(ctx.params.id, { min: 1 }));
  if (!r.changes) throw conflict('bad_state', 'Seller not found or already suspended.');
  audit(ctx.user, 'seller.suspended', 'user', ctx.params.id, { reason }, ctx.ip);
  notifyUser(int(ctx.params.id, { min: 1 }), 'seller_suspended', 'Seller account suspended', reason, '/dashboard');
  return {};
});
api.post('/api/admin/sellers/:id/restore', { auth: 'seller.manage' }, (ctx) => {
  const r = db.run("UPDATE seller_profiles SET seller_status = 'active', suspended_reason = NULL WHERE user_id = ? AND seller_status = 'suspended' AND EXISTS (SELECT 1 FROM users u WHERE u.id = user_id AND u.status = 'active')", int(ctx.params.id, { min: 1 }));
  if (!r.changes) throw conflict('bad_state', 'Seller not found, not suspended, or the user account is not active.');
  audit(ctx.user, 'seller.restored', 'user', ctx.params.id, null, ctx.ip);
  return {};
});

// ---------------- listings: staff can edit or delete anyone's listing ----------------
const PROD_COLS = 'p.id, p.name, p.status, p.price_minor, p.currency, p.price_usd_minor, p.quantity, p.seller_id, p.updated_at, sp.shop_name, u.email AS seller_email';
api.get('/api/admin/products', { auth: 'product.manage' }, (ctx) => {
  const q = String(ctx.query.q || '').toLowerCase().slice(0, 80).replace(/[%_]/g, '');
  const rows = db.all(`SELECT ${PROD_COLS} FROM products p JOIN users u ON u.id = p.seller_id LEFT JOIN seller_profiles sp ON sp.user_id = p.seller_id WHERE p.deleted_at IS NULL AND (? = '' OR LOWER(p.name) LIKE ? OR LOWER(u.email) LIKE ? OR LOWER(COALESCE(sp.shop_name,'')) LIKE ?) ORDER BY p.updated_at DESC LIMIT ?`, q, '%' + q + '%', '%' + q + '%', '%' + q + '%', limit(ctx));
  return { products: rows.map((p) => ({ id: p.id, name: p.name, status: p.status, priceMinor: p.price_minor, currency: p.currency, priceUsdMinor: p.price_usd_minor, quantity: p.quantity, sellerId: p.seller_id, shopName: p.shop_name, sellerEmail: p.seller_email, updatedAt: p.updated_at })) };
});
api.get('/api/admin/products/:id', { auth: 'product.manage' }, (ctx) => {
  const p = db.get('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
  if (!p) throw notFound('Listing not found.');
  return { product: { id: p.id, name: p.name, description: p.description, brand: p.brand, model: p.model, condition: p.condition, quantity: p.quantity, status: p.status, price: p.price_minor === null ? null : { minor: p.price_minor, currency: p.currency }, shippingFee: p.shipping_fee_minor } };
});
api.patch('/api/admin/products/:id', { auth: 'product.manage' }, (ctx) => {
  const p = db.get('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
  if (!p) throw notFound('Listing not found.');
  const allowed = {};
  for (const k of ['name', 'description', 'brand', 'model', 'condition', 'quantity', 'price', 'currency', 'shippingFee']) if (ctx.body[k] !== undefined) allowed[k] = ctx.body[k];
  if (allowed.price !== undefined && allowed.currency === undefined) allowed.currency = p.currency;
  const out = listings.normalize(allowed);
  if (out.quantity !== undefined && out.quantity < p.quantity_reserved) throw conflict('quantity_reserved', 'Some units are reserved by buyers. The quantity cannot go below ' + p.quantity_reserved + '.');
  const keys = Object.keys(out);
  if (!keys.length) throw bad('validation', 'Nothing to update.');
  db.run('UPDATE products SET ' + keys.map((k) => k + ' = ?').join(', ') + ', updated_at = ? WHERE id = ?', ...keys.map((k) => out[k]), nowIso(), p.id);
  audit(ctx.user, 'product.edited_by_staff', 'product', p.id, allowed, ctx.ip);
  notifyUser(p.seller_id, 'product', 'A listing of yours was edited by QYRRAVO staff', '"' + p.name + '" was updated. Contact ' + config.supportEmail + ' if you have questions.', '/dashboard/products');
  return {};
});
api.delete('/api/admin/products/:id', { auth: 'product.manage' }, (ctx) => {
  const p = db.get('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL', int(ctx.params.id, { min: 1 }));
  if (!p) throw notFound('Listing not found.');
  const reason = text(ctx.body.reason, { min: 3, max: 300, field: 'Reason' });
  db.run("UPDATE products SET deleted_at = ?, status = CASE WHEN status = 'approved' THEN 'suspended' ELSE status END, updated_at = ? WHERE id = ?", nowIso(), nowIso(), p.id);
  audit(ctx.user, 'product.deleted_by_staff', 'product', p.id, { name: p.name, reason }, ctx.ip);
  notifyUser(p.seller_id, 'product', 'A listing of yours was removed', '"' + p.name + '" was removed by QYRRAVO staff. Reason: ' + reason, '/dashboard/products');
  return {};
});

// ---------------- settings, plans, rates ----------------
const B = (v, f) => { if (typeof v !== 'boolean') throw bad('validation', f + ' must be true or false.', { field: f }); return v; };
const codes = (arr, f) => { if (!Array.isArray(arr) || !arr.length) throw bad('validation', f + ' must be a non-empty list.', { field: f }); return [...new Set(arr.map((x) => String(x).toUpperCase()))]; };
const VALIDATORS = {
  commission_bps: (v) => int(v, { min: 0, max: 3000, field: 'commission_bps' }),
  commission_fixed_usd_minor: (v) => int(v, { min: 0, max: 100000, field: 'commission_fixed_usd_minor' }),
  commission_base: (v) => oneOf(v, ['items', 'items_and_shipping'], 'commission_base'),
  supported_currencies: (v) => { const a = codes(v, 'supported_currencies'); if (!a.includes('USD')) throw bad('validation', 'USD must stay supported.'); for (const c of a) if (!/^[A-Z]{3}$/.test(c) || !settings.getRate(c)) throw bad('validation', 'No exchange rate is stored for ' + c + '. Add a rate first.', { field: 'supported_currencies' }); return a; },
  enabled_countries: (v) => { const a = codes(v, 'enabled_countries'); const valid = new Set(settings.COUNTRIES.map((c) => c.code)); for (const c of a) if (!valid.has(c)) throw bad('validation', 'Unknown country ' + c); return a; },
  payout_countries: (v) => { const a = codes(v, 'payout_countries'); const valid = new Set(settings.COUNTRIES.map((c) => c.code)); for (const c of a) if (!valid.has(c)) throw bad('validation', 'Unknown country ' + c); return a; },
  checkout_enabled: (v) => B(v, 'checkout_enabled'),
  refund_window_days: (v) => int(v, { min: 0, max: 180, field: 'refund_window_days' }),
  auto_complete_days: (v) => int(v, { min: 1, max: 90, field: 'auto_complete_days' }),
  complete_after_delivered_days: (v) => int(v, { min: 0, max: 30, field: 'complete_after_delivered_days' }),
  reservation_minutes: (v) => int(v, { min: 5, max: 240, field: 'reservation_minutes' }),
  code_ttl_minutes: (v) => int(v, { min: 5, max: 1440, field: 'code_ttl_minutes' }),
  max_images: (v) => int(v, { min: 1, max: 20, field: 'max_images' }),
  max_image_bytes: (v) => int(v, { min: 100000, max: 8 * 1048576, field: 'max_image_bytes' }),
  min_image_px: (v) => int(v, { min: 200, max: 3000, field: 'min_image_px' }),
  fx_max_age_hours: (v) => int(v, { min: 1, max: 720, field: 'fx_max_age_hours' }),
  billing_currency: (v) => { if (!settings.get('supported_currencies').includes(v)) throw bad('validation', 'Billing currency must be a supported currency.'); return v; },
  cancellation_rules: (v) => text(v, { min: 10, max: 1000, field: 'cancellation_rules', multiline: true }),
  refund_rules: (v) => text(v, { min: 10, max: 1000, field: 'refund_rules', multiline: true }),
};
function settingsView() {
  return { settings: settings.all(), plans: settings.getPlans(), categories: db.all('SELECT * FROM categories ORDER BY COALESCE(parent_id, id), parent_id IS NOT NULL, sort'), prohibited: db.all('SELECT id, keyword, reason FROM prohibited_items ORDER BY keyword'),
    rates: db.all('SELECT currency, rate_per_usd AS ratePerUsd, source, fetched_at AS fetchedAt FROM fx_rates ORDER BY currency'), countries: settings.COUNTRIES };
}
api.get('/api/admin/settings', { auth: 'settings.manage' }, () => settingsView());
api.patch('/api/admin/settings', { auth: 'settings.manage' }, (ctx) => {
  const b = ctx.body; const changes = {};
  for (const [k, v] of Object.entries(b)) {
    if (k === 'confirmCommission') continue;
    if (!VALIDATORS[k]) throw bad('validation', 'Unknown or protected setting: ' + k, { field: k });
    const nv = VALIDATORS[k](v);
    const old = settings.get(k);
    if (JSON.stringify(old) !== JSON.stringify(nv)) changes[k] = { from: old, to: nv };
  }
  db.tx(() => {
    for (const [k, c] of Object.entries(changes)) settings.set(k, c.to, ctx.user.id);
    if (b.confirmCommission === true) { settings.set('commission_is_placeholder', false, ctx.user.id); changes.commission_is_placeholder = { from: true, to: false }; }
    if (Object.keys(changes).length) audit(ctx.user, 'settings.changed', 'settings', null, changes, ctx.ip);
  });
  return { ...settingsView(), changed: Object.keys(changes) };
});
api.patch('/api/admin/plans/:id', { auth: 'settings.manage' }, (ctx) => {
  const plan = settings.getPlan(ctx.params.id);
  if (!plan) throw notFound('Plan not found.');
  const b = ctx.body; const sets = []; const vals = [];
  if (b.name !== undefined) { sets.push('name = ?'); vals.push(text(b.name, { min: 2, max: 40, field: 'name' })); }
  if (b.priceMinor !== undefined) {
    const v = int(b.priceMinor, { min: plan.id === 'free' ? 0 : 100, max: plan.id === 'free' ? 0 : 10000000, field: 'priceMinor' });
    sets.push('price_minor = ?'); vals.push(v);
  }
  if (b.maxItemUsdMinor !== undefined) {
    const v = int(b.maxItemUsdMinor, { min: 100, max: 100000000, field: 'maxItemUsdMinor' });
    // limits must keep their order: Free <= Premium <= VIP (by plan sort order)
    const all = settings.getPlans();
    const lower = all.filter((x) => x.sort < plan.sort); const higher = all.filter((x) => x.sort > plan.sort);
    if (lower.some((x) => v < x.max_item_price_usd_minor)) throw bad('validation', 'This limit cannot be lower than the ' + lower.map((x) => x.name).join(' / ') + ' limit.', { field: 'maxItemUsdMinor' });
    if (higher.some((x) => v > x.max_item_price_usd_minor)) throw bad('validation', 'This limit cannot be higher than the ' + higher.map((x) => x.name).join(' / ') + ' limit.', { field: 'maxItemUsdMinor' });
    sets.push('max_item_price_usd_minor = ?'); vals.push(v);
  }
  if (b.maxActiveListings !== undefined) { sets.push('max_active_listings = ?'); vals.push(int(b.maxActiveListings, { min: 1, max: 1000, field: 'maxActiveListings' })); }
  if (b.maxQuantity !== undefined) { sets.push('max_quantity = ?'); vals.push(int(b.maxQuantity, { min: 1, max: 10000, field: 'maxQuantity' })); }
  if (b.active !== undefined) { if (plan.id === 'free' && b.active === false) throw bad('validation', 'The Free plan cannot be switched off.'); sets.push('active = ?'); vals.push(B(b.active, 'active') ? 1 : 0); }
  if (!sets.length) throw bad('validation', 'Nothing to update.');
  db.run('UPDATE plans SET ' + sets.join(', ') + ', updated_at = ? WHERE id = ?', ...vals, nowIso(), plan.id);
  audit(ctx.user, 'plan.changed', 'plan', plan.id, b, ctx.ip);
  return settingsView();
});
api.post('/api/admin/fx', { auth: 'settings.manage' }, (ctx) => {
  const cur = String(ctx.body.currency || '').toUpperCase();
  if (!/^[A-Z]{3}$/.test(cur) || cur === 'USD') throw bad('validation', 'Enter a 3-letter currency code (not USD).', { field: 'currency' });
  const rate = Number(ctx.body.ratePerUsd);
  if (!(rate > 0.0001 && rate < 1e7)) throw bad('validation', 'Enter how many units of the currency equal 1 USD.', { field: 'ratePerUsd' });
  db.run('INSERT INTO fx_rates (currency, rate_per_usd, source, fetched_at) VALUES (?,?,?,?) ON CONFLICT(currency) DO UPDATE SET rate_per_usd=excluded.rate_per_usd, source=excluded.source, fetched_at=excluded.fetched_at', cur, rate, 'manual:admin-' + ctx.user.id, nowIso());
  audit(ctx.user, 'fx.set', 'fx', cur, { rate }, ctx.ip);
  return settingsView();
});
api.post('/api/admin/categories', { auth: 'category.manage' }, (ctx) => {
  const name = text(ctx.body.name, { min: 2, max: 60, field: 'Name' });
  const parent = ctx.body.parentId ? int(ctx.body.parentId, { min: 1, field: 'parentId' }) : null;
  if (parent && !db.get('SELECT 1 AS x FROM categories WHERE id = ? AND parent_id IS NULL', parent)) throw bad('validation', 'Parent category not found.');
  const slug = (parent ? db.get('SELECT slug FROM categories WHERE id = ?', parent).slug + '-' : '') + name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  if (db.get('SELECT 1 AS x FROM categories WHERE slug = ?', slug)) throw conflict('exists', 'A category with that name already exists.');
  const r = db.run('INSERT INTO categories (slug, name, parent_id, active, sort) VALUES (?,?,?,1,?)', slug, name, parent, 100);
  audit(ctx.user, 'category.created', 'category', r.id, { name, parent }, ctx.ip);
  return { id: r.id };
});
api.patch('/api/admin/categories/:id', { auth: 'category.manage' }, (ctx) => {
  const c = db.get('SELECT * FROM categories WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!c) throw notFound('Category not found.');
  if (ctx.body.name !== undefined) db.run('UPDATE categories SET name = ? WHERE id = ?', text(ctx.body.name, { min: 2, max: 60, field: 'Name' }), c.id);
  if (ctx.body.active !== undefined) db.run('UPDATE categories SET active = ? WHERE id = ?', B(ctx.body.active, 'active') ? 1 : 0, c.id);
  audit(ctx.user, 'category.changed', 'category', c.id, ctx.body, ctx.ip);
  return {};
});
api.post('/api/admin/prohibited', { auth: 'category.manage' }, (ctx) => {
  const keyword = text(ctx.body.keyword, { min: 3, max: 60, field: 'Keyword' }).toLowerCase();
  const reason = text(ctx.body.reason, { min: 5, max: 200, field: 'Reason' });
  try { db.run('INSERT INTO prohibited_items (keyword, reason, created_at) VALUES (?,?,?)', keyword, reason, nowIso()); } catch (e) { if (/UNIQUE/.test(String(e.message))) throw conflict('exists', 'That keyword is already listed.'); throw e; }
  audit(ctx.user, 'prohibited.added', 'prohibited', keyword, { reason }, ctx.ip);
  return {};
});
api.delete('/api/admin/prohibited/:id', { auth: 'category.manage' }, (ctx) => {
  db.run('DELETE FROM prohibited_items WHERE id = ?', int(ctx.params.id, { min: 1 }));
  audit(ctx.user, 'prohibited.removed', 'prohibited', ctx.params.id, null, ctx.ip);
  return {};
});

// ---------------- finance ----------------
api.get('/api/admin/finance', { auth: 'finance.view' }, () => {
  const pending = db.all("SELECT currency, kind, COUNT(*) AS n, SUM(amount_minor) AS total FROM payments WHERE status = 'pending' GROUP BY currency, kind");
  const owed = db.all('SELECT currency, SUM(earned_net_minor) AS s FROM seller_balances GROUP BY currency');
  const paid = db.all("SELECT currency, COALESCE(SUM(amount_minor),0) AS s FROM payouts WHERE status IN ('requested','processing','paid') GROUP BY currency");
  return {
    ledger: ledger.summary(),
    pendingNotIncome: pending.map((p) => ({ currency: p.currency, kind: p.kind, count: p.n, totalMinor: p.total })),
    sellerAmountsOwed: owed.map((o) => ({ currency: o.currency, earnedNetMinor: o.s, committedToPayoutsMinor: (paid.find((x) => x.currency === o.currency) || { s: 0 }).s })),
    notes: [
      'Revenue = confirmed subscription payments + earned commissions. Pending payments and unfinished orders are NOT revenue.',
      'Gross order money belongs to sellers until completion; only the commission is platform revenue.',
      'Provider processing fees are only recorded when the provider reports them in a verified webhook.',
      'Totals are per currency and are never added together.',
    ],
    commissionIsPlaceholder: !!settings.get('commission_is_placeholder'),
  };
});
api.get('/api/admin/payments', { auth: 'finance.view' }, (ctx) => ({ payments: db.all('SELECT id, kind, user_id AS userId, order_id AS orderId, subscription_id AS subscriptionId, amount_minor AS amountMinor, currency, status, provider, refunded_minor AS refundedMinor, provider_fee_minor AS providerFeeMinor, failure_reason AS failureReason, created_at AS createdAt, confirmed_at AS confirmedAt FROM payments ORDER BY id DESC LIMIT ?', limit(ctx)) }));
api.get('/api/admin/orders', { auth: 'finance.view' }, (ctx) => ({ orders: db.all('SELECT * FROM orders ORDER BY id DESC LIMIT ?', limit(ctx)).map((o) => ({ ...orders.view(o, false), commissionMinor: o.commission_minor, commissionReversedMinor: o.commission_reversed_minor })) }));
api.get('/api/admin/payouts', { auth: 'payout.manage' }, (ctx) => ({
  payouts: db.all('SELECT p.*, sp.shop_name FROM payouts p JOIN seller_profiles sp ON sp.user_id = p.seller_id ORDER BY p.id DESC LIMIT ?', limit(ctx)).map((p) => ({ id: p.id, sellerId: p.seller_id, shopName: p.shop_name, currency: p.currency, amountMinor: p.amount_minor, status: p.status, failureReason: p.failure_reason, createdAt: p.created_at, paidAt: p.paid_at })),
  sellersWithBalance: db.all('SELECT sb.seller_id AS sellerId, sp.shop_name AS shopName, sp.payout_status AS payoutStatus, sb.currency FROM seller_balances sb JOIN seller_profiles sp ON sp.user_id = sb.seller_id WHERE sb.earned_net_minor > 0').map((r) => ({ ...r, availableMinor: payouts.available(r.sellerId, r.currency) })).filter((r) => r.availableMinor > 0),
}));
api.post('/api/admin/payouts', { auth: 'payout.manage' }, async (ctx) => {
  const p = await payouts.create(ctx.user, int(ctx.body.sellerId, { min: 1, field: 'sellerId' }), String(ctx.body.currency || '').toUpperCase());
  return { payout: { id: p.id, status: p.status, amountMinor: p.amount_minor, currency: p.currency } };
});
api.post('/api/admin/payouts/:id/simulate', { auth: 'payout.manage' }, (ctx) => {
  sim.assertSimulator();
  const p = db.get('SELECT * FROM payouts WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!p) throw notFound('Payout not found.');
  return { result: sim.emit(ctx.body.outcome === 'failed' ? 'payout.failed' : 'payout.paid', { payout_id: p.id, provider_payout_ref: p.provider_payout_ref, reason: 'Simulated failure' }), note: 'TEST MODE: no real money moved.' };
});
api.post('/api/admin/orders/:id/refund', { auth: 'refund.issue' }, async (ctx) => {
  const o = db.get('SELECT * FROM orders WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!o) throw notFound('Order not found.');
  const amount = ctx.body.amountMinor === undefined ? o.total_minor - o.refunded_minor : ctx.body.amountMinor;
  const r = await orders.requestRefund(ctx.user, o.id, amount, ctx.body.reason);
  return { refund: { id: r.id, status: r.status, amountMinor: r.amount_minor }, note: 'The refund is only booked when the payment provider confirms it.' };
});
api.get('/api/admin/refunds', { auth: 'refund.issue' }, (ctx) => ({ refunds: db.all('SELECT id, order_id AS orderId, payment_id AS paymentId, amount_minor AS amountMinor, currency, status, reason, created_at AS createdAt FROM refunds ORDER BY id DESC LIMIT ?', limit(ctx)) }));
api.post('/api/admin/refunds/:id/simulate', { auth: 'refund.issue' }, (ctx) => {
  sim.assertSimulator();
  const r = db.get('SELECT * FROM refunds WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!r) throw notFound('Refund not found.');
  return { result: sim.emit(ctx.body.outcome === 'failed' ? 'refund.failed' : 'refund.succeeded', { refund_id: r.id, provider_refund_ref: r.provider_refund_ref }), note: 'TEST MODE: no real money moved.' };
});

// ---------------- disputes ----------------
api.get('/api/admin/disputes', { auth: 'dispute.handle' }, (ctx) => ({ disputes: db.all('SELECT d.*, o.order_no, o.total_minor, o.currency, o.refunded_minor FROM disputes d JOIN orders o ON o.id = d.order_id ORDER BY d.id DESC LIMIT ?', limit(ctx)).map((d) => ({ id: d.id, orderId: d.order_id, orderNo: d.order_no, source: d.source, reason: d.reason, status: d.status, totalMinor: d.total_minor, refundedMinor: d.refunded_minor, currency: d.currency, createdAt: d.created_at, note: d.resolution_note })) }));
api.post('/api/admin/disputes/:id/resolve', { auth: 'dispute.handle' }, async (ctx) => {
  const d = db.get('SELECT * FROM disputes WHERE id = ?', int(ctx.params.id, { min: 1 }));
  if (!d) throw notFound('Dispute not found.');
  if (d.status !== 'open') throw conflict('bad_state', 'This dispute is already closed.');
  if (d.source === 'provider') throw conflict('provider_dispute', 'Provider disputes (chargebacks) are closed by the provider\'s own notification, not manually.');
  const outcome = oneOf(ctx.body.outcome, ['buyer', 'seller'], 'outcome');
  const note = text(ctx.body.note, { min: 5, max: 1000, field: 'Resolution note', multiline: true });
  const o = db.get('SELECT * FROM orders WHERE id = ?', d.order_id);
  let refund = null;
  if (outcome === 'buyer') {
    const amount = ctx.body.refundAmountMinor === undefined ? o.total_minor - o.refunded_minor : ctx.body.refundAmountMinor;
    refund = await orders.requestRefund(ctx.user, o.id, amount, 'Dispute resolved for buyer: ' + note.slice(0, 200));
  }
  db.tx(() => {
    db.run('UPDATE disputes SET status = ?, resolution_note = ?, resolved_by = ?, resolved_at = ? WHERE id = ?', outcome === 'buyer' ? 'resolved_buyer' : 'resolved_seller', note, ctx.user.id, nowIso(), d.id);
    const cur = db.get('SELECT * FROM orders WHERE id = ?', o.id);
    if (cur.status === 'disputed') orders.setStatus(cur, cur.completed_at ? 'completed' : cur.delivered_at ? 'delivered' : cur.shipped_at ? 'shipped' : 'paid');
    audit(ctx.user, 'dispute.resolved', 'dispute', d.id, { outcome, note }, ctx.ip);
  });
  notifyUser(o.buyer_id, 'dispute', 'Dispute update for ' + o.order_no, outcome === 'buyer' ? 'Resolved in your favour. A refund was requested and will be confirmed by the payment provider.' : 'The review has finished without a refund.', '/orders/' + o.id);
  notifyUser(o.seller_id, 'dispute', 'Dispute update for ' + o.order_no, outcome === 'seller' ? 'Resolved in your favour.' : 'Resolved for the buyer. A refund was requested.', '/dashboard/orders');
  return { refund: refund ? { id: refund.id, amountMinor: refund.amount_minor } : null };
});

// ---------------- logs & monitoring ----------------
api.get('/api/admin/audit', { auth: 'audit.view' }, (ctx) => {
  const before = parseInt(ctx.query.before, 10) || 1e15;
  const act = String(ctx.query.action || '').slice(0, 40);
  return { logs: db.all("SELECT * FROM audit_logs WHERE id < ? AND (? = '' OR action LIKE ?) ORDER BY id DESC LIMIT ?", before, act, act + '%', limit(ctx, 100)).map((l) => ({ id: l.id, actorId: l.actor_id, actorRole: l.actor_role, action: l.action, targetType: l.target_type, targetId: l.target_id, detail: parseJson(l.detail, null), createdAt: l.created_at })) };
});
api.get('/api/admin/errors', { auth: 'audit.view' }, (ctx) => ({ errors: db.all('SELECT * FROM error_log ORDER BY id DESC LIMIT ?', limit(ctx)) }));
api.get('/api/admin/webhooks', { auth: 'audit.view' }, (ctx) => ({ events: db.all('SELECT id, provider, event_id AS eventId, type, status, error, received_at AS receivedAt FROM webhook_events ORDER BY id DESC LIMIT ?', limit(ctx)) }));
api.get('/api/admin/emails', { auth: 'audit.view' }, (ctx) => ({ emailProvider: config.emailProvider, emails: db.all('SELECT id, to_email AS toEmail, subject, template, status, error, created_at AS createdAt FROM email_outbox ORDER BY id DESC LIMIT ?', limit(ctx)) }));

module.exports = {};
