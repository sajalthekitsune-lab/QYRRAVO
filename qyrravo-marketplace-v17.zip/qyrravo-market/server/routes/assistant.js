'use strict';
// Help assistant. If ANTHROPIC_API_KEY is set on the server it asks Claude (key stays server-side).
// Otherwise it answers from a built-in list. Either way it tells the person when it is not sure and gives the contact email.
const config = require('../config');
const settings = require('../settings');
const { api } = require('../http');
const { bad } = require('../util');

const MAIL = config.supportEmail;
function facts() {
  const plans = settings.getPlans().filter((p) => p.active).map((p) => `${p.name}: $${(p.price_minor / 100).toFixed(0)}/month, items up to $${(p.max_item_price_usd_minor / 100).toLocaleString('en-US')} each, ${p.max_active_listings} item(s) for sale at a time`).join('; ');
  return `QYRRAVO ("Quietly Better.") is an international marketplace run by Sajal Dhungana (owner, from Nepal, lives in Qatar). Contact: ${MAIL}.
Plans: ${plans}. Admins/owner get VIP free.
QYRRAVO accepts cash or card for Q Coins and paid plans bought from the owner, arranged by email (the website itself never takes card details).\nBuying: items and paid plans are arranged by email. The customer emails ${MAIL} (the site prepares the email) and QYRRAVO replies with the next steps. Never ask for card numbers.
Selling: create an account, verify email, become a seller, add a listing with photos (front/back camera or upload), take the verification photo showing the code, a moderator reviews it, then it goes live. Photo review does not prove authenticity.
Prices can be shown in many currencies as estimates.
Game: QYRRAVO Drive is a free 3D driving game; each completed lap (about 40 minutes) earns 20 Q Coins with a daily limit, measured by the server.`;
}

const FAQ = [
  [/\b(premium|vip|plan|upgrade|subscription|subscribe)\b/, () => { const p = settings.getPlans().filter((x) => x.active).map((x) => `${x.name} ($${(x.price_minor / 100).toFixed(0)}/mo, items up to $${(x.max_item_price_usd_minor / 100).toLocaleString('en-US')})`).join(', '); return `Plans: ${p}. Every plan lets you have one listing at a time; Premium can hold up to 10 identical units in stock and VIP up to 100, and a higher plan raises the maximum price. To get Premium or VIP, press Choose on the Plan page and email ${MAIL}; we reply with how to pay and then switch it on.`; }],
  [/\b(buy|purchase|order|checkout|pay|payment)\b/, () => `To buy an item, press Buy and the site prepares an email to ${MAIL} with the item, price and your country. Send it and QYRRAVO will reply with the next steps. Q Coins and Premium or VIP plans can be paid by cash or card, arranged by email. Please never send card numbers by email.`],
  [/\b(sell|seller|list|listing|add (an )?item|upload)\b/, () => 'To sell: create an account, verify your email, open Sell and set up your shop, then add a listing with photos. You can take photos with the front or back camera. You also take a verification photo showing the code we give you. A moderator reviews it and then it goes live.'],
  [/\b(camera|photo|picture|verification|code)\b/, () => 'Use the camera button in the listing form (choose front or back camera; it needs https or localhost and your permission). If the camera is blocked you can upload a photo instead. The verification photo must show the item next to the code shown on the page.'],
  [/\b(free|limit|max|maximum|price cap|\$100)\b/, () => 'Free: 1 item at a time, up to $100. Premium: 1 listing at a time with up to 10 identical units, up to $10,000 each. VIP: up to 100 identical units, up to $100,000 each. After an item sells you can list the next one.'],
  [/\b(owner|crown|who (are|is)|sajal|founder|about)\b/, () => `QYRRAVO is owned by Sajal Dhungana (from Nepal, lives in Qatar). Click or hover the 👑 next to the QYRRAVO name to see the owner card. Contact: ${MAIL}.`],
  [/\b(refund|return|cancel|dispute|problem|scam|fraud)\b/, () => `For refunds, returns, problems or suspected fraud email ${MAIL} with the item name and what happened. Meanwhile do not send money outside the arrangements QYRRAVO confirms by email.`],
  [/\b(account|password|login|log in|sign in|register|verify|email)\b/, () => `You can register with Join, sign in with Sign in, and verify your email from the link we send. If you forgot your password use "Forgot password". Still stuck? Email ${MAIL}.`],
  [/\b(country|currency|shipping|deliver|ship)\b/, () => 'Use the country and currency selectors at the top. Shipping depends on each seller (they list where they ship and the fee). Prices in other currencies are estimates.'],
  [/\b(game|drive|driving|car game|play)\b/, () => 'QYRRAVO Drive is a free 3D driving game (menu Community, Drive & earn). While you drive actively signed in with a verified email you earn 20 Q Coins per completed lap, up to a daily limit; you can pick a Lamborghini, Ferrari or Bugatti. The server measures the time. Q Coins are a wallet balance, not cash.'],
  [/\b(hi|hello|hey|salam|namaste)\b/, () => 'Hi! I am the QYRRAVO helper. Ask me about buying, selling, plans, photos or your account.'],
];
function faq(q) { const t = String(q).toLowerCase(); for (const [re, fn] of FAQ) if (re.test(t)) return fn(); return null; }
function builtIn(q) {
  const hit = faq(q); if (hit) return hit;
  return `I don't have a good answer to that. Please email ${MAIL} and we will reply. I can help with buying, selling, plans, photos and your account.`;
}

const sysPrompt = () => 'You are the assistant on the QYRRAVO marketplace website. Answer ANY question the person asks, on any topic from A to Z (shopping, tech, school, health basics, money, languages, coding, life advice, anything), fully and clearly, in the language they use. Be thorough when the question needs it. For questions about QYRRAVO itself use ONLY the facts below, and if something about QYRRAVO is not covered, say you are not sure and suggest emailing ' + MAIL + '. Never invent QYRRAVO prices, policies or availability. Never ask for passwords or card numbers. Be honest when you are unsure.\n\n' + facts();
async function askGemini(messages) {
  let last;
  for (const model of [...new Set([config.geminiModel, 'gemini-2.0-flash'])]) {
    try { return await askGeminiModel(model, messages); } catch (e) { last = e; console.error('assistant: gemini ' + model + ' failed: ' + e.message); }
  }
  throw last;
}
async function askGeminiModel(model, messages) {
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 9000);
  try {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {
      method: 'POST', signal: ctl.signal, headers: { 'content-type': 'application/json', 'x-goog-api-key': config.geminiKey },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: sysPrompt() }] }, contents: messages.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })), generationConfig: { maxOutputTokens: 700 } }),
    });
    if (!r.ok) throw new Error('status ' + r.status);
    const j = await r.json();
    const t = ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map((x) => x.text || '').join('').trim();
    if (!t) throw new Error('empty');
    return t;
  } finally { clearTimeout(to); }
}
async function askClaude(messages) {
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 9000);
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': config.anthropicKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: config.assistantModel, max_tokens: 700,
        system: 'You are the assistant on the QYRRAVO marketplace website. Answer ANY question the person asks, on any topic from A to Z (shopping, tech, school, health basics, money, languages, coding, life advice, anything), fully and clearly, in the language they use. Be thorough when the question needs it. For questions about QYRRAVO itself use ONLY the facts below, and if something about QYRRAVO is not covered, say you are not sure and suggest emailing ' + MAIL + '. Never invent QYRRAVO prices, policies or availability. Never ask for passwords or card numbers. Be honest when you are unsure.\n\n' + facts(),
        messages }),
    });
    if (!r.ok) throw new Error('status ' + r.status);
    const j = await r.json();
    const t = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n').trim();
    if (!t) throw new Error('empty');
    return t;
  } finally { clearTimeout(to); }
}

api.post('/api/assistant', { rate: 'assistant' }, async (ctx) => {
  const raw = Array.isArray(ctx.body.messages) ? ctx.body.messages.slice(-20) : null;
  if (!raw || !raw.length) throw bad('validation', 'Send a message.');
  const messages = raw.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 1000) })).filter((m) => m.content.trim());
  while (messages.length && messages[0].role !== 'user') messages.shift();
  const last = messages[messages.length - 1];
  if (!last || last.role !== 'user') throw bad('validation', 'Send a message.');
  if (last.content.length <= 40) { const quick = faq(last.content); if (quick) return { reply: quick, source: 'builtin' }; }   // short common questions are answered instantly
  if (config.geminiKey) {
    try { return { reply: await askGemini(messages), source: 'ai' }; } catch (e) { /* fall through */ }
  }
  if (config.anthropicKey) {
    try { return { reply: await askClaude(messages), source: 'ai' }; } catch (e) { /* fall through to the built-in answers */ }
  }
  return { reply: builtIn(last.content), source: 'builtin' };
});
module.exports = { builtIn };
