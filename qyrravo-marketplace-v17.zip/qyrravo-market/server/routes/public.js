'use strict';
const config = require('../config');
const db = require('../db');
const settings = require('../settings');
const listings = require('../listings');
const images = require('../images');
const payments = require('../payments');
const auth = require('../auth');
const { api } = require('../http');
const { notFound, int, parseJson } = require('../util');

function categoryTree() {
  const rows = db.all('SELECT * FROM categories WHERE active = 1 ORDER BY sort, id');
  return rows.filter((r) => !r.parent_id).map((p) => ({ id: p.id, slug: p.slug, name: p.name, children: rows.filter((c) => c.parent_id === p.id).map((c) => ({ id: c.id, slug: c.slug, name: c.name })) }));
}

api.get('/api/config', (ctx) => {
  const enabled = new Set(settings.get('enabled_countries'));
  const curs = settings.get('supported_currencies');
  const provider = payments.provider();
  const checkoutAvailable = !!provider && settings.get('checkout_enabled');
  return {
    site: { supportEmail: config.supportEmail, appUrl: config.appUrl, owner: { ...require('../owner').OWNER_PUBLIC, id: (db.get('SELECT id FROM users WHERE is_owner = 1 AND status = \'active\'') || {}).id || null }, assistantAi: !!(config.anthropicKey || config.geminiKey), googleLogin: !!(config.googleClientId && config.googleClientSecret) },
    countries: settings.COUNTRIES.map((c) => ({ code: c.code, name: c.name, currency: c.currency, restricted: c.restricted, enabled: enabled.has(c.code) })),
    currencies: curs,
    rates: curs.map((c) => settings.getRate(c)).filter(Boolean).map((r) => ({ currency: r.currency, ratePerUsd: r.rate, source: r.source, at: r.at, stale: r.stale })),
    categories: categoryTree(),
    plans: settings.getPlans().filter((p) => p.active).map((p) => ({ id: p.id, name: p.name, priceMinor: p.price_minor, currency: p.currency, maxItemUsdMinor: p.max_item_price_usd_minor, maxActiveListings: p.max_active_listings, maxQuantity: p.max_quantity, features: p.features })),
    fees: {
      commissionPercent: settings.get('commission_bps') / 100,
      commissionIsPlaceholder: !!settings.get('commission_is_placeholder'),
      fixedFeeUsdMinor: settings.get('commission_fixed_usd_minor'),
      base: settings.get('commission_base'),
      note: 'Marketplace fees are charged to sellers when an order completes. Buyers see the full price, shipping and total before they pay. Payment-provider and currency-conversion fees may also apply.',
    },
    payment: { mode: config.paymentMode, provider: provider ? provider.name : null, checkoutAvailable, simulator: !!(provider && provider.isSimulator), billingCurrency: settings.get('billing_currency') },
    rules: { refundWindowDays: settings.get('refund_window_days'), cancellation: settings.get('cancellation_rules'), refunds: settings.get('refund_rules'), maxImages: settings.get('max_images'), maxImageBytes: settings.get('max_image_bytes'), minImagePx: settings.get('min_image_px'), codeTtlMinutes: settings.get('code_ttl_minutes') },
  };
});

// ---- catalogue ----
const esc = (s) => String(s).replace(/[\\%_]/g, (m) => '\\' + m);

api.get('/api/products', (ctx) => {
  const q = ctx.query;
  const pub = listings.publicWhere('p');
  const where = [pub.sql]; const params = [...pub.params];
  if (q.ids) {
    const ids = String(q.ids).split(',').map((x) => parseInt(x, 10)).filter((x) => Number.isInteger(x) && x > 0).slice(0, 50);
    if (!ids.length) return { total: 0, page: 1, pageSize: 24, products: [] };
    where.push('p.id IN (' + ids.map(() => '?').join(',') + ')'); params.push(...ids);
  }
  if (q.q) {
    for (const w of String(q.q).toLowerCase().split(/\s+/).filter(Boolean).slice(0, 6)) {
      where.push("(LOWER(p.name) LIKE ? ESCAPE '\\' OR LOWER(COALESCE(p.brand,'')) LIKE ? ESCAPE '\\' OR LOWER(COALESCE(p.model,'')) LIKE ? ESCAPE '\\' OR LOWER(p.description) LIKE ? ESCAPE '\\' OR LOWER(COALESCE(c.name,'')) LIKE ? ESCAPE '\\')");
      const like = '%' + esc(w) + '%'; params.push(like, like, like, like, like);
    }
  }
  if (q.category) { where.push('c.slug = ?'); params.push(String(q.category)); }
  if (q.sub) { where.push('p.subcategory_id = ?'); params.push(parseInt(q.sub, 10) || 0); }
  if (['new', 'used', 'refurbished'].includes(q.condition)) { where.push('p.condition = ?'); params.push(q.condition); }
  if (q.sellerCountry) { where.push('p.seller_country = ?'); params.push(String(q.sellerCountry).toUpperCase().slice(0, 2)); }
  if (q.shipsTo) { where.push("(p.ships_to LIKE '%\"WORLD\"%' OR p.ships_to LIKE ?)"); params.push('%"' + String(q.shipsTo).toUpperCase().slice(0, 2) + '"%'); }
  if (q.inStock === '1') where.push('p.quantity - p.quantity_reserved > 0');
  if (q.min && Number(q.min) >= 0) { where.push('p.price_usd_minor >= ?'); params.push(Math.round(Number(q.min) * 100)); }
  if (q.max && Number(q.max) > 0) { where.push('p.price_usd_minor <= ?'); params.push(Math.round(Number(q.max) * 100)); }
  const order = { price_asc: 'p.price_usd_minor ASC, p.id DESC', price_desc: 'p.price_usd_minor DESC, p.id DESC', newest: 'p.approved_at DESC, p.id DESC' }[q.sort] || 'p.approved_at DESC, p.id DESC';
  const page = Math.max(1, parseInt(q.page, 10) || 1);
  const pageSize = Math.min(48, Math.max(1, parseInt(q.pageSize, 10) || 24));
  const base = `FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE ${where.join(' AND ')}`;
  const total = db.get(`SELECT COUNT(*) AS n ${base}`, ...params).n;
  const ids = db.all(`SELECT p.id ${base} ORDER BY ${order} LIMIT ? OFFSET ?`, ...params, pageSize, (page - 1) * pageSize).map((r) => r.id);
  const out = ids.map((id) => listings.toPublic(db.get(`${listings.SELECT_PUBLIC} WHERE p.id = ?`, id)));
  return { total, page, pageSize, products: out };
});

api.get('/api/products/:id', (ctx) => {
  const id = int(ctx.params.id, { min: 1, field: 'id' });
  const pub = listings.publicWhere('p');
  const row = db.get(`${listings.SELECT_PUBLIC} WHERE p.id = ? AND ${pub.sql}`, id, ...pub.params);
  if (!row) throw notFound('This listing is not available.');
  return { product: listings.toPublic(row) };
});

api.get('/api/sellers/:id', (ctx) => {
  const id = int(ctx.params.id, { min: 1, field: 'id' });
  const sp = db.get("SELECT sp.*, u.created_at AS joined FROM seller_profiles sp JOIN users u ON u.id = sp.user_id WHERE sp.user_id = ? AND sp.seller_status = 'active' AND u.status = 'active'", id);
  if (!sp) throw notFound('Seller not found.');
  const pub = listings.publicWhere('p');
  const rows = db.all(`${listings.SELECT_PUBLIC} WHERE p.seller_id = ? AND ${pub.sql} ORDER BY p.approved_at DESC LIMIT 48`, id, ...pub.params);
  return {
    seller: {
      id: sp.user_id, shopName: sp.shop_name, bio: sp.bio, country: sp.country, joinedAt: sp.joined,
      photoReviewedListings: rows.length,
      verification: { photoReviewedListings: rows.length, identityVerified: false, note: 'Photo review checks listing photos only. QYRRAVO does not currently verify seller identity or guarantee authenticity.' },
      contactEmail: ctx.user && sp.contact_email ? sp.contact_email : null,
    },
    products: rows.map(listings.toPublic),
  };
});

// ---- images: public only when the listing is public; verification photos are NEVER public ----
api.get('/media/:id', { rate: 'read' }, (ctx) => {
  const id = parseInt(ctx.params.id, 10);
  const img = Number.isInteger(id) ? db.get('SELECT * FROM product_images WHERE id = ?', id) : null;
  if (!img) throw notFound();
  const p = db.get('SELECT * FROM products WHERE id = ?', img.product_id);
  let allowed = false; let isPublic = false;
  if (img.kind !== 'verification') {
    const pub = listings.publicWhere('p');
    isPublic = !!db.get(`SELECT 1 AS x FROM products p WHERE p.id = ? AND ${pub.sql}`, p.id, ...pub.params);
    allowed = isPublic;
  }
  if (!allowed && ctx.user) allowed = ctx.user.id === p.seller_id || auth.can(ctx.user, 'product.review');
  if (!allowed && ctx.user && img.kind !== 'verification') { // buyers keep seeing images of items they ordered
    allowed = !!db.get('SELECT 1 AS x FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.buyer_id = ? AND oi.image_id = ?', ctx.user.id, img.id);
  }
  if (!allowed) throw notFound();
  const buf = images.read(img.file_key);
  if (!buf) throw notFound();
  return { __raw: true, status: 200, body: buf, headers: { 'Content-Type': img.mime, 'Content-Length': buf.length, 'Cache-Control': isPublic ? 'public, max-age=3600' : 'private, no-store', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox", 'Content-Disposition': 'inline' } };
});

module.exports = { categoryTree };
