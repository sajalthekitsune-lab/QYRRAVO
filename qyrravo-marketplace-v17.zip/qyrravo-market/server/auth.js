'use strict';
const crypto = require('crypto');
const config = require('./config');
const db = require('./db');
const { HttpError, bad, randomToken, sha256, nowIso, addDays, addMs, safeEqual } = require('./util');

// ---- passwords: scrypt with a random salt per user ----
const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };
function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16);
    crypto.scrypt(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p }, (err, key) => {
      if (err) return reject(err);
      resolve(['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64'), key.toString('base64')].join('$'));
    });
  });
}
function verifyPassword(password, stored) {
  return new Promise((resolve) => {
    const [alg, N, r, p, salt, hash] = String(stored).split('$');
    if (alg !== 'scrypt') return resolve(false);
    crypto.scrypt(password, Buffer.from(salt, 'base64'), Buffer.from(hash, 'base64').length, { N: +N, r: +r, p: +p }, (err, key) => {
      if (err) return resolve(false);
      resolve(crypto.timingSafeEqual(key, Buffer.from(hash, 'base64')));
    });
  });
}
const COMMON = new Set(['password', 'password1', 'password123', '1234567890', 'qwertyuiop', 'letmein123', 'iloveyou123', 'welcome123', 'qyrravo123', 'admin12345']);
function checkPassword(pw, email) {
  if (typeof pw !== 'string' || pw.length < 10) throw bad('weak_password', 'Password must be at least 10 characters.', { field: 'password' });
  if (pw.length > 200) throw bad('weak_password', 'Password is too long.', { field: 'password' });
  if (COMMON.has(pw.toLowerCase()) || (email && pw.toLowerCase() === String(email).toLowerCase())) throw bad('weak_password', 'That password is too easy to guess.', { field: 'password' });
  if (/^(.)\1+$/.test(pw)) throw bad('weak_password', 'That password is too easy to guess.', { field: 'password' });
}

// ---- sessions: random token in an HttpOnly cookie, only its hash is stored ----
function createSession(userId, ip, ua) {
  const token = randomToken(32);
  const csrf = randomToken(24);
  const t = nowIso();
  db.run('INSERT INTO sessions (token_hash, user_id, csrf_token, created_at, expires_at, ip, user_agent) VALUES (?,?,?,?,?,?,?)',
    sha256(token), userId, csrf, t, addDays(t, config.sessionDays), ip || null, String(ua || '').slice(0, 200));
  return { token, csrf };
}
function loadSession(token) {
  const row = db.get(`SELECT s.id AS sid, s.csrf_token, s.expires_at, u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`, sha256(token));
  if (!row) return null;
  if (row.expires_at < nowIso()) { db.run('DELETE FROM sessions WHERE id = ?', row.sid); return null; }
  if (row.status !== 'active') return null; // suspended / deleted accounts lose access immediately
  const user = { id: row.id, email: row.email, displayName: row.display_name, role: row.role, isOwner: !!row.is_owner, country: row.country, emailVerified: !!row.email_verified_at, createdAt: row.created_at };
  return { id: row.sid, csrf: row.csrf_token, user };
}
const destroySession = (token) => db.run('DELETE FROM sessions WHERE token_hash = ?', sha256(token));
const destroyAllSessions = (userId) => db.run('DELETE FROM sessions WHERE user_id = ?', userId);

// ---- one-time email tokens (verify email / reset password) ----
function createAuthToken(userId, kind, ttlMs) {
  const token = randomToken(32);
  const t = nowIso();
  db.run('UPDATE auth_tokens SET used_at = ? WHERE user_id = ? AND kind = ? AND used_at IS NULL', t, userId, kind);
  db.run('INSERT INTO auth_tokens (user_id, kind, token_hash, expires_at, created_at) VALUES (?,?,?,?,?)', userId, kind, sha256(token), addMs(t, ttlMs), t);
  return token;
}
function consumeAuthToken(token, kind) {
  if (typeof token !== 'string' || token.length < 20) throw new HttpError(400, 'invalid_token', 'This link is invalid or has expired.');
  const row = db.get('SELECT * FROM auth_tokens WHERE token_hash = ? AND kind = ?', sha256(token), kind);
  if (!row || row.used_at || row.expires_at < nowIso()) throw new HttpError(400, 'invalid_token', 'This link is invalid or has expired.');
  db.run('UPDATE auth_tokens SET used_at = ? WHERE id = ?', nowIso(), row.id);
  return row.user_id;
}

// ---- permissions come from the database (role -> permissions), checked on the server ----
function can(user, permission) {
  if (!user) return false;
  return !!db.get('SELECT 1 AS x FROM role_permissions WHERE role = ? AND permission = ?', user.role, permission);
}
const requirePerm = (user, permission) => {
  if (!can(user, permission)) throw new HttpError(403, 'forbidden', 'You do not have permission to do that.');
};

module.exports = { hashPassword, verifyPassword, checkPassword, createSession, loadSession, destroySession, destroyAllSessions, createAuthToken, consumeAuthToken, can, requirePerm, safeEqual };
