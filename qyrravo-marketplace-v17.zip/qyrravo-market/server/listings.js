'use strict';
// Product validation, plan limits and the single definition of "publicly visible".
const db = require('./db');
const settings = require('./settings');
const money = require('./money');
const { text, int, oneOf, bad, conflict, parseJson, nowIso } = require('./util');

const CONDITIONS = ['new', 'used', 'refurbished'];
const RETURN_TYPES = ['returns_accepted', 'exchange_only', 'no_returns'];
const SUBSCRIPTION_LIVE = "('active','past_due','canceled')";

// ---------- plan limits (server-side, always) ----------
// A seller is on a paid plan only while a subscription with a verified payment is inside its paid period.
function paidPlanId(userId, at) {
  const row = db.get(`SELECT plan_id FROM subscriptions WHERE user_id = ? AND plan_id != 'free' AND status IN ${SUBSCRIPTION_LIVE} AND current_period_end > ?`, userId, at || nowIso());
  return row ? row.plan_id : null;
}
const premiumActive = (userId, at) => !!paidPlanId(userId, at);
// Listings that occupy a "for sale" slot: everything submitted/live/held and not sold out. Drafts, rejected and deleted do not count.
const ACTIVE_STATUSES = "('submitted','under_review','more_info_required','approved','suspended')";
function activeListingCount(userId, excludeProductId) {
  return db.get(`SELECT COUNT(*) AS n FROM products WHERE seller_id = ? AND deleted_at IS NULL AND status IN ${ACTIVE_STATUSES} AND quantity > 0 AND id != ?`, userId, excludeProductId || 0).n;
}
// Administrators (including the owner) get the top plan for free.
function isStaffVip(userId) { const u = db.get('SELECT role FROM users WHERE id = ?', userId); return !!u && u.role === 'admin'; }
function limitsFor(userId) {
  const plans = settings.getPlans();
  const free = plans.find((p) => p.id === 'free');
  const top = [...plans].sort((a, b) => b.max_item_price_usd_minor - a.max_item_price_usd_minor)[0];
  const paidId = paidPlanId(userId);
  const plan = isStaffVip(userId) ? top : ((paidId && plans.find((p) => p.id === paidId)) || free);
  const platformMax = Math.max(...plans.filter((p) => p.active || p.id === plan.id).map((p) => p.max_item_price_usd_minor));
  const next = plans.filter((p) => p.active && p.max_item_price_usd_minor > plan.max_item_price_usd_minor).sort((x, y) => x.max_item_price_usd_minor - y.max_item_price_usd_minor)[0] || null;
  return {
    planId: plan.id, planName: plan.name, premium: plan.id !== 'free',
    maxUsdMinor: plan.max_item_price_usd_minor,
    freeMaxUsdMinor: free.max_item_price_usd_minor,
    platformMaxUsdMinor: platformMax,
    maxActive: plan.max_active_listings,
    maxQuantity: plan.max_quantity,
    next: next ? { id: next.id, name: next.name, maxUsdMinor: next.max_item_price_usd_minor } : null,
  };
}
function assertWithinPlan(userId, usdMinor) {
  const l = limitsFor(userId);
  if (usdMinor > l.platformMaxUsdMinor) throw conflict('price_over_platform_max', 'The highest price QYRRAVO currently allows for a single item is ' + money.format(l.platformMaxUsdMinor, 'USD') + '.', { limitUsdMinor: l.platformMaxUsdMinor });
  if (usdMinor > l.maxUsdMinor) {
    throw conflict('plan_limit', 'Your ' + l.planName + ' plan allows items priced up to ' + money.format(l.maxUsdMinor, 'USD') + ' each. This item is above that limit.' + (l.next ? ' Upgrade to ' + l.next.name + ' to list items up to ' + money.format(l.next.maxUsdMinor, 'USD') + '.' : ''), { limitUsdMinor: l.maxUsdMinor, upgrade: !!l.next, nextPlan: l.next });
  }
  return l;
}
function assertQuantity(userId, quantity) {
  const l = limitsFor(userId);
  if (quantity > l.maxQuantity) throw conflict('quantity_limit', 'Your ' + l.planName + ' plan allows ' + l.maxQuantity + ' unit' + (l.maxQuantity === 1 ? '' : 's') + ' per listing.' + (l.maxQuantity === 1 ? ' List one item at a time.' : ''), { field: 'quantity', limit: l.maxQuantity });
  return l;
}
// Called when a listing is submitted. A listing that is already in review/live (more_info_required) does not count against itself.
function assertSlotFree(userId, productId) {
  const l = limitsFor(userId);
  const n = activeListingCount(userId, productId);
  if (n >= l.maxActive) {
    throw conflict('listing_limit', 'Your ' + l.planName + ' plan lets you have ' + l.maxActive + ' item' + (l.maxActive === 1 ? '' : 's') + ' for sale at a time, and you already have ' + n + '. When it sells (or you withdraw it), you can list the next one.' + (l.next ? ' Upgrading to ' + l.next.name + ' raises the maximum price per item, not the number of items.' : ''), { limit: l.maxActive, active: n });
  }
  return l;
}

// ---------- price + currency ----------
function priceFields(priceInput, currency) {
  const cur = oneOf(String(currency || '').toUpperCase(), settings.get('supported_currencies'), 'currency');
  const rate = settings.getRate(cur);
  if (!rate) throw bad('fx_unavailable', 'No exchange rate is available for ' + cur + ' yet, so the plan price limit cannot be checked. Choose another currency.', { field: 'currency' });
  const minor = money.parseMajor(priceInput, cur, 'price');
  return { price_minor: minor, currency: cur, price_usd_minor: money.toUsdMinor(minor, cur, rate.rate), fx_rate: rate.rate, fx_source: rate.source, fx_at: rate.at };
}

// ---------- prohibited items (a coarse first check; moderators still review everything) ----------
function prohibitedHits(...parts) {
  const hay = parts.filter(Boolean).join(' \n ').toLowerCase();
  return db.all('SELECT keyword, reason FROM prohibited_items').filter((p) => hay.includes(p.keyword.toLowerCase()));
}

// ---------- validation ----------
function categoryPair(categoryId, subId) {
  const cat = db.get('SELECT * FROM categories WHERE id = ? AND parent_id IS NULL AND active = 1', categoryId);
  if (!cat) throw bad('validation', 'Choose a valid category.', { field: 'category' });
  let sub = null;
  if (subId !== null && subId !== undefined && subId !== '') {
    sub = db.get('SELECT * FROM categories WHERE id = ? AND parent_id = ? AND active = 1', subId, cat.id);
    if (!sub) throw bad('validation', 'Choose a subcategory that belongs to the category.', { field: 'subcategory' });
  }
  return { category_id: cat.id, subcategory_id: sub ? sub.id : null };
}

function shipsTo(v) {
  if (!Array.isArray(v) || v.length === 0) throw bad('validation', 'Choose where you will ship this item.', { field: 'shipsTo' });
  if (v.length > 250) throw bad('validation', 'Too many countries.', { field: 'shipsTo' });
  if (v.length === 1 && v[0] === 'WORLD') return ['WORLD'];
  const valid = new Set(settings.COUNTRIES.map((c) => c.code));
  const out = [...new Set(v.map((x) => String(x).toUpperCase()))];
  for (const c of out) if (!valid.has(c)) throw bad('validation', 'Unknown country code ' + c, { field: 'shipsTo' });
  return out;
}

function specsFrom(v) {
  if (!Array.isArray(v)) throw bad('validation', 'Specifications must be a list.', { field: 'specs' });
  if (v.length > 20) throw bad('validation', 'You can add up to 20 specifications.', { field: 'specs' });
  return v.map((s) => ({ k: text(s && s.k, { min: 1, max: 60, field: 'specification name' }), v: text(s && s.v, { min: 1, max: 200, field: 'specification value' }) }));
}

// Normalises whichever fields are present (drafts can be incomplete). Strict completeness is checked at submit time.
function normalize(input, sellerCountryDefault) {
  const out = {};
  const has = (k) => Object.prototype.hasOwnProperty.call(input, k);
  if (has('name')) out.name = text(input.name, { min: 3, max: 120, field: 'Product name' });
  if (has('description')) out.description = text(input.description, { min: 20, max: 5000, field: 'Description', multiline: true });
  if (has('brand')) out.brand = text(input.brand, { max: 80, field: 'Brand', required: false });
  if (has('model')) out.model = text(input.model, { max: 80, field: 'Model', required: false });
  if (has('condition')) out.condition = oneOf(input.condition, CONDITIONS, 'condition');
  if (has('quantity')) out.quantity = int(input.quantity, { min: 1, max: 10000, field: 'Quantity' });
  if (has('category') || has('subcategory')) Object.assign(out, categoryPair(int(input.category, { min: 1, field: 'category' }), input.subcategory ? int(input.subcategory, { min: 1, field: 'subcategory' }) : null));
  if (has('sellerCountry')) out.seller_country = oneOf(String(input.sellerCountry).toUpperCase(), settings.get('enabled_countries'), 'seller country');
  if (has('shipsTo')) out.ships_to = JSON.stringify(shipsTo(input.shipsTo));
  if (has('dispatchDays')) out.dispatch_days = int(input.dispatchDays, { min: 0, max: 60, field: 'Dispatch time' });
  if (has('shippingNotes')) out.shipping_notes = text(input.shippingNotes, { max: 500, field: 'Shipping notes', multiline: true, required: false });
  if (has('returnsType')) out.returns_type = oneOf(input.returnsType, RETURN_TYPES, 'returns');
  if (has('returnsDays')) out.returns_days = input.returnsDays === null || input.returnsDays === '' ? null : int(input.returnsDays, { min: 0, max: 90, field: 'Return window' });
  if (has('returnsNotes')) out.returns_notes = text(input.returnsNotes, { max: 500, field: 'Return notes', multiline: true, required: false });
  if (has('specs')) out.specs = JSON.stringify(specsFrom(input.specs));
  if (has('acceptsCash') || has('acceptsCoins')) {
    const cash = input.acceptsCash === true || input.acceptsCash === 1, coins = input.acceptsCoins === true || input.acceptsCoins === 1;
    if (!cash && !coins) throw bad('validation', 'Choose at least one way to be paid: cash or Q Coins.', { field: 'acceptsCash' });
    out.accepts_cash = cash ? 1 : 0; out.accepts_coins = coins ? 1 : 0;
  }
  if (has('referenceInfo')) out.reference_info = text(input.referenceInfo, { max: 200, field: 'Reference', required: false });
  if (has('price') || has('currency')) {
    if (!(has('price') && has('currency'))) throw bad('validation', 'Send price and currency together.', { field: 'price' });
    Object.assign(out, priceFields(input.price, input.currency));
  }
  if (has('shippingFee')) {
    const cur = out.currency || input.currency;
    if (!cur) throw bad('validation', 'Send the currency together with the shipping fee.', { field: 'shippingFee' });
    out.shipping_fee_minor = Number(input.shippingFee) === 0 || input.shippingFee === '' || input.shippingFee === null ? 0 : money.parseMajor(input.shippingFee, String(cur).toUpperCase(), 'shippingFee');
  }
  if (out.seller_country === undefined && sellerCountryDefault && input.__init) out.seller_country = sellerCountryDefault;
  return out;
}

// Material fields: changing these on a reviewed listing sends it back to draft so photos/text are re-reviewed.
const MATERIAL = ['name', 'description', 'brand', 'model', 'condition', 'category_id', 'subcategory_id', 'specs', 'reference_info'];

function missingForSubmit(p, images) {
  const missing = [];
  const need = (cond, field, msg) => { if (!cond) missing.push({ field, message: msg }); };
  need(p.name && p.name.length >= 3, 'name', 'Add a product name.');
  need(p.description && p.description.length >= 20, 'description', 'Add a description (at least 20 characters).');
  need(p.category_id, 'category', 'Choose a category.');
  need(p.condition, 'condition', 'Choose the condition.');
  need(Number.isInteger(p.price_minor) && p.price_minor > 0 && p.currency, 'price', 'Enter a price and currency.');
  need(Number.isInteger(p.quantity) && p.quantity >= 1, 'quantity', 'Enter the quantity available.');
  need(p.seller_country, 'sellerCountry', 'Choose your country.');
  need(parseJson(p.ships_to, []).length > 0, 'shipsTo', 'Choose where you ship.');
  need(Number.isInteger(p.dispatch_days), 'dispatchDays', 'Enter your estimated dispatch time.');
  need(p.returns_type, 'returnsType', 'Choose a returns option.');
  need(images.some((i) => i.kind === 'main'), 'mainImage', 'Add a main photo of the actual item.');
  need(images.some((i) => i.kind === 'verification'), 'verificationImage', 'Add the verification photo showing the item with your QYRRAVO code.');
  return missing;
}

// ---------- public visibility: the ONE place that decides what buyers can see ----------
function publicWhere(alias = 'p') {
  const free = settings.getPlan('free').max_item_price_usd_minor;
  // a listing is public only while its price is within the seller's CURRENT plan limit (an expired paid plan pauses expensive items, never deletes them)
  const sql = `${alias}.status = 'approved' AND ${alias}.deleted_at IS NULL AND ${alias}.price_usd_minor IS NOT NULL AND ${alias}.quantity > 0
    AND EXISTS (SELECT 1 FROM users su JOIN seller_profiles sp ON sp.user_id = su.id WHERE su.id = ${alias}.seller_id AND su.status = 'active' AND sp.seller_status = 'active')
    AND ${alias}.price_usd_minor <= COALESCE(CASE WHEN (SELECT role FROM users WHERE id = ${alias}.seller_id) = 'admin' THEN (SELECT MAX(max_item_price_usd_minor) FROM plans) END, (SELECT pl.max_item_price_usd_minor FROM subscriptions s JOIN plans pl ON pl.id = s.plan_id WHERE s.user_id = ${alias}.seller_id AND s.plan_id != 'free' AND s.status IN ${SUBSCRIPTION_LIVE} AND s.current_period_end > ?), ?)`;
  return { sql, params: [nowIso(), free] };
}

function imagesFor(productId, includeVerification) {
  return db.all(`SELECT id, kind, position FROM product_images WHERE product_id = ? ${includeVerification ? '' : "AND kind != 'verification'"} ORDER BY CASE kind WHEN 'main' THEN 0 WHEN 'extra' THEN 1 ELSE 2 END, position, id`, productId);
}

function toPublic(row) {
  const imgs = imagesFor(row.id, false).map((i) => ({ id: i.id, kind: i.kind, url: '/media/' + i.id }));
  const rate = row.fx_rate ? { ratePerUsd: row.fx_rate, source: row.fx_source, at: row.fx_at } : null;
  return {
    id: row.id, name: row.name, description: row.description, brand: row.brand, model: row.model, condition: row.condition,
    price: { minor: row.price_minor, currency: row.currency, usdMinor: row.price_usd_minor, fx: rate },
    shippingFee: { minor: row.shipping_fee_minor, currency: row.currency },
    quantityAvailable: Math.max(0, row.quantity - row.quantity_reserved),
    sellerCountry: row.seller_country, shipsTo: parseJson(row.ships_to, []), dispatchDays: row.dispatch_days, shippingNotes: row.shipping_notes,
    returns: { type: row.returns_type, days: row.returns_days, notes: row.returns_notes },
    specs: parseJson(row.specs, []), referenceInfo: row.reference_info,
    category: row.category_name ? { id: row.category_id, name: row.category_name, slug: row.category_slug } : null,
    subcategory: row.sub_name ? { id: row.subcategory_id, name: row.sub_name } : null,
    images: imgs,
    seller: { id: row.seller_id, shopName: row.shop_name, country: row.shop_country },
    payment: { cash: !!row.accepts_cash || !(row.accepts_coins && row.seller_staff), coins: !!(row.accepts_coins && row.seller_staff), coinPrice: row.accepts_coins && row.seller_staff ? row.price_usd_minor : null, shippingCoins: row.accepts_coins && row.seller_staff && row.shipping_fee_minor ? money.toUsdMinor(row.shipping_fee_minor, row.currency, row.fx_rate || 1) : 0 },
    buyable: row.payout_status === 'verified',
    // honest labels - see docs/VERIFICATION-POLICY
    photoReview: { status: 'photos_reviewed', label: 'Listing photos reviewed', note: 'QYRRAVO moderators reviewed the listing photos. This does not prove ownership, authenticity, or the seller\'s honesty.' },
    approvedAt: row.approved_at, createdAt: row.created_at,
  };
}

const SELECT_PUBLIC = `SELECT p.*, c.name AS category_name, c.slug AS category_slug, sc.name AS sub_name,
  sp.shop_name AS shop_name, sp.country AS shop_country, sp.payout_status AS payout_status,
  (SELECT CASE WHEN role IN ('admin','moderator') OR is_owner = 1 THEN 1 ELSE 0 END FROM users WHERE id = p.seller_id) AS seller_staff
  FROM products p
  LEFT JOIN categories c ON c.id = p.category_id
  LEFT JOIN categories sc ON sc.id = p.subcategory_id
  JOIN seller_profiles sp ON sp.user_id = p.seller_id`;

module.exports = { CONDITIONS, MATERIAL, premiumActive, paidPlanId, activeListingCount, assertQuantity, assertSlotFree, limitsFor, assertWithinPlan, priceFields, prohibitedHits, normalize, missingForSubmit, publicWhere, imagesFor, toPublic, SELECT_PUBLIC, categoryPair };
