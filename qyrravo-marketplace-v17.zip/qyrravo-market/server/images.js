'use strict';
// Safe image handling. We never trust file names or the Content-Type header: the bytes are inspected.
//  - only JPEG, PNG and WebP are accepted (no SVG/GIF/HTML-disguised-as-image)
//  - dimensions are read from the file header and bounded
//  - JPEG EXIF/GPS and PNG text/EXIF metadata are stripped (privacy: photos often contain GPS location)
//  - files are stored under random names OUTSIDE the public web folder and served only through /media/:id,
//    which enforces access control (verification photos are never public)
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('./config');
const { bad } = require('./util');

const MAX_SIDE = 12000;
const MAX_PIXELS = 60e6;

function jpeg(buf) {
  if (buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8 || buf[2] !== 0xff) return null;
  const out = [buf.subarray(0, 2)];
  let i = 2; let w = 0; let h = 0; let sos = false;
  while (i < buf.length) {
    if (buf[i] !== 0xff) return null;
    while (buf[i] === 0xff && i < buf.length) i++;
    const marker = buf[i]; i++;
    if (marker === 0xd9) { out.push(Buffer.from([0xff, 0xd9])); return w && h ? { mime: 'image/jpeg', ext: 'jpg', width: w, height: h, data: Buffer.concat(out) } : null; }
    if ((marker >= 0xd0 && marker <= 0xd7) || marker === 0x01 || marker === 0xd8) { out.push(Buffer.from([0xff, marker])); continue; }
    if (i + 2 > buf.length) return null;
    const len = buf.readUInt16BE(i);
    if (len < 2 || i + len > buf.length) return null;
    const seg = buf.subarray(i - 2, i + len);
    if (marker === 0xda) { // start of scan: the rest is compressed data
      if (!w || !h) return null;
      out.push(buf.subarray(i - 2));
      sos = true;
      return { mime: 'image/jpeg', ext: 'jpg', width: w, height: h, data: Buffer.concat(out) };
    }
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      if (len < 8) return null;
      h = buf.readUInt16BE(i + 3); w = buf.readUInt16BE(i + 5);
    }
    const drop = marker === 0xe1 || marker === 0xed || marker === 0xfe; // EXIF/XMP, IPTC, comments
    if (!drop) out.push(seg);
    i += len;
  }
  return sos ? null : null;
}

function png(buf) {
  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  if (buf.length < 33 || !buf.subarray(0, 8).equals(sig)) return null;
  const out = [buf.subarray(0, 8)];
  let i = 8; let w = 0; let h = 0; let first = true; let iend = false;
  const dropTypes = new Set(['eXIf', 'tEXt', 'zTXt', 'iTXt', 'tIME']);
  while (i + 12 <= buf.length) {
    const len = buf.readUInt32BE(i);
    const type = buf.toString('latin1', i + 4, i + 8);
    if (i + 12 + len > buf.length) return null;
    if (first) { if (type !== 'IHDR' || len !== 13) return null; w = buf.readUInt32BE(i + 8); h = buf.readUInt32BE(i + 12); first = false; }
    if (!dropTypes.has(type)) out.push(buf.subarray(i, i + 12 + len));
    i += 12 + len;
    if (type === 'IEND') { iend = true; break; }
  }
  if (!iend || !w || !h) return null;
  return { mime: 'image/png', ext: 'png', width: w, height: h, data: Buffer.concat(out) };
}

function webp(buf) {
  if (buf.length < 30 || buf.toString('latin1', 0, 4) !== 'RIFF' || buf.toString('latin1', 8, 12) !== 'WEBP') return null;
  const fourcc = buf.toString('latin1', 12, 16);
  let w = 0; let h = 0;
  if (fourcc === 'VP8 ') {
    if (buf[23] !== 0x9d || buf[24] !== 0x01 || buf[25] !== 0x2a) return null;
    w = buf.readUInt16LE(26) & 0x3fff; h = buf.readUInt16LE(28) & 0x3fff;
  } else if (fourcc === 'VP8L') {
    if (buf[20] !== 0x2f) return null;
    const bits = buf.readUInt32LE(21);
    w = (bits & 0x3fff) + 1; h = ((bits >>> 14) & 0x3fff) + 1;
  } else if (fourcc === 'VP8X') {
    w = 1 + (buf[24] | (buf[25] << 8) | (buf[26] << 16));
    h = 1 + (buf[27] | (buf[28] << 8) | (buf[29] << 16));
  } else return null;
  if (!w || !h) return null;
  return { mime: 'image/webp', ext: 'webp', width: w, height: h, data: buf };
}

function inspect(buf, { maxBytes, minPx }) {
  if (!Buffer.isBuffer(buf) || buf.length === 0) throw bad('invalid_image', 'No image data was received.');
  if (buf.length > maxBytes) throw bad('image_too_large', 'That image is larger than ' + Math.round(maxBytes / 1048576) + ' MB. Choose a smaller photo.');
  const info = jpeg(buf) || png(buf) || webp(buf);
  if (!info) throw bad('invalid_image', 'Only valid JPEG, PNG or WebP photos are accepted.');
  if (info.width > MAX_SIDE || info.height > MAX_SIDE || info.width * info.height > MAX_PIXELS) throw bad('invalid_image', 'That image is too large in pixels.');
  if (Math.min(info.width, info.height) < minPx) throw bad('image_too_small', 'Photos must be at least ' + minPx + ' pixels on the shorter side so buyers can see the item clearly.');
  return info;
}

function ensureDir() { fs.mkdirSync(config.uploadDir, { recursive: true }); }
function store(info) {
  ensureDir();
  const key = crypto.randomBytes(24).toString('hex') + '.' + info.ext;
  fs.writeFileSync(path.join(config.uploadDir, key), info.data, { mode: 0o600, flag: 'wx' });
  return key;
}
function read(key) {
  if (!/^[a-f0-9]{48}\.(jpg|png|webp)$/.test(key)) return null;
  try { return fs.readFileSync(path.join(config.uploadDir, key)); } catch (e) { return null; }
}
function remove(key) {
  if (!/^[a-f0-9]{48}\.(jpg|png|webp)$/.test(key)) return;
  try { fs.unlinkSync(path.join(config.uploadDir, key)); } catch (e) { /* already gone */ }
}

module.exports = { inspect, store, read, remove };
