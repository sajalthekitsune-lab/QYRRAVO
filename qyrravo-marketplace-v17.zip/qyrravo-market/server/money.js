'use strict';
// Money helpers. All amounts are INTEGER minor units. Never use floats for stored money.
const { bad } = require('./util');

const expCache = new Map();
function exponent(currency) {
  if (expCache.has(currency)) return expCache.get(currency);
  let e = 2;
  try { e = new Intl.NumberFormat('en', { style: 'currency', currency }).resolvedOptions().maximumFractionDigits; } catch (err) { throw bad('validation', 'Unknown currency ' + currency, { field: 'currency' }); }
  expCache.set(currency, e);
  return e;
}

// "49.99" -> 4999 for USD. Accepts a string or number, rejects too many decimals.
function parseMajor(value, currency, field = 'price') {
  const e = exponent(currency);
  const s = String(value === undefined || value === null ? '' : value).trim().replace(/,/g, '');
  const m = /^(\d{1,10})(?:\.(\d+))?$/.exec(s);
  if (!m) throw bad('validation', 'Enter a valid price, for example 49.99', { field });
  const frac = m[2] || '';
  if (frac.length > e) throw bad('validation', currency + ' prices can have at most ' + e + ' decimal places.', { field });
  const minor = Number(m[1]) * Math.pow(10, e) + (frac ? Number(frac.padEnd(e, '0')) : 0);
  if (!Number.isSafeInteger(minor) || minor <= 0) throw bad('validation', 'Price must be greater than zero.', { field });
  return minor;
}

function format(minor, currency, locale = 'en') {
  const e = exponent(currency);
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(minor / Math.pow(10, e));
}

// Convert an amount in `currency` to USD minor units using rate = units of currency per 1 USD.
function toUsdMinor(amountMinor, currency, ratePerUsd) {
  if (currency === 'USD') return amountMinor;
  const major = amountMinor / Math.pow(10, exponent(currency));
  return Math.round((major / ratePerUsd) * 100);
}
function fromUsdMinor(usdMinor, currency, ratePerUsd) {
  if (currency === 'USD') return usdMinor;
  const major = (usdMinor / 100) * ratePerUsd;
  return Math.round(major * Math.pow(10, exponent(currency)));
}

// commission = round-half-up(base * bps / 10000) + fixed, never more than base.
function commission(baseMinor, bps, fixedMinor = 0) {
  if (!Number.isInteger(baseMinor) || baseMinor < 0) throw new Error('bad base');
  const pct = Math.floor((baseMinor * bps + 5000) / 10000);
  return Math.min(baseMinor, pct + fixedMinor);
}

// cumulative proportional share: share of `part` out of `whole` applied to `amount`
const proportional = (amount, part, whole) => (whole <= 0 ? 0 : Math.round((amount * part) / whole));

module.exports = { exponent, parseMajor, format, toUsdMinor, fromUsdMinor, commission, proportional };
