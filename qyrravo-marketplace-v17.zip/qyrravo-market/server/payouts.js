'use strict';
// Seller payouts. With a real marketplace provider (e.g. Tap marketplace wallets) the PROVIDER pays sellers out
// under its own settlement rules; these records track and reconcile that. Money is only marked paid by a verified webhook.
const db = require('./db');
const ledger = require('./ledger');
const payments = require('./payments');
const { notifyUser } = require('./notify');
const { audit } = require('./audit');
const { conflict, notFound, nowIso } = require('./util');

function earnedNet(sellerId, currency) {
  const r = db.get('SELECT earned_net_minor AS e FROM seller_balances WHERE seller_id = ? AND currency = ?', sellerId, currency);
  return r ? r.e : 0;
}
function committed(sellerId, currency) {
  return db.get("SELECT COALESCE(SUM(amount_minor),0) AS s FROM payouts WHERE seller_id = ? AND currency = ? AND status IN ('requested','processing','paid')", sellerId, currency).s;
}
const available = (sellerId, currency) => earnedNet(sellerId, currency) - committed(sellerId, currency);

function balances(sellerId) {
  const cur = db.all('SELECT DISTINCT currency FROM ledger_entries WHERE seller_id = ?', sellerId).map((r) => r.currency);
  const pending = db.all("SELECT currency, SUM(total_minor - refunded_minor) AS s FROM orders WHERE seller_id = ? AND status IN ('paid','shipped','delivered','disputed') GROUP BY currency", sellerId);
  const set = new Set([...cur, ...pending.map((p) => p.currency)]);
  return [...set].map((currency) => ({
    currency,
    pendingMinor: (pending.find((p) => p.currency === currency) || { s: 0 }).s,   // paid but not completed: NOT yet available
    availableMinor: available(sellerId, currency),
    paidOutMinor: db.get("SELECT COALESCE(SUM(amount_minor),0) AS s FROM payouts WHERE seller_id = ? AND currency = ? AND status = 'paid'", sellerId, currency).s,
    inProgressMinor: db.get("SELECT COALESCE(SUM(amount_minor),0) AS s FROM payouts WHERE seller_id = ? AND currency = ? AND status IN ('requested','processing')", sellerId, currency).s,
  }));
}

async function create(admin, sellerId, currency) {
  const provider = payments.requireProvider();
  const sp = db.get('SELECT * FROM seller_profiles WHERE user_id = ?', sellerId);
  if (!sp) throw notFound('Seller not found.');
  if (sp.payout_status !== 'verified') throw conflict('seller_not_verified_for_payouts', 'This seller has not completed payout verification with the payment provider.');
  const payoutId = db.tx(() => {
    const amount = available(sellerId, currency);
    if (amount <= 0) throw conflict('nothing_to_pay', 'There is nothing available to pay out in ' + currency + '.');
    const version = db.get('SELECT COALESCE(MAX(id),0) AS m FROM ledger_entries WHERE seller_id = ?', sellerId).m;
    try {
      return db.run("INSERT INTO payouts (seller_id, currency, amount_minor, status, provider, idempotency_key, created_by, created_at) VALUES (?,?,?, 'requested', ?, ?, ?, ?)",
        sellerId, currency, amount, provider.name, 'payout:' + sellerId + ':' + currency + ':' + version, admin.id, nowIso()).id;
    } catch (e) {
      if (/UNIQUE/.test(String(e.message))) throw conflict('duplicate_payout', 'A payout for this exact balance was already created.');
      throw e;
    }
  });
  const payout = db.get('SELECT * FROM payouts WHERE id = ?', payoutId);
  try {
    const out = await provider.requestPayout({ payout });
    db.run("UPDATE payouts SET status = 'processing', provider_payout_ref = ? WHERE id = ?", (out && out.providerPayoutRef) || null, payoutId);
  } catch (e) {
    db.run("UPDATE payouts SET status = 'failed', failure_reason = 'provider rejected the request' WHERE id = ?", payoutId);
    throw conflict('payout_failed', 'The payment provider did not accept the payout request.');
  }
  audit(admin, 'payout.created', 'payout', payoutId, { sellerId, currency, amount: payout.amount_minor });
  return db.get('SELECT * FROM payouts WHERE id = ?', payoutId);
}

function markPaid(payoutId, ref) {
  const p = db.get('SELECT * FROM payouts WHERE id = ?', payoutId);
  if (!p || !['requested', 'processing'].includes(p.status)) return null;
  db.run("UPDATE payouts SET status = 'paid', paid_at = ?, provider_payout_ref = COALESCE(provider_payout_ref, ?) WHERE id = ?", nowIso(), ref || null, payoutId);
  ledger.post('payout', { currency: p.currency, amount: p.amount_minor, sellerId: p.seller_id, payoutId, key: 'payout:payout:' + payoutId, memo: 'Payout confirmed by provider' });
  notifyUser(p.seller_id, 'payout_paid', 'Payout sent', 'A payout was confirmed by the payment provider.', '/dashboard/finance');
  return p;
}
function markFailed(payoutId, reason) {
  const p = db.get('SELECT * FROM payouts WHERE id = ?', payoutId);
  if (!p || !['requested', 'processing'].includes(p.status)) return null;
  db.run("UPDATE payouts SET status = 'failed', failure_reason = ? WHERE id = ?", String(reason || 'failed').slice(0, 200), payoutId);
  notifyUser(p.seller_id, 'payout_failed', 'Payout failed', 'A payout could not be completed. The amount is back in your available balance.', '/dashboard/finance');
  return p;
}

module.exports = { available, balances, create, markPaid, markFailed };
