'use strict';
// In-app notifications + email outbox.
// IMPORTANT: an email is only ever marked "sent" if a real provider accepted it.
// With no provider configured, rows are stored as "not_configured" and the UI/logs say so.
const config = require('./config');
const db = require('./db');
const { nowIso } = require('./util');

function notify(userId, type, title, body, link, dedupeKey) {
  try {
    db.run('INSERT INTO notifications (user_id, type, title, body, link, dedupe_key, created_at) VALUES (?,?,?,?,?,?,?)',
      userId, type, title, body || null, link || null, dedupeKey || null, nowIso());
    return true;
  } catch (e) {
    if (/UNIQUE/.test(String(e.message))) return false; // same notification already exists
    throw e;
  }
}

async function deliver(rowId, toEmail, subject, body) {
  if (config.emailProvider === 'resend' && config.emailApiKey && config.emailFrom) {
    // Resend HTTP API (https://resend.com/docs). Not verified against a live account in this build.
    try {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + config.emailApiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: config.emailFrom, to: [toEmail], subject, text: body }),
      });
      if (!r.ok) throw new Error('provider responded ' + r.status);
      db.run("UPDATE email_outbox SET status = 'sent', sent_at = ? WHERE id = ?", nowIso(), rowId);
      return 'sent';
    } catch (e) {
      db.run("UPDATE email_outbox SET status = 'failed', error = ? WHERE id = ?", String(e.message).slice(0, 300), rowId);
      return 'failed';
    }
  }
  db.run("UPDATE email_outbox SET status = 'not_configured', error = 'No email provider configured' WHERE id = ?", rowId);
  if (!config.isProd) console.log('[email NOT SENT - no provider configured] to=' + toEmail + ' subject="' + subject + '"\n' + body + '\n');
  return 'not_configured';
}

function sendEmail(userId, toEmail, subject, body, template) {
  const r = db.run("INSERT INTO email_outbox (user_id, to_email, subject, body, template, status, created_at) VALUES (?,?,?,?,?,'queued',?)",
    userId || null, toEmail, subject, body, template || null, nowIso());
  // fire and forget: delivery problems must never break the request that triggered the email
  deliver(r.id, toEmail, subject, body).catch(() => {});
  return r.id;
}

// notify in-app AND queue an email
function notifyUser(userId, type, title, body, link, dedupeKey) {
  const fresh = notify(userId, type, title, body, link, dedupeKey);
  if (!fresh) return;
  const u = db.get('SELECT email FROM users WHERE id = ?', userId);
  if (u) sendEmail(userId, u.email, '[QYRRAVO] ' + title, (body || '') + (link ? '\n\n' + config.appUrl + '/#' + link : ''), type);
}

module.exports = { notify, notifyUser, sendEmail };
