'use strict';
// The ledger only ever contains CONFIRMED money events. Every entry has a unique idempotency key,
// so replaying a webhook or retrying a job can never create a duplicate commission, refund or payout.
const db = require('./db');
const { nowIso } = require('./util');

function post(kind, { currency, amount, sellerId, orderId, paymentId, refundId, payoutId, subscriptionId, key, memo }) {
  if (!Number.isInteger(amount) || amount < 0) throw new Error('ledger amount must be a non-negative integer');
  if (amount === 0) return false;
  try {
    db.run(`INSERT INTO ledger_entries (kind, currency, amount_minor, seller_id, order_id, payment_id, refund_id, payout_id, subscription_id, idempotency_key, memo, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, kind, currency, amount, sellerId || null, orderId || null, paymentId || null, refundId || null, payoutId || null, subscriptionId || null, key, memo || null, nowIso());
    return true;
  } catch (e) {
    if (/UNIQUE/.test(String(e.message))) return false;
    throw e;
  }
}

// Per-currency totals. We never add different currencies together.
function summary() {
  const rows = db.all('SELECT kind, currency, SUM(amount_minor) AS total, COUNT(*) AS n FROM ledger_entries GROUP BY kind, currency');
  const by = {};
  for (const r of rows) { (by[r.currency] = by[r.currency] || {})[r.kind] = r.total; }
  const out = [];
  for (const [currency, k] of Object.entries(by)) {
    const g = (x) => k[x] || 0;
    const subscriptionNet = g('subscription_payment') - g('subscription_refund');
    const commissionNet = g('commission_earned') - g('commission_reversal');
    const revenue = subscriptionNet + commissionNet;
    out.push({
      currency,
      subscriptionPayments: g('subscription_payment'), subscriptionRefunds: g('subscription_refund'),
      grossOrders: g('order_gross'), orderRefunds: g('refund'), chargebacks: g('chargeback'),
      commissionsEarned: g('commission_earned'), commissionReversals: g('commission_reversal'),
      processingFees: g('processing_fee'),
      sellerAmountsEarned: g('seller_payable_earned') - g('seller_payable_reversal'),
      payoutsCompleted: g('payout'),
      confirmedRevenue: revenue,
      netPlatformRevenue: revenue - g('processing_fee'),
    });
  }
  return out;
}

module.exports = { post, summary };
