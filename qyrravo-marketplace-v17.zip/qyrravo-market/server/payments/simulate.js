'use strict';
// Used ONLY by the test-mode simulator. It builds an event, SIGNS it, and pushes it through the same
// verification + processing code that real provider webhooks use. It refuses to run unless the simulator is the active provider.
const config = require('../config');
const payments = require('./index');
const test = require('./test');
const webhooks = require('./webhooks');
const { HttpError, randomToken } = require('../util');

function assertSimulator() {
  const p = payments.provider();
  if (!p || !p.isSimulator || config.paymentMode !== 'test') throw new HttpError(404, 'not_found', 'Not found.');
}
function emit(type, data) {
  assertSimulator();
  const raw = Buffer.from(JSON.stringify({ id: 'evt_test_' + randomToken(10), type, data }));
  return webhooks.receive(raw, { 'x-qy-signature': test.sign(raw.toString('utf8')) });
}
module.exports = { assertSimulator, emit };
