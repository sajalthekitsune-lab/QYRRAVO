'use strict';
// Verified webhook processing. Everything that moves money in the books starts here.
//  1. the signature is verified by the provider adapter (bad signature -> 400, nothing happens)
//  2. the event id is recorded with a UNIQUE constraint, so a replayed event can never be applied twice
//  3. amounts and currencies in the event are compared with OUR records; mismatches are rejected, never trusted
const crypto = require('crypto');
const db = require('../db');
const payments = require('./index');
const orders = require('../orders');
const subscriptions = require('../subscriptions');
const payouts = require('../payouts');
const settings = require('../settings');
const { notifyUser, notify } = require('../notify');
const { audit } = require('../audit');
const { sha256, nowIso, HttpError } = require('../util');

function notifyAdmins(type, title, body) {
  for (const a of db.all("SELECT u.id FROM users u JOIN role_permissions rp ON rp.role = u.role WHERE rp.permission = 'finance.view' AND u.status = 'active'")) notify(a.id, type, title, body, '/admin/finance');
}
function problem(message, detail) {
  db.run('INSERT INTO error_log (level, message, route, created_at) VALUES (?,?,?,?)', 'warn', message.slice(0, 500), 'webhook', nowIso());
  audit(null, 'webhook.rejected', 'webhook', null, detail);
  notifyAdmins('payment_problem', 'Payment problem needs attention', message);
}

const handlers = {
  'payment.succeeded'(d, provider) {
    const pay = db.get('SELECT * FROM payments WHERE id = ?', d.payment_id);
    if (!pay) return ['ignored', 'unknown payment'];
    if (pay.provider !== provider) return ['rejected', 'provider mismatch'];
    if (pay.status === 'succeeded' || pay.status === 'refunded' || pay.status === 'partially_refunded') return ['ignored', 'payment already confirmed'];
    if (d.amount_minor !== pay.amount_minor || d.currency !== pay.currency) {
      problem('Payment ' + pay.id + ' amount/currency mismatch: expected ' + pay.amount_minor + ' ' + pay.currency + ', provider reported ' + d.amount_minor + ' ' + d.currency + '. Nothing was activated.', { paymentId: pay.id });
      return ['rejected', 'amount mismatch'];
    }
    const fee = Number.isInteger(d.fee_minor) && d.fee_minor > 0 ? d.fee_minor : null;
    if (pay.kind === 'order') {
      const o = db.get('SELECT * FROM orders WHERE id = ?', pay.order_id);
      if (!o || o.status !== 'pending_payment') {
        // money arrived for an order that was already cancelled/expired: record it and alert a human to refund it
        db.run("UPDATE payments SET status = 'succeeded', provider_payment_ref = COALESCE(provider_payment_ref, ?), confirmed_at = ? WHERE id = ?", d.provider_payment_ref || null, nowIso(), pay.id);
        problem('LATE PAYMENT: payment ' + pay.id + ' succeeded for order ' + (o ? o.order_no : pay.order_id) + ' which was already ' + (o ? o.status : 'missing') + '. Refund it in the provider dashboard.', { paymentId: pay.id });
        return ['processed', 'late payment flagged'];
      }
    }
    db.run("UPDATE payments SET status = 'succeeded', provider_payment_ref = COALESCE(provider_payment_ref, ?), confirmed_at = ?, provider_fee_minor = ? WHERE id = ?", d.provider_payment_ref || null, nowIso(), fee, pay.id);
    const fresh = db.get('SELECT * FROM payments WHERE id = ?', pay.id);
    if (pay.kind === 'subscription') subscriptions.activate(pay.subscription_id, pay.id);
    else orders.markPaid(pay.order_id, fresh, fee || 0);
    audit(null, 'payment.confirmed', 'payment', pay.id, { kind: pay.kind, amount: pay.amount_minor, currency: pay.currency });
    return ['processed'];
  },

  'payment.failed'(d) {
    const pay = db.get('SELECT * FROM payments WHERE id = ?', d.payment_id);
    if (!pay || pay.status !== 'pending') return ['ignored', 'nothing to fail'];
    db.run("UPDATE payments SET status = 'failed', failure_reason = ? WHERE id = ?", String(d.reason || 'failed').slice(0, 200), pay.id);
    if (pay.kind === 'order') orders.markPaymentFailed(pay.order_id, d.reason);
    else notifyUser(pay.user_id, 'subscription_payment_failed', 'Plan payment failed', 'Your plan payment did not go through. Nothing was charged and the plan was not activated.', '/dashboard/subscription');
    return ['processed'];
  },

  'subscription.renewed'(d, provider) {
    const sub = db.get('SELECT * FROM subscriptions WHERE id = ?', d.subscription_id);
    if (!sub || !d.provider_payment_ref) return ['ignored', 'unknown subscription'];
    const plan = settings.getPlan(sub.plan_id);
    if (!plan || plan.id === 'free') return ['ignored', 'subscription has no paid plan'];
    if (db.get('SELECT 1 AS x FROM payments WHERE provider_payment_ref = ?', d.provider_payment_ref)) return ['ignored', 'renewal already recorded'];
    if (d.amount_minor !== plan.price_minor || d.currency !== plan.currency) {
      problem('Renewal for subscription ' + sub.id + ' had amount ' + d.amount_minor + ' ' + d.currency + ' but the plan price is ' + plan.price_minor + ' ' + plan.currency + '. Not applied.', { subscriptionId: sub.id });
      return ['rejected', 'amount mismatch'];
    }
    const r = db.run("INSERT INTO payments (kind, user_id, subscription_id, amount_minor, currency, status, provider, provider_payment_ref, idempotency_key, created_at, confirmed_at, plan_id) VALUES ('subscription', ?, ?, ?, ?, 'succeeded', ?, ?, ?, ?, ?, ?)",
      sub.user_id, sub.id, d.amount_minor, d.currency, provider, d.provider_payment_ref, 'renew:' + d.provider_payment_ref, nowIso(), nowIso(), plan.id);
    subscriptions.activate(sub.id, r.id);
    return ['processed'];
  },

  'subscription.payment_failed'(d) {
    const sub = db.get('SELECT * FROM subscriptions WHERE id = ?', d.subscription_id);
    if (!sub || sub.plan_id === 'free') return ['ignored', 'unknown subscription'];
    if (sub.status === 'active') db.run("UPDATE subscriptions SET status = 'past_due', updated_at = ? WHERE id = ?", nowIso(), sub.id);
    notifyUser(sub.user_id, 'subscription_payment_failed', 'Plan renewal payment failed', 'We could not collect your plan renewal. Your plan continues until ' + String(sub.current_period_end).slice(0, 10) + ' and then ends unless a payment succeeds. Listings above the Free limit would pause (not be deleted).', '/dashboard/subscription', 'sub_fail:' + sub.id + ':' + sub.current_period_end);
    return ['processed'];
  },

  'subscription.canceled'(d) {
    const sub = db.get('SELECT * FROM subscriptions WHERE id = ?', d.subscription_id);
    if (!sub) return ['ignored', 'unknown subscription'];
    db.run("UPDATE subscriptions SET cancel_at_period_end = 1, status = CASE WHEN status IN ('active','past_due') THEN 'canceled' ELSE status END, updated_at = ? WHERE id = ?", nowIso(), sub.id);
    return ['processed'];
  },

  'refund.succeeded'(d) {
    const r = orders.applyRefundSucceeded(d.refund_id, d.provider_refund_ref);
    return r ? ['processed'] : ['ignored', 'unknown or already applied refund'];
  },
  'refund.failed'(d) {
    const r = db.get('SELECT * FROM refunds WHERE id = ?', d.refund_id);
    if (!r || r.status !== 'requested') return ['ignored', 'nothing to fail'];
    db.run("UPDATE refunds SET status = 'failed' WHERE id = ?", r.id);
    return ['processed'];
  },

  'dispute.opened'(d) {
    const o = db.get('SELECT * FROM orders WHERE id = ?', d.order_id);
    if (!o || !d.provider_dispute_ref) return ['ignored', 'unknown order'];
    if (db.get('SELECT 1 AS x FROM disputes WHERE provider_dispute_ref = ?', d.provider_dispute_ref)) return ['ignored', 'dispute already recorded'];
    db.run("INSERT INTO disputes (order_id, source, provider_dispute_ref, reason, amount_minor, status, created_at) VALUES (?, 'provider', ?, ?, ?, 'open', ?)", o.id, d.provider_dispute_ref, String(d.reason || 'Chargeback').slice(0, 300), Number.isInteger(d.amount_minor) ? d.amount_minor : o.total_minor - o.refunded_minor, nowIso());
    if (orders.TRANSITIONS[o.status].includes('disputed')) orders.setStatus(o, 'disputed');
    notifyAdmins('dispute', 'Dispute opened on ' + o.order_no, 'The payment provider reported a dispute. Payouts for this order are blocked.');
    notifyUser(o.seller_id, 'dispute', 'Dispute on order ' + o.order_no, 'A dispute was opened. Earnings for this order are on hold.', '/dashboard/orders');
    return ['processed'];
  },
  'dispute.closed'(d) {
    const dp = db.get('SELECT * FROM disputes WHERE provider_dispute_ref = ?', d.provider_dispute_ref);
    if (!dp || dp.status !== 'open') return ['ignored', 'unknown or closed dispute'];
    let o = db.get('SELECT * FROM orders WHERE id = ?', dp.order_id);
    const won = d.outcome === 'won';
    db.run('UPDATE disputes SET status = ?, resolved_at = ? WHERE id = ?', won ? 'won' : 'lost', nowIso(), dp.id);
    if (!won) {
      o = orders.applyMoneyReturn(o, dp.amount_minor || (o.total_minor - o.refunded_minor), 'chargeback', 'chargeback:dispute:' + dp.id, null);
    }
    o = db.get('SELECT * FROM orders WHERE id = ?', o.id);
    if (o.status === 'disputed') {
      const back = o.completed_at ? 'completed' : o.delivered_at ? 'delivered' : o.shipped_at ? 'shipped' : 'paid';
      orders.setStatus(o, back);
    }
    return ['processed'];
  },

  'payout.paid'(d) { return payouts.markPaid(d.payout_id, d.provider_payout_ref) ? ['processed'] : ['ignored', 'unknown or settled payout']; },
  'payout.failed'(d) { return payouts.markFailed(d.payout_id, d.reason) ? ['processed'] : ['ignored', 'unknown or settled payout']; },

  'seller.onboarding'(d) {
    const sp = db.get('SELECT * FROM seller_profiles WHERE user_id = ?', d.seller_id);
    if (!sp || !['verified', 'rejected', 'pending'].includes(d.status)) return ['ignored', 'unknown seller or status'];
    db.run('UPDATE seller_profiles SET payout_status = ?, provider_account_ref = COALESCE(?, provider_account_ref) WHERE user_id = ?', d.status, d.account_ref || null, sp.user_id);
    notifyUser(sp.user_id, 'payout_onboarding', d.status === 'verified' ? 'Payout set-up approved' : 'Payout set-up ' + d.status, d.status === 'verified' ? 'You can now receive orders and payouts.' : 'The payment provider did not approve your payout set-up yet.', '/dashboard/finance');
    return ['processed'];
  },
};

// Entry point used by POST /api/webhooks/payments. `raw` is the exact request body bytes.
function receive(raw, headers) {
  const provider = payments.provider();
  if (!provider) throw new HttpError(409, 'payments_off', 'Payments are not enabled.');
  const event = provider.verifyWebhook(raw, headers); // throws on bad signature
  const hash = sha256(raw);
  return db.tx(() => {
    try {
      db.run("INSERT INTO webhook_events (provider, event_id, type, payload_sha256, status, received_at) VALUES (?,?,?,?, 'processing', ?)", provider.name, event.id, event.type, hash, nowIso());
    } catch (e) {
      if (/UNIQUE/.test(String(e.message))) return { duplicate: true };
      throw e;
    }
    const row = db.get('SELECT id FROM webhook_events WHERE provider = ? AND event_id = ?', provider.name, event.id);
    const h = handlers[event.type];
    let status = 'ignored'; let note = 'unhandled event type';
    if (h) { const out = h(event.data || {}, provider.name); status = out[0]; note = out[1] || null; }
    db.run('UPDATE webhook_events SET status = ?, error = ?, processed_at = ? WHERE id = ?', status === 'rejected' ? 'error' : status, status === 'rejected' || status === 'ignored' ? note : null, nowIso(), row.id);
    return { duplicate: false, status, note };
  });
}

module.exports = { receive, handlers };
