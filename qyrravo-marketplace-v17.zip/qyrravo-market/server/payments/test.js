'use strict';
// TEST-MODE PAYMENT SIMULATOR. NO REAL MONEY EVER MOVES.
// It behaves like a real provider in the ways that matter for security: checkout happens on a separate
// "provider" page, and the app only learns about payment results through SIGNED webhooks that go through
// the very same verification code real providers will use.
const crypto = require('crypto');
const config = require('../config');
const { hmacHex, safeEqual, HttpError } = require('../util');

const name = 'test';
const isSimulator = true;

async function createCheckout({ payment }) {
  const providerRef = 'test_pay_' + payment.id + '_' + crypto.randomBytes(6).toString('hex');
  return { providerRef, checkoutUrl: config.appUrl + '/#/test-pay/' + payment.id };
}
async function refund({ refund }) { return { providerRefundRef: 'test_refund_' + refund.id + '_' + crypto.randomBytes(4).toString('hex') }; }
async function cancelSubscription() { return {}; }
async function startSellerOnboarding({ seller }) { return { accountRef: 'test_acct_' + seller.user_id, url: null }; }
async function requestPayout({ payout }) { return { providerPayoutRef: 'test_payout_' + payout.id + '_' + crypto.randomBytes(4).toString('hex') }; }

// Signature scheme used by the simulator (a real provider has its own; its adapter maps it to the same event shape):
//   header X-QY-Signature: t=<unix seconds>,v1=<hex hmac-sha256 of "<t>.<raw body>" using PAYMENT_WEBHOOK_SECRET>
function sign(rawBody, t = Math.floor(Date.now() / 1000), secret = config.webhookSecret) {
  return 't=' + t + ',v1=' + hmacHex(secret, t + '.' + rawBody);
}
function verifyWebhook(raw, headers) {
  const h = headers['x-qy-signature'];
  const m = /^t=(\d+),v1=([a-f0-9]{64})$/.exec(String(h || ''));
  if (!m) throw new HttpError(400, 'bad_signature', 'Missing or malformed signature.');
  const age = Math.abs(Math.floor(Date.now() / 1000) - Number(m[1]));
  if (age > 300) throw new HttpError(400, 'stale_signature', 'Signature timestamp is outside the allowed window.');
  const expected = hmacHex(config.webhookSecret, m[1] + '.' + raw.toString('utf8'));
  if (!safeEqual(expected, m[2])) throw new HttpError(400, 'bad_signature', 'Signature does not match.');
  let ev;
  try { ev = JSON.parse(raw.toString('utf8')); } catch (e) { throw new HttpError(400, 'bad_json', 'Webhook body is not JSON.'); }
  if (!ev || typeof ev.id !== 'string' || typeof ev.type !== 'string' || typeof ev.data !== 'object') throw new HttpError(400, 'bad_event', 'Unexpected event shape.');
  return ev;
}

module.exports = { name, isSimulator, createCheckout, refund, cancelSubscription, startSellerOnboarding, requestPayout, verifyWebhook, sign };
