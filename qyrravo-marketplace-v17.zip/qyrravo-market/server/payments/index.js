'use strict';
// Payment provider adapters. The rest of the app only talks to this interface:
//   createCheckout({payment, user, description}) -> { providerRef, checkoutUrl }
//   refund({payment, refund}) -> { providerRefundRef? }     (confirmation ALWAYS arrives later via webhook)
//   cancelSubscription({subscription}) -> void
//   startSellerOnboarding({seller}) -> { accountRef, url? }
//   requestPayout({payout}) -> { providerPayoutRef? }
//   verifyWebhook(rawBodyBuffer, headers) -> normalized event { id, type, data }  (throws if the signature is bad)
// Money is NEVER considered received/refunded/paid out because of a browser click: only a verified webhook counts.
const config = require('../config');
const test = require('./test');
const tap = require('./tap');

const providers = { test, tap };
function provider() {
  if (config.paymentMode === 'off') return null;
  const p = providers[config.paymentProvider];
  if (!p) throw new Error('Unknown PAYMENT_PROVIDER ' + config.paymentProvider);
  return p;
}
const requireProvider = () => {
  const p = provider();
  if (!p) { const { HttpError } = require('../util'); throw new HttpError(409, 'payments_unavailable', 'Payments are not switched on yet.'); }
  return p;
};
module.exports = { provider, requireProvider, providers };
