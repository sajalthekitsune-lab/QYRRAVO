'use strict';
// Tap Payments adapter - PLACEHOLDER, NOT IMPLEMENTED.
// I researched Tap's public documentation (see docs/PAYMENTS.md) but I have no Tap account, no keys, and no way to test
// against Tap, so I deliberately did NOT write code that pretends to work. Writing it needs, from you:
//   - a Tap account that has been enabled as a MARKETPLACE (Tap decides this)
//   - test API keys + the webhook signing method from Tap's dashboard/docs
// Until then the app refuses to start in PAYMENT_MODE=live with this provider, instead of faking payments.
const name = 'tap';
const isSimulator = false;
const nope = () => { throw new Error('The Tap adapter is not implemented yet. See docs/PAYMENTS.md for exactly what is needed.'); };
module.exports = { name, isSimulator, createCheckout: nope, refund: nope, cancelSubscription: nope, startSellerOnboarding: nope, requestPayout: nope, verifyWebhook: nope, notImplemented: true };
