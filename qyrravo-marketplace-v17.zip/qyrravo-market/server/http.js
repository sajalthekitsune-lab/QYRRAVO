'use strict';
// Tiny HTTP framework: routing, JSON bodies, cookies, security headers, rate limiting,
// CSRF protection and server-side permission checks. No dependencies.
const fs = require('fs');
const path = require('path');
const config = require('./config');
const db = require('./db');
const { HttpError, forbidden, nowIso } = require('./util');
const auth = require('./auth');

const routes = [];
function add(method, pattern, opts, handler) {
  if (typeof opts === 'function') { handler = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, opts, handler, pattern });
}
const api = {
  get: (p, o, h) => add('GET', p, o, h),
  post: (p, o, h) => add('POST', p, o, h),
  patch: (p, o, h) => add('PATCH', p, o, h),
  put: (p, o, h) => add('PUT', p, o, h),
  delete: (p, o, h) => add('DELETE', p, o, h),
};

// ---- rate limiting (in memory; fine for one server process. Use Redis if you scale out.) ----
const hits = new Map();
function rateAllowed(key, limit, windowMs) {
  limit = limit * config.rateScale;
  const t = Date.now();
  const arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
  if (arr.length >= limit) { hits.set(key, arr); return false; }
  arr.push(t); hits.set(key, arr);
  if (hits.size > 50000) for (const k of hits.keys()) { hits.delete(k); if (hits.size < 25000) break; }
  return true;
}
const RATE = { auth: [40, 15 * 60e3], write: [120, 60e3], read: [600, 60e3], upload: [60, 60e3], webhook: [300, 60e3], assistant: [20, 60e3], redeem: [12, 10 * 60e3] };

function clientIp(req) {
  if (config.trustProxy) {
    const xf = req.headers['x-forwarded-for'];
    if (xf) return String(xf).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'");
  if (config.cookieSecure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function setCookie(res, name, value, { maxAgeSec, clear } = {}) {
  const parts = [name + '=' + (clear ? '' : encodeURIComponent(value)), 'Path=/', 'HttpOnly', 'SameSite=Lax'];
  if (config.cookieSecure) parts.push('Secure');
  if (clear) parts.push('Max-Age=0'); else if (maxAgeSec) parts.push('Max-Age=' + maxAgeSec);
  const prev = res.getHeader('Set-Cookie');
  res.setHeader('Set-Cookie', prev ? [].concat(prev, parts.join('; ')) : parts.join('; '));
}

function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > maxBytes) { reject(new HttpError(413, 'too_large', 'That request is too large.')); chunks.length = 0; return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function sendJson(res, status, obj, headers) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body), ...(headers || {}) });
  res.end(body);
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json', '.woff': 'font/woff', '.woff2': 'font/woff2' };
const PUBLIC_DIR = path.join(config.root, 'public');
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' ) rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    const isHtml = ext === '.html';
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': isHtml ? 'no-cache' : 'public, max-age=300',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

function originOk(req) {
  const o = req.headers.origin;
  if (!o) return true; // non-browser clients; browsers always send Origin on cross-site POSTs
  try { return new URL(o).origin === new URL(config.appUrl).origin || new URL(o).host === req.headers.host; } catch (e) { return false; }
}

async function handle(req, res) {
  securityHeaders(res);
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;
  const method = req.method === 'HEAD' ? 'GET' : req.method;
  const ip = clientIp(req);

  try {
    if (!pathname.startsWith('/api/') && !pathname.startsWith('/media/')) {
      if (method !== 'GET') throw new HttpError(405, 'method_not_allowed', 'Method not allowed.');
      return serveStatic(req, res, pathname);
    }

    let route = null; let params = {};
    for (const r of routes) {
      if (r.method !== method) continue;
      const m = r.re.exec(pathname);
      if (m) { route = r; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); }); break; }
    }
    if (!route) throw new HttpError(404, 'not_found', 'That API endpoint does not exist.');
    const opts = route.opts;

    const bucket = opts.rate || (method === 'GET' ? 'read' : 'write');
    const [lim, win] = RATE[bucket];
    if (!rateAllowed(bucket + ':' + ip, lim, win)) throw new HttpError(429, 'rate_limited', 'Too many requests. Please slow down and try again shortly.');

    const unsafe = method !== 'GET';
    if (unsafe && !opts.noOriginCheck && !originOk(req)) throw forbidden('Cross-site request blocked.');

    // session
    const cookies = parseCookies(req);
    const sess = cookies.qy_sid ? auth.loadSession(cookies.qy_sid) : null;
    const ctx = { req, res, params, query: Object.fromEntries(url.searchParams), ip, user: sess ? sess.user : null, session: sess, body: {}, raw: null, setCookie: (n, v, o) => setCookie(res, n, v, o) };

    // authorization (server side - never trust the browser)
    if (opts.auth) {
      if (!ctx.user) throw new HttpError(401, 'auth_required', 'Please sign in to continue.');
      if (opts.auth === 'seller') {
        if (!(ctx.user.role === 'seller' || ctx.user.role === 'admin' || ctx.user.role === 'moderator') ) throw forbidden('Seller account required.');
      } else if (opts.auth !== true && opts.auth !== 'user') {
        if (!auth.can(ctx.user, opts.auth)) throw forbidden('You do not have the "' + opts.auth + '" permission.');
      }
    }
    // CSRF: every state-changing request from a signed-in session must carry the session's token
    if (unsafe && ctx.session && !opts.noCsrf) {
      const tok = req.headers['x-csrf-token'];
      if (!tok || !require('./util').safeEqual(tok, ctx.session.csrf)) throw forbidden('Security token missing or invalid. Reload the page and try again.');
    }

    // body
    if (unsafe) {
      if (opts.raw) {
        ctx.raw = await readBody(req, opts.maxBytes || config.maxJsonBytes);
      } else {
        const buf = await readBody(req, opts.maxBytes || config.maxJsonBytes);
        if (buf.length) {
          if (!String(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) throw new HttpError(415, 'unsupported_media_type', 'Send JSON.');
          try { ctx.body = JSON.parse(buf.toString('utf8')); } catch (e) { throw new HttpError(400, 'bad_json', 'The request body is not valid JSON.'); }
          if (ctx.body === null || typeof ctx.body !== 'object' || Array.isArray(ctx.body)) throw new HttpError(400, 'bad_json', 'The request body must be a JSON object.');
        }
        ctx.rawText = buf;
      }
    }

    const result = await route.handler(ctx);
    if (res.writableEnded || res.headersSent) return;
    if (result && result.__raw) {
      res.writeHead(result.status || 200, result.headers || {});
      return res.end(result.body);
    }
    sendJson(res, (result && result.__status) || 200, { ok: true, ...(result && result.__status ? { ...result, __status: undefined } : result) });
  } catch (e) {
    if (res.headersSent) { try { res.end(); } catch (_) { /* ignore */ } return; }
    if (e instanceof HttpError) {
      if (e.status === 413) { res.setHeader('Connection', 'close'); res.on('finish', () => req.destroy()); }
      return sendJson(res, e.status, { ok: false, error: { code: e.code, message: e.message, details: e.details } });
    }
    // Unknown error: log it (without secrets or request bodies) and return a generic message
    try { db.run('INSERT INTO error_log (level, message, route, created_at) VALUES (?,?,?,?)', 'error', String(e && e.message || e).slice(0, 500), method + ' ' + pathname, nowIso()); } catch (_) { /* ignore */ }
    if (!config.isProd) console.error('[server error]', method, pathname, e);
    sendJson(res, 500, { ok: false, error: { code: 'server_error', message: 'Something went wrong on our side. Please try again.' } });
  }
}

module.exports = { api, handle, rateAllowed, clientIp, setCookie, sendJson, RATE };
