'use strict';
const db = require('./db');
const { parseJson, nowIso } = require('./util');
const COUNTRIES = require('./data/countries.json');

// Defaults. Everything here can be changed by an administrator (audited) except where noted.
const DEFAULTS = {
  commission_bps: 500,                  // PLACEHOLDER: 5.00%. Not a final rate - the owner must choose.
  commission_is_placeholder: true,      // stays true until an admin explicitly confirms a final rate
  commission_fixed_usd_minor: 0,        // optional fixed fee per order, in USD cents (converted for other currencies)
  commission_base: 'items',             // 'items' or 'items_and_shipping'
  supported_currencies: ['USD', 'QAR', 'AED', 'SAR'],
  enabled_countries: COUNTRIES.filter((c) => !c.restricted).map((c) => c.code),
  payout_countries: ['QA'],             // countries where seller payout onboarding is offered (provider support must be confirmed first)
  checkout_enabled: true,               // admin kill-switch for buyer checkout
  refund_window_days: 14,
  auto_complete_days: 14,               // shipped orders auto-complete this many days after shipping if buyer is silent
  complete_after_delivered_days: 3,
  reservation_minutes: 30,              // stock reserved for an unpaid order
  code_ttl_minutes: 60,                 // verification code lifetime
  max_images: 8,
  max_image_bytes: 5 * 1024 * 1024,
  min_image_px: 500,
  fx_max_age_hours: 72,
  subscription_period_days: 30,
  billing_currency: 'USD',
  cancellation_rules: 'Premium can be cancelled any time. You keep Premium until the end of the period you already paid for. Payments are not refunded automatically.',
  refund_rules: 'Refunds on orders are decided case by case within the refund window and processed only through the payment provider.',
};

const cache = new Map();
function get(key) {
  if (cache.has(key)) return cache.get(key);
  const row = db.get('SELECT value FROM settings WHERE key = ?', key);
  const v = row ? parseJson(row.value, DEFAULTS[key]) : DEFAULTS[key];
  cache.set(key, v);
  return v;
}
function set(key, value, userId) {
  if (!(key in DEFAULTS)) throw new Error('Unknown setting ' + key);
  db.run('INSERT INTO settings (key, value, updated_by, updated_at) VALUES (?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_by=excluded.updated_by, updated_at=excluded.updated_at',
    key, JSON.stringify(value), userId || null, nowIso());
  cache.set(key, value);
}
const all = () => Object.fromEntries(Object.keys(DEFAULTS).map((k) => [k, get(k)]));
const clearCache = () => cache.clear();

function getPlans() {
  return db.all('SELECT * FROM plans ORDER BY sort').map((p) => ({ ...p, features: parseJson(p.features, []), active: !!p.active }));
}
const getPlan = (id) => getPlans().find((p) => p.id === id);

// ---- FX ----
function getRate(currency) {
  if (currency === 'USD') return { currency, rate: 1, source: 'identity', at: nowIso(), stale: false };
  const r = db.get('SELECT * FROM fx_rates WHERE currency = ?', currency);
  if (!r) return null;
  const ageH = (Date.now() - new Date(r.fetched_at).getTime()) / 3600000;
  return { currency, rate: r.rate_per_usd, source: r.source, at: r.fetched_at, stale: r.source.startsWith('peg:') ? false : ageH > get('fx_max_age_hours') };
}

module.exports = { DEFAULTS, get, set, all, getPlans, getPlan, getRate, clearCache, COUNTRIES };
