'use strict';
const db = require('./db');
const { nowIso } = require('./util');

// Append-only record of important actions (admin changes, moderation decisions, payment status changes).
function audit(actor, action, targetType, targetId, detail, ip) {
  db.run('INSERT INTO audit_logs (actor_id, actor_role, action, target_type, target_id, detail, ip, created_at) VALUES (?,?,?,?,?,?,?,?)',
    actor ? actor.id : null, actor ? actor.role : 'system', action, targetType || null, targetId === undefined || targetId === null ? null : String(targetId),
    detail ? JSON.stringify(detail).slice(0, 4000) : null, ip || null, nowIso());
}
module.exports = { audit };
