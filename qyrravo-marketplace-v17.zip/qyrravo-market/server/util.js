'use strict';
const crypto = require('crypto');

class HttpError extends Error {
  constructor(status, code, message, details) {
    super(message || code);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}
const bad = (code, message, details) => new HttpError(400, code, message, details);
const forbidden = (message) => new HttpError(403, 'forbidden', message || 'You do not have permission to do that.');
const notFound = (message) => new HttpError(404, 'not_found', message || 'Not found.');
const conflict = (code, message, details) => new HttpError(409, code, message, details);

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
const sha256 = (data) => crypto.createHash('sha256').update(data).digest('hex');
function safeEqual(a, b) {
  const x = Buffer.from(String(a)); const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
const hmacHex = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest('hex');

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;
const isEmail = (s) => typeof s === 'string' && s.length <= 254 && EMAIL_RE.test(s);

// Collapse whitespace, strip control characters, enforce length. Throws a validation error if the value is wrong.
function text(v, { min = 0, max = 200, field = 'value', multiline = false, required = true } = {}) {
  if (v === undefined || v === null || v === '') {
    if (required && min > 0) throw bad('validation', field + ' is required.', { field });
    return '';
  }
  if (typeof v !== 'string') throw bad('validation', field + ' must be text.', { field });
  let s = v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
  s = multiline ? s.replace(/[ \t]+\n/g, '\n').trim() : s.replace(/\s+/g, ' ').trim();
  if (s.length < min) throw bad('validation', field + ' must be at least ' + min + ' characters.', { field });
  if (s.length > max) throw bad('validation', field + ' must be at most ' + max + ' characters.', { field });
  return s;
}
function int(v, { min = 0, max = 1e12, field = 'value' } = {}) {
  const n = typeof v === 'string' && /^-?\d+$/.test(v.trim()) ? Number(v) : v;
  if (!Number.isInteger(n)) throw bad('validation', field + ' must be a whole number.', { field });
  if (n < min || n > max) throw bad('validation', field + ' must be between ' + min + ' and ' + max + '.', { field });
  return n;
}
const oneOf = (v, list, field) => {
  if (!list.includes(v)) throw bad('validation', field + ' is not valid.', { field });
  return v;
};
const nowIso = () => new Date().toISOString();
const addMs = (iso, ms) => new Date(new Date(iso).getTime() + ms).toISOString();
const addDays = (iso, d) => addMs(iso, d * 86400000);
const parseJson = (s, fallback) => { try { return JSON.parse(s); } catch (e) { return fallback; } };

// Only the owner may carry the crown or the QYRRAVO name (stops impersonation).
function noImpersonation(name, user) {
  if (user && user.isOwner) return name;
  if (/\u{1F451}/u.test(name) || /q\s*y\s*r\s*r\s*a\s*v\s*o/i.test(name)) throw bad('validation', 'That name is reserved for the owner of QYRRAVO. Please choose another.', { field: 'Name' });
  return name;
}
module.exports = { noImpersonation, HttpError, bad, forbidden, notFound, conflict, randomToken, sha256, safeEqual, hmacHex, isEmail, text, int, oneOf, nowIso, addMs, addDays, parseJson };
