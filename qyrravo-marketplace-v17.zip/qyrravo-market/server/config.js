'use strict';
// Reads configuration from environment variables (and an optional .env file).
// Secrets live ONLY here (server side). Nothing in /public ever contains a secret.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');

function loadDotEnv(file) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    for (const line of text.split(/\r?\n/)) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
      if (!m || line.trim().startsWith('#')) continue;
      let v = m[2];
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      if (process.env[m[1]] === undefined) process.env[m[1]] = v;
    }
  } catch (e) { /* no .env file is fine */ }
}
if (process.env.QY_NO_DOTENV !== '1') { if (process.env.QY_ENV_FILE) loadDotEnv(process.env.QY_ENV_FILE); loadDotEnv(path.join(ROOT, '.env')); }

const env = process.env;
const isProd = env.NODE_ENV === 'production';
const appUrl = (env.APP_URL || 'http://localhost:3000').replace(/\/+$/, '');

const config = {
  root: ROOT,
  isProd,
  port: parseInt(env.PORT || '3000', 10),
  appUrl,
  databasePath: path.resolve(ROOT, env.DATABASE_PATH || './data/qyrravo.db'),
  uploadDir: path.resolve(ROOT, env.UPLOAD_DIR || './uploads'),
  cookieSecure: env.COOKIE_SECURE ? env.COOKIE_SECURE === '1' : appUrl.startsWith('https://'),
  trustProxy: env.TRUST_PROXY === '1',
  supportEmail: env.SUPPORT_EMAIL || 'qyrravo@gmail.com',

  // Payments: 'off' (no checkout), 'test' (internal simulator - NO REAL MONEY), 'live' (real provider)
  paymentMode: env.PAYMENT_MODE || 'off',
  paymentProvider: env.PAYMENT_PROVIDER || 'test',
  paymentApiKey: env.PAYMENT_SECRET_KEY || '',
  webhookSecret: env.PAYMENT_WEBHOOK_SECRET || '',

  // Owner account: created/updated at start-up from .env (the password is NEVER stored in source code).
  ownerEmail: (env.OWNER_EMAIL || '').trim().toLowerCase(),
  ownerPassword: env.OWNER_PASSWORD || '',
  // Help assistant: uses Claude when a key is set, otherwise a built-in answer list.
  googleClientId: env.GOOGLE_CLIENT_ID || '',
  googleClientSecret: env.GOOGLE_CLIENT_SECRET || '',
  geminiKey: env.GEMINI_API_KEY || '',
  geminiModel: env.GEMINI_MODEL || 'gemini-2.5-flash',
  anthropicKey: env.ANTHROPIC_API_KEY || '',
  assistantModel: env.ASSISTANT_MODEL || 'claude-sonnet-4-5',

  emailProvider: env.EMAIL_PROVIDER || 'none',   // 'none' | 'resend'
  emailApiKey: env.EMAIL_API_KEY || '',
  emailFrom: env.EMAIL_FROM || '',

  // Test-only multiplier for rate limits (ignored in production)
  rateScale: !isProd && Number(env.RATE_LIMIT_SCALE) > 0 ? Number(env.RATE_LIMIT_SCALE) : 1,
  sessionDays: 14,
  maxJsonBytes: 256 * 1024,
};

if (!config.webhookSecret) {
  if (config.paymentMode === 'live') {
    throw new Error('PAYMENT_WEBHOOK_SECRET is required when PAYMENT_MODE=live');
  }
  // test mode: a random per-process secret is enough, because the simulator signs with the same secret
  config.webhookSecret = crypto.randomBytes(32).toString('hex');
}
if (!['off', 'test', 'live'].includes(config.paymentMode)) {
  throw new Error('PAYMENT_MODE must be off, test or live');
}
if (config.paymentMode === 'live' && config.paymentProvider === 'test') {
  throw new Error('PAYMENT_MODE=live cannot use the test provider');
}
if (config.paymentMode === 'test' && isProd && env.ALLOW_TEST_PAYMENTS_IN_PRODUCTION !== '1') {
  throw new Error('Refusing to run the payment SIMULATOR with NODE_ENV=production. Use PAYMENT_MODE=off or live.');
}

module.exports = config;
