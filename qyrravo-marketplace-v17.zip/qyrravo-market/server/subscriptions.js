'use strict';
// Seller subscriptions (Premium, VIP). A paid plan is activated ONLY by a verified payment-provider confirmation (webhook).
// Policy when a paid plan ends: listings priced above the Free limit are paused (hidden from buyers) automatically -
// they are NEVER deleted, and they come back by themselves if the seller renews. Open orders are unaffected.
// Upgrading (Premium -> VIP) starts a new paid month today; unused time on the old plan is not credited. Downgrading mid-period is not supported: cancel and wait for the period to end.
const config = require('./config');
const db = require('./db');
const settings = require('./settings');
const ledger = require('./ledger');
const listings = require('./listings');
const payments = require('./payments');
const { notifyUser } = require('./notify');
const { audit } = require('./audit');
const money = require('./money');
const { conflict, randomToken, nowIso, addDays, addMs } = require('./util');

function view(userId) {
  const plans = settings.getPlans().filter((p) => p.active);
  const sub = db.get('SELECT * FROM subscriptions WHERE user_id = ?', userId);
  const l = listings.limitsFor(userId);
  const paused = db.get(`SELECT COUNT(*) AS n FROM products WHERE seller_id = ? AND status = 'approved' AND deleted_at IS NULL AND price_usd_minor > ?`, userId, l.maxUsdMinor).n;
  return {
    effectivePlan: l.planId, effectivePlanName: l.planName,
    limits: { maxItemUsdMinor: l.maxUsdMinor, freeMaxUsdMinor: l.freeMaxUsdMinor, platformMaxUsdMinor: l.platformMaxUsdMinor, maxActiveListings: l.maxActive, maxQuantity: l.maxQuantity },
    activeListings: listings.activeListingCount(userId),
    subscription: sub ? { status: sub.status, planId: sub.plan_id, currentPeriodEnd: sub.current_period_end, cancelAtPeriodEnd: !!sub.cancel_at_period_end } : null,
    listingsPausedByPlan: paused,
    plans: plans.map((p) => ({ id: p.id, name: p.name, priceMinor: p.price_minor, currency: p.currency, maxItemUsdMinor: p.max_item_price_usd_minor, maxActiveListings: p.max_active_listings, maxQuantity: p.max_quantity, features: p.features })),
    billingCurrency: settings.get('billing_currency'),
    paymentMode: config.paymentMode,
  };
}

async function startCheckout(user, planId) {
  const provider = payments.requireProvider();
  const plan = settings.getPlan(String(planId || 'premium'));
  if (!plan || plan.id === 'free' || !plan.active) throw conflict('plan_unavailable', 'That plan is not available right now.');
  const t = nowIso();
  let sub = db.get('SELECT * FROM subscriptions WHERE user_id = ?', user.id);
  const live = sub && ['active', 'past_due', 'canceled'].includes(sub.status) && sub.current_period_end > t;
  if (live) {
    const cur = settings.getPlan(sub.plan_id);
    if (sub.plan_id === plan.id && !sub.cancel_at_period_end && sub.status !== 'canceled') throw conflict('already_subscribed', 'You already have an active ' + plan.name + ' subscription.');
    if (cur && plan.price_minor < cur.price_minor) throw conflict('downgrade_not_supported', 'You are on ' + cur.name + ' until ' + sub.current_period_end.slice(0, 10) + '. To move to a cheaper plan, cancel it and choose the new plan when the period ends.');
  }
  if (!sub) {
    const r = db.run("INSERT INTO subscriptions (user_id, plan_id, status, provider, created_at, updated_at) VALUES (?, ?, 'pending', ?, ?, ?)", user.id, plan.id, provider.name, t, t);
    sub = db.get('SELECT * FROM subscriptions WHERE id = ?', r.id);
  }
  // reuse a recent unpaid checkout instead of creating duplicates
  const recent = db.get("SELECT * FROM payments WHERE subscription_id = ? AND kind = 'subscription' AND status = 'pending' AND plan_id = ? AND created_at > ? ORDER BY id DESC", sub.id, plan.id, addMs(t, -30 * 60000));
  if (recent && recent.checkout_url) return { checkoutUrl: recent.checkout_url, paymentId: recent.id, amountMinor: recent.amount_minor, currency: recent.currency, reused: true };
  const pay = db.run("INSERT INTO payments (kind, user_id, subscription_id, amount_minor, currency, status, provider, idempotency_key, created_at, plan_id) VALUES ('subscription', ?, ?, ?, ?, 'pending', ?, ?, ?, ?)",
    user.id, sub.id, plan.price_minor, plan.currency, provider.name, 'sub:' + sub.id + ':' + randomToken(9), t, plan.id);
  const payment = db.get('SELECT * FROM payments WHERE id = ?', pay.id);
  try {
    const c = await provider.createCheckout({ payment, user, description: 'QYRRAVO ' + plan.name + ' - 1 month' });
    db.run('UPDATE payments SET provider_payment_ref = ?, checkout_url = ? WHERE id = ?', c.providerRef, c.checkoutUrl, payment.id);
    return { checkoutUrl: c.checkoutUrl, paymentId: payment.id, amountMinor: payment.amount_minor, currency: payment.currency };
  } catch (e) {
    db.run("UPDATE payments SET status = 'failed', failure_reason = ? WHERE id = ?", 'checkout creation failed', payment.id);
    throw conflict('checkout_failed', 'We could not start checkout. Nothing was charged.');
  }
}

// Called from the verified webhook handler (inside a transaction) after amount + currency were checked.
function activate(subscriptionId, paymentId, { periodEnd } = {}) {
  const sub = db.get('SELECT * FROM subscriptions WHERE id = ?', subscriptionId);
  const pay = db.get('SELECT * FROM payments WHERE id = ?', paymentId);
  const planId = pay.plan_id || sub.plan_id;
  const plan = settings.getPlan(planId);
  const t = nowIso();
  const stillRunning = sub.current_period_end && sub.current_period_end > t && ['active', 'past_due', 'canceled'].includes(sub.status);
  const changing = planId !== sub.plan_id;
  const start = stillRunning && !changing ? sub.current_period_end : t;
  const end = periodEnd || addDays(start, settings.get('subscription_period_days'));
  db.run("UPDATE subscriptions SET plan_id = ?, status = 'active', current_period_start = ?, current_period_end = ?, cancel_at_period_end = 0, updated_at = ? WHERE id = ?", planId, start, end, t, subscriptionId);
  ledger.post('subscription_payment', { currency: pay.currency, amount: pay.amount_minor, subscriptionId, paymentId, key: 'sub_payment:payment:' + paymentId, memo: plan.name + ' subscription payment confirmed' });
  audit(null, 'subscription.activated', 'subscription', subscriptionId, { paymentId, planId, periodEnd: end });
  notifyUser(sub.user_id, 'subscription_confirmed', plan.name + ' payment confirmed', 'Your ' + plan.name + ' plan is active until ' + end.slice(0, 10) + '. You can list items up to ' + money.format(plan.max_item_price_usd_minor, 'USD') + '.', '/dashboard/subscription');
}

async function cancel(user) {
  const sub = db.get('SELECT * FROM subscriptions WHERE user_id = ?', user.id);
  if (!sub || sub.plan_id === 'free' || !['active', 'past_due'].includes(sub.status) || sub.current_period_end <= nowIso()) throw conflict('no_active_subscription', 'You do not have an active paid subscription.');
  if (sub.cancel_at_period_end) return view(user.id);
  const p = payments.provider();
  if (p) { try { await p.cancelSubscription({ subscription: sub }); } catch (e) { throw conflict('cancel_failed', 'We could not reach the payment provider to cancel. Nothing was changed - please try again.'); } }
  db.run("UPDATE subscriptions SET cancel_at_period_end = 1, status = 'canceled', updated_at = ? WHERE id = ?", nowIso(), sub.id);
  audit(user, 'subscription.cancel_requested', 'subscription', sub.id, null);
  notifyUser(user.id, 'subscription_canceled', 'Plan cancelled', 'Your plan will not renew. You keep it until ' + sub.current_period_end.slice(0, 10) + '. After that, listings priced above the Free limit are paused (not deleted).', '/dashboard/subscription');
  return view(user.id);
}

// Run by the scheduled job: expiry + renewal reminders.
function runMaintenance() {
  const t = nowIso();
  const ended = db.all("SELECT * FROM subscriptions WHERE plan_id != 'free' AND status IN ('active','past_due','canceled') AND current_period_end <= ?", t);
  for (const s of ended) {
    db.run("UPDATE subscriptions SET status = 'expired', updated_at = ? WHERE id = ?", t, s.id);
    const n = db.get(`SELECT COUNT(*) AS n FROM products WHERE seller_id = ? AND status = 'approved' AND deleted_at IS NULL AND price_usd_minor > ?`, s.user_id, settings.getPlan('free').max_item_price_usd_minor).n;
    notifyUser(s.user_id, 'subscription_expired', 'Your paid plan expired', 'Your paid plan has ended.' + (n ? ' ' + n + ' listing(s) above the Free limit are now paused and hidden from buyers - they are not deleted and return automatically if you renew.' : ''), '/dashboard/subscription', 'sub_expired:' + s.id + ':' + s.current_period_end);
    audit(null, 'subscription.expired', 'subscription', s.id, { listingsPaused: n });
  }
  for (const [days, key] of [[7, '7d'], [1, '1d']]) {
    const soon = db.all("SELECT * FROM subscriptions WHERE plan_id != 'free' AND status IN ('active','past_due') AND current_period_end > ? AND current_period_end <= ?", t, addDays(t, days));
    for (const s of soon) {
      const msg = s.cancel_at_period_end || s.status === 'canceled' ? 'Your plan ends on ' + s.current_period_end.slice(0, 10) + ' (it will not renew).' : 'Your plan renews on ' + s.current_period_end.slice(0, 10) + ' (if your payment goes through).';
      notifyUser(s.user_id, 'subscription_reminder', 'Plan ends/renews soon', msg, '/dashboard/subscription', 'sub_reminder:' + s.id + ':' + s.current_period_end + ':' + key);
    }
  }
}

module.exports = { view, startCheckout, activate, cancel, runMaintenance };
