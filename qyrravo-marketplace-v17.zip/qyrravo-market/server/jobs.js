'use strict';
const db = require('./db');
const orders = require('./orders');
const subscriptions = require('./subscriptions');
const { nowIso, addDays } = require('./util');

// All jobs are safe to run repeatedly (idempotent).
function runAll() {
  const t = nowIso();
  const out = {};
  const step = (name, fn) => { try { fn(); } catch (e) { out[name] = String(e.message); try { db.run('INSERT INTO error_log (level, message, route, created_at) VALUES (?,?,?,?)', 'error', 'job ' + name + ': ' + String(e.message).slice(0, 400), 'job', nowIso()); } catch (_) { /* ignore */ } } };
  step('orders', () => orders.runMaintenance());
  step('subscriptions', () => subscriptions.runMaintenance());
  step('codes', () => db.run("UPDATE verification_submissions SET status = 'expired' WHERE status = 'code_issued' AND code_expires_at < ?", t));
  step('sessions', () => db.run('DELETE FROM sessions WHERE expires_at < ?', t));
  step('tokens', () => db.run('DELETE FROM auth_tokens WHERE expires_at < ?', addDays(t, -7)));
  return out;
}
function start(intervalMs = 60000) {
  const h = setInterval(runAll, intervalMs);
  h.unref();
  setTimeout(runAll, 2000).unref();
  return h;
}
module.exports = { runAll, start };
