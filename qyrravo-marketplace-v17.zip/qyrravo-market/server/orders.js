'use strict';
// Orders, stock reservation, the order state machine, commissions and refunds.
const crypto = require('crypto');
const config = require('./config');
const db = require('./db');
const settings = require('./settings');
const money = require('./money');
const ledger = require('./ledger');
const listings = require('./listings');
const payments = require('./payments');
const { notifyUser } = require('./notify');
const { audit } = require('./audit');
const { bad, conflict, notFound, forbidden, text, int, nowIso, addMs, addDays, randomToken } = require('./util');

// from -> allowed next states (enforced on the server for every change)
const TRANSITIONS = {
  pending_payment: ['paid', 'payment_failed', 'cancelled'],
  payment_failed: [],
  paid: ['shipped', 'refunded', 'disputed', 'cancelled'],
  shipped: ['delivered', 'completed', 'refunded', 'disputed'],
  delivered: ['completed', 'refunded', 'disputed'],
  disputed: ['paid', 'shipped', 'delivered', 'completed', 'refunded'],
  completed: ['refunded', 'disputed'],
  cancelled: [],
  refunded: [],
};
function setStatus(order, to, extra = {}) {
  if (!TRANSITIONS[order.status] || !TRANSITIONS[order.status].includes(to)) throw conflict('bad_transition', 'An order cannot move from ' + order.status + ' to ' + to + '.');
  const t = nowIso();
  const cols = { status: to, updated_at: t, ...extra };
  const keys = Object.keys(cols);
  db.run('UPDATE orders SET ' + keys.map((k) => k + ' = ?').join(', ') + ' WHERE id = ?', ...keys.map((k) => cols[k]), order.id);
  audit(null, 'order.status', 'order', order.id, { from: order.status, to });
  return db.get('SELECT * FROM orders WHERE id = ?', order.id);
}

function newOrderNo() {
  for (let i = 0; i < 5; i++) {
    const no = 'QY-' + new Date().toISOString().slice(2, 10).replace(/-/g, '') + '-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    if (!db.get('SELECT 1 AS x FROM orders WHERE order_no = ?', no)) return no;
  }
  throw new Error('could not allocate order number');
}

function calcCommission(order) {
  const bps = settings.get('commission_bps');
  const baseMode = settings.get('commission_base');
  const base = baseMode === 'items_and_shipping' ? order.items + order.shipping : order.items;
  let fixed = 0;
  const fixedUsd = settings.get('commission_fixed_usd_minor');
  if (fixedUsd > 0) {
    const rate = settings.getRate(order.currency);
    if (rate) fixed = money.fromUsdMinor(fixedUsd, order.currency, rate.rate);
  }
  return { bps, fixed, amount: money.commission(base, bps, fixed) };
}

function shippingInput(s) {
  if (!s || typeof s !== 'object') throw bad('validation', 'Enter a delivery address.', { field: 'shipping' });
  const country = String(s.country || '').toUpperCase();
  if (!settings.get('enabled_countries').includes(country)) throw bad('validation', 'We cannot take orders for that country yet.', { field: 'country' });
  return {
    name: text(s.name, { min: 2, max: 100, field: 'Full name' }),
    line1: text(s.line1, { min: 3, max: 150, field: 'Address' }),
    line2: text(s.line2, { max: 150, field: 'Address line 2', required: false }),
    city: text(s.city, { min: 2, max: 80, field: 'City' }),
    region: text(s.region, { max: 80, field: 'Region', required: false }),
    postal: text(s.postal, { max: 20, field: 'Postal code', required: false }),
    country,
    phone: text(s.phone, { max: 30, field: 'Phone', required: false }),
  };
}

async function checkout(user, input) {
  if (config.paymentMode === 'off' || !settings.get('checkout_enabled')) throw conflict('checkout_unavailable', 'Checkout is not available yet.');
  const provider = payments.requireProvider();
  if (!user.emailVerified) throw conflict('email_unverified', 'Please verify your email address before buying.');
  const sellerId = int(input.sellerId, { min: 1, field: 'seller' });
  if (!Array.isArray(input.items) || input.items.length < 1 || input.items.length > 20) throw bad('validation', 'Your cart is empty.', { field: 'items' });
  const key = text(input.idempotencyKey, { min: 8, max: 80, field: 'idempotencyKey' });
  const ship = shippingInput(input.shipping);

  const existing = db.get('SELECT * FROM orders WHERE buyer_id = ? AND idempotency_key = ?', user.id, key);
  if (existing) { // double-click / retry protection: return the same order, never a second one
    const pay = db.get('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC', existing.id);
    return { order: existing, payment: pay, replay: true };
  }
  if (sellerId === user.id) throw conflict('own_listing', 'You cannot buy your own item.');
  const seller = db.get('SELECT sp.*, u.status AS user_status FROM seller_profiles sp JOIN users u ON u.id = sp.user_id WHERE sp.user_id = ?', sellerId);
  if (!seller || seller.user_status !== 'active' || seller.seller_status !== 'active') throw conflict('seller_unavailable', 'This seller is not available.');
  if (seller.payout_status !== 'verified') throw conflict('seller_not_ready', 'This seller has not finished payment set-up yet, so their items cannot be bought right now.');

  const pub = listings.publicWhere('p');
  const lines = [];
  let currency = null;
  for (const it of input.items) {
    const pid = int(it.productId, { min: 1, field: 'productId' });
    const qty = int(it.quantity, { min: 1, max: 99, field: 'quantity' });
    const p = db.get(`SELECT p.* FROM products p WHERE p.id = ? AND p.seller_id = ? AND ${pub.sql}`, pid, sellerId, ...pub.params);
    if (!p) throw conflict('item_unavailable', 'An item in your cart is no longer available.', { productId: pid });
    if (currency && currency !== p.currency) throw conflict('mixed_currency', 'Items from one seller must be in the same currency.');
    currency = p.currency;
    const shipsTo = JSON.parse(p.ships_to);
    if (!shipsTo.includes('WORLD') && !shipsTo.includes(ship.country)) throw conflict('not_shippable', '"' + p.name + '" is not listed for delivery to your country.', { productId: pid });
    if (lines.some((l) => l.p.id === pid)) throw bad('validation', 'The same item appears twice in your cart.');
    lines.push({ p, qty });
  }

  const itemsTotal = lines.reduce((a, l) => a + l.p.price_minor * l.qty, 0);
  const shippingTotal = lines.reduce((a, l) => a + l.p.shipping_fee_minor, 0);
  const total = itemsTotal + shippingTotal;
  const com = calcCommission({ currency, items: itemsTotal, shipping: shippingTotal });
  const t = nowIso();
  const expires = addMs(t, settings.get('reservation_minutes') * 60000);

  const { orderId, paymentId } = db.tx(() => {
    for (const l of lines) { // reserve stock atomically
      const r = db.run("UPDATE products SET quantity_reserved = quantity_reserved + ? WHERE id = ? AND status = 'approved' AND quantity - quantity_reserved >= ?", l.qty, l.p.id, l.qty);
      if (r.changes !== 1) throw conflict('out_of_stock', 'Not enough stock for "' + l.p.name + '".', { productId: l.p.id });
    }
    const o = db.run(`INSERT INTO orders (order_no, buyer_id, seller_id, currency, items_total_minor, shipping_minor, total_minor, commission_bps, commission_fixed_minor, commission_minor, status,
        ship_name, ship_line1, ship_line2, ship_city, ship_region, ship_postal, ship_country, ship_phone, idempotency_key, expires_at, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?, 'pending_payment', ?,?,?,?,?,?,?,?, ?,?,?,?)`,
      newOrderNo(), user.id, sellerId, currency, itemsTotal, shippingTotal, total, com.bps, com.fixed, com.amount,
      ship.name, ship.line1, ship.line2 || null, ship.city, ship.region || null, ship.postal || null, ship.country, ship.phone || null, key, expires, t, t);
    for (const l of lines) {
      const main = db.get("SELECT id FROM product_images WHERE product_id = ? AND kind = 'main' ORDER BY id LIMIT 1", l.p.id);
      db.run('INSERT INTO order_items (order_id, product_id, name_snapshot, unit_price_minor, quantity, shipping_minor, image_id) VALUES (?,?,?,?,?,?,?)', o.id, l.p.id, l.p.name, l.p.price_minor, l.qty, l.p.shipping_fee_minor, main ? main.id : null);
    }
    const pay = db.run("INSERT INTO payments (kind, user_id, order_id, amount_minor, currency, status, provider, idempotency_key, created_at) VALUES ('order', ?, ?, ?, ?, 'pending', ?, ?, ?)", user.id, o.id, total, currency, provider.name, 'order:' + o.id + ':' + randomToken(6), t);
    return { orderId: o.id, paymentId: pay.id };
  });

  const payment = db.get('SELECT * FROM payments WHERE id = ?', paymentId);
  try {
    const c = await provider.createCheckout({ payment, user, description: 'QYRRAVO order' });
    db.run('UPDATE payments SET provider_payment_ref = ?, checkout_url = ? WHERE id = ?', c.providerRef, c.checkoutUrl, paymentId);
  } catch (e) {
    cancelPending(orderId, 'checkout creation failed');
    throw conflict('checkout_failed', 'We could not start checkout. You were not charged.');
  }
  return { order: db.get('SELECT * FROM orders WHERE id = ?', orderId), payment: db.get('SELECT * FROM payments WHERE id = ?', paymentId) };
}

function releaseStock(orderId) {
  for (const it of db.all('SELECT * FROM order_items WHERE order_id = ?', orderId)) {
    db.run('UPDATE products SET quantity_reserved = MAX(0, quantity_reserved - ?) WHERE id = ?', it.quantity, it.product_id);
  }
}
function cancelPending(orderId, reason, status = 'cancelled') {
  db.tx(() => {
    const o = db.get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o || o.status !== 'pending_payment') return;
    releaseStock(orderId);
    setStatus(o, status, { cancelled_at: nowIso() });
    db.run("UPDATE payments SET status = CASE WHEN status = 'pending' THEN 'canceled' ELSE status END, failure_reason = COALESCE(failure_reason, ?) WHERE order_id = ?", reason, orderId);
  });
}

// ---- called from the verified webhook (inside a transaction) ----
function markPaid(orderId, payment, feeMinor) {
  const o = db.get('SELECT * FROM orders WHERE id = ?', orderId);
  if (!o) return;
  if (o.status !== 'pending_payment') return; // already handled / cancelled: do nothing (idempotent)
  const t = nowIso();
  for (const it of db.all('SELECT * FROM order_items WHERE order_id = ?', orderId)) {
    db.run('UPDATE products SET quantity = MAX(0, quantity - ?), quantity_reserved = MAX(0, quantity_reserved - ?) WHERE id = ?', it.quantity, it.quantity, it.product_id);
  }
  setStatus(o, 'paid', { paid_at: t });
  ledger.post('order_gross', { currency: o.currency, amount: o.total_minor, sellerId: o.seller_id, orderId, paymentId: payment.id, key: 'order_gross:payment:' + payment.id, memo: 'Buyer payment confirmed by provider' });
  if (feeMinor > 0) ledger.post('processing_fee', { currency: o.currency, amount: feeMinor, orderId, paymentId: payment.id, key: 'fee:payment:' + payment.id, memo: 'Provider-reported processing fee' });
  try {
    db.run("INSERT INTO commissions (order_id, seller_id, currency, base_minor, bps, fixed_minor, amount_minor, status, created_at) VALUES (?,?,?,?,?,?,?, 'accrued', ?)",
      orderId, o.seller_id, o.currency, settings.get('commission_base') === 'items_and_shipping' ? o.items_total_minor + o.shipping_minor : o.items_total_minor, o.commission_bps, o.commission_fixed_minor, o.commission_minor, t);
  } catch (e) { if (!/UNIQUE/.test(String(e.message))) throw e; }
  notifyUser(o.seller_id, 'order_paid', 'New paid order ' + o.order_no, 'A buyer has paid for order ' + o.order_no + '. Please dispatch it and add tracking.', '/dashboard/orders');
  notifyUser(o.buyer_id, 'order_paid', 'Payment confirmed for ' + o.order_no, 'The payment provider confirmed your payment.', '/orders/' + orderId);
}

function markPaymentFailed(orderId, reason) {
  cancelPending(orderId, reason || 'payment failed', 'payment_failed');
  const o = db.get('SELECT * FROM orders WHERE id = ?', orderId);
  if (o) notifyUser(o.buyer_id, 'order_payment_failed', 'Payment failed for ' + o.order_no, 'The payment did not go through. Nothing was charged. You can try again.', '/orders/' + orderId);
}

// ---- seller / buyer actions ----
function ship(sellerId, orderId, tracking) {
  return db.tx(() => {
    const o = db.get('SELECT * FROM orders WHERE id = ? AND seller_id = ?', orderId, sellerId);
    if (!o) throw notFound('Order not found.');
    if (o.status !== 'paid') throw conflict('bad_transition', 'Only paid orders can be marked as shipped.');
    const r = setStatus(o, 'shipped', { shipped_at: nowIso(), tracking: text(tracking, { max: 120, field: 'Tracking', required: false }) || null });
    notifyUser(o.buyer_id, 'order_shipped', 'Order ' + o.order_no + ' has been dispatched', r.tracking ? 'Tracking: ' + r.tracking : 'The seller marked your order as shipped.', '/orders/' + orderId);
    return r;
  });
}
function confirmDelivery(buyerId, orderId) {
  return db.tx(() => {
    const o = db.get('SELECT * FROM orders WHERE id = ? AND buyer_id = ?', orderId, buyerId);
    if (!o) throw notFound('Order not found.');
    if (o.status !== 'shipped') throw conflict('bad_transition', 'You can confirm delivery once the seller has shipped the order.');
    const r = setStatus(o, 'delivered', { delivered_at: nowIso() });
    notifyUser(o.seller_id, 'order_delivered', 'Order ' + o.order_no + ' delivered', 'The buyer confirmed delivery.', '/dashboard/orders');
    return r;
  });
}

// Commission is only EARNED (and seller money only becomes payable) when the order completes.
function complete(orderId) {
  return db.tx(() => {
    const o = db.get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o || !['shipped', 'delivered'].includes(o.status)) return null;
    if (db.get("SELECT 1 AS x FROM disputes WHERE order_id = ? AND status = 'open'", orderId)) return null;
    const net = o.total_minor - o.refunded_minor;
    const commissionNet = Math.max(0, o.commission_minor - o.commission_reversed_minor);
    const payable = Math.max(0, net - commissionNet);
    const r = setStatus(o, 'completed', { completed_at: nowIso() });
    ledger.post('commission_earned', { currency: o.currency, amount: commissionNet, sellerId: o.seller_id, orderId, key: 'commission_earned:order:' + orderId, memo: 'Commission on completed order' });
    ledger.post('seller_payable_earned', { currency: o.currency, amount: payable, sellerId: o.seller_id, orderId, key: 'seller_payable:order:' + orderId, memo: 'Seller share of completed order' });
    db.run("UPDATE commissions SET status = 'earned', amount_minor = ?, earned_at = ? WHERE order_id = ?", commissionNet, nowIso(), orderId);
    notifyUser(o.seller_id, 'order_completed', 'Order ' + o.order_no + ' completed', 'Your earnings for this order are now available for payout.', '/dashboard/finance');
    return r;
  });
}

function sellerCancel(sellerId, orderId, reason) {
  // a seller who cannot fulfil a PAID order asks the platform for a full refund (money moves only via the provider)
  const o = db.get('SELECT * FROM orders WHERE id = ? AND seller_id = ?', orderId, sellerId);
  if (!o) throw notFound('Order not found.');
  if (o.status !== 'paid') throw conflict('bad_transition', 'Only paid, unshipped orders can be cancelled by the seller.');
  return requestRefund({ id: sellerId, role: 'seller' }, orderId, o.total_minor - o.refunded_minor, 'Seller cancelled: ' + text(reason, { min: 3, max: 300, field: 'Reason' }));
}

// ---- refunds: requested here, CONFIRMED only by the provider's webhook ----
async function requestRefund(actor, orderId, amountMinor, reason) {
  const provider = payments.requireProvider();
  const o = db.get('SELECT * FROM orders WHERE id = ?', orderId);
  if (!o) throw notFound('Order not found.');
  if (!['paid', 'shipped', 'delivered', 'completed', 'disputed'].includes(o.status)) throw conflict('not_refundable', 'This order cannot be refunded in its current state.');
  const pay = db.get("SELECT * FROM payments WHERE order_id = ? AND status IN ('succeeded','partially_refunded') ORDER BY id DESC", orderId);
  if (!pay) throw conflict('not_refundable', 'There is no confirmed payment to refund.');
  const pending = db.get("SELECT COALESCE(SUM(amount_minor),0) AS s FROM refunds WHERE order_id = ? AND status = 'requested'", orderId).s;
  const refundable = o.total_minor - o.refunded_minor - pending;
  const amount = int(amountMinor, { min: 1, max: 1e12, field: 'amount' });
  if (amount > refundable) throw conflict('refund_too_large', 'The most that can still be refunded is ' + money.format(refundable, o.currency) + '.');
  const reasonText = text(reason, { min: 3, max: 300, field: 'Reason' });
  const r = db.run("INSERT INTO refunds (order_id, payment_id, amount_minor, currency, reason, status, requested_by, created_at) VALUES (?,?,?,?,?, 'requested', ?, ?)", orderId, pay.id, amount, o.currency, reasonText, actor.id, nowIso());
  const refund = db.get('SELECT * FROM refunds WHERE id = ?', r.id);
  try {
    const out = await provider.refund({ payment: pay, refund });
    if (out && out.providerRefundRef) db.run('UPDATE refunds SET provider_refund_ref = ? WHERE id = ?', out.providerRefundRef, refund.id);
  } catch (e) {
    db.run("UPDATE refunds SET status = 'failed' WHERE id = ?", refund.id);
    throw conflict('refund_failed', 'The payment provider did not accept the refund request. Nothing was refunded.');
  }
  audit(actor, 'refund.requested', 'order', orderId, { refundId: refund.id, amount, reason: reasonText });
  return db.get('SELECT * FROM refunds WHERE id = ?', refund.id);
}

// Returns money to the buyer in the books. kind = 'refund' | 'chargeback'.
function applyMoneyReturn(order, amount, kind, key, refundId) {
  const o = db.get('SELECT * FROM orders WHERE id = ?', order.id);
  const refundedAfter = Math.min(o.total_minor, o.refunded_minor + amount);
  const applied = refundedAfter - o.refunded_minor;
  if (applied <= 0) return o;
  const revAfter = money.proportional(o.commission_minor, refundedAfter, o.total_minor);
  const revDelta = Math.max(0, revAfter - o.commission_reversed_minor);
  db.run('UPDATE orders SET refunded_minor = ?, commission_reversed_minor = ?, updated_at = ? WHERE id = ?', refundedAfter, o.commission_reversed_minor + revDelta, nowIso(), o.id);
  ledger.post(kind, { currency: o.currency, amount: applied, sellerId: o.seller_id, orderId: o.id, refundId: refundId || null, key, memo: kind === 'chargeback' ? 'Chargeback lost' : 'Refund confirmed by provider' });
  if (o.status === 'completed') { // earnings were already booked: reverse the corresponding part
    ledger.post('commission_reversal', { currency: o.currency, amount: revDelta, sellerId: o.seller_id, orderId: o.id, key: 'commission_reversal:' + key, memo: 'Commission reversed' });
    ledger.post('seller_payable_reversal', { currency: o.currency, amount: applied - revDelta, sellerId: o.seller_id, orderId: o.id, key: 'seller_payable_reversal:' + key, memo: 'Seller share reversed' });
  }
  let fresh = db.get('SELECT * FROM orders WHERE id = ?', o.id);
  if (fresh.refunded_minor >= fresh.total_minor && fresh.status !== 'refunded') {
    const neverShipped = !fresh.shipped_at;
    if (neverShipped) releaseSoldStock(fresh.id);
    fresh = setStatus(fresh, 'refunded');
    db.run("UPDATE commissions SET status = 'voided' WHERE order_id = ? AND status = 'accrued'", fresh.id);
  }
  return fresh;
}
function releaseSoldStock(orderId) {
  for (const it of db.all('SELECT * FROM order_items WHERE order_id = ?', orderId)) db.run('UPDATE products SET quantity = quantity + ? WHERE id = ?', it.quantity, it.product_id);
}

function applyRefundSucceeded(refundId, providerRefundRef) {
  const r = db.get('SELECT * FROM refunds WHERE id = ?', refundId);
  if (!r || r.status !== 'requested') return null; // unknown or already applied
  db.run("UPDATE refunds SET status = 'succeeded', confirmed_at = ?, provider_refund_ref = COALESCE(provider_refund_ref, ?) WHERE id = ?", nowIso(), providerRefundRef || null, refundId);
  const pay = db.get('SELECT * FROM payments WHERE id = ?', r.payment_id);
  const total = pay.refunded_minor + r.amount_minor;
  db.run('UPDATE payments SET refunded_minor = ?, status = ? WHERE id = ?', total, total >= pay.amount_minor ? 'refunded' : 'partially_refunded', pay.id);
  if (pay.kind === 'subscription') {
    ledger.post('subscription_refund', { currency: r.currency, amount: r.amount_minor, subscriptionId: pay.subscription_id, paymentId: pay.id, refundId, key: 'sub_refund:refund:' + refundId, memo: 'Subscription payment refunded' });
    // policy: a refunded subscription payment ends Premium immediately (listings above the Free limit pause, none are deleted)
    db.run("UPDATE subscriptions SET status = 'expired', current_period_end = ?, updated_at = ? WHERE id = ?", nowIso(), nowIso(), pay.subscription_id);
    const sub = db.get('SELECT user_id FROM subscriptions WHERE id = ?', pay.subscription_id);
    if (sub) notifyUser(sub.user_id, 'subscription_refunded', 'Plan refunded', 'Your plan payment was refunded and the plan has ended. Listings above the Free limit are paused (not deleted).', '/dashboard/subscription');
    return r;
  }
  const o = db.get('SELECT * FROM orders WHERE id = ?', r.order_id);
  applyMoneyReturn(o, r.amount_minor, 'refund', 'refund:refund:' + refundId, refundId);
  notifyUser(o.buyer_id, 'refund', 'Refund confirmed for ' + o.order_no, 'The payment provider confirmed a refund of ' + money.format(r.amount_minor, r.currency) + '.', '/orders/' + o.id);
  notifyUser(o.seller_id, 'refund', 'Refund on order ' + o.order_no, 'A refund of ' + money.format(r.amount_minor, r.currency) + ' was confirmed. Your payable balance was adjusted.', '/dashboard/orders');
  return r;
}

// ---- background maintenance ----
function runMaintenance() {
  const t = nowIso();
  for (const o of db.all("SELECT id FROM orders WHERE status = 'pending_payment' AND expires_at < ?", t)) cancelPending(o.id, 'unpaid order expired');
  const afterDelivered = settings.get('complete_after_delivered_days');
  for (const o of db.all("SELECT id FROM orders WHERE status = 'delivered' AND delivered_at <= ?", addDays(t, -afterDelivered))) complete(o.id);
  const auto = settings.get('auto_complete_days');
  for (const o of db.all("SELECT id FROM orders WHERE status = 'shipped' AND shipped_at <= ?", addDays(t, -auto))) complete(o.id);
}

// ---- views ----
function sellerView(o) { return view(o, true); }
function view(o, includeAddress) {
  const items = db.all('SELECT * FROM order_items WHERE order_id = ?', o.id).map((i) => ({ productId: i.product_id, name: i.name_snapshot, unitPriceMinor: i.unit_price_minor, quantity: i.quantity, shippingMinor: i.shipping_minor, imageUrl: i.image_id ? '/media/' + i.image_id : null }));
  const out = {
    id: o.id, orderNo: o.order_no, status: o.status, currency: o.currency,
    itemsTotalMinor: o.items_total_minor, shippingMinor: o.shipping_minor, totalMinor: o.total_minor, refundedMinor: o.refunded_minor,
    tracking: o.tracking, createdAt: o.created_at, paidAt: o.paid_at, shippedAt: o.shipped_at, deliveredAt: o.delivered_at, completedAt: o.completed_at,
    sellerId: o.seller_id, buyerId: o.buyer_id, items,
  };
  if (includeAddress) out.shipTo = { name: o.ship_name, line1: o.ship_line1, line2: o.ship_line2, city: o.ship_city, region: o.ship_region, postal: o.ship_postal, country: o.ship_country, phone: o.ship_phone };
  return out;
}

module.exports = { checkout, cancelPending, markPaid, markPaymentFailed, ship, confirmDelivery, complete, sellerCancel, requestRefund, applyRefundSucceeded, applyMoneyReturn, runMaintenance, view, sellerView, setStatus, calcCommission, TRANSITIONS };
