'use strict';
const http = require('http');
const config = require('./config');
const db = require('./db');
const { seed } = require('./seed');
const payments = require('./payments');

function createApp({ dbFile } = {}) {
  db.open(dbFile);
  seed();
  const p = payments.provider();
  if (config.paymentMode === 'live' && (!p || p.notImplemented)) {
    throw new Error('PAYMENT_MODE=live but the "' + config.paymentProvider + '" adapter is not implemented in this build. Implement server/payments/' + config.paymentProvider + '.js against the provider\'s documented API first (see docs/PAYMENTS.md).');
  }
  require('./routes/public'); require('./routes/account'); require('./routes/seller'); require('./routes/buyer');
  require('./routes/mod'); require('./routes/admin'); require('./routes/payments'); require('./routes/assistant'); require('./routes/google'); require('./routes/requests'); require('./routes/community'); require('./routes/redeem'); require('./routes/game');
  const { handle } = require('./http');
  const server = http.createServer((req, res) => { handle(req, res); });
  server.requestTimeout = 60000; server.headersTimeout = 20000;
  return {
    server,
    listen: async (port = config.port) => { await require('./owner').ensureOwner(); return new Promise((resolve) => server.listen(port, () => resolve(server.address().port))); },
    close: () => new Promise((resolve) => { server.close(() => { db.close(); resolve(); }); server.closeAllConnections && server.closeAllConnections(); }),
  };
}

if (require.main === module || process.env.QY_BUNDLE === '1') {
  const app = createApp();
  require('./jobs').start();
  app.listen().then((port) => {
    console.log('QYRRAVO marketplace listening on ' + config.appUrl.replace(/:\d+$/, '') + ':' + port + '  (online payments: ' + config.paymentMode + ')');
  });
  const stop = () => app.close().then(() => process.exit(0));
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
module.exports = { createApp };
