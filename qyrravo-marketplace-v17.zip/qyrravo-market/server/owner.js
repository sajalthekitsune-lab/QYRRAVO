'use strict';
// The owner account. Email + password come ONLY from the server's .env (OWNER_EMAIL, OWNER_PASSWORD).
// Run at every start-up: creates the account if missing, keeps it an active, verified administrator,
// and updates the stored password hash if the .env password was changed.
const config = require('./config');
const db = require('./db');
const auth = require('./auth');
const { nowIso } = require('./util');

const OWNER_NAME = 'QYRRAVO 👑';
// Public "about the owner" card. Deliberately no phone number.
const OWNER_PUBLIC = { name: 'Sajal Dhungana', title: 'Founder & owner of QYRRAVO', from: 'Nepal', livesIn: 'Qatar', email: config.supportEmail, tagline: 'Quietly Better.' };

async function ensureOwner() {
  if (!config.ownerEmail || !config.ownerPassword) { return { created: false, reason: 'OWNER_EMAIL / OWNER_PASSWORD not set in .env' }; }
  if (config.ownerPassword.length < 10) throw new Error('OWNER_PASSWORD must be at least 10 characters.');
  const t = nowIso();
  const email = config.ownerEmail;
  let u = db.get('SELECT * FROM users WHERE email = ?', email);
  if (!u) {
    const hash = await auth.hashPassword(config.ownerPassword);
    const id = db.run("INSERT INTO users (email, password_hash, display_name, role, country, status, email_verified_at, terms_accepted_at, is_owner, created_at, updated_at) VALUES (?,?,?, 'admin', 'QA', 'active', ?, ?, 1, ?, ?)", email, hash, OWNER_NAME, t, t, t, t).id;
    u = db.get('SELECT * FROM users WHERE id = ?', id);
  } else {
    if (!(await auth.verifyPassword(config.ownerPassword, u.password_hash))) db.run('UPDATE users SET password_hash = ? WHERE id = ?', await auth.hashPassword(config.ownerPassword), u.id);
    db.run("UPDATE users SET role = 'admin', is_owner = 1, status = 'active', display_name = ?, email_verified_at = COALESCE(email_verified_at, ?), updated_at = ? WHERE id = ?", OWNER_NAME, t, t, u.id);
  }
  db.run('UPDATE users SET is_owner = 0 WHERE id != ? AND is_owner = 1', u.id); // there is only ever one owner
  if (!db.get('SELECT 1 AS x FROM seller_profiles WHERE user_id = ?', u.id)) {
    db.run('INSERT INTO seller_profiles (user_id, shop_name, bio, country, contact_email, agreed_seller_terms_at, created_at) VALUES (?,?,?,?,?,?,?)', u.id, 'QYRRAVO 👑', 'Official QYRRAVO shop. Quietly Better.', 'QA', config.supportEmail, t, t);
  }
  return { created: true };
}
module.exports = { ensureOwner, OWNER_PUBLIC, OWNER_NAME };
