// 3D polish for the whole site (no libraries): a WebGL showroom for the home page and CSS-3D tilt on cards.
import { h } from './core.js';
import { Renderer, Builder, m4 } from './game/gl.js';
import { buildSuper, hex } from './game/cars.js';

// ---------- tilt cards ----------
let tiltOn = false;
export function initTilt() {
  if (tiltOn || !window.matchMedia || !matchMedia('(hover:hover) and (pointer:fine)').matches || matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  tiltOn = true; let cur = null;
  const SEL = '.card, .comm, .cattile, .pack, .gcar, .panel';
  const reset = () => { if (cur) { cur.classList.remove('t3d-on'); cur.style.removeProperty('--rx'); cur.style.removeProperty('--ry'); cur = null; } };
  document.addEventListener('pointermove', (e) => {
    const el = e.target.closest && e.target.closest(SEL);
    if (!el || el.classList.contains('nt')) { reset(); return; }
    if (cur && cur !== el) reset();
    cur = el; const r = el.getBoundingClientRect(); if (r.width > 700) { reset(); return; }
    const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    el.classList.add('t3d-on'); el.style.setProperty('--ry', ((px - 0.5) * 12).toFixed(2) + 'deg'); el.style.setProperty('--rx', ((0.5 - py) * 10).toFixed(2) + 'deg');
    el.style.setProperty('--mx', (px * 100).toFixed(0) + '%'); el.style.setProperty('--my', (py * 100).toFixed(0) + '%');
  }, { passive: true });
  document.addEventListener('pointerleave', reset, true); document.addEventListener('scroll', reset, { passive: true });
}

// ---------- WebGL showroom ----------
function coinMesh(gl) {
  const B = new Builder(), gold = hex(0xf5b72b), light = hex(0xffe08a), dark = hex(0xb87d00), R = 1.25, Hh = 0.14, S = 28;
  for (let i = 0; i < S; i++) {
    const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2, am = (a0 + a1) / 2, p = (a, z) => [Math.cos(a) * R, Math.sin(a) * R, z];
    B.quad(p(a0, -Hh), p(a1, -Hh), p(a1, Hh), p(a0, Hh), [Math.cos(am), Math.sin(am), 0], dark, 0.25);
    for (const z of [Hh, -Hh]) B.tri([0, 0, z], p(a0, z), p(a1, z), [0, 0, Math.sign(z)], gold, 0.12);
  }
  for (const z of [Hh + 0.02, -Hh - 0.02]) {                         // raised rim and a blocky Q
    for (let i = 0; i < 32; i++) { const a = i / 32 * Math.PI * 2; B.box(Math.cos(a) * 1.08, Math.sin(a) * 1.08, z, 0.17, 0.17, 0.06, light, 0.5); }
    for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2; B.box(Math.cos(a) * 0.5, Math.sin(a) * 0.5, z, 0.2, 0.2, 0.07, light, 0.8); }
    B.box(0.3 * Math.sign(z), -0.42, z, 0.24, 0.12, 0.07, light, 0.8, 0.8);
  }
  return B.mesh(gl);
}
function stageMesh(gl) {
  const B = new Builder(), S = 40; let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const ring = (r, w, y, col, e) => { for (let i = 0; i < S; i++) { const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2; B.flat([Math.cos(a0) * r, Math.sin(a0) * r], [Math.cos(a1) * r, Math.sin(a1) * r], [Math.cos(a1) * (r + w), Math.sin(a1) * (r + w)], [Math.cos(a0) * (r + w), Math.sin(a0) * (r + w)], y, col, e); } };
  B.cone(0, 0, 0, 7.4, 7.2, 0.4, S, hex(0x101a26)); for (let i = 0; i < S; i++) { const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2; B.tri([0, 0.4, 0], [Math.cos(a0) * 7.4, 0.4, Math.sin(a0) * 7.4], [Math.cos(a1) * 7.4, 0.4, Math.sin(a1) * 7.4], [0, 1, 0], hex(0x16222f)); }
  ring(5.6, 0.18, 0.42, hex(0x00d5f2), 1); ring(6.6, 0.1, 0.42, hex(0xffd24a), 0.9); ring(7.0, 0.12, 0.42, hex(0xff3fb4), 0.9);
  for (let i = 0; i < 26; i++) { const a = i / 26 * Math.PI * 2 + rnd() * 0.2, r = 22 + rnd() * 20, hh = 8 + rnd() * 30, w = 3 + rnd() * 4; B.box(Math.cos(a) * r, hh / 2, Math.sin(a) * r, w, hh, w, hex(0x0d1824)); for (let k = 0; k < 5; k++) B.box(Math.cos(a) * (r - w / 2 - 0.02), 1 + rnd() * (hh - 2), Math.sin(a) * (r - w / 2 - 0.02), 0.7, 0.5, 0.1, hex(rnd() > 0.5 ? 0xffe08a : 0x7fe9ff), 1, -a + Math.PI / 2); }
  B.flat([-80, -80], [80, -80], [80, 80], [-80, 80], -0.02, hex(0x0a121c));
  return B.mesh(gl);
}
export function showroom(host, carId = 'lambo') {
  let force = false; try { force = localStorage.getItem('qy_3d') === '1'; } catch { /* no storage */ }
  if (navigator.webdriver && !force) return false;   // automated test browsers have no GPU; keep the flat hero there
  const canvas = h('canvas', { class: 'showroom-cv', 'aria-label': 'Rotating 3D sports car and Q Coin' });
  let R; try { R = new Renderer(canvas); } catch { return false; }
  const keep = [...host.childNodes];
  const gl = R.gl, stage = stageMesh(gl), car = buildSuper(gl, carId, true), coin = coinMesh(gl);
  R.fogDensity = 0.006;
  host.replaceChildren(canvas, h('div', { class: 'showroom-cta' }, h('a', { class: 'btn small primary', href: '#/game' }, 'Drive & earn Q'), h('a', { class: 'btn small', href: '#/redeem' }, 'Q Coin shop')));
  host.classList.add('showroom');
  let lastF = 0, mx = 0, my = 0, run = true, t0 = performance.now();
  host.addEventListener('pointermove', (e) => { const r = host.getBoundingClientRect(); mx = (e.clientX - r.left) / r.width - 0.5; my = (e.clientY - r.top) / r.height - 0.5; });
  const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const io = 'IntersectionObserver' in window ? new IntersectionObserver((en) => { run = en[0].isIntersecting; }) : null; if (io) io.observe(host);
  let frames = 0, bad = 0;
  const revert = () => { run = false; host.classList.remove('showroom'); host.replaceChildren(...keep); };
  canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); revert(); });
  const frame = (now) => {
    if (!host.isConnected) { if (io) io.disconnect(); return; }
    requestAnimationFrame(frame); if (!run || document.hidden || now - lastF < 30) return; lastF = now;
    const t = reduce ? 1.2 : (now - t0) / 1000, asp = R.resize();
    const a = 0.7 + t * 0.12 + mx * 0.9, cam = [Math.sin(a) * 14.5, 4.6 - my * 3, Math.cos(a) * 14.5];
    const vp = m4.mul(m4.persp(0.8, asp, 0.5, 400), m4.lookAt(cam, [0.6, 1.2, 0]));
    R.begin(vp, cam, Math.atan2(-cam[0], -cam[2]), asp);
    R.draw(stage); R.draw(car, m4.model(0, 0.4, 0, t * 0.45, 0));
    R.draw(coin, m4.model(3.3, 2.7 + Math.sin(t * 1.6) * 0.25, -1.0, t * 1.3, 0));
    if (++frames === 4 || frames === 8) {   // safety net: if the canvas is still all black, fall back to the flat hero instead of showing a black box
      const px = new Uint8Array(4); let any = false; for (const [fx, fy] of [[0.5, 0.5], [0.25, 0.7], [0.75, 0.3]]) { gl.readPixels(Math.floor(canvas.width * fx), Math.floor(canvas.height * fy), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px); if (px[0] + px[1] + px[2] > 6) any = true; }
      if (!any && ++bad >= 2) revert();
    }
  };
  requestAnimationFrame(frame); return true;
}
