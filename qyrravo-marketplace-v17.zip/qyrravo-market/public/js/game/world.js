// Builds the QYRRAVO Drive map: one very long closed neon circuit (about 132 km): two dead-straight highways and two wide U-turns, through cities, pines and mountains.
// The world is made in chunks along the road and only the chunks near the car exist at any time. Same seed = same map for everyone.
import { Builder } from './gl.js';

export const HALF = 16;                    // half road width (m): a 32 m wide highway
export const CHUNK = 260;                  // road points per chunk (about 1 km)
const rng = (seed) => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const hex = (h) => [(h >> 16 & 255) / 255, (h >> 8 & 255) / 255, (h & 255) / 255];
const TARGET = 132000;                      // metres per lap

export function makeTrack() {
  // A stadium-shaped circuit: two dead-straight highways joined by two wide, gentle U-turns (6 km radius).
  const R = 6000, S = (TARGET - Math.PI * 2 * R) / 2, L = 2 * S + 2 * Math.PI * R, N = Math.round(L / 4), pts = [];
  const at = (s) => {
    if (s < S) return [s, 0];
    s -= S; if (s < Math.PI * R) { const a = s / R; return [S + Math.sin(a) * R, R - Math.cos(a) * R]; }
    s -= Math.PI * R; if (s < S) return [S - s, 2 * R];
    s -= S; const a = s / R; return [-Math.sin(a) * R, R + Math.cos(a) * R];
  };
  for (let i = 0; i < N; i++) pts.push(at(i / N * L));
  const T = pts.map((p, i) => { const a = pts[(i + N - 1) % N], b = pts[(i + 1) % N]; const dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz); return [dx / l, dz / l]; });
  const Nm = T.map((t) => [-t[1], t[0]]); // left normal in (x,z)
  return { pts, T, Nm, N, length: L, step: L / N };
}

export function buildWorld(tr, gl) {
  const { pts, T, Nm, N } = tr;
  const edge = (i, off) => [pts[i][0] + Nm[i][0] * off, pts[i][1] + Nm[i][1] * off];
  const asphalt = [hex(0x1b2230), hex(0x1f2634)], white = hex(0xe8eef7), red = hex(0xd8334a), neonC = hex(0x00d5f2), neonM = hex(0xff3fb4), yellow = hex(0xffc857);
  const wins = [hex(0xffd98a), hex(0x7be8ff), hex(0xffb3e6), hex(0xfff3c4)];
  // spatial hash of the whole road so scenery never lands on (or near) any part of it
  const cell = 120, grid = new Map(); const key = (cx, cz) => cx + ',' + cz;
  pts.forEach((p, i) => { if (i % 3) return; const k = key(Math.floor(p[0] / cell), Math.floor(p[1] / cell)); (grid.get(k) || grid.set(k, []).get(k)).push(p); });
  const roadDist = (x, z) => { let best = 1e9; const cx = Math.floor(x / cell), cz = Math.floor(z / cell); for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) { const l = grid.get(key(cx + a, cz + b)); if (l) for (const p of l) { const d = Math.hypot(p[0] - x, p[1] - z); if (d < best) best = d; } } return best; };

  const nChunks = Math.ceil(N / CHUNK);
  function buildChunk(c) {
    const R = rng(20261105 + c * 7919), B = new Builder(), i0 = c * CHUNK, i1 = Math.min(N, i0 + CHUNK);
    for (let i = i0; i < i1; i++) {
      const j = (i + 1) % N, a = edge(i, HALF), b = edge(i, -HALF), cc = edge(j, -HALF), d = edge(j, HALF);
      B.flat(b, cc, d, a, 0.0, asphalt[(i >> 3) & 1]);
      const cu = i % 2 ? white : red; const a2 = edge(i, HALF + 1.6), d2 = edge(j, HALF + 1.6), b2 = edge(i, -HALF - 1.6), c2 = edge(j, -HALF - 1.6);
      B.flat(a, d, d2, a2, 0.03, cu); B.flat(b2, c2, edge(j, -HALF), edge(i, -HALF), 0.03, cu);
      const el = (o) => [edge(i, o - 0.2), edge(j, o - 0.2), edge(j, o + 0.2), edge(i, o + 0.2)];
      let q = el(HALF - 0.9); B.flat(q[0], q[1], q[2], q[3], 0.025, white); q = el(-HALF + 0.9); B.flat(q[0], q[1], q[2], q[3], 0.025, white);
      if ((i % 6) < 3) { for (const o of [-HALF / 2, 0, HALF / 2]) { q = el(o); B.flat(q[0], q[1], q[2], q[3], 0.025, yellow, 0.25); } }
      if ((i % 3) === 0) { const yaw = Math.atan2(T[i][0], T[i][1]); for (const [s, col] of [[1, neonC], [-1, neonM]]) { const e = edge(i, s * (HALF + 2.4)); B.box(e[0], 0.5, e[1], 0.7, 1.0, 12.4, hex(0x151b27), 0, yaw); B.box(e[0], 1.04, e[1], 0.5, 0.12, 12.2, col, 1, yaw); } }
    }
    if (i0 === 0) {
      const yaw = Math.atan2(T[0][0], T[0][1]); const l = edge(0, HALF + 3), r = edge(0, -HALF - 3), m = pts[0];
      B.box(l[0], 6, l[1], 1.4, 12, 1.4, hex(0x222a3a), 0, yaw); B.box(r[0], 6, r[1], 1.4, 12, 1.4, hex(0x222a3a), 0, yaw); B.box(m[0], 12.4, m[1], 1.6, 1.8, (HALF + 3) * 2 + 1, hex(0x10151f), 0, yaw);
      for (let k = 0; k < 18; k++) { const o = -HALF - 2 + k * ((HALF + 2) * 2 / 17); const e = edge(0, o); B.box(e[0], 12.4, e[1], 1.7, 1.4, 1.5, k % 2 ? hex(0xffffff) : hex(0x05070b), 0.9, yaw); }
      for (let c2 = 0; c2 < 8; c2++) for (let k = 0; k < 2; k++) { if ((c2 + k) % 2) continue; const o = -HALF + 1.6 + c2 * ((HALF * 2 - 3.2) / 7); B.box(pts[0][0] + Nm[0][0] * o + T[0][0] * (k * 1.8), 0.04, pts[0][1] + Nm[0][1] * o + T[0][1] * (k * 1.8), 1.8, 0.02, 1.8, white, 0.3, yaw); }
    }
    for (let i = i0 + 4; i < i1; i += 14) { const s = (i / 14 | 0) % 2 ? 1 : -1, e = edge(i, s * (HALF + 6)); B.box(e[0], 4.5, e[1], 0.35, 9, 0.35, hex(0x1b2230)); B.box(e[0], 9.1, e[1], 1.3, 0.35, 1.3, hex(0xffe2a8), 1); }
    // scenery on both sides of this stretch of road. The first part of the lap is a city; later parts are forest, then city again.
    const zone = (Math.sin(c * 0.5) + 1) / 2;                       // 0 = forest, 1 = city
    for (let i = i0; i < i1; i += 11) for (const side of [-1, 1]) {
      const off = side * (HALF + 40 + R() * 220), dx = (R() - .5) * 30, e = edge(i, off), x = e[0] + dx, z = e[1] + dx * 0.5;
      if (roadDist(x, z) < HALF + 36) continue;
      if (R() < 0.15 + zone * 0.5) {                               // a building
        const w = 20 + R() * 26, dpt = 20 + R() * 26, h = 24 + R() * (50 + 150 * zone), shade = 0.1 + R() * 0.1, col = [shade * 0.9, shade * 1.1, shade * 1.7], yaw = (R() - .5) * 0.5;
        B.box(x, h / 2, z, w, h, dpt, col, 0, yaw); B.box(x, h + 0.4, z, w * 0.8, 0.8, dpt * 0.8, hex(0x111722), 0, yaw);
        if (R() < 0.5) { B.box(x, h + 4, z, 0.5, 8, 0.5, hex(0x222a3a)); B.box(x, h + 8.2, z, 1.1, 1.1, 1.1, hex(0xff2d4d), 1); }
        const cs = Math.cos(yaw), sn = Math.sin(yaw), rows = Math.min(14, Math.floor(h / 7)), colsW = Math.floor(w / 6), colsD = Math.floor(dpt / 6);
        for (let r = 1; r < rows; r++) { const y = r * (h / rows) - 0.5; for (const [fx, fz, n2] of [[0, 1, colsW], [0, -1, colsW], [1, 0, colsD], [-1, 0, colsD]]) for (let k = 0; k < n2; k++) { if (R() > 0.3) continue; const u = (k + 0.5) / n2 - 0.5; const lx = fx ? fx * (w / 2 + 0.12) : u * w, lz = fx ? u * dpt : fz * (dpt / 2 + 0.12);
          B.box(x + lx * cs + lz * sn, y, z - lx * sn + lz * cs, fx ? 0.12 : 2.2, 2.0, fx ? 2.2 : 0.12, wins[(R() * 4) | 0], 1, yaw); } }
      } else if (R() < 0.9) {                                        // a few pines
        for (let t = 0; t < 4; t++) { const px = x + (R() - .5) * 60, pz = z + (R() - .5) * 60; if (roadDist(px, pz) < HALF + 14) continue; const h = 9 + R() * 12, g = 0.12 + R() * 0.12;
          B.box(px, 1.2, pz, 0.8, 2.4, 0.8, hex(0x2b1d17)); B.cone(px, 2, pz, 4, 0.2, h, 6, [0.03, g, 0.1]); B.cone(px, 2 + h * 0.5, pz, 3, 0.1, h * 0.7, 6, [0.04, g * 1.15, 0.12]); }
      }
    }
    // close roadside trees
    for (let i = i0; i < i1; i += 5) for (const side of [-1, 1]) { if (R() > 0.45) continue; const e = edge(i, side * (HALF + 14 + R() * 18)); if (roadDist(e[0], e[1]) < HALF + 9) continue; const h = 7 + R() * 8, g = 0.12 + R() * 0.12;
      B.box(e[0], 1.2, e[1], 0.7, 2.4, 0.7, hex(0x2b1d17)); B.cone(e[0], 2, e[1], 3.4, 0.2, h, 6, [0.03, g, 0.1]); B.cone(e[0], 2 + h * 0.5, e[1], 2.6, 0.1, h * 0.7, 6, [0.04, g * 1.15, 0.12]); }
    return B.mesh(gl);
  }

  // ground (with a neon grid) and the mountain ring both follow the camera; the grid is snapped so it appears to stay put
  const G = new Builder(); const GS = 80;
  G.flat([-3600, -3600], [-3600, 3600], [3600, 3600], [3600, -3600], -0.06, hex(0x07121a));
  for (let g = -2400; g <= 2400; g += GS) { const c = hex(0x0a3a48); G.flat([g - .6, -2400], [g - .6, 2400], [g + .6, 2400], [g + .6, -2400], -0.03, c, 0.5); G.flat([-2400, g - .6], [-2400, g + .6], [2400, g + .6], [2400, g - .6], -0.03, c, 0.5); }
  const ground = G.mesh(gl);
  const M = new Builder(), RM = rng(77);
  for (let k = 0; k < 30; k++) { const a = k / 30 * Math.PI * 2 + RM() * 0.2, r = 1850 + RM() * 250, h = 280 + RM() * 300, w = 400 + RM() * 280; M.cone(Math.cos(a) * r, -2, Math.sin(a) * r, w, 6, h, 7, [0.2 + RM() * .08, 0.1, 0.36 + RM() * .1]); M.cone(Math.cos(a) * r, h * 0.8, Math.sin(a) * r, w * 0.16, 3, h * 0.22, 7, hex(0xcfe4ff), 0.15); }
  const ring = M.mesh(gl);
  const loaded = new Map();
  const id = (c) => ((c % nChunks) + nChunks) % nChunks;
  return {
    nChunks,
    // keep chunks from 2 behind to 5 ahead of the car's chunk loaded; build at most `budget` new ones per call
    update(idx, budget = 1) {
      const cur = Math.floor(idx / CHUNK), want = new Set(); for (let k = -2; k <= 5; k++) want.add(id(cur + k));
      for (const [c, m] of loaded) if (!want.has(c)) { gl.deleteBuffer(m.buf); loaded.delete(c); }
      let built = 0; for (const k of [0, 1, -1, 2, 3, 4, 5, -2]) { const c = id(cur + k); if (!loaded.has(c)) { if (built >= budget) break; loaded.set(c, buildChunk(c)); built++; } }
      return built;
    },
    ready(idx) { const cur = Math.floor(idx / CHUNK); return loaded.has(id(cur)) && loaded.has(id(cur + 1)); },
    draw(Rn, x, z) {
      const sx = Math.round(x / GS) * GS, sz = Math.round(z / GS) * GS;
      Rn.draw(ground, translate(sx, 0, sz)); Rn.draw(ring, translate(x, 0, z));
      for (const m of loaded.values()) Rn.draw(m);
    },
  };
}
const translate = (x, y, z) => { const o = new Float32Array(16); o[0] = o[5] = o[10] = o[15] = 1; o[12] = x; o[13] = y; o[14] = z; return o; };
