// Hand-built low-poly supercars and people for QYRRAVO Drive. Generic shapes only: no logos or badges.
import { Builder } from './gl.js';

export const hex = (v) => [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];

// Extrude a side profile (points are [z, y], z forward) across a half width, so we get real wedges and slopes.
function extrude(B, hw, poly, col, e = 0) {
  const n = poly.length; let cz = 0, cy = 0; for (const p of poly) { cz += p[0]; cy += p[1]; } cz /= n; cy /= n;
  for (let i = 0; i < n; i++) {
    const a = poly[i], b = poly[(i + 1) % n]; let nz = -(b[1] - a[1]), ny = b[0] - a[0];
    if (nz * ((a[0] + b[0]) / 2 - cz) + ny * ((a[1] + b[1]) / 2 - cy) < 0) { nz = -nz; ny = -ny; }
    const l = Math.hypot(nz, ny) || 1;
    B.quad([-hw, a[1], a[0]], [hw, a[1], a[0]], [hw, b[1], b[0]], [-hw, b[1], b[0]], [0, ny / l, nz / l], col, e);
  }
  for (const s of [1, -1]) for (let i = 1; i < n - 1; i++) B.tri([s * hw, poly[0][1], poly[0][0]], [s * hw, poly[i][1], poly[i][0]], [s * hw, poly[i + 1][1], poly[i + 1][0]], [s, 0, 0], col, e);
}
function wheel(B, x, y, z, r, w, rimCol) {
  const S = 12, tire = hex(0x0a0c10);
  for (let i = 0; i < S; i++) {
    const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2, am = (a0 + a1) / 2;
    const p = (xx, a) => [xx, y + Math.sin(a) * r, z + Math.cos(a) * r];
    B.quad(p(x - w / 2, a0), p(x + w / 2, a0), p(x + w / 2, a1), p(x - w / 2, a1), [0, Math.sin(am), Math.cos(am)], tire);
  }
  const sx = x > 0 ? 1 : -1; B.box(x + sx * (w / 2 + 0.01), y, z, 0.04, r * 1.25, r * 1.25, rimCol, 0.55);
}

export const CARS = {
  lambo: { id: 'lambo', name: 'Lamborghini', blurb: 'Razor-edged V12 wedge. Great all-rounder.', body: 0xf2c200, accent: 0x111111, glow: 0xffd400, maxV: 222.2, nitro: 0, accel: 31, grip: 8.2, steer: 1.0, pitch: 1.0, bars: [4, 4, 4] },
  ferrari: { id: 'ferrari', name: 'Ferrari', blurb: 'Screaming V12 and the sharpest handling.', body: 0xd4121e, accent: 0xf4f4f4, glow: 0xff2a2a, maxV: 222.2, nitro: 0, accel: 33, grip: 9.0, steer: 1.18, pitch: 1.18, bars: [3, 5, 5] },
  royale: { id: 'royale', hidden: true, name: 'QYRRAVO F1 (staff)', blurb: 'Staff only. Formula-style, 10,000 km/h, 10 gears, unlimited nitro, press F to fly.', body: 0xc9a227, accent: 0x0b0b10, glow: 0xffd24a, maxV: 2777.8, nitro: 0, accel: 95, hyper: 1.15, grip: 11, steer: 1.1, pitch: 1.0, gears: 10, bars: [5, 5, 5] },
  tesla: { id: 'tesla', name: 'Tesla Roadster', cost: 30000, fly: true, blurb: 'Flies (F) and reaches 20,000 km/h. Unlock once for 30,000 Q.', body: 0xeef2f7, accent: 0xd01820, glow: 0x39a0ff, maxV: 5555.6, hyper: 1.2, gears: 10, nitro: 0, accel: 90, grip: 9.4, steer: 1.05, pitch: 1.0, bars: [4, 5, 5] },
  bugatti: { id: 'bugatti', name: 'Bugatti', blurb: 'Huge top speed. Heavy, so brake early.', body: 0x0d2a6b, accent: 0x9fb4c8, glow: 0x39a0ff, maxV: 222.2, nitro: 0, accel: 28, grip: 7.4, steer: 0.86, pitch: 0.82, bars: [5, 3, 3] },
};

// Lofted body: each station is a cross-section at depth z. Half profile runs bottom -> top centre, then it is mirrored.
function loft(B, st, col, e = 0) {
  const ring = (q) => { const hp = [[q.w * 0.9, q.y0], [q.w, q.y0 + (q.ys - q.y0) * 0.3], [q.w, q.ys], [q.wt, q.yt], [0.001, q.yt]]; return [...hp.map(([x, y]) => [x, y, q.z]), ...hp.slice().reverse().map(([x, y]) => [-x, y, q.z])]; };
  const R = st.map(ring), M = R[0].length;
  const quad = (a, b, c, d, cen) => {
    let u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [d[0] - a[0], d[1] - a[1], d[2] - a[2]];
    let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]; const l = Math.hypot(...n) || 1; n = n.map((x) => x / l);
    const mx = (a[0] + c[0]) / 2 - cen[0], my = (a[1] + c[1]) / 2 - cen[1], mz = (a[2] + c[2]) / 2 - cen[2];
    if (n[0] * mx + n[1] * my + n[2] * mz < 0) n = n.map((x) => -x);
    B.quad(a, b, c, d, n, col, e);
  };
  for (let i = 0; i < R.length - 1; i++) {
    const cen = [0, (st[i].y0 + st[i].yt) / 2, (st[i].z + st[i + 1].z) / 2];
    for (let j = 0; j < M; j++) { const k = (j + 1) % M; quad(R[i][j], R[i][k], R[i + 1][k], R[i + 1][j], cen); }
  }
  for (const [ri, dir] of [[0, -1], [R.length - 1, 1]]) { const r = R[ri], z = r[0][2], cy = (st[ri].y0 + st[ri].yt) / 2; for (let j = 1; j < M - 1; j++) B.tri(r[0], r[j], r[j + 1], [0, 0, dir], col, e); void cy; }
}
const S = (z, w, y0, ys, wt, yt) => ({ z, w, y0, ys, wt, yt });

export function buildSuper(gl, id, player = true) {
  const B = new Builder(), c = CARS[id], body = hex(c.body), acc = hex(c.accent), glass = hex(0x0a1624), dark = hex(0x07090d), glow = hex(c.glow), rim = hex(0xcfd8e3);
  const lamp = hex(0xfff3c4), tail = hex(0xff1f3d), chrome = hex(0xb9c4d0), cal = hex(0xd01820);
  let W = 1.0, wheelX = 1.0, wr = 0.38, fz = 1.46, rz = -1.42;
  if (id === 'lambo') {
    W = 1.02; wheelX = 0.98; wr = 0.38; fz = 1.5; rz = -1.5;
    loft(B, [S(2.42, 0.82, 0.14, 0.3, 0.55, 0.42), S(2.0, 0.97, 0.18, 0.42, 0.7, 0.52), S(1.2, 1.02, 0.2, 0.55, 0.78, 0.66), S(0.55, 1.03, 0.22, 0.68, 0.8, 0.8), S(-0.6, 1.03, 0.22, 0.78, 0.7, 0.96), S(-1.6, 1.0, 0.22, 0.8, 0.62, 0.95), S(-2.25, 0.96, 0.24, 0.74, 0.6, 0.82), S(-2.42, 0.9, 0.3, 0.66, 0.55, 0.74)], body);
    loft(B, [S(0.9, 0.72, 0.78, 0.8, 0.6, 0.84), S(0.2, 0.8, 0.82, 0.98, 0.5, 1.13), S(-0.8, 0.8, 0.9, 1.0, 0.5, 1.14), S(-1.55, 0.72, 0.92, 0.98, 0.5, 1.0)], glass);
    B.box(0, 1.14, -0.3, 0.9, 0.02, 1.0, body);                                                      // roof panel
    B.box(0, 0.18, 2.35, 1.9, 0.06, 0.4, dark); B.box(0, 0.34, 2.43, 1.2, 0.2, 0.05, dark);               // splitter + central intake
    B.box(-0.6, 0.62, 2.28, 0.7, 0.05, 0.12, lamp, 1, 0.3); B.box(0.6, 0.62, 2.28, 0.7, 0.05, 0.12, lamp, 1, -0.3);   // slim angled lamps
    B.box(-0.88, 0.66, -0.9, 0.12, 0.28, 1.0, dark); B.box(0.88, 0.66, -0.9, 0.12, 0.28, 1.0, dark);       // side air intakes
    B.box(-0.3, 0.98, -1.9, 0.5, 0.04, 0.55, dark); B.box(0.3, 0.98, -1.9, 0.5, 0.04, 0.55, dark);         // engine cover vents
    B.box(0, 0.4, -2.44, 1.3, 0.3, 0.08, dark); B.box(-0.62, 0.72, -2.45, 0.55, 0.05, 0.05, tail, 1, 0.2); B.box(0.62, 0.72, -2.45, 0.55, 0.05, 0.05, tail, 1, -0.2);
    for (const x of [-0.18, 0.18]) B.box(x, 0.5, -2.46, 0.14, 0.14, 0.06, chrome);                       // exhausts
    B.box(-1.06, 0.98, 0.4, 0.14, 0.1, 0.18, body); B.box(1.06, 0.98, 0.4, 0.14, 0.1, 0.18, body);        // mirrors
  } else if (id === 'ferrari') {
    W = 0.99; wheelX = 0.96; wr = 0.38; fz = 1.48; rz = -1.4;
    loft(B, [S(2.38, 0.8, 0.13, 0.3, 0.5, 0.45), S(2.0, 0.94, 0.17, 0.42, 0.62, 0.58), S(1.0, 0.99, 0.2, 0.56, 0.7, 0.78), S(0.2, 1.0, 0.22, 0.7, 0.68, 0.9), S(-0.8, 1.0, 0.22, 0.78, 0.66, 0.97), S(-1.7, 0.98, 0.22, 0.8, 0.66, 1.0), S(-2.28, 0.94, 0.26, 0.78, 0.62, 0.95), S(-2.4, 0.9, 0.3, 0.7, 0.6, 0.88)], body);
    loft(B, [S(0.85, 0.7, 0.88, 0.9, 0.58, 0.94), S(0.1, 0.78, 0.92, 1.05, 0.5, 1.2), S(-0.7, 0.78, 0.95, 1.07, 0.5, 1.22), S(-1.4, 0.7, 0.95, 1.0, 0.54, 1.02)], glass);
    B.box(0, 1.22, -0.3, 0.88, 0.02, 0.9, body);
    B.box(0, 0.16, 2.3, 1.9, 0.06, 0.4, dark); B.box(0, 0.36, 2.4, 1.3, 0.22, 0.05, dark);
    B.box(-0.62, 0.6, 2.3, 0.62, 0.07, 0.1, lamp, 1, 0.12); B.box(0.62, 0.6, 2.3, 0.62, 0.07, 0.1, lamp, 1, -0.12);
    B.box(0, 0.62, 1.95, 0.08, 0.02, 1.3, acc, 0.1);                                                  // centre racing stripe
    B.box(-0.92, 0.64, -0.55, 0.1, 0.25, 0.9, dark); B.box(0.92, 0.64, -0.55, 0.1, 0.25, 0.9, dark);       // side intakes
    B.box(0, 1.02, -2.3, 1.7, 0.05, 0.4, body);                                                        // ducktail
    for (const x of [-0.68, -0.34, 0.34, 0.68]) B.box(x, 0.8, -2.42, 0.24, 0.2, 0.05, tail, 1);          // four round tail lamps
    B.box(0, 0.4, -2.43, 1.0, 0.28, 0.08, dark); for (const x of [-0.45, -0.15, 0.15, 0.45]) B.box(x, 0.48, -2.46, 0.12, 0.12, 0.05, chrome);
    B.box(-1.04, 0.98, 0.35, 0.14, 0.1, 0.18, body); B.box(1.04, 0.98, 0.35, 0.14, 0.1, 0.18, body);
  } else if (id === 'royale') {
    // open-wheel Formula-style car: narrow nose, sidepods, halo, big wings, exposed wheels
    W = 0.55; wheelX = 1.02; wr = 0.38; fz = 1.75; rz = -1.7;
    loft(B, [S(2.9, 0.13, 0.16, 0.2, 0.08, 0.26), S(2.2, 0.2, 0.16, 0.24, 0.14, 0.32), S(1.2, 0.34, 0.16, 0.3, 0.22, 0.46), S(0.4, 0.5, 0.16, 0.36, 0.34, 0.6), S(-0.5, 0.56, 0.16, 0.4, 0.38, 0.62), S(-1.5, 0.4, 0.16, 0.38, 0.26, 0.56), S(-2.6, 0.22, 0.2, 0.34, 0.14, 0.46)], body);
    for (const sx of [-1, 1]) { B.box(sx * 0.62, 0.34, -0.1, 0.5, 0.36, 2.4, body); B.box(sx * 0.62, 0.34, 1.3, 0.4, 0.22, 0.6, body); B.box(sx * 0.9, 0.3, -0.1, 0.06, 0.16, 1.8, acc, 0.1); }   // sidepods
    B.box(0, 0.5, 2.9, 2.0, 0.06, 0.5, acc); B.box(0, 0.58, 2.95, 1.9, 0.04, 0.25, body); for (const sx of [-1, 1]) B.box(sx * 1.0, 0.4, 2.95, 0.06, 0.34, 0.6, acc);      // front wing + end plates
    B.box(0, 1.1, -2.7, 1.8, 0.07, 0.6, acc); B.box(0, 1.28, -2.74, 1.8, 0.06, 0.4, body); for (const sx of [-1, 1]) B.box(sx * 0.9, 1.0, -2.72, 0.06, 0.6, 0.7, acc); B.box(0, 0.8, -2.6, 0.08, 0.6, 0.4, acc);   // rear wing + pylon
    B.box(0, 0.8, -1.2, 0.08, 0.5, 1.4, body);                                                         // engine cover fin
    B.box(0, 0.78, -0.2, 0.4, 0.22, 0.5, hex(0xe8eef7), 0.1);                                          // helmet
    B.box(0, 0.9, 0.35, 0.05, 0.05, 0.9, dark); B.box(-0.22, 0.86, 0.1, 0.04, 0.3, 0.05, dark); B.box(0.22, 0.86, 0.1, 0.04, 0.3, 0.05, dark); B.box(0, 1.02, 0.45, 0.46, 0.05, 0.05, dark);   // halo
    B.box(0, 0.2, 1.1, 0.5, 0.05, 1.8, dark); B.box(0, 0.3, -2.75, 0.5, 0.2, 0.1, tail, 1);            // floor + rain light
    for (const sx of [-1, 1]) for (const z of [fz, rz]) { B.box(sx * 0.78, 0.38, z, 0.7, 0.03, 0.05, dark); }   // wishbones
  } else if (id === 'tesla') {
    W = 0.98; wheelX = 0.95; wr = 0.37; fz = 1.42; rz = -1.38;
    loft(B, [S(2.3, 0.78, 0.14, 0.34, 0.5, 0.44), S(1.9, 0.94, 0.17, 0.46, 0.64, 0.56), S(1.0, 0.98, 0.2, 0.58, 0.76, 0.72), S(0.2, 0.98, 0.22, 0.66, 0.78, 0.84), S(-0.7, 0.98, 0.22, 0.7, 0.72, 0.9), S(-1.6, 0.96, 0.22, 0.72, 0.64, 0.86), S(-2.3, 0.88, 0.26, 0.68, 0.58, 0.8)], body);
    loft(B, [S(0.7, 0.7, 0.8, 0.82, 0.58, 0.88), S(0.0, 0.76, 0.84, 0.96, 0.5, 1.08), S(-0.8, 0.76, 0.86, 0.98, 0.5, 1.08), S(-1.5, 0.66, 0.86, 0.92, 0.44, 0.94)], glass);
    B.box(0, 1.1, -0.45, 0.9, 0.02, 1.0, hex(0x101820), 0.1);                                           // glass roof
    B.box(0, 0.6, 2.28, 1.3, 0.05, 0.12, lamp, 1); B.box(-0.7, 0.58, 2.22, 0.5, 0.06, 0.1, lamp, 1, 0.3); B.box(0.7, 0.58, 2.22, 0.5, 0.06, 0.1, lamp, 1, -0.3);   // slim LED lamps
    B.box(0, 0.78, -2.3, 1.7, 0.07, 0.06, tail, 1);                                                      // full-width tail bar
    B.box(0, 0.22, 2.2, 1.9, 0.06, 0.4, dark); B.box(0, 0.3, -2.3, 1.6, 0.14, 0.1, dark);                // splitter + diffuser (no exhaust: it is electric)
    B.box(-0.99, 0.48, 0.1, 0.05, 0.04, 2.2, acc, 0.2); B.box(0.99, 0.48, 0.1, 0.05, 0.04, 2.2, acc, 0.2);  // red side accent
    B.box(-1.04, 0.92, 0.55, 0.14, 0.09, 0.18, body); B.box(1.04, 0.92, 0.55, 0.14, 0.09, 0.18, body);
  } else if (c.lux) {
    // 20 luxury cars share one parametric body so they stay light; shape picks the proportions
    const p = c.lux, sh = p.shape, w = sh === 'limo' ? 1.06 : sh === 'hyper' ? 1.04 : 1.0, L = sh === 'limo' ? 2.75 : sh === 'gt' ? 2.55 : sh === 'hyper' ? 2.5 : 2.35;
    const hood = { hyper: 0.52, gt: 0.74, limo: 0.98, coupe: 0.64 }[sh], rb = { hyper: 0.86, gt: 0.92, limo: 1.08, coupe: 0.9 }[sh], rY = { hyper: 1.12, gt: 1.26, limo: 1.55, coupe: 1.2 }[sh];
    W = w; wheelX = w - 0.03; wr = sh === 'limo' ? 0.43 : 0.38; fz = L * 0.6; rz = -L * 0.58;
    loft(B, [S(L, 0.82 * w, 0.14, 0.32, 0.5 * w, hood * 0.62), S(L * 0.85, 0.95 * w, 0.17, 0.44, 0.66 * w, hood * 0.8), S(L * 0.45, w, 0.2, 0.56, 0.78 * w, hood), S(L * 0.05, w * 1.01, 0.22, 0.68, 0.78 * w, rb * 0.92), S(-L * 0.4, w * 1.01, 0.22, 0.76, 0.7 * w, rb), S(-L * 0.8, w, 0.22, 0.78, 0.62 * w, rb * 0.95), S(-L, w * 0.92, 0.28, 0.72, 0.58 * w, rb * 0.85)], body);
    const c0 = sh === 'gt' ? L * 0.18 : L * 0.4;
    loft(B, [S(c0, 0.72 * w, rb - 0.05, rb - 0.03, 0.58 * w, rb + 0.06), S(c0 * 0.2, 0.78 * w, rb - 0.04, (rb + rY) / 2, 0.5 * w, rY), S(-L * 0.4, 0.78 * w, rb - 0.04, (rb + rY) / 2, 0.5 * w, rY), S(-L * 0.75, 0.7 * w, rb - 0.04, rb + 0.02, 0.44 * w, rb + 0.1)], glass);
    B.box(0, rY + 0.01, -L * 0.2, 0.9 * w, 0.02, L * 0.5, sh === 'limo' || sh === 'gt' ? acc : body, 0.05);
    B.box(0, 0.18, L - 0.05, 1.9 * w, 0.06, 0.4, dark);
    B.box(-0.6 * w, 0.6, L - 0.1, 0.6, 0.06, 0.1, lamp, 1, 0.2); B.box(0.6 * w, 0.6, L - 0.1, 0.6, 0.06, 0.1, lamp, 1, -0.2);
    if (sh === 'limo') { B.box(0, 0.7, L + 0.02, 0.9, 0.7, 0.08, chrome, 0.2); B.box(0, 0.7, L + 0.06, 0.7, 0.55, 0.04, dark); B.box(0, hood + 0.08, L * 0.8, 0.06, 0.14, 0.06, chrome, 0.4); }
    else B.box(0, 0.4, L + 0.02, 1.2 * w, 0.2, 0.06, dark);
    B.box(0, 0.8, -L - 0.02, 1.7 * w, 0.06, 0.06, tail, 1);
    for (const sx of [-1, 1]) { B.box(sx * (w - 0.02), 0.66, -L * 0.3, 0.1, 0.26, L * 0.4, dark); B.box(sx * (w + 0.02), 0.5, L * 0.1, 0.04, 0.05, L * 0.9, acc, 0.2); }
    if (p.wing) { B.box(0, rb + 0.22, -L + 0.12, 1.8 * w, 0.06, 0.42, acc); for (const sx of [-1, 1]) B.box(sx * 0.7 * w, rb + 0.1, -L + 0.12, 0.06, 0.26, 0.3, acc); }
    B.box(0, 0.78, L * 0.35, 0.07, 0.02, L * 0.7, acc, 0.1);
    for (const x of (sh === 'hyper' ? [-0.5, -0.17, 0.17, 0.5] : [-0.3, 0.3])) B.box(x * w, 0.46, -L - 0.04, 0.16, 0.14, 0.06, chrome);
    B.box(-1.06 * w, rb + 0.06, L * 0.15, 0.14, 0.09, 0.18, body); B.box(1.06 * w, rb + 0.06, L * 0.15, 0.14, 0.09, 0.18, body);
  } else {
    W = 1.07; wheelX = 1.03; wr = 0.4; fz = 1.45; rz = -1.4;
    loft(B, [S(2.28, 0.9, 0.14, 0.45, 0.62, 0.65), S(1.9, 1.04, 0.2, 0.6, 0.78, 0.82), S(1.1, 1.07, 0.22, 0.72, 0.84, 0.98), S(0.1, 1.08, 0.24, 0.8, 0.84, 1.06), S(-1.0, 1.08, 0.24, 0.84, 0.8, 1.1), S(-1.9, 1.04, 0.26, 0.86, 0.7, 1.08), S(-2.3, 0.96, 0.3, 0.8, 0.64, 0.96)], body);
    loft(B, [S(0.95, 0.8, 1.0, 1.02, 0.66, 1.08), S(0.2, 0.88, 1.04, 1.12, 0.6, 1.3), S(-0.9, 0.88, 1.06, 1.14, 0.58, 1.3), S(-1.8, 0.78, 1.06, 1.1, 0.5, 1.12)], glass);
    B.box(0, 1.3, -0.35, 0.96, 0.02, 1.1, acc, 0.1);                                                  // roof in the second colour
    B.box(-1.08, 0.78, 0.1, 0.06, 0.2, 1.8, acc, 0.12); B.box(1.08, 0.78, 0.1, 0.06, 0.2, 1.8, acc, 0.12);   // the long side "C" line
    B.box(-1.08, 0.66, -0.9, 0.06, 0.34, 0.5, acc, 0.12); B.box(1.08, 0.66, -0.9, 0.06, 0.34, 0.5, acc, 0.12);   // C bow over the rear intake
    B.box(0, 0.62, 2.3, 0.62, 0.55, 0.08, dark); B.box(0, 0.62, 2.34, 0.7, 0.62, 0.04, chrome, 0.15);             // horseshoe grille: frame ...
    B.box(0, 0.62, 2.35, 0.5, 0.5, 0.05, dark);                                                         // ... and opening
    B.box(-0.74, 0.8, 2.1, 0.32, 0.12, 0.1, lamp, 1); B.box(0.74, 0.8, 2.1, 0.32, 0.12, 0.1, lamp, 1);          // main lamps
    B.box(-0.74, 0.62, 2.14, 0.3, 0.1, 0.08, lamp, 1); B.box(0.74, 0.62, 2.14, 0.3, 0.1, 0.08, lamp, 1);
    B.box(0, 0.18, 2.2, 2.0, 0.06, 0.4, dark);
    B.box(0, 0.95, -2.32, 1.9, 0.07, 0.06, tail, 1);                                                     // full-width tail bar
    B.box(0, 0.38, -2.35, 1.4, 0.3, 0.1, dark); for (const x of [-0.5, 0.5]) B.box(x, 0.46, -2.4, 0.3, 0.3, 0.06, chrome);   // big quad exhausts (two shown)
    B.box(-1.12, 1.02, 0.45, 0.14, 0.1, 0.2, body); B.box(1.12, 1.02, 0.45, 0.14, 0.1, 0.2, body);
  }
  // wheels with wheel-arch shadows, rims, brake calipers
  for (const [sx, z] of [[-1, fz], [1, fz], [-1, rz], [1, rz]]) {
    const x = sx * wheelX; wheel(B, x, wr, z, wr, id === 'bugatti' ? 0.34 : id === 'royale' ? 0.46 : 0.32, rim);
    if (id === 'royale') continue;
    B.box(sx * (W + 0.01), wr, z, 0.05, wr * 2.35, wr * 2.9, dark); B.box(sx * (wheelX - 0.18), wr, z, 0.04, wr * 0.7, wr * 0.5, cal, 0.2);
    B.box(x + sx * 0.17, wr, z, 0.03, wr * 0.55, wr * 0.55, hex(0x20262e));                                  // centre hub cap
  }
  if (id !== 'royale') B.box(0, 0.12, 0, 1.7, 0.04, 4.2, player ? glow : hex(0xff3fb4), 1);   // under-glow
  return B.mesh(gl);
}

export function buildPerson(gl, shirt, hostile = false) {
  const B = new Builder(), skin = hex(0xd9a77c), pants = hex(0x1c2230), top = hex(shirt);
  B.box(-0.14, 0.45, 0, 0.2, 0.9, 0.24, pants); B.box(0.14, 0.45, 0, 0.2, 0.9, 0.24, pants);
  B.box(0, 1.25, 0, 0.56, 0.7, 0.3, top, hostile ? 0.25 : 0);
  B.box(-0.38, 1.25, 0, 0.14, 0.62, 0.2, top); B.box(0.38, 1.25, 0, 0.14, 0.62, 0.2, top);
  B.box(0, 1.8, 0, 0.3, 0.3, 0.3, skin);
  if (hostile) { B.box(0, 1.8, 0.03, 0.34, 0.12, 0.34, hex(0x120a0a)); B.box(0, 2.55, 0, 0.3, 0.3, 0.3, hex(0xff1f3d), 1, Math.PI / 4); }   // mask and a red marker
  return B.mesh(gl);
}

// the 20 luxury cars come from public/data/luxury-cars.json (the server reads the same file for prices)
export function registerLuxury(list) {
  list.forEach((l, i) => {
    CARS[l.id] = { id: l.id, name: l.name, cost: l.price, kmh: l.kmh, lux: { shape: l.shape, wing: l.wing }, body: l.body, accent: l.accent, glow: l.glow,
      blurb: 'Top speed ' + l.kmh.toLocaleString('en-US') + ' km/h.', maxV: l.kmh / 3.6, nitro: 0, accel: 40 + i * 2.5, hyper: 0.3 + i * 0.045, grip: 8.2 + (i % 4) * 0.5, steer: 1.0 + (i % 3) * 0.05, pitch: 1.0, gears: 10,
      bars: [Math.min(5, 3 + Math.ceil(i / 6)), 3 + (i % 3), 3 + ((i + 1) % 3)] };
  });
}
