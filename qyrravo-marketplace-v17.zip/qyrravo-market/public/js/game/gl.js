// A tiny WebGL1 engine: lit coloured meshes, distance fog, a procedural night sky. No libraries.
export const m4 = {
  persp(fovy, asp, n, f) { const t = 1 / Math.tan(fovy / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = 2 * f * n / (n - f); return o; },
  lookAt(e, c, u = [0, 1, 0]) {
    let zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2]; let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
    let xx = u[1] * zz - u[2] * zy, xy = u[2] * zx - u[0] * zz, xz = u[0] * zy - u[1] * zx; l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx; const o = new Float32Array(16);
    o[0] = xx; o[1] = yx; o[2] = zx; o[4] = xy; o[5] = yy; o[6] = zy; o[8] = xz; o[9] = yz; o[10] = zz;
    o[12] = -(xx * e[0] + xy * e[1] + xz * e[2]); o[13] = -(yx * e[0] + yy * e[1] + yz * e[2]); o[14] = -(zx * e[0] + zy * e[1] + zz * e[2]); o[15] = 1; return o;
  },
  mul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3]; return o; },
  model(x, y, z, yaw, roll = 0) { const c = Math.cos(yaw), s = Math.sin(yaw), o = new Float32Array(16); const cr = Math.cos(roll), sr = Math.sin(roll);
    // yaw about Y, then a small roll about the car's forward axis (for body lean)
    o[0] = c * cr; o[1] = sr; o[2] = -s * cr; o[4] = -c * sr; o[5] = cr; o[6] = s * sr; o[8] = s; o[10] = c; o[12] = x; o[13] = y; o[14] = z; o[15] = 1; return o; },
};

export class Builder {
  constructor() { this.v = []; }
  vert(x, y, z, n, c, e) { this.v.push(x, y, z, n[0], n[1], n[2], c[0], c[1], c[2], e); }
  tri(a, b, c, n, col, e = 0) { this.vert(...a, n, col, e); this.vert(...b, n, col, e); this.vert(...c, n, col, e); }
  quad(a, b, c, d, n, col, e = 0) { this.tri(a, b, c, n, col, e); this.tri(a, c, d, n, col, e); }
  // flat quad lying on the ground between four (x,z) points
  flat(p0, p1, p2, p3, y, col, e = 0) { this.quad([p0[0], y, p0[1]], [p1[0], y, p1[1]], [p2[0], y, p2[1]], [p3[0], y, p3[1]], [0, 1, 0], col, e); }
  box(cx, cy, cz, sx, sy, sz, col, e = 0, yaw = 0) {
    const c = Math.cos(yaw), s = Math.sin(yaw), hx = sx / 2, hy = sy / 2, hz = sz / 2;
    const P = (x, y, z) => [cx + x * c + z * s, cy + y, cz - x * s + z * c]; const N = (x, y, z) => [x * c + z * s, y, -x * s + z * c];
    const f = (n, a, b, cc, d) => this.quad(P(...a), P(...b), P(...cc), P(...d), N(...n), col, e);
    f([0, 1, 0], [-hx, hy, -hz], [-hx, hy, hz], [hx, hy, hz], [hx, hy, -hz]); f([0, -1, 0], [-hx, -hy, hz], [-hx, -hy, -hz], [hx, -hy, -hz], [hx, -hy, hz]);
    f([0, 0, 1], [-hx, -hy, hz], [hx, -hy, hz], [hx, hy, hz], [-hx, hy, hz]); f([0, 0, -1], [hx, -hy, -hz], [-hx, -hy, -hz], [-hx, hy, -hz], [hx, hy, -hz]);
    f([1, 0, 0], [hx, -hy, hz], [hx, -hy, -hz], [hx, hy, -hz], [hx, hy, hz]); f([-1, 0, 0], [-hx, -hy, -hz], [-hx, -hy, hz], [-hx, hy, hz], [-hx, hy, -hz]);
  }
  // cone / cylinder standing on y
  cone(cx, cy, cz, r1, r2, h, sides, col, e = 0) {
    for (let i = 0; i < sides; i++) {
      const a0 = i / sides * Math.PI * 2, a1 = (i + 1) / sides * Math.PI * 2, am = (a0 + a1) / 2;
      const p = (r, a, y) => [cx + Math.cos(a) * r, cy + y, cz + Math.sin(a) * r]; const n = [Math.cos(am), (r1 - r2) / h, Math.sin(am)];
      this.quad(p(r1, a0, 0), p(r1, a1, 0), p(r2, a1, h), p(r2, a0, h), n, col, e);
    }
  }
  mesh(gl) { const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.v), gl.STATIC_DRAW); return { buf, count: this.v.length / 10 }; }
}

const VS = `attribute vec3 aPos;attribute vec3 aNor;attribute vec4 aCol;
uniform mat4 uVP;uniform mat4 uModel;uniform vec3 uSun;uniform vec3 uCam;uniform float uFogD;
varying vec3 vCol;varying float vFog;
void main(){vec4 w=uModel*vec4(aPos,1.0);vec3 n=normalize(mat3(uModel)*aNor);
float d=max(dot(n,normalize(uSun)),0.0);float hemi=0.5+0.5*n.y;vec3 lit=aCol.rgb*(0.22+0.42*hemi+0.55*d);
vCol=mix(lit,aCol.rgb*1.5,aCol.a);float dist=length(w.xyz-uCam);vFog=1.0-exp(-dist*uFogD);vFog=clamp(vFog,0.0,1.0);gl_Position=uVP*w;}`;
const FS = `precision mediump float;uniform vec3 uFog;varying vec3 vCol;varying float vFog;void main(){gl_FragColor=vec4(mix(vCol,uFog,vFog),1.0);}`;
const SVS = `attribute vec2 aP;varying vec2 vUv;void main(){vUv=aP*0.5+0.5;gl_Position=vec4(aP,0.9999,1.0);}`;
const SFS = `precision mediump float;varying vec2 vUv;uniform float uYaw;uniform float uAsp;uniform float uHor;
float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){float y=vUv.y;vec3 top=vec3(0.015,0.02,0.07),mid=vec3(0.05,0.07,0.2),hor=vec3(0.09,0.2,0.3);
float t=clamp((y-uHor)/(1.0-uHor),0.0,1.0);vec3 c=mix(hor,mid,smoothstep(0.0,0.35,t));c=mix(c,top,smoothstep(0.25,1.0,t));
if(y<uHor){c=mix(hor,vec3(0.04,0.1,0.16),clamp((uHor-y)*6.0,0.0,1.0));}
vec2 sp=vec2(vUv.x*uAsp*1.6-uYaw*2.2,y)*vec2(90.0,90.0);vec2 g=floor(sp);float s=step(0.9955,h(g))*smoothstep(uHor+0.05,uHor+0.4,y);c+=vec3(s)*(0.5+0.5*h(g+3.0));
vec2 m=vec2((vUv.x-0.74)*uAsp-uYaw*0.9*0.0-fract(uYaw*0.0),y-0.78);float md=length(vec2((vUv.x*uAsp*1.6-uYaw*2.2)-1.2,(y-0.8)*1.6));
c+=vec3(0.75,0.9,1.0)*smoothstep(0.075,0.065,md)+vec3(0.15,0.3,0.5)*smoothstep(0.35,0.0,md)*0.5;
gl_FragColor=vec4(c,1.0);}`;

export class Renderer {
  constructor(canvas) {
    const gl = this.gl = canvas.getContext('webgl', { antialias: true, alpha: false }) || canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('no webgl');
    this.canvas = canvas;
    const prog = (v, f) => { const p = gl.createProgram(); for (const [t, s] of [[gl.VERTEX_SHADER, v], [gl.FRAGMENT_SHADER, f]]) { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); gl.attachShader(p, sh); } gl.linkProgram(p); return p; };
    this.p = prog(VS, FS); this.sky = prog(SVS, SFS);
    const u = (p, n) => gl.getUniformLocation(p, n); const a = (p, n) => gl.getAttribLocation(p, n);
    this.U = { vp: u(this.p, 'uVP'), model: u(this.p, 'uModel'), sun: u(this.p, 'uSun'), cam: u(this.p, 'uCam'), fogd: u(this.p, 'uFogD'), fog: u(this.p, 'uFog') };
    this.A = { pos: a(this.p, 'aPos'), nor: a(this.p, 'aNor'), col: a(this.p, 'aCol') };
    this.S = { yaw: u(this.sky, 'uYaw'), asp: u(this.sky, 'uAsp'), hor: u(this.sky, 'uHor'), p: a(this.sky, 'aP') };
    this.quadBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    this.fog = [0.07, 0.16, 0.25]; this.fogDensity = 0.0011; this.ident = m4.model(0, 0, 0, 0);
  }
  resize() { const dpr = Math.min(window.devicePixelRatio || 1, 1.75), w = Math.max(2, Math.floor(this.canvas.clientWidth * dpr)), h = Math.max(2, Math.floor(this.canvas.clientHeight * dpr)); if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; } this.gl.viewport(0, 0, w, h); return w / h; }
  begin(vp, cam, yaw, asp) {
    const gl = this.gl; gl.clearColor(this.fog[0], this.fog[1], this.fog[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.disable(gl.DEPTH_TEST); gl.useProgram(this.sky); gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuf); gl.enableVertexAttribArray(this.S.p); gl.vertexAttribPointer(this.S.p, 2, gl.FLOAT, false, 0, 0);
    gl.uniform1f(this.S.yaw, yaw); gl.uniform1f(this.S.asp, asp); gl.uniform1f(this.S.hor, 0.5); gl.drawArrays(gl.TRIANGLES, 0, 3); gl.disableVertexAttribArray(this.S.p);
    gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.useProgram(this.p);
    gl.uniformMatrix4fv(this.U.vp, false, vp); gl.uniform3f(this.U.sun, 0.4, 0.8, 0.3); gl.uniform3f(this.U.cam, cam[0], cam[1], cam[2]); gl.uniform1f(this.U.fogd, this.fogDensity); gl.uniform3f(this.U.fog, ...this.fog);
  }
  draw(mesh, model = this.ident) {
    const gl = this.gl; gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf); const S = 40;
    gl.enableVertexAttribArray(this.A.pos); gl.vertexAttribPointer(this.A.pos, 3, gl.FLOAT, false, S, 0);
    gl.enableVertexAttribArray(this.A.nor); gl.vertexAttribPointer(this.A.nor, 3, gl.FLOAT, false, S, 12);
    gl.enableVertexAttribArray(this.A.col); gl.vertexAttribPointer(this.A.col, 4, gl.FLOAT, false, S, 24);
    gl.uniformMatrix4fv(this.U.model, false, model); gl.drawArrays(gl.TRIANGLES, 0, mesh.count);
  }
}
