import { icon } from './icons.js';
import { initTilt } from './fx3d.js';
import { logoImg, socialLinks, gmailUrl, nameTag, ownerCard, h, $, clear, state, GET, POST, loadMe, lsGet, lsSet, toast, flag, errorBox, skeletonGrid, can, ApiError } from './core.js';

const routes = [];
const add = (re, mod, fn) => routes.push({ re, mod, fn });
// [pattern, module, export]
add(/^$|^home$/, 'store', 'home');
add(/^browse$/, 'store', 'browse');
add(/^p\/(\d+)$/, 'store', 'product');
add(/^s\/(\d+)$/, 'store', 'sellerPage');
add(/^game$/, 'game', 'game');
add(/^compare$/, 'store', 'compare');
add(/^wishlist$/, 'store', 'wishlist');
add(/^cart$/, 'store', 'cart');
add(/^login$/, 'auth', 'login');
add(/^register$/, 'auth', 'register');
add(/^verify$/, 'auth', 'verify');
add(/^forgot$/, 'auth', 'forgot');
add(/^reset$/, 'auth', 'reset');
add(/^account$/, 'auth', 'account');
add(/^sell$/, 'seller', 'sellLanding');
add(/^dashboard$/, 'seller', 'dashboard');
add(/^dashboard\/products$/, 'seller', 'products');
add(/^dashboard\/products\/new$/, 'seller', 'productForm');
add(/^dashboard\/products\/(\d+)$/, 'seller', 'productForm');
add(/^dashboard\/plan$/, 'seller', 'plan');
add(/^mod$/, 'staff', 'modQueue');
add(/^mod\/(\d+)$/, 'staff', 'modProduct');
add(/^admin(?:\/([a-z-]+))?$/, 'staff', 'admin');
add(/^legal\/([a-z-]+)$/, 'legal', 'legalPage');
add(/^legal$/, 'legal', 'legalIndex');
add(/^about$/, 'legal', 'about');
add(/^notifications$/, 'auth', 'notifications');
add(/^owner$/, 'legal', 'ownerPage');
add(/^events$/, 'community', 'events');
add(/^polls$/, 'community', 'polls');
add(/^wiki$/, 'community', 'wiki');
add(/^redeem$/, 'redeem', 'redeem');


const cache = {};
const load = (m) => cache[m] || (cache[m] = import('./views/' + m + '.js'));
let token = 0;

export function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, qs = ''] = raw.split('?');
  return { path: path.replace(/\/$/, ''), query: Object.fromEntries(new URLSearchParams(qs)) };
}
export function go(path) { location.hash = '#/' + path.replace(/^\/?#?\/?/, ''); }
export function setQuery(q) { const { path } = parseHash(); const s = new URLSearchParams(Object.entries(q).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString(); history.replaceState(null, '', '#/' + path + (s ? '?' + s : '')); }

async function render() {
  const my = ++token;
  const { path, query } = parseHash();
  const main = $('#main');
  let hit = null; let m = null;
  for (const r of routes) { m = r.re.exec(path); if (m) { hit = r; break; } }
  clear(main).append(h('div', { class: 'wrap' }, skeletonGrid(4)));
  try {
    let node;
    if (!hit) node = h('div', { class: 'wrap block' }, h('h1', null, 'Page not found'), h('p', { class: 'muted' }, 'That page does not exist.'), h('p', null, h('a', { href: '#/' }, 'Go to the home page')));
    else { const mod = await load(hit.mod); node = await mod[hit.fn]({ params: m.slice(1), query, path }); }
    if (my !== token) return;
    clear(main).append(node); node.classList.add('pg3d');
    document.title = (node.dataset && node.dataset.title ? node.dataset.title + ' · ' : '') + 'QYRRAVO';
    window.scrollTo(0, 0); main.focus({ preventScroll: true });
    markNav();
  } catch (e) {
    if (my !== token) return;
    if (e instanceof ApiError && e.status === 401) { go('login?next=' + encodeURIComponent(path)); return; }
    clear(main).append(h('div', { class: 'wrap block' }, errorBox(e.message ? e : new Error('Unexpected error'), render)));
    if (!(e instanceof ApiError)) console.error(e);
  }
}
function markNav() { const { path } = parseHash(); document.querySelectorAll('.nav a').forEach((a) => { const t = a.getAttribute('href').replace(/^#\//, '').split('?')[0]; if (t && (path === t || (t !== '' && path.startsWith(t + '/')))) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); }); }

// ---------- header / footer ----------
export function cartItems() { return lsGet('qy_cart', []); }
export function cartCount() { return cartItems().reduce((a, i) => a + i.quantity, 0); }
export function refreshHeader() { drawHeader(); }

function setCountry(code) {
  state.country = code; lsSet('qy_country', code);
  const c = state.config.countries.find((x) => x.code === code);
  if (c && state.config.currencies.includes(c.currency)) { state.currency = c.currency; lsSet('qy_currency', c.currency); }
}
function drawHeader() {
  const top = $('#top'); clear(top);
  const cfg = state.config; const me = state.me;
  const countrySel = h('select', { 'aria-label': 'Country', onchange: (e) => { setCountry(e.target.value); drawHeader(); render(); } },
    h('option', { value: '' }, '🌐 Country'),
    cfg.countries.map((c) => h('option', { value: c.code, selected: c.code === state.country }, flag(c.code) + ' ' + c.name)));
  const curSel = h('select', { 'aria-label': 'Currency', title: 'Display currency (other currencies are labelled estimates)', onchange: (e) => { state.currency = e.target.value; lsSet('qy_currency', e.target.value); render(); } },
    cfg.currencies.map((c) => h('option', { value: c, selected: c === (state.currency || 'USD') }, c)));
  const search = h('form', { class: 'searchbox', role: 'search', onsubmit: (e) => { e.preventDefault(); const q = e.target.q.value.trim(); go('browse' + (q ? '?q=' + encodeURIComponent(q) : '')); } }, h('input', { name: 'q', type: 'search', placeholder: 'Search listings', 'aria-label': 'Search listings' }));
  const acct = me ? [
    h('a', { class: 'qchip', href: '#/redeem', title: 'Your Q Coins. Open the Q Coin shop', 'aria-label': 'Q Coins: ' + Number(me.coins || 0).toLocaleString('en-US') + '. Open the Q Coin shop' }, h('i', { 'aria-hidden': 'true' }, 'Q'), h('b', null, Number(me.coins || 0).toLocaleString('en-US'))),
    me.role === 'seller' || me.seller ? h('a', { class: 'btn small hide-m', href: '#/dashboard' }, 'Dashboard') : null,
    can('product.review') ? h('a', { class: 'btn small hide-m', href: '#/mod' }, 'Moderation') : null,
    can('product.review') ? null : null,
    me.role === 'admin' ? h('a', { class: 'btn small hide-m', href: '#/admin' }, 'Admin panel') : null,
    h('a', { class: 'btn small acct', href: '#/account' }, me.isOwner ? logoImg('mark', { alt: '', class: 'mini-avatar' }) : null, me.isOwner ? nameTag(me.displayName) : me.displayName.split(' ')[0] + (me.unread ? ' ' : ''), me.unread ? h('span', { class: 'badge', 'aria-label': me.unread + ' unread' }, me.unread) : null),
  ] : [h('a', { class: 'btn small hide-m', href: '#/login' }, 'Sign in'), h('a', { class: 'btn small primary', href: '#/register' }, 'Join')];
  const cmenu = h('details', { class: 'menu' }, h('summary', null, 'Community ', icon('chevron', 14)),
    h('div', { class: 'menu-pop' }, [['gift', 'Events & giveaways', '#/events'], ['vote', 'Polls', '#/polls'], ['car', 'Drive & earn Q', '#/game'], ['ticket', 'Redeem a code', '#/redeem'], ['book', 'QYRRAVO Wiki', '#/wiki']].map(([ic, t, href]) => h('a', { href, onclick: () => cmenu.removeAttribute('open') }, icon(ic, 18), t))));
  const nav2 = h('nav', { class: 'nav', 'aria-label': 'Main' }, h('a', { href: '#/browse' }, 'Marketplace'), h('a', { href: '#/sell' }, 'Sell'), cmenu, h('a', { href: '#/compare' }, 'Compare'),
    me && (me.role === 'seller' || me.seller) ? h('a', { class: 'show-m', href: '#/dashboard' }, 'Dashboard') : null, me && can('product.review') ? h('a', { class: 'show-m', href: '#/mod' }, 'Moderation') : null, me && me.role === 'admin' ? h('a', { class: 'show-m', href: '#/admin' }, 'Admin') : null);
  top.append(
    h('div', { class: 'wrap hrow' },
      h('a', { class: 'brand', href: '#/', 'aria-label': 'QYRRAVO home' }, logoImg('wordmark', { alt: 'QYRRAVO' })),
      search,
      h('div', { class: 'tools' }, countrySel, curSel, themeSwitch(),
        h('a', { class: 'btn small iconb', href: '#/wishlist', 'aria-label': 'Wishlist' }, icon('heart', 18)),
        h('a', { class: 'btn small iconb', href: '#/cart', 'aria-label': 'Cart, ' + cartCount() + ' items' }, icon('cart', 18), cartCount() ? h('span', { class: 'badge' }, cartCount()) : null),
        acct)),
    h('div', { class: 'snav' }, h('div', { class: 'wrap' }, nav2)));
  markNav();
}
function themeSwitch() {
  const cur = window.qyTheme ? window.qyTheme.get() : 'dark';
  return h('div', { class: 'themesw', role: 'group', 'aria-label': 'Theme' }, [['light', '☀️', 'Light mode'], ['dark', '🌙', 'Dark mode'], ['future', '✨', 'Future mode (neon)']].map(([k, ic, t]) =>
    h('button', { type: 'button', 'data-themebtn': k, title: t, 'aria-label': t, 'aria-pressed': String(k === cur), onclick: () => window.qyTheme && window.qyTheme.set(k) }, ic)));
}
function drawFooter() {
  const f = $('#foot'); clear(f);
  const l = (p, t) => h('a', { href: '#/legal/' + p }, t);
  f.append(h('div', { class: 'wrap' }, h('div', { class: 'cols' },
    h('div', null, logoImg('wordmark', { alt: 'QYRRAVO', style: 'height:30px;margin-bottom:10px' }), h('p', { class: 'muted' }, 'QUIETLY BETTER. An international marketplace where listing photos are reviewed by people before anything goes live. Photo review does not prove ownership, authenticity or a seller’s honesty.'), h('p', { class: 'small', style: 'margin-top:10px' }, 'Contact the owner ', h('button', { class: 'crown', type: 'button', title: 'Owner of QYRRAVO', 'aria-label': 'About the owner', onclick: ownerCard }, '👑'), ' ', h('a', { href: gmailUrl(state.config.site.supportEmail), target: '_blank', rel: 'noopener' }, state.config.site.supportEmail))),
    h('div', null, h('h4', null, 'Marketplace'), h('a', { href: '#/browse' }, 'Browse listings'), h('a', { href: '#/game' }, 'Drive & earn'), h('a', { href: '#/events' }, 'Events'), h('a', { href: '#/polls' }, 'Polls'), h('a', { href: '#/wiki' }, 'QYRRAVO Wiki'), h('a', { href: '#/redeem' }, 'Redeem a code'), h('a', { href: '#/sell' }, 'Sell on QYRRAVO'), l('seller-agreement', 'Seller agreement')),
    h('div', null, h('h4', null, 'Policies'), l('terms', 'Terms of Service'), l('privacy', 'Privacy Policy'), l('shipping-returns', 'Shipping & returns'), l('refunds', 'Refunds & cancellation'), l('disputes', 'Dispute process')),
    h('div', null, h('h4', null, 'Rules'), l('prohibited', 'Prohibited products'), l('photo-verification', 'Photo verification'), l('commission', 'Fees & commission'), l('subscription', 'Subscription terms'), h('a', { href: '#/legal' }, 'All legal pages'), h('a', { href: '#/about' }, 'About & contact'))),
    h('div', { class: 'foot-social' }, h('h4', null, 'Social media'), socialLinks()),
    h('div', { class: 'foot-bottom' }, h('span', null, '© ' + new Date().getFullYear() + ' QYRRAVO. Legal pages are drafts pending review by a qualified lawyer.'), h('span', { class: 'paynote' }, icon('shield', 16), 'Cash or card, arranged by email. This site never collects card details.'), h('button', { class: 'totop', type: 'button', onclick: () => window.scrollTo({ top: 0, behavior: 'smooth' }) }, icon('up', 16), 'Back to top'))));
}
function drawBanner() {
  const b = $('#test-banner'); const p = state.config.payment;
  b.hidden = true; 
}

function drawTabbar() {
  let t = document.getElementById('tabbar'); if (!t) { t = h('nav', { id: 'tabbar', class: 'tabbar', 'aria-label': 'Quick navigation' }); document.body.append(t); }
  clear(t);
  [['home', 'Home', '#/'], ['search', 'Browse', '#/browse'], ['tag', 'Sell', '#/sell'], ['ticket', 'Redeem', '#/redeem'], ['user', state.me ? 'Account' : 'Sign in', state.me ? '#/account' : '#/login']].forEach(([i, l, href]) => t.append(h('a', { href }, icon(i, 22), h('span', null, l))));
  const { path } = parseHash(); t.querySelectorAll('a').forEach((a) => { const p = a.getAttribute('href').replace(/^#\/?/, ''); if ((p === '' && path === '') || (p && (path === p || path.startsWith(p + '/')))) a.setAttribute('aria-current', 'page'); });
}
initTilt();
document.addEventListener('click', (e) => { document.querySelectorAll('details.menu[open]').forEach((m) => { if (!m.contains(e.target)) m.removeAttribute('open'); }); });

async function boot() {
  try {
    state.config = await GET('/api/config');
    await loadMe();
    // merge a logged-out wishlist into the account once
    if (state.me) { const ids = lsGet('qy_wish', []); if (ids.length) { try { await POST('/api/wishlist/merge', { ids }); lsSet('qy_wish', []); } catch { /* retry next load */ } } }
    if (!state.country) { /* user chooses; marketplace works for everyone */ }
    if (!state.currency) state.currency = 'USD';
  } catch (e) {
    $('#main').append(errorBox(e, () => location.reload())); return;
  }
  drawBanner(); drawHeader(); drawFooter(); drawTabbar();
  window.addEventListener('hashchange', drawTabbar); window.addEventListener('qy:session', () => setTimeout(drawTabbar, 200));
  import('./assistant.js').then((m) => m.mountAssistant()).catch(() => {});
  window.addEventListener('hashchange', render);
  window.addEventListener('qy:session', async () => { await loadMe(); drawHeader(); });
  window.addEventListener('qy:cart', drawHeader);
  render();
}
boot();
