// QYRRAVO Drive: a 3D night-city driving game (plain JavaScript + WebGL, no libraries).
// Playing earns Q Coins: 1 Q per minute of ACTIVE driving. The SERVER measures play time from heartbeats; this page cannot award coins itself.
import { h, state, GET, POST, toast, lsGet, lsSet } from '../core.js';
import { refreshHeader } from '../app.js';
import { Renderer, Builder, m4 } from '../game/gl.js';
import { HALF, makeTrack, buildWorld } from '../game/world.js';
import { CARS, buildSuper, hex, registerLuxury } from '../game/cars.js';

const BEAT_MS = 15000;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const mmss = (s) => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
const lap = (s) => (s == null ? '--' : Math.floor(s / 60) + ':' + (s % 60).toFixed(2).padStart(5, '0'));
const best = () => { try { return Number(localStorage.getItem('qy_game_best')) || null; } catch { return null; } };
const setBest = (v) => { try { localStorage.setItem('qy_game_best', String(v)); } catch { /* storage blocked */ } };
const css = (n) => '#' + n.toString(16).padStart(6, '0');
const GEARS10 = [0.07, 0.15, 0.24, 0.34, 0.45, 0.57, 0.7, 0.82, 0.92, 1.0];   // staff F1: ten gears
const GEARS = [0.15, 0.27, 0.4, 0.54, 0.69, 0.84, 1.0];   // top speed of each gear as a share of the car's top speed

// A synthesised V12: six firing pulses per crank turn, so the base note is rpm / 10 Hz, plus rich harmonics, a soft-clip stage and a rising low-pass.
function makeEngine(ev = false) {
  const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
  const ctx = new AC();
  const master = ctx.createGain(); master.gain.value = 0;
  const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -20; comp.ratio.value = 6;
  const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 1.4; lp.frequency.value = 900;
  const shaper = ctx.createWaveShaper(); const c = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; c[i] = Math.tanh(x * 2.6); } shaper.curve = c;
  const mix = ctx.createGain(); mix.gain.value = 0.5;
  mix.connect(shaper); shaper.connect(lp); lp.connect(master); master.connect(comp); comp.connect(ctx.destination);
  const voices = [[1, 'sawtooth', 0.5, 0], [2, 'sawtooth', 0.32, 4], [3, 'square', 0.14, -3], [0.5, 'triangle', 0.5, 0], [4, 'sawtooth', 0.16, 6], [1, 'sawtooth', 0.3, -7], [6, 'square', 0.06, 3], [1.5, 'sawtooth', 0.12, 5]].map(([mul, type, g, det]) => {
    const o = ctx.createOscillator(), gg = ctx.createGain(); o.type = ev ? 'sine' : type; o.detune.value = det; gg.gain.value = g; o.connect(gg); gg.connect(mix); o.start(); return { o, mul };
  });
  // firing roughness: the cylinders pulse the sound the way a big Lamborghini V12 growls
  const f0n = (rpm) => rpm / 10, mod = ctx.createOscillator(), modg = ctx.createGain(); mod.type = 'sine'; mod.frequency.value = 40; modg.gain.value = 0.12; mod.connect(modg); modg.connect(mix.gain); mod.start();
  // intake / road noise
  const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), d = buf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  const ns = ctx.createBufferSource(); ns.buffer = buf; ns.loop = true; const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 600; bp.Q.value = 0.8; const ng = ctx.createGain(); ng.gain.value = 0;
  ns.connect(bp); bp.connect(ng); ng.connect(comp); ns.start();
  const pop = (vol = 0.25) => { if (ev) return; try { const b = ctx.createBufferSource(); b.buffer = buf; const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900; const g = ctx.createGain(); g.gain.value = vol; b.connect(f); f.connect(g); g.connect(comp); b.start(0, Math.random()); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12); b.stop(ctx.currentTime + 0.14); } catch { /* ignore */ } };
  return {
    ctx, pop, muted: false,
    update(rpm, throttle, speed, paused) {
      const t = ctx.currentTime, f0 = ev ? 160 + rpm * 0.11 : rpm / 10;   // an electric car whines instead of firing like a V12
      { const fr = ev ? 0 : f0n(rpm); mod.frequency.setTargetAtTime(Math.max(5, fr * 0.5), t, 0.05); modg.gain.setTargetAtTime(0.1 + throttle * 0.12, t, 0.05); }
      for (const v of voices) v.o.frequency.setTargetAtTime(Math.max(18, f0 * v.mul), t, 0.03);
      lp.frequency.setTargetAtTime(500 + rpm * 0.55 + throttle * 1800, t, 0.05);
      const vol = this.muted || paused ? 0 : (0.16 + throttle * 0.22 + Math.min(0.1, rpm / 90000));
      master.gain.setTargetAtTime(vol, t, 0.05);
      bp.frequency.setTargetAtTime(300 + speed * 14, t, 0.1); ng.gain.setTargetAtTime(this.muted || paused ? 0 : Math.min(0.2, speed / 400), t, 0.1);
    },
    tone(f, dur, vol) { if (this.muted) return; try { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'square'; o.frequency.value = f; g.gain.value = vol; o.connect(g); g.connect(comp); o.start(); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur); o.stop(ctx.currentTime + dur); } catch { /* ignore */ } },
    close() { try { ctx.close(); } catch { /* closed */ } },
  };
}

export async function game() {
  const root = h('div', { class: 'wrap block game-page', dataset: { title: 'Drive & earn' } });
  let st = null;
  const isStaff = !!(state.me && (state.me.isOwner || state.me.role === 'admin' || state.me.role === 'moderator'));
  try { st = await GET('/api/game/status'); } catch { /* shown as offline below */ }
  try { registerLuxury(await (await fetch('/data/luxury-cars.json')).json()); } catch { /* the luxury garage is simply empty if the list cannot load */ }
  

  root.append(h('div', { class: 'phero rhero' }, h('div', { class: 'phero-ic', 'aria-hidden': 'true' }, '🏎️'),
    h('div', null, h('h1', null, 'QYRRAVO Drive'),
      h('p', { class: 'muted' }, 'Pick a supercar and drive the 132 km night circuit. Finish a lap through every checkpoint to earn ' + (st ? st.lapCoins : 20) + ' Q Coins. Our server checks your play time.'))));

  const canvas = h('canvas', { class: 'gcanvas', tabindex: '0', 'aria-label': 'Driving game view' });
  const hud = h('div', { class: 'ghud' });
  const mk = (cls, txt = '') => h('div', { class: cls }, txt);
  const speedEl = mk('gspeed', '0'), gearEl = h('small', null, 'N'), lapEl = mk('gtxt', 'Lap 1'), timeEl = mk('gtxt', '0:00.00'), bestEl = mk('gtxt small', 'Best ' + lap(best())), driftEl = mk('gtxt small', ''), cpEl = mk('gtxt small', 'Checkpoint 1 / 11'), pctEl = mk('gtxt small', '');
  const nitroBar = h('i'); const nitro = h('div', { class: 'gnitro', title: 'Nitro (Shift)' }, nitroBar);
  const mini = h('canvas', { class: 'gmini', width: 150, height: 150, 'aria-hidden': 'true' });
  const earnTitle = mk('gtxt', 'Not earning'), earnSub = mk('gtxt small muted', ''); const earnBar = h('i'); const earnProg = h('div', { class: 'gprog' }, earnBar);
  const chip = mk('gchip', 'Ready'); const popup = mk('gpop', ''); const lines = mk('glines');
  hud.append(lines, h('div', { class: 'gtl' }, lapEl, timeEl, cpEl, pctEl, bestEl, driftEl), h('div', { class: 'gtr', title: 'Click for the full map (N)', role: 'button', tabindex: '0', onclick: () => openMap() }, mini, h('small', { class: 'gmaphint' }, 'Map (N)')),
    h('div', { class: 'gbl' }, h('div', { class: 'gspeedbox' }, speedEl, h('small', null, 'km/h'), gearEl), nitro),
    h('div', { class: 'gbr' }, chip, earnTitle, earnProg, earnSub), popup);

  const overlay = h('div', { class: 'goverlay' });
  const mapCv = h('canvas', { class: 'gmapcv', width: 900, height: 420 }); const mapInfo = h('div', { class: 'gmapinfo' });
  const mapFs = h('div', { class: 'gmapfs', role: 'dialog', 'aria-label': 'Full map', onclick: () => closeMap() }, h('div', { class: 'gmapbox', onclick: (e) => e.stopPropagation() }, h('div', { class: 'gmaphead' }, h('b', null, 'Map of the whole circuit'), h('button', { class: 'btn small', type: 'button', onclick: () => closeMap() }, 'Close (Esc)')), mapCv, mapInfo));
  const stage = h('div', { class: 'gstage' }, canvas, hud, overlay, mapFs);
  root.append(stage);

  const keys = new Set(); let lastInput = 0;
  const touch = h('div', { class: 'gtouch' });
  const tb = (label, key, cls) => { const b = h('button', { type: 'button', class: 'gtb ' + cls, 'aria-label': label }, label);
    const on = (e) => { e.preventDefault(); keys.add(key); lastInput = performance.now(); }; const off = (e) => { e.preventDefault(); keys.delete(key); };
    b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointerleave', off); b.addEventListener('pointercancel', off); return b; };
  touch.append(tb('◀', 'left', 'l'), tb('▶', 'right', 'r'), tb('Brake', 'down', 'b'), tb('Nitro', 'nitro', 'n'), tb('Go', 'up', 'g'));
  stage.append(touch);

  root.append(h('div', { class: 'gdesc' },
    h('div', { class: 'card pad' }, h('h3', null, 'Controls'), h('p', { class: 'small muted' }, 'W / ↑ accelerate, S / ↓ brake and reverse, A D / ← → steer, Space handbrake drift, Shift nitro, R back to the road, P pause, M mute. N or click the minimap opens the full map. A lap counts only after you drive through all 11 glowing checkpoint gates in order and then the finish arch. On phones use the on-screen buttons.')),
    isStaff ? h('div', { class: 'card pad' }, h('h3', null, 'Staff controls'), h('p', { class: 'small muted' }, 'Press F to fly (staff and Tesla Roadster owners). E goes up, Q goes down, F again lands. Nitro (Shift) is unlimited for staff. The staff F1 car (key 5) reaches 10,000 km/h with 10 gears, and staff own every car in the luxury garage. Staff flying or driving the F1 car does not earn lap rewards.')) : null,
    h('div', { class: 'card pad' }, h('h3', null, 'How earning works'), h('p', { class: 'small muted' },
      'Sign in with a verified email. Every completed lap pays ' + (st ? st.lapCoins : 20) + ' Q Coins (a lap is about 132 km, roughly 40 minutes). Time spent driving earns nothing by itself: the server only pays a lap after it has seen enough real, active driving, up to ' + (st ? st.dailyLaps : 12) + ' laps a day per account, and there is a daily budget for everyone. Your lap progress is saved on this device. Only one tab can earn at a time. Spend Q Coins in the Q Coin shop.'))));

  // ---------- state ----------
  let disposed = false, started = false, paused = false, sessionId = null, beatTimer = null, moved = 0, raf = 0, eng = null, carId = lsGet('qy_game_car', 'lambo');
  if (!CARS[carId]) carId = 'lambo';
  const stopAll = () => { disposed = true;  cancelAnimationFrame(raf); clearInterval(beatTimer); clearInterval(progTimer); removeEventListener('keydown', kd); removeEventListener('keyup', ku); document.removeEventListener('visibilitychange', onVis); if (eng) eng.close(); };

  const showState = (r) => {
    if (!r) return; st = { ...st, ...r };
    earnSub.textContent = 'Today: ' + (r.coinsToday || 0) + ' Q, ' + (r.lapsToday || 0) + ' / ' + (r.dailyLaps || 12) + ' laps paid';
  };
  const setChip = (t, cls = '') => { chip.textContent = t; chip.className = 'gchip ' + cls; };
  const pop = (t) => { popup.textContent = t; popup.classList.remove('show'); void popup.offsetWidth; popup.classList.add('show'); };

  let pendingLap = false, flying = false, flew = false;
  const beat = async () => {
    if (!sessionId || disposed) return;
    const active = !paused && !document.hidden && performance.now() - lastInput < 10000 && moved >= 100;
    moved = 0;
    try {
      const r = await POST('/api/game/beat', { sessionId, active, laps: pendingLap ? 1 : 0, car: carId });
      showState(r);
      if (pendingLap) {
        if (r.lapEarned > 0) { pendingLap = false; pop('+' + r.lapEarned + ' Q lap reward!'); toast('Lap complete: +' + r.lapEarned + ' Q Coins', 'ok'); }
        else if (r.lapDenied) { pendingLap = false; const m = { too_fast: 'Keep driving a little longer, then finish the next lap to get paid.', daily_limit: 'You collected all of today\'s lap rewards. More laps pay again tomorrow!', budget: 'Today\'s Q Coin pool is empty. Try again tomorrow.' }[r.lapDenied] || 'Lap not counted.'; toast(m, 'error'); }
      }
      if (r.balance != null && state.me && state.me.coins !== r.balance) { state.me.coins = r.balance; refreshHeader(); }
      if (r.remainingSeconds <= 0) { setChip('Today\'s play time is full', 'warn'); earnTitle.textContent = 'Back tomorrow for more'; }
      else if (r.budgetLeft === false) { setChip('Today\'s coin pool is empty', 'warn'); earnTitle.textContent = 'Back tomorrow for more'; }
      else if (active) { setChip('Earning ' + (st.lapCoins || 20) + ' Q per lap', 'ok'); earnTitle.textContent = 'Finish the lap to earn'; }
      else { setChip('Idle: drive to count', 'warn'); earnTitle.textContent = 'Paused, keep driving'; }
    } catch (e) {
      sessionId = null; const m = (e && e.status === 409) ? 'Another tab is earning' : 'Earning stopped';
      setChip(m, 'warn'); earnTitle.textContent = m;
    }
  };
  const beginEarning = async () => {
    if (!st || !st.enabled) { earnTitle.textContent = 'Earning is switched off'; setChip('Free play'); return; }
    if (!state.me) { earnTitle.textContent = 'Sign in to earn'; setChip('Free play'); return; }
    try { const r = await POST('/api/game/start', {}); sessionId = r.sessionId; showState(r); setChip('Earning ' + (st.lapCoins || 20) + ' Q per lap', 'ok'); earnTitle.textContent = 'Finish the lap to earn'; beatTimer = setInterval(beat, BEAT_MS); }
    catch (e) { const m = e && e.status === 403 ? 'Verify your email to earn' : 'Free play'; earnTitle.textContent = m; setChip(m, 'warn'); if (e && e.message) earnSub.textContent = e.message; }
  };
  showState(st);
  earnTitle.textContent = !st ? 'Earning unavailable' : !st.enabled ? 'Earning is switched off' : !state.me ? 'Sign in to earn 20 Q per lap' : 'Press Start to earn';

  // ---------- WebGL ----------
  let R;
  try { R = new Renderer(canvas); } catch { R = null; }
  if (!R) {
    overlay.classList.add('on'); overlay.append(h('div', { class: 'gbox' }, h('h2', null, 'WebGL is not available'), h('p', { class: 'muted' }, 'This game needs 3D graphics (WebGL). Try a recent Chrome, Edge, Firefox or Safari with hardware acceleration on.')));
    return root;
  }
  const gl = R.gl, tr = makeTrack();
  const world = buildWorld(tr, gl);
  const meshes = {}, glowPad = {}, flames = {};
  const owned = (id) => { const c = CARS[id]; return !!c && (!c.cost || isStaff || !!(st && st.cars && st.cars.includes(id))); };
  const shadow = (() => { const B = new Builder(); B.box(0, 0.05, 0, 2.2, 0.03, 5.4, [0.01, 0.015, 0.02]); return B.mesh(gl); })();
  // under-car neon glow that lights the road, and exhaust flames (afterfire / nitro). Built the first time a car is picked.
  const EX = { lambo: [[-0.18, 0.18], 0.5, -2.5], ferrari: [[-0.45, -0.15, 0.15, 0.45], 0.48, -2.5], bugatti: [[-0.5, 0.5], 0.46, -2.45], royale: [[0], 0.55, -2.8] };
  function ensure(id) {
    if (meshes[id]) return; const cc = CARS[id]; meshes[id] = buildSuper(gl, id, true);
    const gc = hex(cc.glow), dim = gc.map((v) => v * 0.55), G = new Builder(), wide = id === 'royale' ? 2.3 : 2.1, len = id === 'royale' ? 6.4 : 5.4;
    G.box(0, 0.045, 0, wide + 0.9, 0.02, len, dim.map((v) => v * 0.45), 1); G.box(0, 0.05, 0, wide, 0.02, len - 0.8, dim, 1);
    for (const sx of [-1, 1]) { G.box(sx * (wide / 2 + 0.05), 0.07, 0, 0.1, 0.04, len - 0.6, gc, 1); G.box(sx * (wide / 2 - 0.25), 0.2, 0, 0.07, 0.05, len * 0.62, gc, 1); }
    G.box(0, 0.07, len / 2 - 0.1, wide + 0.3, 0.04, 0.1, gc, 1); G.box(0, 0.07, -len / 2 + 0.1, wide + 0.3, 0.04, 0.1, gc, 1);
    glowPad[id] = G.mesh(gl);
    const ex = EX[id] || (cc.lux ? [[-0.2, 0.2], 0.5, -(cc.lux.shape === 'limo' ? 2.75 : 2.5) - 0.1] : null);
    if (ex && !cc.ev) { const [xs, y, z0] = ex; flames[id] = [0.9, 1.7, 2.8, 4.2].map((L) => { const F = new Builder(); for (const x of xs) { F.box(x, y, z0 - L / 2, 0.2, 0.2, L, hex(0xff5a14), 1); F.box(x, y, z0 - L * 0.42, 0.11, 0.11, L * 0.85, hex(0xffc83a), 1); F.box(x, y, z0 - L * 0.25, 0.06, 0.06, L * 0.5, hex(0xfff6d0), 1); } return F.mesh(gl); }); }
  }
  if (!CARS[carId] || (CARS[carId].hidden && !isStaff) || !owned(carId)) carId = 'lambo';
  ensure(carId);
  const aiOf = { lambo: buildSuper(gl, 'lambo', false), ferrari: buildSuper(gl, 'ferrari', false), bugatti: buildSuper(gl, 'bugatti', false) };
  const aiList = [aiOf.ferrari, aiOf.bugatti, aiOf.lambo];

  const N = tr.N, P = tr.pts, T = tr.T, Nm = tr.Nm;
  const CPN = 12, cpAt = (k) => Math.floor((k % CPN) * N / CPN);
  const gate = (i, col, e) => { const B = new Builder(), yaw = Math.atan2(T[i][0], T[i][1]), x = P[i][0], z = P[i][1], o = HALF - 0.4;
    for (const sg of [-1, 1]) B.box(x + Nm[i][0] * o * sg, 7, z + Nm[i][1] * o * sg, 1, 14, 1, col, e, yaw);
    B.box(x, 14, z, o * 2 + 1, 1.2, 1, col, e, yaw); B.box(x, 12.9, z, o * 2, 0.2, 0.3, hex(0xffffff), e, yaw); return B.mesh(gl); };
  const gatesDim = [], gatesLit = []; for (let k = 0; k < CPN; k++) { gatesDim.push(gate(cpAt(k), hex(0x2a5a6e), 0.6)); gatesLit.push(gate(cpAt(k), hex(0xffd24a), 1)); }
  const car = { x: P[0][0], z: P[0][1], yaw: Math.atan2(T[0][0], T[0][1]), vx: 0, vz: 0, steer: 0, roll: 0, idx: 0, nit: 1, shake: 0, fire: 0, alt: 0, vy: 0, rpm: 1000, gear: 1, thr: 0 };
  const ai = Array.from({ length: 0 }, (_, k) => ({ s: (k + 1) * (N / 10), v: 16 + (k % 4) * 5, off: k % 2 ? 4.2 : -4.2, mesh: aiList[k % 3], x: 0, z: 0, yaw: 0 }));
  let lapN = 1, lapT = 0, bestLap = best(), nextCp = 1, lastIdx = 0, smoothFov = 1.0, driftScore = 0, driftHold = 0, camAng = car.yaw;
  const C = () => CARS[carId];
  const reset = () => { const i = car.idx; car.x = P[i][0]; car.z = P[i][1]; car.yaw = Math.atan2(T[i][0], T[i][1]); car.vx = car.vz = 0; };

  function nearest() {
    let bi = car.idx, bd = 1e12; for (let o = -30; o <= 30; o++) { const i = (car.idx + o + N) % N; const dx = car.x - P[i][0], dz = car.z - P[i][1], d = dx * dx + dz * dz; if (d < bd) { bd = d; bi = i; } }
    return bi;
  }

  function step(dt) {
    const c = C(); const up = keys.has('up'), dn = keys.has('down'), L = keys.has('left'), Rr = keys.has('right'), hb = keys.has('space'), nit = keys.has('nitro');
    const fx = Math.sin(car.yaw), fz = Math.cos(car.yaw), lx = Math.cos(car.yaw), lz = -Math.sin(car.yaw);
    let vf = car.vx * fx + car.vz * fz, vl = car.vx * lx + car.vz * lz;
    const useNit = nit && car.nit > 0.02 && vf > 5;
    car.fire = Math.max(0, car.fire - dt * 2.5); if (useNit) car.fire = Math.max(car.fire, 0.75);
    const top = c.maxV + (useNit ? c.nitro : 0);
    const launch = vf < 12 ? 1.25 : 1;   // strong launch off the line
    const hy = c.hyper || 0;   // the staff car's thrust grows with speed so it can reach 100,000 km/h
    if (up) vf += ((useNit ? c.accel * 1.5 : c.accel) + hy * Math.max(0, vf)) * launch * dt * (1 - Math.max(0, vf) / (top + 6)); else vf -= Math.sign(vf) * Math.min(Math.abs(vf), (6 + hy * Math.abs(vf) * 0.6) * dt);
    if (dn) vf -= ((vf > 0.5 ? 62 + hy * vf * 3 : 16)) * dt;
    vf = clamp(vf, -16, top);
    car.nit = isStaff ? 1 : clamp(car.nit + (useNit ? -0.26 : 0.05) * dt, 0, 1);   // staff have unlimited nitro
    if (flying) { flew = true; car.vy += ((keys.has('fup') ? 1 : 0) - (keys.has('fdown') ? 1 : 0)) * 90 * dt; car.vy *= Math.exp(-2.2 * dt); car.alt = clamp(car.alt + car.vy * dt, 0, 400); if (car.alt === 0 && car.vy < 0) car.vy = 0; }
    else { car.vy -= 45 * dt; car.alt = Math.max(0, car.alt + car.vy * dt); if (car.alt === 0) car.vy = 0; }
    const slip = Math.abs(vl); const grip = hb ? 1.5 : c.grip * (slip > 9 ? 0.75 : 1); vl *= Math.exp(-grip * dt);
    const want = (L ? 1 : 0) - (Rr ? 1 : 0); car.steer += (want - car.steer) * Math.min(1, dt * 7);
    const sp = Math.abs(vf);
    const turn = car.steer * c.steer * (hb ? 1.5 : 1) * clamp(sp / 12, 0, 1) * (1 - clamp(sp / 190, 0, 0.5)) * (vf >= 0 ? 1 : -1);
    car.yaw += turn * dt * 1.55;
    if (sp > 300) { const j0 = car.idx, ty = Math.atan2(T[j0][0], T[j0][1]) + want * 0.06; let dy = ty - car.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); car.yaw += dy * Math.min(1, dt * 7); vl *= Math.exp(-30 * dt); }   // lane-keeping so the road can be followed at crazy speed
    const nfx = Math.sin(car.yaw), nfz = Math.cos(car.yaw), nlx = Math.cos(car.yaw), nlz = -Math.sin(car.yaw);
    car.vx = nfx * vf + nlx * vl; car.vz = nfz * vf + nlz * vl;
    car.x += car.vx * dt; car.z += car.vz * dt;
    // walls
    const i = nearest(); car.idx = i;
    const dx = car.x - P[i][0], dz = car.z - P[i][1], d = dx * Nm[i][0] + dz * Nm[i][1], lim = HALF - 1.5;
    if (Math.abs(d) > lim) {
      const sgn = Math.sign(d), over = Math.abs(d) - lim; car.x -= Nm[i][0] * sgn * over; car.z -= Nm[i][1] * sgn * over;
      const vn = car.vx * Nm[i][0] + car.vz * Nm[i][1];
      if (vn * sgn > 0 && flying) { car.vx -= Nm[i][0] * vn; car.vz -= Nm[i][1] * vn; }   // flying cars just slide along the edge of the track corridor
      else if (vn * sgn > 0) { car.vx -= Nm[i][0] * vn * 1.3; car.vz -= Nm[i][1] * vn * 1.3; car.vx *= 0.95; car.vz *= 0.95; car.shake = Math.min(1, Math.abs(vn) / 16); if (eng) { eng.tone(90, 0.1, 0.12); eng.pop(0.18); } }   // scrape along the wall and lose a little speed
    }
    // traffic
    for (const a of ai) {
      { let df = ((a.s - car.idx) % N + N) % N; if (df > N / 2) df -= N; if (df > 650 || df < -250) { a.s = (car.idx + 90 + Math.random() * 520) % N; a.v = 18 + Math.random() * 30; } }
      a.s = (a.s + a.v * dt / tr.step) % N; const j = Math.floor(a.s) % N, k = (j + 1) % N, f = a.s - Math.floor(a.s);
      a.x = P[j][0] + (P[k][0] - P[j][0]) * f + Nm[j][0] * a.off; a.z = P[j][1] + (P[k][1] - P[j][1]) * f + Nm[j][1] * a.off; a.yaw = Math.atan2(T[j][0], T[j][1]);
      const ex = car.x - a.x, ez = car.z - a.z, dist = Math.hypot(ex, ez);
      if (dist < 3.6) { const nx = ex / (dist || 1), nz = ez / (dist || 1); car.x += nx * (3.6 - dist); car.z += nz * (3.6 - dist); car.vx *= 0.72; car.vz *= 0.72; car.vx += nx * 4; car.vz += nz * 4; car.shake = 0.7; if (eng) eng.tone(140, 0.12, 0.12); }
    }
    const speed = Math.hypot(car.vx, car.vz); moved += speed * dt;
    car.roll += ((-car.steer * speed / 650) - car.roll) * Math.min(1, dt * 6);
    car.shake *= Math.exp(-dt * 6);
    // drift score: sliding sideways at speed
    if (Math.abs(vl) > 5 && speed > 18 && Math.abs(d) < lim) { driftScore += Math.abs(vl) * speed * dt * 0.06; driftHold = 0.8; } else { driftHold -= dt; if (driftHold <= 0 && driftScore > 0) { if (driftScore > 60) pop('Drift ' + Math.round(driftScore)); driftScore = 0; } }
    driftEl.textContent = flying || car.alt > 1 ? 'FLYING ' + Math.round(car.alt) + ' m' : driftScore > 20 ? 'Drift ' + Math.round(driftScore) : '';
    // gearbox + rpm (V12: idles near 1000 and sings to ~8800)
    const GG = c.gears === 10 ? GEARS10 : GEARS, vtop = c.maxV + c.nitro; let g = 0; while (g < GG.length - 1 && speed > GG[g] * vtop * 0.985) g++;
    if (g !== car.gear - 1) { const up2 = g > car.gear - 1; car.gear = g + 1; if (eng && up2 && up) eng.pop(0.12); if (up2 && car.gear >= 5) { car.fire = 1; if (eng) { eng.pop(0.32); setTimeout(() => eng && eng.pop(0.22), 70); } } }
    const lo = g ? GG[g - 1] * vtop : 0, hi = GG[g] * vtop;
    const target = (speed < 0.5 && !up) ? 1000 : 1900 + clamp((speed - lo * 0.7) / (hi - lo * 0.7), 0, 1) * 6900;
    const was = car.rpm; car.rpm += ((up || speed > 3 ? target : 1000) - car.rpm) * Math.min(1, dt * (up ? 9 : 5)); car.thr += ((up ? 1 : 0) - car.thr) * Math.min(1, dt * 8);
    if (!up && car.gear >= 5 && was > 4500 && car.rpm < was - 40) { car.fire = Math.max(car.fire, 0.85); if (eng && Math.random() < dt * 9) eng.pop(0.3); }   // afterfire when you lift off in 5th gear or higher
    if (eng && !up && was > 5500 && car.rpm < was - 40 && Math.random() < dt * 5) eng.pop(0.16);   // overrun crackle when you lift off
    // checkpoints: pass all gates in order, then the finish arch, to complete a lap
    { const t = cpAt(nextCp), cd = Math.min(Math.abs(i - t), N - Math.abs(i - t));
      if (cd <= 14 && Math.abs(d) < HALF + 2) {
        if (nextCp < CPN) { pop('Checkpoint ' + nextCp + ' / ' + (CPN - 1) + '   ' + lap(lapT)); if (eng) eng.tone(880, 0.12, 0.1); nextCp++; }
        else { const t2 = lapT; if (!bestLap || t2 < bestLap) { bestLap = t2; setBest(t2); bestEl.textContent = 'Best ' + lap(t2); } pop('Lap ' + lapN + ' done  ' + lap(t2)); if (eng) { eng.tone(660, 0.15, 0.1); setTimeout(() => eng && eng.tone(990, 0.2, 0.1), 140); } lapN++; lapT = 0; nextCp = 1; pendingLap = true; flew = false; if (pendingLap && sessionId) beat(); }
      } }
    lastIdx = i; lapT += dt;
  }

  // ---------- input ----------
  const map = { ArrowUp: 'up', w: 'up', W: 'up', ArrowDown: 'down', s: 'down', S: 'down', ArrowLeft: 'left', a: 'left', A: 'left', ArrowRight: 'right', d: 'right', D: 'right', ' ': 'space', Shift: 'nitro', e: 'fup', E: 'fup', q: 'fdown', Q: 'fdown' };
  function kd(e) {
    if (!root.isConnected || !started) return; const t = e.target; if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
    if (e.key in map) { keys.add(map[e.key]); lastInput = performance.now(); e.preventDefault(); }
    else if (e.key === 'n' || e.key === 'N') { mapOpen ? closeMap() : openMap(); } else if (e.key === 'Escape') closeMap(); else if (e.key === 'r' || e.key === 'R') reset(); else if ((e.key === 'f' || e.key === 'F') && (isStaff || C().fly)) { flying = !flying; if (flying) car.vy = 30; pop(flying ? 'Flight on' : 'Landing'); } else if (e.key === 'm' || e.key === 'M') { if (eng) eng.muted = !eng.muted; } else if (e.key === 'p' || e.key === 'P') togglePause();
  }
  function ku(e) { if (e.key in map) keys.delete(map[e.key]); }
  addEventListener('keydown', kd); addEventListener('keyup', ku);
  const togglePause = () => { paused = !paused; overlay.replaceChildren(); if (paused) { overlay.append(h('div', { class: 'gbox' }, h('h2', null, 'Paused'), h('p', { class: 'muted' }, 'No coins are earned while paused.'), h('button', { class: 'btn primary', type: 'button', onclick: togglePause }, 'Resume'))); overlay.classList.add('on'); } else overlay.classList.remove('on'); };
  const onVis = () => { if (document.hidden && started && !paused) togglePause(); };
  document.addEventListener('visibilitychange', onVis);

  // ---------- start screen with the car picker ----------
  const startBtn = h('button', { class: 'btn primary big', type: 'button' }, 'Start driving');
  const bar = (n) => h('i', { style: 'width:' + n * 14 + 'px' });
  const ORDER = ['lambo', 'ferrari', 'bugatti', 'tesla', 'royale'];
  const priceOf = (c) => (c.id === 'tesla' ? ((st && st.teslaPrice) || c.cost) : c.cost);
  const sortKey = (c) => (ORDER.includes(c.id) ? ORDER.indexOf(c.id) : 100 + (c.cost || 0));
  const picks = Object.values(CARS).filter((c) => !c.hidden || isStaff).sort((x, y) => sortKey(x) - sortKey(y)).map((c) => {
    const lock = h('small', { class: 'glock' }, c.cost ? (owned(c.id) ? 'Owned' : 'Unlock: ' + priceOf(c).toLocaleString('en-US') + ' Q') : '');
    const b = h('button', { type: 'button', class: 'gcar' + (c.id === carId ? ' on' : ''), 'aria-pressed': String(c.id === carId), dataset: { car: c.id } },
      h('div', { class: 'gsw', style: '--c1:' + css(c.body) + ';--c2:' + css(c.accent) + ';--c3:' + css(c.glow) }),
      h('b', null, (ORDER.includes(c.id) ? (ORDER.indexOf(c.id) + 1) + '  ' : '') + c.name), h('small', null, c.blurb), lock,
      h('div', { class: 'gbars' }, ['Speed', 'Handling', 'Launch'].map((n, k) => h('span', null, h('em', null, n), bar([c.bars[0], c.bars[1], c.bars[2]][k]), h('b', { style: 'font-size:.62rem;margin-left:4px' }, [c.bars[0], c.bars[1], c.bars[2]][k] * 20 + '%')))));
    b.addEventListener('click', () => pick(c.id)); b._lock = lock; return b;
  });
  async function unlock(id) {
    if (!state.me) { toast('Sign in to unlock this car.', 'error'); return false; }
    const cc = CARS[id], price = priceOf(cc); if (!confirm('Unlock the ' + cc.name + (cc.fly ? ' (it can fly)' : '') + ' for ' + price.toLocaleString('en-US') + ' Q Coins?')) return false;
    try { const r = await POST('/api/game/buy-car', { car: id }); showState(r); state.me.coins = r.balance; refreshHeader(); toast(cc.name + ' unlocked!', 'ok'); picks.forEach((b) => { if (b.dataset.car === id) b._lock.textContent = 'Owned'; }); return true; }
    catch (e) { toast(e.message || 'Could not unlock.', 'error'); return false; }
  }
  const pick = async (id) => { if (!CARS[id]) return; if (!owned(id)) { if (!(await unlock(id))) return; } ensure(id); carId = id; lsSet('qy_game_car', id); picks.forEach((b) => { const on = b.dataset.car === id; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); }); };
  overlay.classList.add('on');
  overlay.append(h('div', { class: 'gbox' }, h('h2', null, 'Choose your car'),
    h('div', { class: 'gpick' }, picks.filter((b) => ORDER.includes(b.dataset.car))),
    picks.some((b) => !ORDER.includes(b.dataset.car)) ? h('h3', { class: 'glux' }, 'Luxury garage: 900 to 10,000 km/h') : null,
    h('div', { class: 'gpick' }, picks.filter((b) => !ORDER.includes(b.dataset.car))),
    h('p', { class: 'muted small' }, state.me ? (st && st.enabled ? 'You earn ' + (st.lapCoins || 20) + ' Q Coins for every completed lap (about 40 minutes).' : 'Earning is off right now; free play.') : 'You can play as a guest. Sign in with a verified email to earn Q Coins.'),
    startBtn, !state.me ? h('p', { class: 'small' }, h('a', { href: '#/login' }, 'Sign in'), ' or ', h('a', { href: '#/register' }, 'create an account')) : null));
  startBtn.addEventListener('click', () => { started = true; overlay.classList.remove('on'); overlay.replaceChildren(); canvas.focus(); eng = makeEngine(false); if (eng && eng.ctx.state === 'suspended') eng.ctx.resume(); lastInput = performance.now(); restore(); beginEarning(); });
  const kp = (e) => { if (started || !root.isConnected) return; const k = { 1: 'lambo', 2: 'ferrari', 3: 'bugatti', 4: 'tesla', 5: isStaff ? 'royale' : null }[e.key]; if (k) pick(k); else if (e.key === 'Enter') startBtn.click(); };
  addEventListener('keydown', kp);

  // ---------- saved lap progress ----------
  const saveProg = () => { if (started) lsSet('qy_game_prog2', { idx: car.idx, nextCp, lapT, lapN }); };
  function restore() {
    const g = lsGet('qy_game_prog2', null); if (!g || !(g.idx >= 0 && g.idx < N)) return;
    car.idx = g.idx; reset(); nextCp = clamp(g.nextCp | 0, 1, CPN); lapT = Number(g.lapT) || 0; lapN = Math.max(1, g.lapN | 0); world.update(car.idx, 8); pop('Resumed your lap');
  }
  const progTimer = setInterval(() => { if (disposed) clearInterval(progTimer); else saveProg(); }, 4000);

  // ---------- minimaps: a rotating local radar, and a full map of the whole circuit ----------
  const mctx = mini.getContext('2d'), RAD = 900, k0 = 75 / RAD;
  const drawMini = () => {
    mctx.clearRect(0, 0, 150, 150); mctx.save(); mctx.beginPath(); mctx.arc(75, 75, 75, 0, 7); mctx.clip(); mctx.fillStyle = 'rgba(5,12,20,.6)'; mctx.fillRect(0, 0, 150, 150);
    const fx = Math.sin(car.yaw), fz = Math.cos(car.yaw), lx = Math.cos(car.yaw), lz = -Math.sin(car.yaw);
    const sp = (x, z) => { const dx = x - car.x, dz = z - car.z; return [75 - (dx * lx + dz * lz) * k0, 75 - (dx * fx + dz * fz) * k0]; };
    mctx.strokeStyle = '#00d5f2'; mctx.lineWidth = 4; mctx.lineJoin = 'round'; mctx.beginPath();
    for (let o = -240; o <= 240; o += 2) { const q = P[(car.idx + o + N) % N], [x, y] = sp(q[0], q[1]); o === -240 ? mctx.moveTo(x, y) : mctx.lineTo(x, y); } mctx.stroke();
    for (let k = 0; k < CPN; k++) { const q = P[cpAt(k)], [x, y] = sp(q[0], q[1]); if (Math.hypot(x - 75, y - 75) > 80) continue; mctx.fillStyle = k === nextCp % CPN ? '#ffd24a' : '#3b6c80'; mctx.beginPath(); mctx.arc(x, y, k === nextCp % CPN ? 6 : 4, 0, 7); mctx.fill(); }
    mctx.fillStyle = '#ff3fb4'; for (const a of ai) { const [x, y] = sp(a.x, a.z); mctx.fillRect(x - 2, y - 2, 4, 4); }
    mctx.fillStyle = '#fff'; mctx.beginPath(); mctx.moveTo(75, 66); mctx.lineTo(70, 82); mctx.lineTo(80, 82); mctx.closePath(); mctx.fill(); mctx.restore();
  };
  let minX = 1e9, maxX = -1e9, minZ = 1e9, maxZ = -1e9; for (const p of P) { minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minZ = Math.min(minZ, p[1]); maxZ = Math.max(maxZ, p[1]); }
  const fsx = Math.min(860 / (maxX - minX), 380 / (maxZ - minZ)), fx0 = (900 - (maxX - minX) * fsx) / 2, fz0 = (420 - (maxZ - minZ) * fsx) / 2, fmx = (x) => fx0 + (x - minX) * fsx, fmz = (z) => fz0 + (z - minZ) * fsx;
  const mc = mapCv.getContext('2d'); let mapOpen = false, mapPaused = false;
  const drawMap = () => {
    mc.clearRect(0, 0, 900, 420); mc.fillStyle = '#071019'; mc.fillRect(0, 0, 900, 420);
    mc.strokeStyle = 'rgba(255,255,255,.05)'; mc.lineWidth = 1; for (let g = 0; g <= 900; g += 90) { mc.beginPath(); mc.moveTo(g, 0); mc.lineTo(g, 420); mc.stroke(); } for (let g = 0; g <= 420; g += 70) { mc.beginPath(); mc.moveTo(0, g); mc.lineTo(900, g); mc.stroke(); }
    mc.lineJoin = 'round'; mc.strokeStyle = '#0b4f60'; mc.lineWidth = 9; mc.beginPath(); P.forEach((p, i) => { if (i % 4) return; i ? mc.lineTo(fmx(p[0]), fmz(p[1])) : mc.moveTo(fmx(p[0]), fmz(p[1])); }); mc.closePath(); mc.stroke();
    mc.strokeStyle = '#00d5f2'; mc.lineWidth = 3; mc.stroke();
    mc.strokeStyle = '#ffd24a'; mc.lineWidth = 5; mc.beginPath(); for (let i = 0; i <= car.idx; i += 4) { const p = P[i]; i ? mc.lineTo(fmx(p[0]), fmz(p[1])) : mc.moveTo(fmx(p[0]), fmz(p[1])); } mc.stroke();   // the part of the lap you have covered
    mc.font = 'bold 15px system-ui,sans-serif'; mc.textAlign = 'center'; mc.textBaseline = 'middle';
    for (let k = 0; k < CPN; k++) { const q = P[cpAt(k)], x = fmx(q[0]), y = fmz(q[1]), nxt = k === nextCp % CPN, done = k > 0 && k < nextCp; mc.fillStyle = nxt ? '#ffd24a' : done ? '#2ee59d' : '#3b6c80'; mc.beginPath(); mc.arc(x, y, nxt ? 15 : 12, 0, 7); mc.fill(); mc.fillStyle = '#04101a'; mc.fillText(k === 0 ? 'S' : String(k), x, y + 1); }
    const cx = fmx(car.x), cy = fmz(car.z); mc.save(); mc.translate(cx, cy); mc.rotate(Math.PI - car.yaw); mc.fillStyle = '#ffffff'; mc.strokeStyle = '#ff3fb4'; mc.lineWidth = 3; mc.beginPath(); mc.moveTo(0, -13); mc.lineTo(-9, 10); mc.lineTo(9, 10); mc.closePath(); mc.fill(); mc.stroke(); mc.restore();
    mc.fillStyle = '#9fb4c8'; mc.textAlign = 'left'; mc.font = '13px system-ui,sans-serif'; const bar = 5000 * fsx; mc.fillRect(24, 396, bar, 3); mc.fillText('5 km', 24 + bar + 8, 398);
    const left = (cpAt(nextCp % CPN) - car.idx + N) % N * tr.step;
    mapInfo.textContent = 'Lap ' + lapN + ': ' + Math.round(car.idx / N * 100) + '% done (' + (car.idx * tr.step / 1000).toFixed(1) + ' of ' + (tr.length / 1000).toFixed(1) + ' km). Next: ' + (nextCp < CPN ? 'checkpoint ' + nextCp : 'the finish arch') + ', ' + (left / 1000).toFixed(1) + ' km ahead. Yellow = covered, green = checkpoints passed.';
  };
  function openMap() { if (mapOpen) return; mapOpen = true; mapFs.classList.add('on'); if (started && !paused) { paused = true; mapPaused = true; } drawMap(); }
  function closeMap() { if (!mapOpen) return; mapOpen = false; mapFs.classList.remove('on'); if (mapPaused) { paused = false; mapPaused = false; } canvas.focus(); }

  // ---------- render loop ----------
  let last = performance.now(), hudT = 0;
  function frame(now) {
    if (disposed) return; if (!root.isConnected) { removeEventListener('keydown', kp); stopAll(); return; }
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (started && !paused) { const sp0 = Math.hypot(car.vx, car.vz), n = clamp(Math.ceil(sp0 * dt / 15), 1, 90); for (let k = 0; k < n; k++) step(dt / n); } else if (!started) car.yaw += dt * 0.35;
    if (eng) eng.update(car.rpm, car.thr, Math.hypot(car.vx, car.vz), paused);
    const asp = R.resize(); const speed = Math.hypot(car.vx, car.vz);
    // chase camera: eases toward the car's heading, and leans into slides
    let da = car.yaw - camAng; da = Math.atan2(Math.sin(da), Math.cos(da)); camAng += da * Math.min(1, dt * 6.5);
    const cfx = Math.sin(camAng), cfz = Math.cos(camAng), fx = Math.sin(car.yaw), fz = Math.cos(car.yaw);
    const back = Math.min(32, 9 + speed * 0.045), hgt = Math.min(12, 3.5 + speed * 0.012), sh = (car.shake * 0.25) + (speed > 60 ? Math.min(0.3, (speed - 60) * 0.0035) : 0);
    const cam = [car.x - cfx * back + (Math.random() - 0.5) * sh, hgt + car.alt * 0.85 + (Math.random() - 0.5) * sh, car.z - cfz * back + (Math.random() - 0.5) * sh];
    smoothFov += ((Math.min(1.45, 1 + speed / 190)) - smoothFov) * Math.min(1, dt * 4);
    const proj = m4.persp(0.98 * smoothFov, asp, 0.5, 4500), view = m4.lookAt(cam, [car.x + fx * 6, 1.3 + car.alt * 0.9, car.z + fz * 6]);
    R.begin(m4.mul(proj, view), cam, camAng, asp);
    world.update(car.idx, speed > 3000 ? 8 : speed > 120 ? 3 : 1); world.draw(R, cam[0], cam[2]);
    for (let k = 1; k < CPN; k++) if (k !== nextCp) R.draw(gatesDim[k]);
    R.draw(gatesLit[nextCp % CPN]);
    for (const a of ai) R.draw(a.mesh, m4.model(a.x, 0, a.z, a.yaw));
    if (car.alt < 2) R.draw(glowPad[carId], m4.model(car.x, 0, car.z, car.yaw, 0));
    if (car.fire > 0.05 && flames[carId]) { const fl = flames[carId], v = Math.min(fl.length - 1, Math.floor(car.fire * (fl.length - 0.01) * (0.6 + Math.random() * 0.5))); R.draw(fl[v], m4.model(car.x, car.alt, car.z, car.yaw, car.roll)); }
    if (car.alt > 1) R.draw(shadow, m4.model(car.x, 0, car.z, car.yaw, 0));
    R.draw(meshes[carId], m4.model(car.x, car.alt, car.z, car.yaw, car.roll));
    hudT += dt; if (hudT > 0.07) {
      hudT = 0; speedEl.textContent = Math.round(speed * 3.6); gearEl.textContent = speed < 0.5 ? 'N' : 'G' + car.gear; nitroBar.style.width = (car.nit * 100) + '%';
      pctEl.textContent = Math.round(car.idx / N * 100) + '% of lap'; if (mapOpen) drawMap(); lapEl.textContent = 'Lap ' + lapN; cpEl.textContent = nextCp < CPN ? 'Checkpoint ' + nextCp + ' / ' + (CPN - 1) : 'Go to the finish arch!'; timeEl.textContent = lap(lapT); drawMini();
      lines.style.opacity = String(clamp((speed - 45) / 40, 0, 0.9));
    }
  }
  world.update(0, 8);
  raf = requestAnimationFrame(frame);
  // hooks for the automated browser check (they do nothing for visitors)
  root.__game = { car, keys, get lapN() { return lapN; }, get sessionId() { return sessionId; }, beat, get moved() { return moved; }, get carId() { return carId; }, get nextCp() { return nextCp; }, get flying() { return flying; }, get hasRoyale() { return !!(isStaff && meshes.royale); }, P, cpAt, N, CPN };
  window.__qyGame = root.__game;
  return root;
}
