import { logoImg, emailPrompt, nameTag, h, state, GET, POST, DEL, lsGet, lsSet, toast, priceEl, fmt, flag, countryName, dt, dOnly, empty, errorBox, skeletonGrid, pill, statusPill, debounce, submitting, fieldErr, formData, modal, ApiError, can } from '../core.js';
import { icon } from '../icons.js';
import { showroom } from '../fx3d.js';
import { go, setQuery, cartItems, refreshHeader } from '../app.js';

const page = (title, ...kids) => { const d = h('div', { class: 'wrap block', dataset: { title } }, ...kids); return d; };
const ICONS_OK = { gaming: 1, phones: 1, royal: 1, budget: 1, lookalike: 1, giftcards: 1, tech: 1, home: 1, carry: 1, travel: 1 };
const CATS_ICON = { gaming: '🎮', phones: '📱', royal: '👑', budget: '💸', lookalike: '✨', giftcards: '🎁', tech: '🔌', home: '🏠', carry: '🎒', travel: '✈️' };

// ---------- local lists ----------
const recent = () => lsGet('qy_recent', []);
const addRecent = (id) => lsSet('qy_recent', [id, ...recent().filter((x) => x !== id)].slice(0, 12));
const cmp = () => lsGet('qy_compare', []);
export function toggleCompare(id) {
  let c = cmp(); if (c.includes(id)) c = c.filter((x) => x !== id); else { if (c.length >= 4) { toast('You can compare up to 4 items.', 'error'); return false; } c.push(id); }
  lsSet('qy_compare', c); toast(c.includes(id) ? 'Added to compare' : 'Removed from compare'); return true;
}
let wishIds = null;
async function wished() {
  if (!state.me) return new Set(lsGet('qy_wish', []));
  if (!wishIds) wishIds = new Set((((await GET('/api/wishlist')) || {}).products || []).map((p) => p.id));
  return wishIds;
}
async function toggleWish(id, btn) {
  const set = await wished(); const on = set.has(id);
  try {
    if (state.me) { if (on) await DEL('/api/wishlist/' + id); else await POST('/api/wishlist', { productId: id }); }
    else lsSet('qy_wish', on ? lsGet('qy_wish', []).filter((x) => x !== id) : [...lsGet('qy_wish', []), id]);
    on ? set.delete(id) : set.add(id); if (btn) btn.setAttribute('aria-pressed', String(!on));
    toast(on ? 'Removed from wishlist' : 'Saved to wishlist');
  } catch (e) { toast(e.message, 'error'); }
}
export function addToCart(p, qty = 1) {
  const c = cartItems(); const ex = c.find((i) => i.productId === p.id);
  if (ex) ex.quantity = Math.min(99, ex.quantity + qty); else c.push({ productId: p.id, sellerId: p.seller.id, quantity: qty });
  lsSet('qy_cart', c); window.dispatchEvent(new Event('qy:cart')); toast('Added to cart', 'ok');
}

// ---------- cards ----------
function shipsLabel(p) { return p.shipsTo.includes('WORLD') ? 'Ships worldwide' : 'Ships to ' + (p.shipsTo.length > 3 ? p.shipsTo.length + ' countries' : p.shipsTo.join(', ')); }
export async function productCard(p, set) {
  const wishSet = set || await wished();
  const img = p.images && p.images[0];
  const here = state.country && !p.shipsTo.includes('WORLD') && !p.shipsTo.includes(state.country);
  return h('article', { class: 'card' },
    h('a', { href: '#/p/' + p.id, 'aria-label': p.name }, img ? h('img', { class: 'card-img', src: img.url, alt: p.name, loading: 'lazy', width: 400, height: 300 }) : h('div', { class: 'ph' }, 'No photo')),
    h('button', { class: 'heart', 'aria-label': 'Save to wishlist', 'aria-pressed': String(wishSet.has(p.id)), onclick: (e) => toggleWish(p.id, e.currentTarget) }, '♥'),
    h('div', { class: 'body' },
      h('h3', null, h('a', { href: '#/p/' + p.id }, p.name)),
      p.payment && p.payment.coins ? h('div', { class: 'qbadge' }, h('i', null, 'Q'), p.payment.cash ? 'Cash or Q Coins' : 'Q Coins only') : null,
      h('div', { class: 'muted small' }, flag(p.sellerCountry) + ' ' + p.seller.shopName + ' · ' + (p.condition[0].toUpperCase() + p.condition.slice(1))),
      h('div', { class: 'pricetag' }, priceEl(p.price.minor, p.price.currency)),
      h('div', { class: 'small muted' }, p.shippingFee.minor ? '+ ' + fmt(p.shippingFee.minor, p.shippingFee.currency) + ' shipping' : 'Free shipping', ' · ', shipsLabel(p)),
      here ? h('div', { class: 'small', style: 'color:var(--warn)' }, 'Not listed for delivery to ' + countryName(state.country)) : null,
      h('div', { class: 'row', style: 'margin-top:auto;padding-top:8px' }, pill(p.photoReview.label, 'ok'), h('button', { class: 'btn small', onclick: () => toggleCompare(p.id) }, 'Compare'))));
}
async function grid(products) {
  const set = await wished();
  const cards = await Promise.all(products.map((p) => productCard(p, set)));
  return h('div', { class: 'grid' }, cards);
}
const noListings = () => empty('No listings here yet', 'Sellers are still joining. Every listing appears only after a moderator has reviewed its photos.', h('p', { style: 'margin-top:14px' }, h('a', { class: 'btn primary', href: '#/sell' }, 'Become a seller')));

// ---------- home ----------
export async function home() {
  const d = page('Quietly better');
  const [r, cats] = [await GET('/api/products?pageSize=8'), state.config.categories];
  const searchForm = h('form', { class: 'herosearch', role: 'search', onsubmit: (e) => { e.preventDefault(); const q = e.target.q.value.trim(); go('browse' + (q ? '?q=' + encodeURIComponent(q) : '')); } },
    icon('search', 20), h('input', { name: 'q', type: 'search', placeholder: 'Search phones, gaming, gift cards…', 'aria-label': 'Search listings' }), h('button', { class: 'btn primary', type: 'submit' }, 'Search'));
  d.append(h('section', { class: 'hero2' },
    h('div', { class: 'hero-copy' },
      h('h1', null, 'Buy and sell with people you can see.'),
      h('p', { class: 'lead' }, 'A worldwide marketplace where a person checks every listing’s photos before it goes live. Gaming, phones, luxury finds, gift cards and more.'),
      searchForm,
      h('div', { class: 'popular' }, h('span', null, 'Popular:'), [['Gaming', 'gaming'], ['Smartphones', 'phones'], ['Gift cards', 'giftcards'], ['Royal & luxury', 'royal']].map(([t, slug]) => h('a', { href: '#/browse?category=' + slug }, t))),
      h('div', { class: 'actions' }, h('a', { class: 'btn primary big', href: '#/browse' }, 'Browse the marketplace'), h('a', { class: 'btn big', href: '#/sell' }, 'Start selling free'))),
    h('div', { class: 'hero-art' }, h('a', { class: 'orb', href: '#/browse', 'aria-label': 'Browse the marketplace' }, logoImg('mark', { alt: 'QYRRAVO' })), h('div', { class: 'orbit' }, [['🎮', 'gaming', 'Gaming'], ['📱', 'phones', 'Smartphones'], ['👑', 'royal', 'Royal & Luxury'], ['🎁', 'giftcards', 'Gift cards'], ['⌚', 'lookalike', 'Looks expensive, costs less'], ['🎧', 'tech', 'Tech']].map(([e, slug, label], i) => h('span', { class: 'slot', style: '--a:' + (i * 60) + 'deg' }, h('a', { class: 'float f' + i, href: '#/browse?category=' + slug, title: label, 'aria-label': label, onclick: (ev) => { const el = ev.currentTarget; el.classList.add('boom'); setTimeout(() => el.classList.remove('boom'), 700); } }, e)))))));
  try { const ha = d.querySelector('.hero-art'); if (ha && window.WebGLRenderingContext) showroom(ha); } catch { /* keep the flat hero */ }
  d.append(h('section', { class: 'strip' }, [['camera', 'Photo-checked', 'A person reviews every listing'], ['globe', 'Every country', 'Pick your country and currency'], ['chat', 'Help 24/7', 'Ask the QYRRAVO assistant'], ['mail', 'Buy by email', 'Cash or card, arranged by email']].map(([i, t, s]) => h('div', { class: 'strip-i' }, icon(i, 24), h('div', null, h('b', null, t), h('span', null, s))))));
  d.append(h('section', { class: 'block' }, h('div', { class: 'sechead' }, h('h2', null, 'Shop by category'), h('a', { class: 'more', href: '#/browse' }, 'All listings ', icon('arrow', 16))), h('div', { class: 'cattiles' }, cats.map((c) => h('a', { class: 'cattile', href: '#/browse?category=' + c.slug }, h('span', { class: 'ci' }, icon(c.slug in ICONS_OK ? c.slug : 'tag', 26)), h('span', { class: 'cn' }, c.name))))));
  d.append(h('section', { class: 'block' }, h('div', { class: 'sechead' }, h('h2', null, 'Newest approved listings'), h('a', { class: 'more', href: '#/browse' }, 'See all ', icon('arrow', 16))), r.products.length ? await grid(r.products) : h('div', { class: 'firstlist' }, h('div', { class: 'fl-art' }, icon('camera', 38)), h('div', null, h('h3', null, 'The first listings are on their way'), h('p', { class: 'muted' }, 'Every item appears only after a moderator checks its photos. Be one of the first sellers and get seen first.'), h('div', { class: 'actions' }, h('a', { class: 'btn primary', href: '#/sell' }, 'List an item'), h('a', { class: 'btn', href: '#/game' }, 'Drive & earn Q'))))));
  d.append(h('section', { class: 'block how' }, h('h2', null, 'How QYRRAVO works'), h('div', { class: 'steps3' }, [['List it', 'Sellers add photos, a price and shipping details. Free for your first item up to $100.', 'tag'], ['A person checks it', 'You photograph the item next to a one-time code. A moderator reviews it before it goes live.', 'shield'], ['Buyers email you', 'Buyers press Buy and send a message. QYRRAVO confirms the address and arranges payment.', 'mail']].map(([t, s, i], n) => h('div', { class: 'step3' }, h('div', { class: 'sn' }, String(n + 1)), icon(i, 26), h('h3', null, t), h('p', { class: 'muted' }, s)))),
    h('p', { class: 'honest small muted' }, 'Photo review does not prove authenticity or ownership, and it is not an identity check. Read the seller’s returns terms and use tracked shipping.')));
  d.append(h('section', { class: 'block' }, h('div', { class: 'sechead' }, h('h2', null, 'Join the community')), h('div', { class: 'comm3' }, [['gift', 'Events & giveaways', 'Enter free giveaways. Winners can get a personal prize code.', '#/events'], ['vote', 'Community polls', 'Vote on what QYRRAVO adds next. The most votes win.', '#/polls'], ['ticket', 'Redeem a code', 'Turn a QYRRAVO code into Q Coins in your wallet.', '#/redeem'], ['car', 'Drive & earn Q', 'A free 3D driving game. Pick a Lamborghini, Ferrari or Bugatti. 1 lap = 20 Q Coins.', '#/game']].map(([i, t, s, href]) => h('a', { class: 'comm', href }, h('span', { class: 'comm-i' }, icon(i, 26)), h('h3', null, t), h('p', { class: 'muted' }, s), h('span', { class: 'go' }, 'Open ', icon('arrow', 16)))))));
  d.append(h('section', { class: 'cta' }, h('h2', null, 'Got something to sell?'), h('p', null, 'List your first item free, up to $100. Upgrade any time.'), h('a', { class: 'btn primary big', href: '#/sell' }, 'Start selling')));
  const rec = recent();
  if (rec.length) { const rr = await GET('/api/products?ids=' + rec.join(',')); if (rr.products.length) d.append(h('section', { class: 'block' }, h('h2', null, 'Recently viewed'), await grid(rr.products))); }
  return d;
}

// ---------- browse ----------
export async function browse({ query }) {
  const d = page('Marketplace');
  const q = { ...query }; const f = h('form', { class: 'filters', onsubmit: (e) => { e.preventDefault(); apply(); } });
  const sel = (name, opts, v) => h('select', { name }, opts.map(([val, t]) => h('option', { value: val, selected: String(v || '') === String(val) }, t)));
  f.append(h('h3', null, 'Filters'),
    h('label', null, 'Search'), h('input', { name: 'q', value: q.q || '', type: 'search' }),
    h('label', null, 'Category'), sel('category', [['', 'All categories'], ...state.config.categories.map((c) => [c.slug, c.name])], q.category),
    h('label', null, 'Condition'), sel('condition', [['', 'Any'], ['new', 'New'], ['used', 'Used'], ['refurbished', 'Refurbished']], q.condition),
    h('label', null, 'Price in USD (min – max)'), h('div', { class: 'row' }, h('input', { name: 'min', type: 'number', min: 0, value: q.min || '', placeholder: 'Min', style: 'width:48%' }), h('input', { name: 'max', type: 'number', min: 0, value: q.max || '', placeholder: 'Max', style: 'width:48%' })),
    h('label', null, 'Delivers to'), sel('shipsTo', [['', 'Anywhere'], ...state.config.countries.map((c) => [c.code, c.name])], q.shipsTo === undefined ? (state.country || '') : q.shipsTo),
    h('label', null, 'Seller country'), sel('sellerCountry', [['', 'Any'], ...state.config.countries.map((c) => [c.code, c.name])], q.sellerCountry),
    h('label', null, 'Sort'), sel('sort', [['newest', 'Newest'], ['price_asc', 'Price: low to high'], ['price_desc', 'Price: high to low']], q.sort),
    h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'inStock', value: '1', checked: q.inStock === '1' }), 'In stock only'),
    h('button', { class: 'btn primary', type: 'submit', style: 'width:100%' }, 'Apply'), h('a', { class: 'btn', href: '#/browse', style: 'width:100%;margin-top:8px' }, 'Reset'));
  const out = h('div', { 'aria-live': 'polite' });
  function apply() { const o = formData(f); if (!f.inStock.checked) delete o.inStock; if (o.shipsTo === '') o.shipsTo = ''; go('browse?' + new URLSearchParams(Object.entries(o).filter(([k, v]) => v !== '' || k === 'shipsTo')).toString()); }
  async function run() {
    out.replaceChildren(skeletonGrid(6));
    const o = { ...q }; if (o.shipsTo === undefined && state.country) o.shipsTo = state.country; if (o.shipsTo === '') delete o.shipsTo;
    try {
      const r = await GET('/api/products?' + new URLSearchParams(o).toString());
      const pg = r.page, pages = Math.max(1, Math.ceil(r.total / r.pageSize));
      out.replaceChildren(h('p', { class: 'muted' }, r.total + ' listing' + (r.total === 1 ? '' : 's') + (o.shipsTo ? ' that deliver to ' + countryName(o.shipsTo) : '')),
        r.products.length ? await grid(r.products) : empty('Nothing matches', 'Try fewer filters' + (o.shipsTo ? ' or choose “Anywhere” in “Delivers to”.' : '.')),
        pages > 1 ? h('div', { class: 'row', style: 'margin-top:18px;justify-content:center' }, h('button', { class: 'btn', disabled: pg <= 1, onclick: () => go('browse?' + new URLSearchParams({ ...q, page: pg - 1 })) }, '← Previous'), h('span', { class: 'muted' }, 'Page ' + pg + ' of ' + pages), h('button', { class: 'btn', disabled: pg >= pages, onclick: () => go('browse?' + new URLSearchParams({ ...q, page: pg + 1 })) }, 'Next →')) : null);
    } catch (e) { out.replaceChildren(errorBox(e, run)); }
  }
  d.append(h('h1', null, 'Marketplace'), h('div', { class: 'layout' }, window.matchMedia('(max-width:860px)').matches ? h('details', { class: 'fdetails' }, h('summary', null, icon('search', 18), ' Filters and sorting'), f) : f, out)); run();
  return d;
}

// ---------- product ----------
export async function product({ params }) {
  const id = +params[0];
  let p;
  try { p = (await GET('/api/products/' + id)).product; } catch (e) { if (e.status === 404) return page('Not available', h('h1', null, 'Listing not available'), h('p', { class: 'muted' }, 'It may have been sold, removed or is still being reviewed.'), h('a', { class: 'btn', href: '#/browse' }, 'Back to the marketplace')); throw e; }
  addRecent(p.id);
  const d = page(p.name);
  const main = h('img', { class: 'main', src: p.images[0] ? p.images[0].url : '', alt: p.name });
  const gal = h('div', { class: 'gallery' }, p.images.length ? main : h('div', { class: 'ph main' }, 'No photo'), p.images.length > 1 ? h('div', { class: 'thumbs' }, p.images.map((i) => h('img', { src: i.url, alt: 'Photo of ' + p.name, loading: 'lazy', onclick: () => { main.src = i.url; } }))) : null);
  let qty = 1;
  const qtyIn = h('input', { type: 'number', min: 1, max: Math.min(99, p.quantityAvailable), value: 1, style: 'width:90px', 'aria-label': 'Quantity', oninput: (e) => { qty = Math.max(1, Math.min(+e.target.value || 1, p.quantityAvailable)); } });
  const ship = p.shipsTo.includes('WORLD') || !state.country || p.shipsTo.includes(state.country);
  const rt = { returns_accepted: 'Returns accepted' + (p.returns.days ? ' within ' + p.returns.days + ' days' : ''), exchange_only: 'Exchange only', no_returns: 'No returns (your legal rights still apply)' }[p.returns.type];
  d.append(h('p', { class: 'muted small' }, h('a', { href: '#/browse' }, 'Marketplace'), ' › ', h('a', { href: '#/browse?category=' + p.category.slug }, p.category.name)),
    h('div', { class: 'two' }, gal, h('div', null,
      h('h1', null, p.name), h('p', { class: 'muted' }, [p.brand, p.model].filter(Boolean).join(' · ')),
      h('div', { style: 'margin:14px 0', class: 'row' }, p.payment.cash ? h('span', { class: 'pricetag' }, priceEl(p.price.minor, p.price.currency, { size: 'lg' })) : h('span', { class: 'pricetag none' }, 'Not sold for cash'), p.payment.coins ? h('span', { class: 'pricetag coin' }, h('i', { class: 'qi' }, 'Q'), p.payment.coinPrice.toLocaleString('en-US') + ' Q Coins') : null),
      h('p', { class: 'muted' }, p.shippingFee.minor ? 'Shipping: ' + fmt(p.shippingFee.minor, p.shippingFee.currency) : 'Free shipping', ' · dispatch within ' + p.dispatchDays + ' day(s) · ' + shipsLabel(p)),
      !ship ? h('div', { class: 'notice warn' }, 'This seller has not listed delivery to ' + countryName(state.country) + '. Check “Ships to” below.') : null,
      h('div', { class: 'row', style: 'margin:14px 0' }, emailOnly() ? [h('label', { class: 'muted', style: 'margin:0' }, 'Qty'), qtyIn, h('button', { class: 'btn primary', onclick: () => emailBuy([{ id: p.id, name: p.name, qty, price: fmt(p.price.minor * qty, p.price.currency), seller: p.seller.shopName }]) }, 'Buy this item'), h('button', { class: 'btn', onclick: () => addToCart(p, qty) }, 'Add to cart')] : p.buyable ? [h('label', { class: 'muted', style: 'margin:0' }, 'Qty'), qtyIn, h('button', { class: 'btn primary', onclick: () => addToCart(p, qty) }, 'Add to cart'), h('button', { class: 'btn', onclick: () => { addToCart(p, qty); go('cart'); } }, 'Buy now')] : h('div', { class: 'notice warn' }, 'This item cannot be bought right now (the seller has not finished payment set-up, or it is out of stock).')),
      h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: (e) => toggleWish(p.id, e.currentTarget) }, '♡ Wishlist'), h('button', { class: 'btn small', onclick: () => toggleCompare(p.id) }, 'Compare'), h('button', { class: 'btn small', onclick: () => reportDialog('product', p.id) }, 'Report listing')),
      h('div', { class: 'panel' }, h('dl', { class: 'kv' }, h('dt', null, 'Condition'), h('dd', null, p.condition), h('dt', null, 'In stock'), h('dd', null, p.quantityAvailable), h('dt', null, 'Seller'), h('dd', null, h('a', { href: '#/s/' + p.seller.id }, nameTag(p.seller.shopName)), ' ' + flag(p.sellerCountry) + ' ' + countryName(p.sellerCountry)), h('dt', null, 'Ships to'), h('dd', null, p.shipsTo.includes('WORLD') ? 'Worldwide' : p.shipsTo.map(countryName).join(', ')), h('dt', null, 'Returns'), h('dd', null, rt, p.returns.notes ? ' — ' + p.returns.notes : ''), p.referenceInfo ? [h('dt', null, 'Reference'), h('dd', null, p.referenceInfo)] : null)),
      h('div', { class: 'notice' }, h('strong', null, p.photoReview.label + '. '), p.photoReview.note, ' See ', h('a', { href: '#/legal/photo-verification' }, 'how it works'), '.'))),
    h('section', { class: 'block' }, h('h2', null, 'Description'), h('p', { style: 'white-space:pre-wrap;max-width:75ch' }, p.description), p.specs.length ? h('table', { style: 'max-width:640px;margin-top:14px' }, h('tbody', null, p.specs.map((s) => h('tr', null, h('th', null, s.k), h('td', null, s.v))))) : null, p.shippingNotes ? h('p', { class: 'muted', style: 'margin-top:10px' }, 'Shipping notes: ' + p.shippingNotes) : null));
  return d;
}
function reportDialog(type, id) {
  if (!state.me) { toast('Sign in to report a listing.'); go('login?next=' + encodeURIComponent(location.hash.slice(2))); return; }
  const f = h('form', { onsubmit: async (e) => { e.preventDefault(); await submitting(f.querySelector('button.primary'), async () => { try { await POST('/api/reports', { targetType: type, targetId: id, ...formData(f) }); m.close(); toast('Thanks. A moderator will look at it.', 'ok'); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); } },
    h('label', null, 'Reason'), h('select', { name: 'reason' }, ['Counterfeit or fake', 'Prohibited item', 'Misleading photos or description', 'Scam or suspicious seller', 'Other'].map((r) => h('option', { value: r }, r))),
    h('label', null, 'Details (optional)'), h('textarea', { name: 'details', maxlength: 1000 }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Send report')));
  const m = modal('Report this ' + type, f);
}

// ---------- seller page ----------
export async function sellerPage({ params }) {
  const r = await GET('/api/sellers/' + params[0]); const s = r.seller;
  const d = page(s.shopName);
  d.append(h('h1', null, nameTag(s.shopName)), h('p', { class: 'muted' }, flag(s.country) + ' ' + countryName(s.country) + ' · joined ' + dOnly(s.joinedAt) + ' · ' + s.photoReviewedListings + ' photo-reviewed listing(s)'), s.bio ? h('p', { style: 'max-width:70ch;margin:10px 0' }, s.bio) : null,
    h('div', { class: 'notice' }, s.verification.note), h('button', { class: 'btn small', onclick: () => reportDialog('seller', s.id) }, 'Report seller'), h('h2', { style: 'margin-top:22px' }, 'Listings'), r.products.length ? await grid(r.products) : empty('No live listings', 'This seller has nothing approved right now.'));
  return d;
}

// ---------- buying by email ----------
const emailOnly = () => true; // payment is money only, arranged by email
async function emailBuy(lines) {
  if (!state.me) { toast('Please sign in to buy.'); go('login?next=' + encodeURIComponent(location.hash.slice(2))); return; }
  let pay = { cash: true, coins: false, total: 0, balance: 0 };
  try {
    const ps = (await GET('/api/products?ids=' + lines.map((l) => l.id).join(','))).products; const by = Object.fromEntries(ps.map((x) => [x.id, x]));
    const all = lines.map((l) => by[l.id]).filter(Boolean);
    pay.cash = all.every((x) => x.payment.cash);
    pay.coins = all.length === lines.length && all.every((x) => x.payment.coins) && new Set(all.map((x) => x.seller.id)).size === 1;
    pay.total = lines.reduce((a, l) => { const x = by[l.id]; return a + (x ? x.payment.coinPrice * l.qty + x.payment.shippingCoins : 0); }, 0);
    if (pay.coins) pay.balance = (await GET('/api/wallet')).coins;
    if (!pay.cash && !pay.coins) { toast('These items cannot be paid together. Buy them one seller at a time.', 'error'); return; }
  } catch { /* fall back to cash */ }
  emailBuyForm(lines, pay);
}
function emailBuyForm(lines, pay) {
  // lines: [{ id, name, qty, price, seller }]. Step 1: ONE contact (phone or email) + a confirmed address. Step 2: the ready-to-send Gmail message.
  const f = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    await submitting(f.querySelector('button.primary'), async () => {
      try {
        const kind = f.kind.value;
        const r = await POST('/api/purchase-requests', { items: lines.map((l) => ({ productId: l.id, quantity: l.qty })), contactKind: kind, paymentMethod: f.pay ? f.pay.value : 'cash', contactValue: f.contact.value, name: f.name.value, line1: f.line1.value, line2: f.line2.value, city: f.city.value, region: f.region.value, postal: f.postal.value, country: f.country.value, confirmAddress: f.confirm.checked });
        m.close();
        if (r.paymentMethod === 'coins') { modal('Order placed', h('div', null, h('p', null, h('strong', null, r.coins.toLocaleString('en-US') + ' Q Coins'), ' are now on hold for request #' + r.id + '.'), h('p', { class: 'muted' }, 'QYRRAVO will verify your address and contact you. The seller is paid only after delivery is confirmed. If the order is cancelled, your coins come back.'), h('div', { class: 'actions' }, h('a', { class: 'btn primary', href: '#/redeem' }, 'See my wallet')))); return; }
        
        const addr = [f.name.value, f.line1.value, f.line2.value, f.city.value, f.region.value, f.postal.value, f.country.selectedOptions[0].text].filter(Boolean).join(', ');
        emailPrompt({ title: 'Send your request', intro: 'Your request #' + r.id + ' is saved. Now send this email to ', subject: 'Purchase request #' + r.id, body: 'I would like to buy:\n' + r.summary + '\n\n' + (kind === 'phone' ? 'My phone: ' : 'My contact email: ') + f.contact.value + '\nDelivery address: ' + addr + '\n\nPlease verify my address and tell me the next steps (how to pay, and delivery).' });
      } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); }
    });
  } },
    h('div', { class: 'panel' }, lines.map((l) => h('div', { class: 'row between small' }, h('span', null, l.name + ' × ' + l.qty), h('strong', null, l.price)))),
    pay.coins ? h('div', { class: 'panel paysel' }, h('h3', null, 'How do you want to pay?'),
      h('div', { class: 'seg' }, pay.cash ? h('label', null, h('input', { type: 'radio', name: 'pay', value: 'cash', checked: true }), ' 💵 Cash') : null, h('label', null, h('input', { type: 'radio', name: 'pay', value: 'coins', checked: !pay.cash }), ' Ⓠ Q Coins')),
      h('p', { class: 'small' + (pay.balance < pay.total ? ' bad-t' : ' muted') }, 'Q Coins price: ', h('b', null, pay.total.toLocaleString('en-US')), ' · your wallet: ', h('b', null, pay.balance.toLocaleString('en-US')), pay.balance < pay.total ? ' · not enough yet. ' : ' · held until delivery is confirmed.', pay.balance < pay.total ? h('a', { href: '#/redeem', onclick: () => m.close() }, 'Redeem a code') : null)) : null,
    h('h3', null, 'How can we reach you?'), h('p', { class: 'muted small' }, 'Give ONE: a phone number or an email address.'),
    h('div', { class: 'seg' }, h('label', null, h('input', { type: 'radio', name: 'kind', value: 'phone', checked: true }), ' Phone'), h('label', null, h('input', { type: 'radio', name: 'kind', value: 'email' }), ' Email')),
    h('input', { name: 'contact', placeholder: '+974 5xxx xxxx or name@gmail.com', autocomplete: 'tel', required: true }),
    h('h3', { style: 'margin-top:14px' }, 'Delivery address'),
    h('input', { name: 'name', placeholder: 'Full name', autocomplete: 'name', value: state.me.displayName.replace(/ ?👑/, ''), required: true }),
    h('input', { name: 'line1', placeholder: 'Street, building, apartment', autocomplete: 'address-line1', required: true }), h('input', { name: 'line2', placeholder: 'Address line 2 (optional)' }),
    h('div', { class: 'two' }, h('input', { name: 'city', placeholder: 'City', autocomplete: 'address-level2', required: true }), h('input', { name: 'region', placeholder: 'Region (optional)' })),
    h('div', { class: 'two' }, h('input', { name: 'postal', placeholder: 'Postal code (optional)' }), h('select', { name: 'country', style: 'max-width:none;width:100%' }, state.config.countries.map((c) => h('option', { value: c.code, selected: c.code === (state.country || state.me.country) }, c.name)))),
    h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'confirm' }), h('span', null, 'I checked that my address is correct. QYRRAVO will verify it with me before anything is sent.')),
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Continue')));
  const m = modal('Buy: delivery details', f, { wide: true });
  f.kind.forEach && f.kind.forEach((r) => r.addEventListener('change', () => { f.contact.placeholder = r.value === 'phone' ? '+974 5xxx xxxx' : 'name@gmail.com'; f.contact.autocomplete = r.value === 'phone' ? 'tel' : 'email'; }));
}


// ---------- compare / wishlist ----------
export async function compare() {
  const d = page('Compare'); const ids = cmp();
  d.append(h('h1', null, 'Compare'));
  if (!ids.length) { d.append(empty('Nothing to compare', 'Press “Compare” on up to 4 listings.', h('a', { class: 'btn', href: '#/browse' }, 'Browse listings'))); return d; }
  const ps = (await GET('/api/products?ids=' + ids.join(','))).products;
  const rows = [['Price', (p) => priceEl(p.price.minor, p.price.currency)], ['Shipping', (p) => p.shippingFee.minor ? fmt(p.shippingFee.minor, p.shippingFee.currency) : 'Free'], ['Condition', (p) => p.condition], ['Seller', (p) => p.seller.shopName], ['Ships from', (p) => countryName(p.sellerCountry)], ['Dispatch', (p) => p.dispatchDays + ' day(s)'], ['Returns', (p) => p.returns.type.replace(/_/g, ' ')], ['In stock', (p) => p.quantityAvailable]];
  d.append(h('div', { class: 'scroll-x' }, h('table', null, h('thead', null, h('tr', null, h('th'), ps.map((p) => h('th', null, h('a', { href: '#/p/' + p.id }, p.name), h('div', null, h('button', { class: 'btn small', onclick: () => { toggleCompare(p.id); compare().then((n) => d.replaceWith(n)); } }, 'Remove')))))), h('tbody', null, rows.map(([l, f]) => h('tr', null, h('th', null, l), ps.map((p) => h('td', null, f(p)))))))));
  return d;
}
export async function wishlist() {
  const d = page('Wishlist'); d.append(h('h1', null, 'Wishlist'));
  let ps;
  if (state.me) ps = (await GET('/api/wishlist')).products; else { const ids = lsGet('qy_wish', []); ps = ids.length ? (await GET('/api/products?ids=' + ids.join(','))).products : []; d.append(h('p', { class: 'muted' }, 'Saved on this device. ', h('a', { href: '#/login?next=wishlist' }, 'Sign in'), ' to keep it across devices.')); }
  d.append(ps.length ? await grid(ps) : empty('Your wishlist is empty', 'Tap the heart on any listing.', h('a', { class: 'btn', href: '#/browse' }, 'Browse listings')));
  return d;
}

// ---------- cart ----------
export async function cart() {
  const d = page('Cart'); d.append(h('h1', null, 'Cart'));
  let items = cartItems();
  if (!items.length) { d.append(empty('Your cart is empty', null, h('a', { class: 'btn', href: '#/browse' }, 'Browse listings'))); return d; }
  const ps = (await GET('/api/products?ids=' + items.map((i) => i.productId).join(','))).products; const by = Object.fromEntries(ps.map((p) => [p.id, p]));
  items = items.filter((i) => by[i.productId]); lsSet('qy_cart', items);
  const sellers = [...new Set(items.map((i) => by[i.productId].seller.id))];
  d.append(h('div', { class: 'notice' }, 'Items from different sellers are requested separately, one seller at a time. Payment is arranged by email.'));
  for (const sid of sellers) {
    const mine = items.filter((i) => by[i.productId].seller.id === sid); const cur = by[mine[0].productId].price.currency;
    const same = mine.every((i) => by[i.productId].price.currency === cur);
    const sub = mine.reduce((a, i) => a + by[i.productId].price.minor * i.quantity, 0), shipT = mine.reduce((a, i) => a + by[i.productId].shippingFee.minor, 0);
    d.append(h('div', { class: 'panel' }, h('h3', null, 'From ', h('a', { href: '#/s/' + sid }, by[mine[0].productId].seller.shopName)),
      mine.map((i) => { const p = by[i.productId]; return h('div', { class: 'row between', style: 'padding:10px 0;border-bottom:1px solid var(--line)' }, h('div', { class: 'thumbrow' }, p.images[0] ? h('img', { src: p.images[0].url, alt: '' }) : null, h('div', null, h('a', { href: '#/p/' + p.id }, p.name), h('div', { class: 'small muted' }, fmt(p.price.minor, p.price.currency) + ' each'))), h('div', { class: 'row' }, h('input', { type: 'number', min: 1, max: Math.min(99, p.quantityAvailable), value: i.quantity, style: 'width:80px', 'aria-label': 'Quantity for ' + p.name, onchange: (e) => { i.quantity = Math.max(1, Math.min(+e.target.value || 1, p.quantityAvailable)); lsSet('qy_cart', cartItems().map((x) => x.productId === i.productId ? i : x)); window.dispatchEvent(new Event('qy:cart')); cart().then((n) => d.replaceWith(n)); } }), h('button', { class: 'btn small danger', onclick: () => { lsSet('qy_cart', cartItems().filter((x) => x.productId !== i.productId)); window.dispatchEvent(new Event('qy:cart')); cart().then((n) => d.replaceWith(n)); } }, 'Remove'))); }),
      same ? h('div', { class: 'row between', style: 'margin-top:12px' }, h('div', null, h('div', null, 'Items ', h('strong', null, fmt(sub, cur))), h('div', null, 'Shipping ', h('strong', null, fmt(shipT, cur))), h('div', { style: 'font-size:1.1rem' }, 'Total ', h('strong', null, fmt(sub + shipT, cur)))), emailOnly() ? h('button', { class: 'btn primary', onclick: () => emailBuy(mine.filter((i) => by[i.productId]).map((i) => ({ id: i.productId, name: by[i.productId].name, qty: i.quantity, price: fmt(by[i.productId].price.minor * i.quantity, by[i.productId].price.currency), seller: by[i.productId].seller.shopName }))) }, 'Buy by email') : h('a', { class: 'btn primary', href: '#/checkout/' + sid }, 'Check out with this seller')) : h('div', { class: 'notice warn' }, 'These items use different currencies. Remove one to continue.')));
  }
  return d;
}

// ---------- checkout ----------
export async function checkout({ params }) {
  if (!state.me) { go('login?next=' + encodeURIComponent('checkout/' + params[0])); return h('div'); }
  const sid = +params[0]; const d = page('Checkout'); d.append(h('h1', null, 'Checkout'));
  const mine = cartItems().filter((i) => i.sellerId === sid);
  if (!mine.length) { d.append(empty('Nothing to check out', null, h('a', { class: 'btn', href: '#/cart' }, 'Back to cart'))); return d; }
  const ps = (await GET('/api/products?ids=' + mine.map((i) => i.productId).join(','))).products; const by = Object.fromEntries(ps.map((p) => [p.id, p]));
  const lines = mine.filter((i) => by[i.productId]); const cur = by[lines[0].productId].price.currency;
  const sub = lines.reduce((a, i) => a + by[i.productId].price.minor * i.quantity, 0), shipT = lines.reduce((a, i) => a + by[i.productId].shippingFee.minor, 0);
  const pay = state.config.payment;
  const key = 'co-' + crypto.randomUUID(); // one key per visit: a double-click can never create two orders
  const f = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); const btn = f.querySelector('button.primary');
    await submitting(btn, async () => {
      try {
        if (!f.accept.checked) throw new ApiError(400, { error: { field: 'accept', message: 'Please confirm you have read the terms.' } });
        const r = await POST('/api/checkout', { sellerId: sid, items: lines.map((i) => ({ productId: i.productId, quantity: i.quantity })), shipping: { name: f.name.value, line1: f.line1.value, line2: f.line2.value, city: f.city.value, region: f.region.value, postal: f.postal.value, country: f.country.value, phone: f.phone.value }, idempotencyKey: key });
        lsSet('qy_cart', cartItems().filter((i) => i.sellerId !== sid)); window.dispatchEvent(new Event('qy:cart'));
        const u = r.order.payment && r.order.payment.checkoutUrl;
        if (u) { const hash = u.includes('#/') ? u.slice(u.indexOf('#/')) : null; if (hash && new URL(u).origin === location.origin) location.hash = hash; else location.href = u; } else go('orders/' + r.order.id);
      } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); }
    });
  } },
    h('h2', null, 'Delivery address'),
    h('label', { for: 'name' }, 'Full name'), h('input', { id: 'name', name: 'name', autocomplete: 'name', required: true }),
    h('label', { for: 'line1' }, 'Address'), h('input', { id: 'line1', name: 'line1', autocomplete: 'address-line1', required: true }),
    h('label', { for: 'line2' }, 'Address line 2 (optional)'), h('input', { id: 'line2', name: 'line2', autocomplete: 'address-line2' }),
    h('div', { class: 'two' }, h('div', null, h('label', { for: 'city' }, 'City'), h('input', { id: 'city', name: 'city', autocomplete: 'address-level2', required: true })), h('div', null, h('label', { for: 'region' }, 'Region (optional)'), h('input', { id: 'region', name: 'region' }))),
    h('div', { class: 'two' }, h('div', null, h('label', { for: 'postal' }, 'Postal code (optional)'), h('input', { id: 'postal', name: 'postal', autocomplete: 'postal-code' })), h('div', null, h('label', { for: 'phone' }, 'Phone for the courier (optional)'), h('input', { id: 'phone', name: 'phone', autocomplete: 'tel' }))),
    h('label', { for: 'country' }, 'Country'), h('select', { id: 'country', name: 'country', style: 'max-width:none;width:100%' }, state.config.countries.map((c) => h('option', { value: c.code, selected: c.code === (state.country || state.me.country) }, c.name))),
    h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'accept' }), h('span', null, 'I have read the ', h('a', { href: '#/legal/terms', target: '_blank' }, 'Terms'), ', ', h('a', { href: '#/legal/shipping-returns', target: '_blank' }, 'shipping & returns'), ' and the seller’s returns terms.')),
    h('button', { class: 'btn primary', type: 'submit', style: 'width:100%' }, 'Continue to secure payment'));
  d.append(h('div', { class: 'two' }, h('div', null, f), h('div', { class: 'panel' }, h('h2', null, 'Order summary'),
    lines.map((i) => h('div', { class: 'row between small', style: 'padding:6px 0' }, h('span', null, by[i.productId].name + ' × ' + i.quantity), h('span', null, fmt(by[i.productId].price.minor * i.quantity, cur)))),
    h('hr', { style: 'border:0;border-top:1px solid var(--line);margin:10px 0' }), h('div', { class: 'row between' }, h('span', null, 'Items'), h('span', null, fmt(sub, cur))), h('div', { class: 'row between' }, h('span', null, 'Shipping'), h('span', null, fmt(shipT, cur))), h('div', { class: 'row between', style: 'font-size:1.2rem;margin-top:8px' }, h('strong', null, 'Total'), h('strong', null, fmt(sub + shipT, cur))),
    h('p', { class: 'small muted', style: 'margin-top:10px' }, 'Charged in ' + cur + ' by the seller. Your bank may add currency-conversion fees. The marketplace fee is paid by the seller, not added to your total.'),
    h('p', { class: 'small muted' }, 'You pay on the payment provider’s hosted page. QYRRAVO never sees or stores your card number.'))));
  return d;
}

// ---------- test-mode payment simulator ----------
export async function testPay({ params }) {
  const d = page('Test payment');
  if (!state.config.payment.simulator) return page('Not available', h('h1', null, 'Not available'));
  const r = await GET('/api/test-pay/' + params[0]); const p = r.payment;
  d.append(h('h1', null, 'Payment simulator'), h('div', { class: 'notice warn' }, h('strong', null, 'TEST MODE. '), 'This page stands in for a payment provider. No card is used and no money moves. Pressing a button sends a SIGNED simulated webhook to the real server code, exactly as a provider would.'),
    h('div', { class: 'panel' }, h('dl', { class: 'kv' }, h('dt', null, 'Payment'), h('dd', null, '#' + p.id + ' (' + p.kind + ')'), h('dt', null, 'Amount'), h('dd', null, fmt(p.amountMinor, p.currency)), h('dt', null, 'Status'), h('dd', null, p.status)),
      p.status === 'pending' ? h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: async (e) => submitting(e.currentTarget, async () => { try { await POST('/api/test-pay/' + p.id + '/complete', { outcome: 'succeeded' }); toast('Simulated payment succeeded', 'ok'); go(p.kind === 'order' ? 'orders' : 'dashboard/plan'); } catch (err) { toast(err.message, 'error'); } }) }, 'Simulate successful payment'), h('button', { class: 'btn danger', onclick: async (e) => submitting(e.currentTarget, async () => { try { await POST('/api/test-pay/' + p.id + '/complete', { outcome: 'failed' }); toast('Simulated payment failed'); go(p.kind === 'order' ? 'orders' : 'dashboard/plan'); } catch (err) { toast(err.message, 'error'); } }) }, 'Simulate failed payment')) : h('p', null, 'This payment is already ' + p.status + '.')));
  return d;
}

// ---------- orders ----------
export async function orders() {
  const d = page('Your orders'); d.append(h('h1', null, 'Your orders'));
  const r = await GET('/api/orders');
  d.append(r.orders.length ? h('div', { class: 'scroll-x' }, h('table', null, h('thead', null, h('tr', null, ['Order', 'Date', 'Seller', 'Total', 'Status', ''].map((x) => h('th', null, x)))), h('tbody', null, r.orders.map((o) => h('tr', null, h('td', null, o.orderNo), h('td', null, dOnly(o.createdAt)), h('td', null, o.seller.shopName), h('td', null, fmt(o.totalMinor, o.currency)), h('td', null, statusPill(o.status)), h('td', null, h('a', { href: '#/orders/' + o.id }, 'Open'))))))) : empty('No orders yet', null, h('a', { class: 'btn', href: '#/browse' }, 'Browse listings')));
  return d;
}
export async function orderDetail({ params }) {
  const d = page('Order'); const r = await GET('/api/orders/' + params[0]); const o = r.order;
  const act = (label, url, body, cls = '') => h('button', { class: 'btn ' + cls, onclick: async (e) => submitting(e.currentTarget, async () => { try { await POST(url, body || {}); toast('Done', 'ok'); orderDetail({ params }).then((n) => d.replaceWith(n)); } catch (err) { toast(err.message, 'error'); } }) }, label);
  d.append(h('p', null, h('a', { href: '#/orders' }, '← All orders')), h('h1', null, 'Order ' + o.orderNo), h('p', null, statusPill(o.status), ' placed ' + dt(o.createdAt)),
    o.status === 'pending_payment' ? h('div', { class: 'notice warn' }, 'Waiting for payment confirmation from the payment provider. Items are held for you until ' + dt(o.expiresAt) + '. ', o.payment && o.payment.checkoutUrl ? h('a', { href: o.payment.checkoutUrl.includes('#/') ? o.payment.checkoutUrl.slice(o.payment.checkoutUrl.indexOf('#/')) : o.payment.checkoutUrl }, 'Continue to payment') : null) : null,
    h('div', { class: 'two' }, h('div', { class: 'panel' }, h('h2', null, 'Items'), o.items.map((i) => h('div', { class: 'thumbrow', style: 'padding:6px 0' }, i.imageUrl ? h('img', { src: i.imageUrl, alt: '' }) : null, h('div', null, h('a', { href: '#/p/' + i.productId }, i.name), h('div', { class: 'small muted' }, i.quantity + ' × ' + fmt(i.unitPriceMinor, o.currency))))), h('hr', { style: 'border:0;border-top:1px solid var(--line);margin:10px 0' }), h('div', null, 'Items ' + fmt(o.itemsTotalMinor, o.currency) + ' · Shipping ' + fmt(o.shippingMinor, o.currency)), h('div', { style: 'font-size:1.15rem' }, h('strong', null, 'Total ' + fmt(o.totalMinor, o.currency))), o.refundedMinor ? h('div', { class: 'muted' }, 'Refunded: ' + fmt(o.refundedMinor, o.currency)) : null),
      h('div', { class: 'panel' }, h('h2', null, 'Delivery'), h('p', null, [o.shipTo.name, o.shipTo.line1, o.shipTo.line2, o.shipTo.city, o.shipTo.region, o.shipTo.postal, countryName(o.shipTo.country)].filter(Boolean).join(', ')), o.tracking ? h('p', null, 'Tracking: ', h('strong', null, o.tracking)) : h('p', { class: 'muted' }, 'No tracking yet.'), h('p', { class: 'small muted' }, 'Seller: ', h('a', { href: '#/s/' + o.seller.id }, o.seller.shopName), o.seller.contactEmail ? ' · ' + o.seller.contactEmail : ''))),
    h('div', { class: 'actions' }, o.status === 'pending_payment' ? act('Cancel order', '/api/orders/' + o.id + '/cancel', {}, 'danger') : null, o.status === 'shipped' ? act('I received it', '/api/orders/' + o.id + '/confirm-delivery') : null,
      ['paid', 'shipped', 'delivered', 'completed'].includes(o.status) && !o.dispute ? h('button', { class: 'btn danger', onclick: () => disputeDialog(o, () => orderDetail({ params }).then((n) => d.replaceWith(n))) }, 'Open a dispute') : null),
    o.dispute ? h('div', { class: 'notice bad' }, 'Dispute ' + o.dispute.status + ': ' + o.dispute.reason) : null,
    o.refunds.length ? h('div', { class: 'panel' }, h('h2', null, 'Refunds'), o.refunds.map((x) => h('div', null, fmt(x.amountMinor, o.currency) + ' · ' + x.status + ' · ' + dOnly(x.createdAt)))) : null);
  return d;
}
function disputeDialog(o, done) {
  const f = h('form', { onsubmit: async (e) => { e.preventDefault(); await submitting(f.querySelector('button.primary'), async () => { try { await POST('/api/orders/' + o.id + '/dispute', formData(f)); m.close(); toast('Dispute opened', 'ok'); done(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); } },
    h('p', { class: 'muted' }, 'Tell us what went wrong (at least 10 characters). A moderator reviews both sides. The seller’s earnings for this order are on hold meanwhile.'), h('textarea', { name: 'reason', required: true, maxlength: 1000 }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Open dispute')));
  const m = modal('Open a dispute', f);
}
