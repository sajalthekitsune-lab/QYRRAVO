import { logoImg, h, state, GET, POST, DEL, toast, dt, empty, submitting, can, fieldErr, nameTag, socialLinks } from '../core.js';
import { go } from '../app.js';

const wrap = (title, ...k) => h('div', { class: 'wrap block', dataset: { title } }, ...k);
const hero = (icon, title, sub, ...extra) => h('div', { class: 'phero' }, h('div', { class: 'phero-ic', 'aria-hidden': 'true' }, icon), h('div', null, h('h1', null, title), h('p', { class: 'muted' }, sub)), ...extra);
const staff = () => !!state.me && can('content.manage');
const needSignIn = () => go('login?next=' + encodeURIComponent(location.hash.slice(2)));
const left = (iso) => { const ms = new Date(iso) - Date.now(); if (ms <= 0) return 'ended'; const d = Math.floor(ms / 864e5), hr = Math.floor(ms / 36e5) % 24; return d ? d + 'd ' + hr + 'h left' : hr + 'h ' + (Math.floor(ms / 6e4) % 60) + 'm left'; };
const act = (label, fn, cls = '') => h('button', { class: 'btn small ' + cls, onclick: async (e) => submitting(e.currentTarget, async () => { try { await fn(); } catch (err) { toast(err.message, 'error'); } }) }, label);

// ================= EVENTS / GIVEAWAYS =================
export async function events() {
  const r = await GET('/api/events'); const d = wrap('Events', hero('🎁', 'Events & giveaways', 'QYRRAVO gives away free items. Enter once. When the event ends, a winner is picked at random from everyone who entered.'));
  const reload = () => events().then((n) => d.replaceWith(n));
  if (staff()) {
    const f = h('form', { class: 'panel', onsubmit: async (e) => { e.preventDefault(); try { await POST('/api/admin/events', { title: f.title.value, prize: f.prize.value, description: f.description.value, days: +f.days.value, codeDollars: f.codeDollars ? f.codeDollars.value : undefined }); toast('Event created', 'ok'); reload(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } } },
      h('h2', null, 'Create an event'), h('label', null, 'Title'), h('input', { name: 'title', placeholder: 'Free headphones giveaway' }), h('label', null, 'Free item (the prize)'), h('input', { name: 'prize', placeholder: 'JBL Live 670NC headphones' }),
      state.me.isOwner ? [h('label', null, 'Prize code value in $ (optional, owner only)'), h('input', { name: 'codeDollars', type: 'number', min: '0.01', step: '0.01', placeholder: 'e.g. 10: the winner gets a code worth $10' })] : null, h('label', null, 'Description / rules'), h('textarea', { name: 'description', rows: 3 }), h('label', null, 'Runs for (days)'), h('input', { name: 'days', type: 'number', min: 1, max: 90, value: 7 }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Start event')));
    d.append(f);
  }
  if (!r.events.length) { d.append(empty('No events right now', 'Check back soon for giveaways.')); return d; }
  d.append(h('div', { class: 'three' }, r.events.map((e) => h('div', { class: 'panel event' + (e.status === 'open' ? ' live' : '') },
    h('div', { class: 'row between' }, h('span', { class: 'pill ' + (e.status === 'open' ? 'ok' : '') }, e.status === 'open' ? 'LIVE' : e.status === 'drawn' ? 'Winner picked' : 'Ended'), h('span', { class: 'muted small' }, e.status === 'open' ? left(e.endsAt) : dt(e.endsAt))),
    h('h2', null, e.title), h('div', { class: 'prize' }, '🎁 ', h('strong', null, e.prize)), h('p', { class: 'muted' }, e.description), h('p', { class: 'small muted' }, e.entries + ' ' + (e.entries === 1 ? 'entry' : 'entries')),
    e.winner ? h('div', { class: 'notice' }, '🏆 Winner: ', h('strong', null, nameTag(e.winner)), e.winnerIsMe ? h('div', null, 'That is you! Check your notifications for your prize code, or email qyrravo@gmail.com.') : null) : null,
    e.status === 'open' ? (e.entered ? h('span', { class: 'pill ok' }, '✓ You are entered') : (state.me ? act('Enter giveaway', async () => { await POST('/api/events/' + e.id + '/enter'); toast('You are in. Good luck!', 'ok'); reload(); }, 'primary') : h('button', { class: 'btn small primary', onclick: needSignIn }, 'Sign in to enter'))) : null,
    staff() ? h('div', { class: 'row', style: 'margin-top:10px' }, e.status !== 'drawn' ? act('🎲 Draw winner', async () => { if (!confirm('Draw a random winner now?')) return; await POST('/api/admin/events/' + e.id + '/draw'); reload(); }, 'primary') : null, act('Delete', async () => { if (!confirm('Delete this event?')) return; await DEL('/api/admin/events/' + e.id); reload(); }, 'danger')) : null))));
  return d;
}

// ================= POLLS =================
export async function polls() {
  const r = await GET('/api/polls');
  const open = r.polls.filter((p) => !p.closed).length; const votes = r.polls.reduce((n, p) => n + p.total, 0);
  const d = wrap('Polls', hero('🗳️', 'Community polls', 'Vote once per poll. Everyone can watch the results live. The option with the most votes wins.',
    h('div', { class: 'pstats' }, [[r.polls.length, 'Polls'], [open, 'Open now'], [votes, 'Total votes']].map(([n, l]) => h('div', null, h('b', null, n), h('span', null, l))))));
  const reload = () => polls().then((n) => d.replaceWith(n));
  if (staff()) {
    const f = h('form', { class: 'panel pform', onsubmit: async (e) => { e.preventDefault(); try { await POST('/api/admin/polls', { question: f.question.value, options: f.options.value.split('\n'), days: +f.days.value }); toast('Poll created', 'ok'); reload(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } } },
      h('h2', null, '➕ Create a poll ', h('span', { class: 'pill' }, 'admins only')), h('label', null, 'Question'), h('input', { name: 'question', placeholder: 'Which category should we add next?' }), h('label', null, 'Options (one per line, 2 to 10)'), h('textarea', { name: 'options', rows: 4, placeholder: 'Books\nSports\nToys' }), h('label', null, 'Runs for (days)'), h('input', { name: 'days', type: 'number', min: 1, max: 90, value: 7 }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Start poll')));
    d.append(f);
  }
  if (!r.polls.length) { d.append(empty('No polls yet', 'The owner will post one soon.')); return d; }
  d.append(h('div', { class: 'pgrid' }, r.polls.map((p) => {
    const ranked = [...p.options].sort((x, y) => y.votes - x.votes); const rank = Object.fromEntries(ranked.map((o, i) => [o.id, i + 1]));
    const winners = p.options.filter((o) => o.winner);
    return h('article', { class: 'pcard' + (p.closed ? ' closed' : '') },
      h('div', { class: 'row between' }, h('span', { class: 'pill ' + (p.closed ? '' : 'ok') }, p.closed ? '● Closed' : '● Live'), h('span', { class: 'muted small' }, p.closed ? '' : '⏱ ' + left(p.endsAt))),
      h('h2', { class: 'pq' }, p.question),
      p.closed && winners.length ? h('div', { class: 'pwin' }, '🏆 ', h('strong', null, winners.length > 1 ? 'Tie: ' + winners.map((w) => w.label).join(' & ') : winners[0].label + ' wins')) : null,
      h('div', { class: 'popts' }, p.options.map((o) => {
        const canVote = !p.closed && !p.myVote; const lead = !p.closed && p.total && rank[o.id] === 1 && o.votes > 0;
        return h('div', { class: 'popt' + (o.winner ? ' win' : '') + (p.myVote === o.id ? ' mine' : '') + (canVote ? ' votable' : ''), role: canVote ? 'button' : null, tabindex: canVote ? 0 : null, 'aria-label': canVote ? 'Vote for ' + o.label : null,
          onkeydown: canVote ? (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.currentTarget.click(); } } : null,
          onclick: canVote ? async () => { if (!state.me) { needSignIn(); return; } try { await POST('/api/polls/' + p.id + '/vote', { optionId: o.id }); toast('Vote saved. Thank you!', 'ok'); reload(); } catch (err) { toast(err.message, 'error'); } } : null },
          h('div', { class: 'pfill', style: 'width:' + Math.max(o.percent, o.votes ? 3 : 0) + '%' }),
          h('span', { class: 'prank' }, o.winner ? '🏆' : '#' + rank[o.id]),
          h('span', { class: 'plabel' }, o.label, p.myVote === o.id ? h('em', null, ' ✓ your vote') : null, lead ? h('em', { class: 'lead' }, ' leading') : null),
          h('span', { class: 'pnum' }, h('b', null, o.percent + '%'), h('small', null, o.votes + (o.votes === 1 ? ' vote' : ' votes'))));
      })),
      h('div', { class: 'row between pfoot' }, h('span', { class: 'small muted' }, p.total + (p.total === 1 ? ' vote' : ' votes') + ' in total'), !p.closed && !p.myVote ? h('span', { class: 'small', style: 'color:var(--cyan)' }, state.me ? 'Tap an option to vote' : 'Sign in to vote') : null),
      staff() ? h('div', { class: 'row', style: 'margin-top:10px' }, p.closed ? null : act('Close now', async () => { await POST('/api/admin/polls/' + p.id + '/close'); reload(); }), act('Delete', async () => { if (!confirm('Delete this poll?')) return; await DEL('/api/admin/polls/' + p.id); reload(); }, 'danger')) : null);
  })));
  return d;
}

// ================= WIKI =================
export async function wiki() {
  const cfg = state.config; const o = cfg.site.owner || {}; const mail = cfg.site.supportEmail; const plans = cfg.plans || [];
  const usd = (m) => '$' + (m / 100).toLocaleString('en-US');
  const gm = 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(mail);
  const S = [];
  const sec = (id, icon, title, ...body) => S.push({ id, icon, title, body });
  const P = (t) => h('p', null, t);
  const L = (items) => h('ul', { class: 'prose' }, items.map((i) => h('li', null, i)));
  const steps = (items) => h('ol', { class: 'steps' }, items.map((i) => h('li', null, h('span', null, i))));
  const tip = (t, kind = '') => h('div', { class: 'callout ' + kind }, h('b', null, kind === 'warn' ? '⚠️ Honest limit' : '💡 Good to know'), h('span', null, t));
  const faq = (q, a) => h('details', { class: 'faq' }, h('summary', null, q), h('p', null, a));
  sec('what', '✨', 'What is QYRRAVO?', P('QYRRAVO (“Quietly Better.”) is an international marketplace. People list real items to sell, a human moderator checks the listing photos before anything goes live, and buyers from any country can browse and ask to buy.'), P('It is built and run by one owner, Sajal Dhungana, and it keeps growing. This wiki explains every part of the app.'));
  sec('owner', '👑', 'The owner', h('div', { class: 'wiki-owner' }, logoImg('mark', { class: 'owner-logo', alt: 'QYRRAVO logo' }), h('div', null, h('h3', null, 'QYRRAVO ', '👑'), P((o.name || '') + ' · ' + (o.title || 'Founder & owner')))),
    h('dl', { class: 'kv' }, h('dt', null, 'Name'), h('dd', null, o.name), h('dt', null, 'Role'), h('dd', null, 'Founder and owner of QYRRAVO'), h('dt', null, 'From'), h('dd', null, o.from), h('dt', null, 'Lives in'), h('dd', null, o.livesIn), h('dt', null, 'Brand line'), h('dd', null, o.tagline || 'Quietly Better.'), h('dt', null, 'Email'), h('dd', null, h('a', { href: gm, target: '_blank', rel: 'noopener' }, mail))),
    L(['The owner account is named “QYRRAVO 👑”. Only this account may use the crown or the QYRRAVO name.', 'Click or hover the 👑 anywhere on the site to open the owner card.', 'The owner is an administrator and has the VIP plan for free.', 'Only the owner can make or remove other administrators.']));
  sec('buy', '🛒', 'How to buy', steps(['Open an item and press “Buy this item” (or add several to the cart).', 'Sign in, then give ONE way to reach you (phone or email), your delivery address, and tick that the address is correct.', 'Your request is saved and a ready-to-send Gmail message to ' + mail + ' opens.', 'QYRRAVO contacts you, verifies the address, and explains payment and delivery.']), tip('QYRRAVO accepts cash or card for Q Coins and paid plans, arranged by email. The site itself never collects card details. Never send passwords or card numbers by email.'));
  sec('sell', '🏷️', 'How to sell', steps(['Create an account and verify your email (or email ' + mail + ' to be verified).', 'Open Sell, accept the Seller Agreement, and set up your shop name and country.', 'Add a listing: name, description, category, condition, price, quantity, shipping and returns.', 'Add photos. Use the front or back camera, or upload them.', 'Take the verification photo: the item next to the one-time code the site gives you.', 'A moderator reviews it and approves, rejects or asks for more. Approved listings appear for buyers.']));
  sec('plans', '💎', 'Plans and limits', P('You can have one listing for sale at a time on every plan. A higher plan raises the maximum price per item and lets you stock more identical units in that one listing: Free 1, Premium up to 10, VIP up to 100.'),
    h('div', { class: 'plan-cards' }, plans.map((p, i) => h('div', { class: 'plan-card p' + i }, h('b', null, p.name), h('div', { class: 'pc-price' }, p.priceMinor ? usd(p.priceMinor) + '/mo' : 'Free'), h('div', { class: 'muted small' }, 'items up to'), h('div', { class: 'pc-max' }, usd(p.maxItemUsdMinor)), h('div', { class: 'muted small', style: 'margin-top:8px' }, 'identical units in stock'), h('div', { class: 'pc-max' }, String(p.maxQuantity || 1))))),
    P('To get Premium or VIP press Buy on the Plan page and send the email. After payment is confirmed, the owner switches the plan on. If a paid plan ends, expensive listings are paused (never deleted) until you renew. Admins get VIP free.'));
  sec('photos', '📸', 'Photo verification', L(['Every listing needs photos and a verification photo showing the item next to a one-time code.', 'Codes are made by the server, expire, and are private. Moderators read the code and compare it.', 'Photos are cleaned (location data removed) and stored privately. The verification photo is never shown to buyers.']), tip('Photo review does not prove ownership, authenticity or that the seller is honest.', 'warn'));
  sec('cat', '🌍', 'Categories, countries and currencies', L(['Categories: Gaming, Smartphones, Royal & Luxury, Cheap Finds, Looks Expensive Costs Less, Gift Cards, Tech Accessories, Home & Desk, Everyday Carry and Travel.', 'Choose your country and currency at the top. Other currencies are estimates from stored exchange rates.', 'Each seller lists where they ship. Check “Ships to” before buying.']));
  sec('tools', '🔎', 'Search, compare and wishlist', L(['Search any word from the top bar.', '♡ saves an item to your wishlist.', 'Compare puts up to four items side by side.']));
  sec('community', '🎁', 'Events, giveaways and polls', L(['Events: the owner posts a giveaway with a free item. Sign in and enter once. When it ends, the owner draws a random winner, who is notified and shown on the page.', 'Polls: only admins create polls. Everyone can see the votes; signed-in users vote once. The option with the most votes wins when the poll closes (ties show several winners).']),
    h('div', { class: 'row' }, h('a', { class: 'btn small', href: '#/events' }, '🎁 Open Events'), h('a', { class: 'btn small', href: '#/polls' }, '🗳️ Open Polls')));
  sec('game', '🏎️', 'QYRRAVO Drive (earn Q Coins)', P('QYRRAVO Drive is a free 3D driving game in your browser. While you are actively driving signed in with a verified email, you earn 20 Q Coins for every completed lap of the 132 km circuit (about 40 minutes, through all the checkpoints). You can choose a Lamborghini, Ferrari or Bugatti. The server measures the time: it only counts while you steer and move with the tab visible. There is a daily limit per account (120 minutes by default), a shared daily budget for everyone, and only one tab can earn at a time. Q Coins are a wallet balance, not cash.')),
  sec('redeem', '🎟️', 'Redeem codes and Q Coins', P('Q Coins are the QYRRAVO wallet currency (100 Q Coins = $1). Only the owner can create redeem codes. Giveaway winners can receive a personal code that only they can use. Open the Redeem page, type the code and the Q Coins are added to your wallet. You can also buy Q Coins: pick an amount on the Redeem page and email QYRRAVO. You pay money (no card), and the owner adds the coins after the payment is confirmed. The owner can also gift Q Coins to any account.'), P('Sellers can accept cash, Q Coins or both for each item. When you pay with Q Coins, they are held until QYRRAVO confirms delivery, then paid to the seller. If the order is cancelled before the address is verified you can cancel it yourself and get your coins back.'), tip('Q Coins cannot be withdrawn as cash. They can only be spent on items that accept them.', 'warn'), h('a', { class: 'btn small', href: '#/redeem' }, '🎟️ Open Redeem')),
  sec('bot', '🤖', 'Help assistant', P('The 💬 Help button (bottom right) opens an assistant. It answers questions about the site and, when connected to AI, general questions too.'), tip('It can make mistakes. For anything important email ' + mail + '.', 'warn'));
  sec('acct', '🔐', 'Accounts and sign in', L(['Join with email and password (at least 10 characters), or use “Continue with Google” when it is switched on.', 'Passwords are stored as one-way hashes. Sessions use secure cookies.', 'You can change your name or password and delete your account from Account. Deleted emails can be used again.']));
  sec('admin', '🛡️', 'Admin panel (staff only)', L(['Users & admins: change roles (only the owner can make admins), suspend, verify emails, give a plan after payment, delete accounts.', 'All listings: edit or delete any listing; sellers are told and every change is logged.', 'Purchase requests: see buyers’ contact and address, then mark the address verified.', 'Moderation, settings, categories, prohibited items, audit log and errors.', 'Events and polls: create them, close polls, draw giveaway winners.']));
  sec('safety', '🚨', 'Safety and rules', L(['Prohibited items are not allowed and are flagged for review.', 'Use the Report buttons on listings and sellers.', 'Names with the crown or “QYRRAVO” are reserved for the owner to stop impersonation.', 'QYRRAVO never asks for passwords or card numbers.']));
  sec('faq', '❓', 'Quick answers', faq('Can I pay by card?', 'Yes, for Q Coins and Premium or VIP plans bought from QYRRAVO: cash or card, arranged by email. The website never takes card details, and you should never email a card number. QYRRAVO will tell you a safe way to pay.'), faq('How long until my listing goes live?', 'After a moderator reviews your photos and verification code. You will get a notification.'), faq('Can I sell more than one item?', 'You have one listing at a time on every plan, but Premium can stock up to 10 identical units in it and VIP up to 100. Free is 1 unit. When the listing sells out, you can list the next.'), faq('How do I get Premium or VIP?', 'Press Buy on the Plan page and send the prepared email to ' + mail + '.'), faq('I forgot my password.', 'Use “Forgot your password?” on the sign-in page, or email ' + mail + '.'), faq('Who can create polls and events?', 'Only admins. Everyone can vote and enter.'));
  sec('legal', '⚖️', 'Legal and honest limits', L(['The legal pages (Terms, Privacy, Shipping & returns, Refunds, Disputes, Prohibited, Fees) are drafts and should be reviewed by a lawyer.', 'QYRRAVO is run by an individual and is not yet a registered company.', 'Sellers are responsible for what they list.']));
  sec('contact', '📬', 'Social media and contact', P('Email ' + mail + ' or find us online:'), socialLinks());
  const q = h('input', { type: 'search', placeholder: 'Search the wiki… (try “plans” or “photo”)', 'aria-label': 'Search the wiki' });
  const body = h('div', { class: 'wiki-body' }, S.map((s) => h('section', { class: 'panel wiki-sec', id: 'w-' + s.id }, h('h2', null, h('span', { class: 'w-ic' }, s.icon), s.title), ...s.body)));
  const links = S.map((s) => h('a', { href: 'javascript:void(0)', 'data-id': s.id, onclick: () => document.getElementById('w-' + s.id).scrollIntoView({ behavior: 'smooth', block: 'start' }) }, h('span', null, s.icon), s.title));
  const toc = h('nav', { class: 'wiki-toc', 'aria-label': 'Wiki contents' }, h('h3', null, 'Contents'), links);
  const quick = ['buy', 'sell', 'plans', 'photos', 'community', 'owner'].map((id) => S.find((x) => x.id === id));
  const tiles = h('div', { class: 'wtiles' }, quick.map((s) => h('button', { type: 'button', class: 'wtile', onclick: () => document.getElementById('w-' + s.id).scrollIntoView({ behavior: 'smooth', block: 'start' }) }, h('span', null, s.icon), s.title)));
  const hit = h('p', { class: 'muted small', hidden: true }, 'No section matches your search.');
  q.addEventListener('input', () => { const t = q.value.toLowerCase().trim(); let n = 0; body.querySelectorAll('.wiki-sec').forEach((e) => { const show = !t || e.textContent.toLowerCase().includes(t); e.hidden = !show; if (show) n++; }); hit.hidden = n > 0; });
  const root = wrap('QYRRAVO Wiki', h('div', { class: 'whero' }, h('div', { class: 'whero-in' }, h('div', { class: 'eyebrow' }, 'Knowledge base'), h('h1', null, '📚 QYRRAVO Wiki'), h('p', { class: 'lead' }, 'Every detail about this app, and about the person behind it. Search or jump to a topic.'), q), logoImg('mark', { alt: '', class: 'whero-logo' })), tiles, hit, h('div', { class: 'wiki-grid' }, toc, body));
  if ('IntersectionObserver' in window) { const io = new IntersectionObserver((es) => { es.forEach((e) => { if (e.isIntersecting) { const id = e.target.id.slice(2); links.forEach((l) => l.classList.toggle('on', l.dataset.id === id)); } }); }, { rootMargin: '-20% 0px -70% 0px' }); setTimeout(() => body.querySelectorAll('.wiki-sec').forEach((e) => io.observe(e)), 0); }
  return root;
}
