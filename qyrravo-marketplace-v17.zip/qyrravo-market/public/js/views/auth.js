import { h, state, GET, POST, PATCH, toast, flag, dt, empty, formData, fieldErr, submitting, loadMe, modal } from '../core.js';
import { go, refreshHeader } from '../app.js';

const page = (title, ...k) => h('div', { class: 'wrap block', dataset: { title }, style: 'max-width:520px' }, ...k);
const wide = (title, ...k) => h('div', { class: 'wrap block', dataset: { title } }, ...k);
const safeNext = (n) => (n && /^[a-z0-9\-\/]+$/i.test(n) ? n : '');

function authForm(onSubmit, ...kids) {
  const f = h('form', { novalidate: true, onsubmit: async (e) => { e.preventDefault(); const b = f.querySelector('button.primary'); await submitting(b, async () => { try { await onSubmit(f); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); } }, ...kids);
  return f;
}
const field = (label, name, type = 'text', extra = {}) => [h('label', { for: name }, label), h('input', { id: name, name, type, ...extra })];
const afterAuth = async (next) => { window.dispatchEvent(new Event('qy:session')); await loadMe(); refreshHeader(); go(safeNext(next) || ''); };

const googleBtn = (query) => state.config.site.googleLogin ? h('div', null, query && query.error ? h('div', { class: 'notice warn' }, 'Google sign-in did not work. Please try again or use email.') : null, h('a', { class: 'btn', href: '/api/auth/google', style: 'width:100%;justify-content:center;margin-bottom:14px' }, 'G  Continue with Google'), h('p', { class: 'muted small', style: 'text-align:center' }, 'or use your email')) : null;
export async function login({ query }) {
  if (state.me) { go(safeNext(query.next) || ''); return h('div'); }
  const f = authForm(async (f) => { await POST('/api/auth/login', { email: f.email.value, password: f.password.value }); await afterAuth(query.next); },
    ...field('Email', 'email', 'email', { autocomplete: 'email', required: true }), ...field('Password', 'password', 'password', { autocomplete: 'current-password', required: true }),
    h('button', { class: 'btn primary', type: 'submit', style: 'width:100%;margin-top:18px' }, 'Sign in'));
  return page('Sign in', h('h1', null, 'Sign in'), googleBtn(query), f, h('p', { class: 'muted', style: 'margin-top:14px' }, h('a', { href: '#/forgot' }, 'Forgot your password?'), ' · ', h('a', { href: '#/register' }, 'Create an account')));
}
export async function register({ query }) {
  if (state.me) { go(''); return h('div'); }
  const f = authForm(async (f) => {
    if (!f.acceptTerms.checked) { const e = new Error('Please accept the Terms and Privacy Policy.'); e.field = 'acceptTerms'; throw e; }
    const r = await POST('/api/auth/register', { email: f.email.value, password: f.password.value, displayName: f.displayName.value, country: f.country.value, acceptTerms: true });
    toast(r.message, 'ok'); await afterAuth(query.next);
  },
    ...field('Your name', 'displayName', 'text', { autocomplete: 'name', required: true }), ...field('Email', 'email', 'email', { autocomplete: 'email', required: true }),
    ...field('Password (at least 10 characters)', 'password', 'password', { autocomplete: 'new-password', required: true, minlength: 10 }),
    h('label', { for: 'country' }, 'Country'), h('select', { id: 'country', name: 'country', style: 'max-width:none;width:100%' }, state.config.countries.map((c) => h('option', { value: c.code, selected: c.code === state.country }, flag(c.code) + ' ' + c.name))),
    h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'acceptTerms' }), h('span', null, 'I accept the ', h('a', { href: '#/legal/terms', target: '_blank' }, 'Terms of Service'), ' and ', h('a', { href: '#/legal/privacy', target: '_blank' }, 'Privacy Policy'), '.')),
    h('button', { class: 'btn primary', type: 'submit', style: 'width:100%' }, 'Create account'));
  return page('Join', h('h1', null, 'Create your account'), googleBtn(), f, h('p', { class: 'muted', style: 'margin-top:14px' }, 'Already have one? ', h('a', { href: '#/login' }, 'Sign in')));
}
export async function verify({ query }) {
  const d = page('Verify email', h('h1', null, 'Verifying your email…'));
  try { await POST('/api/auth/verify', { token: query.token || '' }); await loadMe(); refreshHeader(); d.replaceChildren(h('h1', null, 'Email verified'), h('p', null, 'Thank you. You can now sell and buy.'), h('a', { class: 'btn primary', href: '#/' }, 'Continue')); }
  catch (e) { d.replaceChildren(h('h1', null, 'Link not valid'), h('p', { class: 'muted' }, e.message + ' Links work once and expire after 48 hours.'), state.me ? h('button', { class: 'btn primary', onclick: async () => { try { await POST('/api/auth/resend-verification'); toast('A new link was prepared.', 'ok'); } catch (err) { toast(err.message, 'error'); } } }, 'Send a new link') : h('a', { class: 'btn', href: '#/login' }, 'Sign in to request a new link')); }
  return d;
}
export async function forgot() {
  const d = page('Forgot password', h('h1', null, 'Reset your password'));
  const f = authForm(async (f) => { const r = await POST('/api/auth/forgot', { email: f.email.value }); f.replaceChildren(h('div', { class: 'notice' }, r.message)); }, ...field('Email', 'email', 'email', { required: true }), h('button', { class: 'btn primary', type: 'submit', style: 'width:100%;margin-top:18px' }, 'Send reset link'));
  d.append(f); return d;
}
export async function reset({ query }) {
  const f = authForm(async (f) => { await POST('/api/auth/reset', { token: query.token || '', password: f.password.value }); toast('Password changed. Please sign in.', 'ok'); go('login'); }, ...field('New password (at least 10 characters)', 'password', 'password', { autocomplete: 'new-password', required: true }), h('button', { class: 'btn primary', type: 'submit', style: 'width:100%;margin-top:18px' }, 'Change password'));
  return page('Reset password', h('h1', null, 'Choose a new password'), f);
}

export async function account() {
  if (!state.me) { go('login?next=account'); return h('div'); }
  const me = state.me;
  const d = wide('Account', h('h1', null, 'Your account'));
  if (!me.emailVerified) d.append(h('div', { class: 'notice warn' }, 'Your email is not verified yet. ', h('button', { class: 'btn small', onclick: async () => { try { await POST('/api/auth/resend-verification'); toast('A new link was prepared (email delivery needs a configured email service).', 'ok'); } catch (e) { toast(e.message, 'error'); } } }, 'Send a new link')));
  const prof = authForm(async (f) => { await PATCH('/api/account', { displayName: f.displayName.value, country: f.country.value }); await loadMe(); refreshHeader(); toast('Saved', 'ok'); },
    h('h2', null, 'Profile'), ...field('Name', 'displayName', 'text', { value: me.displayName }), h('label', { for: 'country2' }, 'Country'),
    h('select', { id: 'country2', name: 'country', style: 'max-width:none;width:100%' }, state.config.countries.map((c) => h('option', { value: c.code, selected: c.code === me.country }, c.name))), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Save')));
  const pw = authForm(async (f) => { const r = await POST('/api/account/password', { current: f.current.value, password: f.password.value }); state.csrf = r.csrfToken; f.reset(); toast('Password changed. Other devices were signed out.', 'ok'); },
    h('h2', null, 'Change password'), ...field('Current password', 'current', 'password', { autocomplete: 'current-password' }), ...field('New password', 'password', 'password', { autocomplete: 'new-password' }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Change password')));
  d.append(h('div', { class: 'two' }, h('div', { class: 'panel' }, prof), h('div', { class: 'panel' }, pw)),
    h('div', { class: 'actions' }, h('a', { class: 'btn', href: '#/notifications' }, 'Notifications' + (me.unread ? ' (' + me.unread + ')' : '')), h('a', { class: 'btn', href: '#/wishlist' }, 'Wishlist'), h('button', { class: 'btn', onclick: async () => { try { await POST('/api/auth/logout'); } catch { /* ignore */ } state.csrf = ''; window.dispatchEvent(new Event('qy:session')); go(''); } }, 'Sign out')),
    h('div', { class: 'panel' }, h('h2', null, 'Delete my account'), h('p', { class: 'muted' }, 'Your personal details are removed and your email can be used to sign up again. Your listings are taken down.'),
      h('button', { class: 'btn danger', onclick: () => { const f = authForm(async (f) => { await POST('/api/account/delete', { password: f.password.value }); m.close(); state.csrf = ''; window.dispatchEvent(new Event('qy:session')); toast('Account deleted'); go(''); }, ...field('Confirm your password', 'password', 'password', { autocomplete: 'current-password' }), h('div', { class: 'actions' }, h('button', { class: 'btn danger primary', type: 'submit' }, 'Delete permanently'))); const m = modal('Delete account', f); } }, 'Delete account…')));
  return d;
}
export async function notifications() {
  if (!state.me) { go('login?next=notifications'); return h('div'); }
  const r = await GET('/api/notifications');
  if (r.unread) { await POST('/api/notifications/read', { all: true }); state.me.unread = 0; refreshHeader(); }
  return wide('Notifications', h('h1', null, 'Notifications'), r.notifications.length ? r.notifications.map((n) => h('div', { class: 'panel' }, h('strong', null, n.title), h('div', { class: 'muted small' }, dt(n.created_at)), n.body ? h('p', null, n.body) : null, n.link ? h('a', { href: '#' + n.link }, 'Open') : null)) : empty('Nothing yet', 'Updates about your listings, orders and payments appear here.'));
}
