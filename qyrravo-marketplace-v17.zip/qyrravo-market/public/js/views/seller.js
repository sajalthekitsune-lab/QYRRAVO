import { gmailUrl, emailPrompt, h, state, GET, POST, PATCH, DEL, upload, toast, fmt, flag, countryName, dt, dOnly, empty, formData, fieldErr, submitting, statusPill, pill, modal, errorBox, loadMe, ApiError } from '../core.js';
import { go, refreshHeader } from '../app.js';
import { openCamera } from '../camera.js';

const wide = (title, ...k) => h('div', { class: 'wrap block', dataset: { title } }, ...k);
const needLogin = (p) => { if (!state.me) { go('login?next=' + encodeURIComponent(p)); return true; } return false; };
const usd = (m) => fmt(m, 'USD');

function tabs(cur) {
  const t = [['dashboard', 'Overview'], ['dashboard/products', 'Listings'], ['dashboard/plan', 'Plan']];
  return h('nav', { class: 'tabs', 'aria-label': 'Seller' }, t.map(([p, l]) => h('a', { href: '#/' + p, 'aria-current': cur === p ? 'page' : null }, l)));
}
async function sellerGuard(path) {
  if (needLogin(path)) return null;
  if (!state.me.seller) { go('sell'); return null; }
  return GET('/api/seller/me');
}

// ---------- landing + onboarding ----------
export async function sellLanding() {
  const d = wide('Sell on QYRRAVO');
  const plans = state.config.plans; const fees = state.config.fees;
  d.append(h('h1', null, 'Sell on QYRRAVO'), h('p', { class: 'lead muted', style: 'max-width:65ch' }, 'List real items you own and can ship. Every listing’s photos are reviewed by a moderator, together with a one-time code photographed next to the item, before it goes live.'),
    h('div', { class: 'three' }, plans.map((p) => h('div', { class: 'panel' }, h('h2', null, p.name), h('p', { style: 'font-size:1.6rem' }, p.priceMinor ? fmt(p.priceMinor, p.currency) + ' / month' : 'Free'), h('ul', { class: 'prose' }, p.features.map((f) => h('li', null, f)))))),
    h('div', { class: 'notice' }, h('strong', null, 'Fees. '), fees.note, ' Current marketplace commission: ', h('strong', null, fees.commissionPercent + '%'), '. See ', h('a', { href: '#/legal/commission' }, 'fees & commission'), '.'),
    h('div', { class: 'notice warn' }, 'Photo review does not prove ownership, authenticity, or that a seller is honest, and QYRRAVO does not currently verify seller identity. Prohibited and counterfeit items are removed. See the ', h('a', { href: '#/legal/prohibited' }, 'prohibited products'), ' list.'));
  if (!state.me) d.append(h('div', { class: 'actions' }, h('a', { class: 'btn primary', href: '#/register?next=sell' }, 'Create an account to start'), h('a', { class: 'btn', href: '#/login?next=sell' }, 'Sign in')));
  else if (state.me.seller) d.append(h('a', { class: 'btn primary', href: '#/dashboard' }, 'Open seller dashboard'));
  else if (state.me.role !== 'buyer') d.append(h('div', { class: 'notice' }, 'Staff accounts cannot sell.'));
  else {
    if (!state.me.emailVerified) d.append(h('div', { class: 'notice warn' }, 'Verify your email address first. Use the link we prepared at sign-up, or request a new one from your account page.'));
    const f = h('form', { class: 'panel', novalidate: true, onsubmit: async (e) => { e.preventDefault(); await submitting(f.querySelector('button.primary'), async () => { try { await POST('/api/seller/onboard', { shopName: f.shopName.value, country: f.country.value, bio: f.bio.value, contactEmail: f.contactEmail.value || undefined, agreeSellerTerms: f.agree.checked, confirmAdult: f.adult.checked }); await loadMe(); refreshHeader(); toast('Seller profile created', 'ok'); go('dashboard'); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); } },
      h('h2', null, 'Set up your shop'),
      h('label', { for: 'shopName' }, 'Shop name'), h('input', { id: 'shopName', name: 'shopName', required: true, maxlength: 50 }),
      h('label', { for: 'sc' }, 'Country you sell from'), h('select', { id: 'sc', name: 'country', style: 'max-width:none;width:100%' }, state.config.countries.map((c) => h('option', { value: c.code, selected: c.code === (state.me.country || 'QA') }, c.name))),
      h('label', { for: 'bio' }, 'About your shop (optional)'), h('textarea', { id: 'bio', name: 'bio', maxlength: 600 }),
      h('label', { for: 'ce' }, 'Public contact email (optional, defaults to your account email)'), h('input', { id: 'ce', name: 'contactEmail', type: 'email' }),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'agree' }), h('span', null, 'I accept the ', h('a', { href: '#/legal/seller-agreement', target: '_blank' }, 'Seller Agreement'), ', ', h('a', { href: '#/legal/prohibited', target: '_blank' }, 'prohibited products rules'), ' and ', h('a', { href: '#/legal/commission', target: '_blank' }, 'fee terms'), '.')),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'adult' }), h('span', null, 'I am legally allowed to sell here (18+, or acting together with a parent/guardian where the law requires it), and the items I list are mine to sell.')),
      h('button', { class: 'btn primary', type: 'submit' }, 'Create seller profile'));
    d.append(f);
  }
  return d;
}

// ---------- dashboard ----------
export async function dashboard() {
  const me = await sellerGuard('dashboard'); if (!me) return h('div');
  const d = wide('Seller dashboard', h('h1', null, me.profile.shopName), tabs('dashboard'));
  const c = me.counts; const n = (k) => c[k] || 0;
  d.append(h('div', { class: 'stat' }, [['Live', n('approved')], ['In review', n('submitted') + n('under_review')], ['Need changes', n('more_info_required') + n('rejected')], ['Drafts', n('draft')]].map(([l, v]) => h('div', null, h('b', null, v), h('span', { class: 'muted' }, l)))));
  d.append(h('div', { class: 'panel' }, h('h2', null, 'Your plan'), h('p', null, h('strong', null, me.plan.effectivePlanName), ' · maximum price per item ', h('strong', null, usd(me.plan.limits.maxItemUsdMinor)), ' · ', h('strong', null, me.plan.activeListings + ' of ' + me.plan.limits.maxActiveListings), ' item' + (me.plan.limits.maxActiveListings === 1 ? '' : 's') + ' for sale'), me.plan.listingsPausedByPlan ? h('div', { class: 'notice warn' }, me.plan.listingsPausedByPlan + ' listing(s) are paused because they cost more than your current limit. They are not deleted.') : null, h('a', { class: 'btn', href: '#/dashboard/plan' }, 'Manage plan')));
  d.append(h('div', { class: 'panel' }, h('h2', null, 'Selling and getting paid'), h('p', { class: 'muted' }, 'When a buyer presses Buy on your item, we contact you and arrange payment and delivery by email. Payment is arranged by email. ')));
  d.append(h('div', { class: 'actions' }, h('a', { class: 'btn primary', href: '#/dashboard/products/new' }, '+ New listing'), h('a', { class: 'btn', href: '#/dashboard/products' }, 'All listings')));
  return d;
}

// ---------- listings ----------
export async function products() {
  const me = await sellerGuard('dashboard/products'); if (!me) return h('div');
  const d = wide('Listings', h('div', { class: 'row between' }, h('h1', null, 'Listings'), h('a', { class: 'btn primary', href: '#/dashboard/products/new' }, '+ New listing')), tabs('dashboard/products'));
  const r = await GET('/api/seller/products');
  const act = (label, fn, cls = '') => h('button', { class: 'btn small ' + cls, onclick: async (e) => submitting(e.currentTarget, async () => { try { await fn(); products().then((n) => d.replaceWith(n)); } catch (err) { toast(err.message, 'error'); } }) }, label);
  d.append(r.products.length ? h('div', { class: 'scroll-x' }, h('table', null, h('thead', null, h('tr', null, ['', 'Listing', 'Price', 'Status', 'Updated', ''].map((x) => h('th', null, x)))), h('tbody', null, r.products.map((p) => h('tr', null,
    h('td', null, p.images[0] ? h('img', { src: p.images[0].url, alt: '', style: 'width:52px;height:52px;object-fit:cover;border-radius:8px' }) : null),
    h('td', null, h('a', { href: '#/dashboard/products/' + p.id }, p.name || '(untitled draft)'), p.statusReason ? h('div', { class: 'small', style: 'color:var(--warn)' }, p.statusReason) : null, p.status === 'approved' && !p.publicNow ? h('div', { class: 'small', style: 'color:var(--warn)' }, 'Paused: above your plan limit or seller account paused') : null),
    h('td', null, p.price ? fmt(p.price.minor, p.price.currency) : '—'), h('td', null, statusPill(p.status), p.flagged ? ' ' : null), h('td', null, dOnly(p.updatedAt)),
    h('td', { class: 'row' }, h('a', { class: 'btn small', href: '#/dashboard/products/' + p.id }, 'Edit'), p.status === 'approved' ? h('a', { class: 'btn small', href: '#/p/' + p.id }, 'View') : null,
      ['submitted', 'under_review', 'approved'].includes(p.status) ? act('Withdraw', () => POST('/api/seller/products/' + p.id + '/withdraw')) : null,
      act('Delete', async () => { if (confirm('Delete this listing?')) await DEL('/api/seller/products/' + p.id); }, 'danger'))))))) : empty('No listings yet', 'Create your first listing. It stays private until a moderator approves it.', h('a', { class: 'btn primary', href: '#/dashboard/products/new' }, 'Create a listing')));
  return d;
}

// ---------- multi-step product form ----------
const STEPS = ['Details', 'Price & delivery', 'Photos', 'Verification', 'Preview & submit'];
export async function productForm({ params }) {
  const me = await sellerGuard('dashboard/products'); if (!me) return h('div');
  const coinRights = !!(state.me && (state.me.isOwner || state.me.role === 'admin' || state.me.role === 'moderator'));
  const id = params[0] ? +params[0] : null;
  let p = id ? (await GET('/api/seller/products/' + id)).product : null;
  let step = 0; const submitKey = 'sub-' + crypto.randomUUID(); let saving = false;
  const d = wide(id ? 'Edit listing' : 'New listing');
  const body = h('div');
  const locked = p && !['draft', 'more_info_required', 'rejected', 'approved'].includes(p.status);
  const cats = state.config.categories;
  const form = { specs: p ? p.specs.slice() : [], shipsTo: p ? p.shipsTo.slice() : ['WORLD'] };
  const hdr = () => h('div', null, h('div', { class: 'row between' }, h('h1', null, p && p.name ? p.name : 'New listing'), p ? statusPill(p.status) : pill('New', '')), p && p.statusReason ? h('div', { class: 'notice warn' }, h('strong', null, 'From the moderator / system: '), p.statusReason) : null,
    locked ? h('div', { class: 'notice' }, 'This listing is ' + p.status.replace(/_/g, ' ') + ' and cannot be edited. Withdraw it from the Listings page to make changes.') : null,
    h('div', { class: 'steps', role: 'list' }, STEPS.map((s, i) => h('span', { role: 'listitem', class: i === step ? 'on' : (i < step ? 'done' : ''), 'aria-current': i === step ? 'step' : null }, (i + 1) + '. ' + s))));
  const nav = (next) => h('div', { class: 'actions' }, step > 0 ? h('button', { class: 'btn', type: 'button', onclick: () => { step--; draw(); } }, '← Back') : null, next);
  const refresh = async () => { p = (await GET('/api/seller/products/' + p.id)).product; };

  async function save(f, extra = {}) {
    const val = (n) => f[n] && f[n].value;
    let payload;
    if (step === 0) payload = { name: val('name'), brand: val('brand') || '', model: val('model') || '', category: +val('category'), subcategory: val('subcategory') || null, condition: val('condition'), description: val('description'), specs: form.specs.filter((s) => s.k && s.v), referenceInfo: val('referenceInfo') || '' };
    else if (step === 1) { form.shipsTo = f.world.checked ? ['WORLD'] : [...f.shipsList.selectedOptions].map((o) => o.value); payload = { currency: val('currency'), price: val('price'), quantity: +val('quantity'), sellerCountry: val('sellerCountry'), shipsTo: form.shipsTo, dispatchDays: +val('dispatchDays'), shippingFee: val('shippingFee') || '0', shippingNotes: val('shippingNotes') || '', returnsType: val('returnsType'), returnsDays: val('returnsDays') === '' ? null : +val('returnsDays'), returnsNotes: val('returnsNotes') || '', acceptsCash: f.acceptsCash.checked || !coinRights, acceptsCoins: coinRights && f.acceptsCoins.checked }; }
    if (p) { const r = await PATCH('/api/seller/products/' + p.id, payload); p = r.product; if (r.product.resetToDraft) toast('Your change sends this listing back to draft: it must be reviewed again.'); }
    else { const r = await POST('/api/seller/products', { ...payload, sellerCountry: me.profile.country }); p = r.product; history.replaceState(null, '', '#/dashboard/products/' + p.id); }
  }
  const stepForm = (render, after) => { const f = h('form', { novalidate: true, onsubmit: async (e) => { e.preventDefault(); if (locked || saving) return; saving = true; const b = f.querySelector('button.primary'); await submitting(b, async () => { try { await save(f); toast('Saved', 'ok'); step++; draw(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); saving = false; } }); render(f); return f; };

  function s0() {
    const catSel = h('select', { id: 'category', name: 'category', style: 'max-width:none;width:100%', onchange: (e) => fillSub(+e.target.value) }, h('option', { value: '' }, 'Choose…'), cats.map((c) => h('option', { value: c.id, selected: p && p.category === c.id }, c.name)));
    const subSel = h('select', { id: 'subcategory', name: 'subcategory', style: 'max-width:none;width:100%' });
    const fillSub = (cid) => { const c = cats.find((x) => x.id === cid); subSel.replaceChildren(h('option', { value: '' }, '(none)'), ...(c ? c.children : []).map((s) => h('option', { value: s.id, selected: p && p.subcategory === s.id }, s.name))); };
    fillSub(p ? p.category : 0);
    const specsBox = h('div'); const drawSpecs = () => specsBox.replaceChildren(...form.specs.map((s, i) => h('div', { class: 'row', style: 'margin:6px 0' }, h('input', { value: s.k, placeholder: 'e.g. Storage', 'aria-label': 'Specification name', style: 'flex:1', oninput: (e) => { s.k = e.target.value; } }), h('input', { value: s.v, placeholder: 'e.g. 256 GB', 'aria-label': 'Specification value', style: 'flex:1', oninput: (e) => { s.v = e.target.value; } }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Remove specification', onclick: () => { form.specs.splice(i, 1); drawSpecs(); } }, '✕'))), h('button', { type: 'button', class: 'btn small', onclick: () => { form.specs.push({ k: '', v: '' }); drawSpecs(); } }, '+ Add specification')); drawSpecs();
    return stepForm((f) => f.append(h('label', { for: 'name' }, 'Product name'), h('input', { id: 'name', name: 'name', value: p && p.name || '', maxlength: 120, required: true }),
      h('div', { class: 'two' }, h('div', null, h('label', { for: 'brand' }, 'Brand (optional)'), h('input', { id: 'brand', name: 'brand', value: p && p.brand || '' })), h('div', null, h('label', { for: 'model' }, 'Model (optional)'), h('input', { id: 'model', name: 'model', value: p && p.model || '' }))),
      h('div', { class: 'two' }, h('div', null, h('label', { for: 'category' }, 'Category'), catSel), h('div', null, h('label', { for: 'subcategory' }, 'Subcategory'), subSel)),
      h('label', { for: 'condition' }, 'Condition'), h('select', { id: 'condition', name: 'condition', style: 'max-width:none;width:100%' }, ['new', 'used', 'refurbished'].map((c) => h('option', { value: c, selected: p && p.condition === c }, c[0].toUpperCase() + c.slice(1)))),
      h('label', { for: 'description' }, 'Description (at least 20 characters. Be accurate: say about flaws, what is included and where it came from.)'), h('textarea', { id: 'description', name: 'description', maxlength: 5000, style: 'min-height:170px' }, p && p.description || ''),
      h('label', null, 'Specifications (optional)'), specsBox,
      h('label', { for: 'referenceInfo' }, 'Model / serial reference to show moderators (optional)'), h('input', { id: 'referenceInfo', name: 'referenceInfo', value: p && p.referenceInfo || '', maxlength: 200 }),
      nav(locked ? null : h('button', { class: 'btn primary', type: 'submit' }, 'Save and continue →'))));
  }
  function s1() {
    const lim = me.plan.limits.maxItemUsdMinor; const worldChk = h('input', { type: 'checkbox', name: 'world', checked: form.shipsTo.includes('WORLD'), onchange: (e) => { list.disabled = e.target.checked; } });
    const list = h('select', { name: 'shipsList', multiple: true, size: 8, style: 'max-width:none;width:100%', disabled: form.shipsTo.includes('WORLD') }, state.config.countries.map((c) => h('option', { value: c.code, selected: form.shipsTo.includes(c.code) }, c.name)));
    const price = p && p.price;
    return stepForm((f) => f.append(h('div', { class: 'notice' }, 'Your ' + me.plan.effectivePlanName + ' plan allows up to ', h('strong', null, usd(lim)), ' per item (checked in US dollars using the stored exchange rate), ', h('strong', null, me.plan.limits.maxActiveListings + ' item' + (me.plan.limits.maxActiveListings === 1 ? '' : 's')), ' for sale at a time, and ', h('strong', null, me.plan.limits.maxQuantity + ' unit' + (me.plan.limits.maxQuantity === 1 ? '' : 's')), ' per listing. When your item sells, you can list the next one. ', h('a', { href: '#/dashboard/plan' }, 'See plans.')),
      h('div', { class: 'two' }, h('div', null, h('label', { for: 'currency' }, 'Currency you will charge in'), h('select', { id: 'currency', name: 'currency', style: 'max-width:none;width:100%' }, state.config.currencies.map((c) => h('option', { value: c, selected: (price ? price.currency : (state.currency || 'USD')) === c }, c)))), h('div', null, h('label', { for: 'price' }, 'Price (what the buyer pays for one item)'), h('input', { id: 'price', name: 'price', inputmode: 'decimal', value: price ? (price.minor / 100).toFixed(2) : '', required: true }))),
      h('fieldset', { class: 'payopts' }, h('legend', null, 'How can buyers pay you?'),
        h('label', { class: 'payopt' }, h('input', { type: 'checkbox', name: 'acceptsCash', checked: p ? p.acceptsCash : true }), h('span', null, h('b', null, '💵 Cash (money)'), h('small', null, 'Buyer emails QYRRAVO and pays money, as before.'))),
        coinRights ? h('label', { class: 'payopt' }, h('input', { type: 'checkbox', name: 'acceptsCoins', checked: p ? p.acceptsCoins : false }), h('span', null, h('b', null, 'Ⓠ Q Coins'), h('small', null, 'Coin price follows your price: 100 Q Coins = $1. You are paid after delivery is confirmed.')))
          : h('div', { class: 'payopt locked' }, h('input', { type: 'checkbox', name: 'acceptsCoins', disabled: true }), h('span', null, h('b', null, 'Ⓠ Q Coins (staff only)'), h('small', null, 'Only the owner, admins and moderators can sell for Q Coins. Everyone can buy with them.'))),
        h('p', { class: 'hint', id: 'coinhint' }, 'Tick one or both.')),
      h('div', { class: 'two' }, h('div', null, h('label', { for: 'quantity' }, 'Quantity available'), h('input', { id: 'quantity', name: 'quantity', type: 'number', min: 1, max: me.plan.limits.maxQuantity, value: p && p.quantity || 1 })), h('div', null, h('label', { for: 'shippingFee' }, 'Shipping fee (0 = free)'), h('input', { id: 'shippingFee', name: 'shippingFee', inputmode: 'decimal', value: p ? (p.shippingFee.minor / 100).toFixed(2) : '0.00' }))),
      h('label', { for: 'sellerCountry' }, 'Item ships from'), h('select', { id: 'sellerCountry', name: 'sellerCountry', style: 'max-width:none;width:100%' }, state.config.countries.map((c) => h('option', { value: c.code, selected: c.code === (p && p.sellerCountry || me.profile.country) }, c.name))),
      h('label', { class: 'check' }, worldChk, 'I can ship worldwide'), h('label', { for: 'shipsList' }, 'Or choose the countries you ship to (hold Ctrl/Cmd to pick several)'), list,
      h('div', { class: 'two' }, h('div', null, h('label', { for: 'dispatchDays' }, 'Dispatch within (days)'), h('input', { id: 'dispatchDays', name: 'dispatchDays', type: 'number', min: 0, max: 60, value: p ? p.dispatchDays : 2 })), h('div', null, h('label', { for: 'shippingNotes' }, 'Shipping notes (optional)'), h('input', { id: 'shippingNotes', name: 'shippingNotes', value: p && p.shippingNotes || '' }))),
      h('div', { class: 'two' }, h('div', null, h('label', { for: 'returnsType' }, 'Returns'), h('select', { id: 'returnsType', name: 'returnsType', style: 'max-width:none;width:100%' }, [['returns_accepted', 'Returns accepted'], ['exchange_only', 'Exchange only'], ['no_returns', 'No returns']].map(([v, t]) => h('option', { value: v, selected: (p && p.returnsType || 'returns_accepted') === v }, t)))), h('div', null, h('label', { for: 'returnsDays' }, 'Return window (days)'), h('input', { id: 'returnsDays', name: 'returnsDays', type: 'number', min: 0, max: 90, value: p && p.returnsDays !== null && p.returnsDays !== undefined ? p.returnsDays : 14 }))),
      h('label', { for: 'returnsNotes' }, 'Return conditions (optional)'), h('input', { id: 'returnsNotes', name: 'returnsNotes', value: p && p.returnsNotes || '' }),
      nav(locked ? null : h('button', { class: 'btn primary', type: 'submit' }, 'Save and continue →'))));
  }
  function uploader(kind, label, many) {
    const out = h('div'); const prog = h('div', { class: 'progress', hidden: true }, h('i')); const msg = h('div', { class: 'hint', 'aria-live': 'polite' });
    const imgs = () => p.images.filter((i) => i.kind === kind);
    const drawImgs = () => out.replaceChildren(h('div', { class: 'imgs' }, imgs().map((i) => h('figure', null, h('img', { src: i.url + '?v=' + i.id, alt: 'Uploaded ' + i.kind + ' photo' }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Remove photo', disabled: locked, onclick: async () => { try { await DEL('/api/seller/products/' + p.id + '/images/' + i.id); await refresh(); drawImgs(); } catch (e) { toast(e.message, 'error'); } } }, '✕')))));
    const input = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', multiple: !!many, hidden: true, onchange: async (e) => { for (const file of [...e.target.files]) await send(file); e.target.value = ''; } });
    async function send(file) {
      if (file.size > 5 * 1024 * 1024) { toast(file.name + ' is larger than 5 MB.', 'error'); return; }
      prog.hidden = false; prog.firstChild.style.width = '0%'; msg.textContent = 'Uploading ' + file.name + '…';
      try { await upload('/api/seller/products/' + p.id + '/images?kind=' + kind, file, (x) => { prog.firstChild.style.width = Math.round(x * 100) + '%'; }); await refresh(); drawImgs(); msg.textContent = 'Uploaded. Location data and camera details are removed from JPEG/PNG files.'; }
      catch (err) { msg.textContent = ''; toast(err.message, 'error'); } finally { prog.hidden = true; }
    }
    const drop = h('div', { class: 'drop', tabindex: 0, role: 'button', 'aria-label': label, onclick: () => !locked && input.click(), onkeydown: (e) => { if ((e.key === 'Enter' || e.key === ' ') && !locked) { e.preventDefault(); input.click(); } }, ondragover: (e) => { e.preventDefault(); drop.classList.add('over'); }, ondragleave: () => drop.classList.remove('over'), ondrop: async (e) => { e.preventDefault(); drop.classList.remove('over'); if (locked) return; for (const file of [...e.dataTransfer.files]) await send(file); } }, label);
    drawImgs();
    const camBtn = h('button', { type: 'button', class: 'btn', disabled: locked, onclick: () => openCamera((file) => send(file)) }, '📷 Take photo with camera (back or front)');
    return h('div', null, drop, h('div', { class: 'actions', style: 'margin:8px 0' }, camBtn), input, prog, msg, out);
  }
  function s2() {
    if (!p) { return h('div', { class: 'notice warn' }, 'Save the details first.'); }
    return h('div', null, h('div', { class: 'notice' }, 'The first photo is your main photo. Photos must be real, show the actual item, be at least 500px wide, and be JPEG, PNG or WebP (max 5 MB). Do not use stock images or other sellers’ photos.'), h('h3', null, 'Main photo'), uploader('main', 'Drop the main photo here or click to choose', false),
      h('h3', { style: 'margin-top:18px' }, 'More photos (up to ' + 8 + ')'), uploader('extra', 'Add more photos (different angles, flaws, accessories)', true),
      nav(h('button', { class: 'btn primary', type: 'button', onclick: async () => { await refresh(); if (!p.images.some((i) => i.kind === 'main')) { toast('Add a main photo first.', 'error'); return; } step++; draw(); } }, 'Continue →')));
  }
  function s3() {
    const box = h('div'); let timer = null;
    const v = p.verification;
    const put = (...k) => box.replaceChildren(...k.flat(Infinity).filter(Boolean));
    const draw3 = () => {
      clearInterval(timer);
      const cur = p.verification; const hasPhoto = cur && cur.hasPhoto;
      put(
        h('div', { class: 'notice' }, h('strong', null, 'Why: '), 'Moderators need to see that the person listing the item has it in hand right now. QYRRAVO’s server makes a one-time code for this listing only. Write it on paper (or show it on a screen) and photograph it NEXT TO THE ITEM in a single picture. The code expires.'),
        cur && cur.status === 'code_issued' && !cur.expired ? [h('p', null, 'Your code:'), h('div', { class: 'code', 'aria-label': 'Verification code ' + cur.code.split('').join(' ') }, cur.code), h('p', { class: 'muted', id: 'cd' }, ''), uploader('verification', hasPhoto ? 'Replace the verification photo' : 'Drop your verification photo here or click to choose', false)] : [cur && cur.expired ? h('div', { class: 'notice warn' }, 'Your last code expired.') : null, h('p', { class: 'muted' }, cur && cur.status === 'more_info_required' ? 'The moderator asked for more information. Request a fresh code and take a new photo.' : 'You have no active code.')],
        !locked ? h('div', { class: 'actions' }, h('button', { class: 'btn' + (cur && cur.status === 'code_issued' && !cur.expired ? '' : ' primary'), type: 'button', onclick: async (e) => submitting(e.currentTarget, async () => { try { await POST('/api/seller/products/' + p.id + '/verification-code'); await refresh(); draw3(); } catch (err) { toast(err.message, 'error'); } }) }, cur && cur.status === 'code_issued' && !cur.expired ? 'Get a new code (invalidates the old one)' : 'Get my verification code')) : null);
      if (cur && cur.status === 'code_issued' && !cur.expired) { const tick = () => { const ms = new Date(cur.expiresAt) - Date.now(); const el = box.querySelector('#cd'); if (!el) return; if (ms <= 0) { clearInterval(timer); cur.expired = true; draw3(); return; } el.textContent = 'Expires in ' + Math.floor(ms / 60000) + ' min ' + String(Math.floor(ms / 1000) % 60).padStart(2, '0') + ' s. Take and upload the photo before then.'; }; tick(); timer = setInterval(tick, 1000); }
    };
    draw3();
    return h('div', null, box, nav(h('button', { class: 'btn primary', type: 'button', onclick: async () => { await refresh(); step++; draw(); } }, 'Continue →')));
  }
  function s4() {
    const miss = [];
    if (!p.name || p.name.length < 3) miss.push('Product name'); if (!p.description || p.description.length < 20) miss.push('Description (20+ characters)'); if (!p.category) miss.push('Category');
    if (!p.price) miss.push('Price'); if (!p.shipsTo.length) miss.push('Where you ship'); if (!p.images.some((i) => i.kind === 'main')) miss.push('Main photo');
    if (!p.verification || p.verification.status !== 'code_issued' && p.verification.status !== 'more_info_required' || !p.verification.hasPhoto) miss.push('Verification photo showing your current code');
    const price = p.price;
    const prev = h('div', { class: 'card', style: 'max-width:340px' }, p.images.find((i) => i.kind === 'main') ? h('img', { class: 'card-img', src: p.images.find((i) => i.kind === 'main').url, alt: '' }) : h('div', { class: 'ph' }, 'No photo'), h('div', { class: 'body' }, h('h3', null, p.name || '(no name)'), h('div', { class: 'muted small' }, flag(p.sellerCountry) + ' ' + me.profile.shopName), price ? h('div', { class: 'pricetag' }, fmt(price.minor, price.currency)) : h('div', { class: 'pricetag none' }, 'No price yet'), h('div', { class: 'small muted' }, p.shippingFee.minor ? '+ ' + fmt(p.shippingFee.minor, p.shippingFee.currency) + ' shipping' : 'Free shipping')));
    const canSubmit = !miss.length && ['draft', 'more_info_required', 'rejected'].includes(p.status);
    return h('div', null, h('p', { class: 'muted' }, 'This is how buyers will see your listing card. The verification photo is never shown to buyers.'), prev,
      miss.length ? h('div', { class: 'notice warn' }, h('strong', null, 'Still needed: '), miss.join(' · ')) : h('div', { class: 'notice' }, 'Everything is in place.'),
      ['submitted', 'under_review'].includes(p.status) ? h('div', { class: 'notice' }, 'Submitted. A moderator will review it. You will be notified.') : null,
      p.status === 'approved' ? h('div', { class: 'notice' }, p.publicNow ? 'Live on the marketplace.' : 'Approved, but currently paused (above your plan limit).') : null,
      nav(h('button', { class: 'btn primary', type: 'button', disabled: !canSubmit, onclick: async (e) => submitting(e.currentTarget, async () => { try { const r = await POST('/api/seller/products/' + p.id + '/submit', { submitKey }); p = r.product; (r.warnings || []).forEach((w) => toast(w)); toast(r.replay ? 'Already submitted.' : 'Submitted for review', 'ok'); go('dashboard/products'); } catch (err) { if (err.details && err.details.missing) toast('Please complete: ' + err.details.missing.map((m) => m.message).join(' '), 'error'); else toast(err.message, 'error'); } }) }, 'Submit for review')));
  }
  function draw() {
    const fns = [s0, s1, s2, s3, s4];
    body.replaceChildren(hdr());
    if (step > 0 && !p) { step = 0; }
    body.append(fns[step]());
    window.scrollTo({ top: 0 });
  }
  d.append(h('p', null, h('a', { href: '#/dashboard/products' }, '← All listings')), body); draw();
  return d;
}

// ---------- seller orders ----------
export async function sellerOrders() {
  const me = await sellerGuard('dashboard/orders'); if (!me) return h('div');
  const d = wide('Seller orders', h('h1', null, 'Orders'), tabs('dashboard/orders'));
  const r = await GET('/api/seller/orders');
  const reload = () => sellerOrders().then((n) => d.replaceWith(n));
  d.append(r.orders.length ? r.orders.map((o) => h('div', { class: 'panel' }, h('div', { class: 'row between' }, h('strong', null, o.orderNo), statusPill(o.status)), h('p', { class: 'muted small' }, dt(o.createdAt)),
    o.items.map((i) => h('div', null, i.quantity + ' × ' + i.name)), h('p', null, 'Total ', h('strong', null, fmt(o.totalMinor, o.currency)), o.commissionMinor !== undefined ? ' · marketplace fee ' + fmt(o.commissionMinor, o.currency) : ''),
    o.shipTo ? h('p', { class: 'small' }, 'Ship to: ' + [o.shipTo.name, o.shipTo.line1, o.shipTo.line2, o.shipTo.city, o.shipTo.region, o.shipTo.postal, countryName(o.shipTo.country)].filter(Boolean).join(', ')) : null,
    o.status === 'paid' ? h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => { const f = h('form', { onsubmit: async (e) => { e.preventDefault(); try { await POST('/api/seller/orders/' + o.id + '/ship', { tracking: f.tracking.value }); m.close(); toast('Marked as shipped', 'ok'); reload(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } } }, h('label', null, 'Tracking number'), h('input', { name: 'tracking', required: true }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Mark shipped'))); const m = modal('Ship order', f); } }, 'Mark as shipped'),
      h('button', { class: 'btn danger', onclick: async () => { const reason = prompt('Reason for cancelling (the buyer is refunded in full):'); if (reason) { try { await POST('/api/seller/orders/' + o.id + '/cancel', { reason }); toast('Refund requested'); reload(); } catch (err) { toast(err.message, 'error'); } } } }, 'Cancel and refund')) : null)) : empty('No orders yet', 'Orders appear here after the payment provider confirms payment.'));
  return d;
}

// ---------- finance ----------
export async function finance() {
  const me = await sellerGuard('dashboard/finance'); if (!me) return h('div');
  const r = await GET('/api/seller/finance');
  const d = wide('Money', h('h1', null, 'Money'), tabs('dashboard/finance'), h('div', { class: 'notice' }, r.explanation), !state.config.payment.checkoutAvailable ? h('div', { class: 'notice' }, 'Sales and payments are arranged by email. Contact ', h('a', { href: gmailUrl(state.config.site.supportEmail), target: '_blank', rel: 'noopener' }, state.config.site.supportEmail), ' about orders and getting paid.') : null);
  d.append(h('div', { class: 'panel' }, h('h2', null, 'Payout account'), h('p', null, 'Status: ', pill(r.payoutStatus, r.payoutStatus === 'verified' ? 'ok' : 'warn')),
    !r.payoutCountries.includes(r.sellerCountry) ? h('div', { class: 'notice warn' }, 'Payouts are not available in ' + countryName(r.sellerCountry) + ' yet. You can still prepare listings. Currently supported: ' + r.payoutCountries.map(countryName).join(', ') + '.') : r.payoutStatus !== 'verified' ? h('div', null, h('p', { class: 'muted' }, 'The payment provider verifies your identity and bank account. QYRRAVO never sees your bank details.'), h('button', { class: 'btn primary', onclick: async (e) => submitting(e.currentTarget, async () => { try { const x = await POST('/api/seller/payout-onboarding'); if (x.onboardingUrl) location.href = x.onboardingUrl; else if (x.simulator) { const y = await POST('/api/test-pay/onboarding/complete', {}); toast('Test mode: payout account marked verified (simulated).', 'ok'); await loadMe(); finance().then((n) => d.replaceWith(n)); } else toast('Payout set-up started.', 'ok'); } catch (err) { toast(err.message, 'error'); } }) }, state.config.payment.simulator ? 'Set up payouts (test mode)' : 'Set up payouts')) : null));
  d.append(h('div', { class: 'panel' }, h('h2', null, 'Balances'), r.balances.length ? h('table', null, h('thead', null, h('tr', null, ['Currency', 'Pending', 'Available', 'Paid out'].map((x) => h('th', null, x)))), h('tbody', null, r.balances.map((b) => h('tr', null, h('td', null, b.currency), h('td', null, fmt(b.pendingMinor, b.currency)), h('td', null, fmt(b.availableMinor, b.currency)), h('td', null, fmt(b.paidOutMinor || 0, b.currency)))))) : h('p', { class: 'muted' }, 'No money yet.'), h('p', { class: 'small muted' }, 'Marketplace fee: ' + r.fees.commissionPercent + '%' + (r.fees.placeholder ? ' (PLACEHOLDER, not final)' : '') + ' of ' + (r.fees.base === 'items' ? 'item totals' : 'items plus shipping') + (r.fees.fixedFeeUsdMinor ? ' + ' + usd(r.fees.fixedFeeUsdMinor) + ' per order' : '') + '. Provider fees may also apply.')));
  if (r.payouts.length) d.append(h('div', { class: 'panel' }, h('h2', null, 'Payouts'), r.payouts.map((p) => h('div', null, fmt(p.amountMinor, p.currency) + ' · ' + p.status + ' · ' + dOnly(p.createdAt)))));
  return d;
}

// ---------- plan ----------
export async function plan() {
  const me = await sellerGuard('dashboard/plan'); if (!me) return h('div');
  const s = await GET('/api/seller/subscription');
  const d = wide('Plan', h('h1', null, 'Your plan'), tabs('dashboard/plan'));
  const sub = s.subscription;
  d.append(h('p', null, 'Current: ', h('strong', null, s.effectivePlanName), ' · ', s.activeListings + ' of ' + s.limits.maxActiveListings + ' item' + (s.limits.maxActiveListings === 1 ? '' : 's') + ' for sale'));
  if (state.me.role === 'admin') d.append(h('div', { class: 'notice' }, 'As an administrator you have the VIP plan for free.'));
  d.append(h('p', { class: 'muted' }, 'On every plan you have one listing for sale at a time. A higher plan raises the maximum price and lets you stock more identical units in that listing: Free 1, Premium up to 10, VIP up to 100. When it sells out (or you withdraw it) you can list the next one.'));
  if (s.listingsPausedByPlan) d.append(h('div', { class: 'notice warn' }, s.listingsPausedByPlan + ' listing(s) are paused because they exceed your current limit. They come back when you upgrade.'));
  const rank = (id) => s.plans.findIndex((x) => x.id === id);
  const choose = (p) => submitting0(async () => { try { const r = await POST('/api/seller/subscription/checkout', { planId: p.id }); const u = r.checkoutUrl; if (u.includes('#/') && new URL(u).origin === location.origin) location.hash = u.slice(u.indexOf('#/')); else location.href = u; } catch (err) { toast(err.message, 'error'); } });
  const submitting0 = (fn) => (e) => submitting(e.currentTarget, fn);
  d.append(h('div', { class: 'three' }, s.plans.map((p) => {
    const cur = p.id === s.effectivePlan;
    const btn = p.priceMinor === 0 ? null
      : state.me.role === 'admin' ? null
      : true ? h('button', { class: 'btn primary', onclick: () => emailPrompt({ title: 'Get ' + p.name, intro: 'To get the ' + p.name + ' plan, send this email to ', subject: 'I want the ' + p.name + ' plan', body: 'I would like to buy the ' + p.name + ' plan (' + fmt(p.priceMinor, p.currency) + ' per month, items up to ' + usd(p.maxItemUsdMinor) + ' each).\n\nI will pay by cash or card. Please tell me how to pay and switch it on for my account.' }) }, 'Buy ' + p.name)
      : cur && !(sub && sub.cancelAtPeriodEnd) ? null
      : rank(p.id) < rank(s.effectivePlan) && s.effectivePlan !== 'free' ? h('p', { class: 'muted small' }, 'To move to a cheaper plan, cancel your current plan and choose this one when it ends.')
      : h('button', { class: 'btn primary', onclick: choose(p) }, ((rank(p.id) > rank(s.effectivePlan) && s.effectivePlan !== 'free' ? 'Upgrade to ' : 'Choose ') + p.name));
    return h('div', { class: 'panel' + (cur ? ' current' : '') }, h('h2', null, p.name, cur ? ' ' : null, cur ? pill('Current', 'ok') : null),
      h('p', { style: 'font-size:1.5rem;margin:6px 0' }, p.priceMinor ? fmt(p.priceMinor, p.currency) + ' / month' : '$0'),
      h('p', null, 'Up to ', h('strong', null, usd(p.maxItemUsdMinor)), ' per item'),
      h('ul', { class: 'prose' }, p.features.map((f) => h('li', null, f))), btn);
  })));
  d.append(h('p', { class: 'muted small' }, 'To get Premium or VIP, press Buy and send the prepared email to qyrravo@gmail.com. We reply with the next steps and switch the plan on for your account after payment is confirmed. Upgrading starts a new paid month today; time left on your old plan is not credited.'));
  if (sub && sub.planId !== 'free' && ['active', 'past_due', 'canceled'].includes(sub.status)) d.append(h('div', { class: 'panel' }, h('h2', null, 'Subscription'), h('dl', { class: 'kv' }, h('dt', null, 'Plan'), h('dd', null, (s.plans.find((x) => x.id === sub.planId) || {}).name || sub.planId), h('dt', null, 'Status'), h('dd', null, sub.status), h('dt', null, 'Paid until'), h('dd', null, sub.currentPeriodEnd ? dt(sub.currentPeriodEnd) : '—'), h('dt', null, 'Renews'), h('dd', null, sub.cancelAtPeriodEnd ? 'No. Cancelled; keeps the plan until the date above.' : 'Yes, monthly')),
    sub.cancelAtPeriodEnd ? null : h('button', { class: 'btn danger', onclick: async (e) => submitting(e.currentTarget, async () => { if (!confirm('Cancel your plan? You keep it until the end of the paid period.')) return; try { await POST('/api/seller/subscription/cancel'); toast('Cancelled. Your plan stays until the paid period ends.', 'ok'); plan().then((n) => d.replaceWith(n)); } catch (err) { toast(err.message, 'error'); } }) }, 'Cancel subscription')));
  return d;
}
