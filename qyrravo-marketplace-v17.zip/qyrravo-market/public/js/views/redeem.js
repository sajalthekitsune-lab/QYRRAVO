import { h, state, GET, POST, toast, dt, dOnly, fieldErr, submitting, emailPrompt } from '../core.js';
import { go } from '../app.js';

const usd = (n) => '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
const coin = (n) => h('span', { class: 'qcoin' }, h('i', { 'aria-hidden': 'true' }, 'Q'), Number(n).toLocaleString('en-US'));
const copy = async (t) => { try { await navigator.clipboard.writeText(t); toast('Copied', 'ok'); } catch { toast('Copy failed. Select the code and copy it.', 'error'); } };

export async function redeem() {
  const d = h('div', { class: 'wrap block', dataset: { title: 'Redeem' } });
  d.append(h('div', { class: 'phero rhero' }, h('div', { class: 'phero-ic', 'aria-hidden': 'true' }, '🎟️'),
    h('div', null, h('h1', null, 'Q Coin Shop & Code Redeem'), h('p', { class: 'muted' }, 'Got a QYRRAVO code from a giveaway or a gift? Redeem it here to add Q Coins to your wallet.'))));
  if (!state.me) {
    d.append(h('div', { class: 'panel' }, h('h2', null, 'Sign in to redeem'), h('p', { class: 'muted' }, 'Your Q Coins live in your QYRRAVO account.'), h('a', { class: 'btn primary', href: '#/login?next=redeem' }, 'Sign in')));
    return d;
  }
  const w = await GET('/api/wallet');
  const reload = () => redeem().then((n) => d.replaceWith(n));
  d.append(h('div', { class: 'wallet' },
    h('div', null, h('div', { class: 'eyebrow' }, 'Your wallet'), h('div', { class: 'wbal' }, coin(w.coins)), h('div', { class: 'muted' }, 'Worth about ' + usd(w.dollars) + ' · ' + w.coinsPerUsd + ' Q Coins = $1')),
    (() => {
      const f = h('form', { class: 'rform', onsubmit: async (e) => { e.preventDefault(); const b = f.querySelector('button'); await submitting(b, async () => { try { const r = await POST('/api/redeem', { code: f.code.value }); toast('🎉 +' + r.coins + ' Q Coins · ' + r.reward, 'ok'); reload(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); } },
        h('label', null, 'Enter your code'), h('div', { class: 'row' }, h('input', { name: 'code', placeholder: 'QYR-XXXX-XXXX-XXXX', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Redeem code' }), h('button', { class: 'btn primary', type: 'submit' }, 'Redeem')));
      return f;
    })()));
  const packs = await GET('/api/coin-packs'); const myReq = (await GET('/api/coin-requests/mine')).requests;
  const ask = async (coins) => {
    try {
      const r = await POST('/api/coin-requests', { coins });
      emailPrompt({ title: 'Send your request', intro: 'Your request #' + r.id + ' is saved. Now email ', subject: 'Buy ' + r.coins.toLocaleString('en-US') + ' Q Coins (request #' + r.id + ')', body: 'I would like to buy ' + r.coins.toLocaleString('en-US') + ' Q Coins for $' + r.dollars + '.\n\nPayment: I will pay by cash or card. Please tell me how to pay. When you confirm my payment, please add the coins to my wallet.' });
      reload();
    } catch (err) { toast(err.message, 'error'); }
  };
  const custom = h('form', { class: 'row', onsubmit: (e) => { e.preventDefault(); const v = Math.round(Number(custom.amt.value) * 100); if (!(v >= 100)) { toast('Enter at least $1.', 'error'); return; } ask(v); } }, h('input', { name: 'amt', type: 'number', min: '1', max: '1000', step: '1', placeholder: 'Other amount in $', style: 'max-width:180px', 'aria-label': 'Other amount in dollars' }), h('button', { class: 'btn small', type: 'submit' }, 'Request'));
  d.append(h('div', { class: 'panel buycoins' }, h('h2', null, 'Buy Q Coins'), h('p', { class: 'muted' }, 'Pick an amount and send QYRRAVO an email. You pay by cash or card, arranged by email, and the owner adds the coins to your wallet once the payment is confirmed.'),
    h('div', { class: 'packs' }, packs.packs.map((x) => h('button', { class: 'pack', type: 'button', onclick: () => ask(x.coins) }, coin(x.coins), h('span', { class: 'muted small' }, '$' + x.dollars)))), custom,
    myReq.length ? h('div', { style: 'margin-top:14px' }, h('h3', null, 'Your requests'), h('ul', { class: 'ledger' }, myReq.map((x) => h('li', null, h('span', null, '#' + x.id + ' · ' + x.coins.toLocaleString('en-US') + ' Q ($' + x.dollars + ')'), h('b', { class: x.status === 'delivered' ? 'plus' : x.status === 'cancelled' ? 'minus' : '' }, x.status === 'pending' ? 'waiting for payment' : x.status), h('small', { class: 'muted' }, dt(x.createdAt)))))) : null));
  if (w.myCodes.length) d.append(h('div', { class: 'panel' }, h('h2', null, '🏆 Your prize codes'), h('p', { class: 'muted small' }, 'These codes were made for you and work only on your account.'),
    h('div', { class: 'codes' }, w.myCodes.map((c) => h('div', { class: 'codecard' + (c.redeemed ? ' used' : '') }, h('div', null, h('code', null, c.code), h('div', { class: 'small muted' }, c.reward + ' · ' + usd(c.dollars) + ' (' + c.coins + ' Q)')),
      c.redeemed ? h('span', { class: 'pill' }, 'Redeemed') : h('div', { class: 'row' }, h('button', { class: 'btn small', type: 'button', onclick: () => copy(c.code) }, 'Copy'), h('button', { class: 'btn small primary', type: 'button', onclick: async () => { try { const r = await POST('/api/redeem', { code: c.code }); toast('🎉 +' + r.coins + ' Q Coins', 'ok'); reload(); } catch (err) { toast(err.message, 'error'); } } }, 'Redeem now')))))));
  const mine = (await GET('/api/purchase-requests/mine')).requests;
  if (mine.length) d.append(h('div', { class: 'panel' }, h('h2', null, 'My Q Coins purchases'), h('div', { class: 'codes' }, mine.map((x) => h('div', { class: 'codecard' + (x.state === 'refunded' ? ' used' : '') }, h('div', null, h('b', null, 'Request #' + x.id + ' · ' + x.coins.toLocaleString('en-US') + ' Q'), h('div', { class: 'small muted', style: 'white-space:pre-wrap' }, x.summary.split('\n')[0]), h('div', { class: 'small' }, x.stateText)),
    x.canCancel ? h('button', { class: 'btn small danger', type: 'button', onclick: async () => { if (!confirm('Cancel this order and get your coins back?')) return; try { await POST('/api/purchase-requests/' + x.id + '/cancel'); toast('Cancelled. Coins refunded.', 'ok'); reload(); } catch (err) { toast(err.message, 'error'); } } }, 'Cancel and refund') : null)))));
  d.append(h('div', { class: 'panel' }, h('h2', null, 'History'), w.history.length ? h('ul', { class: 'ledger' }, w.history.map((x) => h('li', null, h('span', null, x.reason), h('b', { class: x.delta >= 0 ? 'plus' : 'minus' }, (x.delta >= 0 ? '+' : '') + x.delta + ' Q'), h('small', { class: 'muted' }, dt(x.at))))) : h('p', { class: 'muted' }, 'Nothing yet. Redeem a code to get started.')));
  if (state.me.isOwner) d.append(await ownerPanel());
  return d;
}

async function ownerPanel() {
  const r = await GET('/api/owner/codes');
  const box = h('div', { class: 'panel owner-codes' });
  const reload = () => ownerPanel().then((n) => box.replaceWith(n));
  const f = h('form', { onsubmit: async (e) => { e.preventDefault(); await submitting(f.querySelector('button'), async () => { try { const x = await POST('/api/owner/codes', { reward: f.reward.value, dollars: f.dollars.value, maxUses: f.maxUses.value, days: f.days.value }); toast('Code created: ' + x.code, 'ok'); copy(x.code); reload(); } catch (err) { if (!fieldErr(f, err)) toast(err.message, 'error'); } }); } },
    h('h2', null, '👑 Create a code ', h('span', { class: 'pill' }, 'owner only')),
    h('div', { class: 'two' }, h('div', null, h('label', null, 'Reward (what the winner gets)'), h('input', { name: 'reward', placeholder: 'Free headphones credit' })), h('div', null, h('label', null, 'Value in $'), h('input', { name: 'dollars', type: 'number', min: '0.01', step: '0.01', placeholder: '10' }))),
    h('div', { class: 'two' }, h('div', null, h('label', null, 'Times it can be used'), h('input', { name: 'maxUses', type: 'number', min: '1', value: '1' })), h('div', null, h('label', null, 'Expires after (days, optional)'), h('input', { name: 'days', type: 'number', min: '1', placeholder: 'never' }))),
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Generate code')),
    h('p', { class: 'muted small' }, 'To give a code to a giveaway winner automatically, add a prize code value when you create the event. The code is made when you draw the winner and works only for them.'));
  const rq = (await GET('/api/owner/coin-requests')).requests;
  const g = h('form', { class: 'panel', style: 'margin:0 0 18px', onsubmit: async (e) => { e.preventDefault(); await submitting(g.querySelector('button'), async () => { try { const x = await POST('/api/owner/gift', { email: g.email.value, dollars: g.dollars.value, note: g.note.value }); toast('Gifted ' + x.coins.toLocaleString('en-US') + ' Q Coins to ' + x.name, 'ok'); g.reset(); } catch (err) { if (!fieldErr(g, err)) toast(err.message, 'error'); } }); } },
    h('h2', null, '🎁 Gift Q Coins'), h('div', { class: 'two' }, h('div', null, h('label', null, 'Account email'), h('input', { name: 'email', type: 'email', placeholder: 'friend@gmail.com' })), h('div', null, h('label', null, 'Value in $'), h('input', { name: 'dollars', type: 'number', min: '0.01', step: '0.01', placeholder: '5' }))),
    h('label', null, 'Note (optional)'), h('input', { name: 'note', placeholder: 'Thanks for being here', maxlength: 120 }), h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'submit' }, 'Send gift')));
  const req = h('div', { class: 'panel', style: 'margin:0 0 18px' }, h('h2', null, 'Coin purchase requests'), rq.length ? h('div', { class: 'codes' }, rq.map((x) => h('div', { class: 'codecard' + (x.status !== 'pending' ? ' used' : '') }, h('div', null, h('b', null, x.coins.toLocaleString('en-US') + ' Q · $' + x.dollars), h('div', { class: 'small muted' }, x.name + ' · ' + x.email + ' · ' + dt(x.createdAt))),
    x.status === 'pending' ? h('div', { class: 'row' }, h('button', { class: 'btn small primary', type: 'button', onclick: async () => { if (!confirm('Add ' + x.coins + ' Q Coins to ' + x.email + '? Only do this after you received their payment.')) return; try { await POST('/api/owner/coin-requests/' + x.id + '/deliver'); toast('Coins delivered', 'ok'); reload(); } catch (err) { toast(err.message, 'error'); } } }, 'Payment received: add coins'), h('button', { class: 'btn small', type: 'button', onclick: async () => { await POST('/api/owner/coin-requests/' + x.id + '/cancel'); reload(); } }, 'Cancel')) : h('span', { class: 'pill' }, x.status)))) : h('p', { class: 'muted' }, 'No requests yet.'));
  box.append(g, req, f, h('h3', { style: 'margin-top:18px' }, 'All codes'), r.codes.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'table' }, h('thead', null, h('tr', null, ['Code', 'Reward', 'Value', 'Used', 'Expires', 'For', ''].map((x) => h('th', null, x)))),
    h('tbody', null, r.codes.map((c) => h('tr', { class: c.active ? '' : 'off' }, h('td', null, h('code', null, c.code)), h('td', null, c.reward), h('td', null, usd(c.dollars) + ' · ' + c.coins + ' Q'), h('td', null, c.uses + '/' + c.maxUses), h('td', null, c.expiresAt ? dOnly(c.expiresAt) : 'never'), h('td', null, c.assignedTo || 'anyone'),
      h('td', null, h('button', { class: 'btn small', type: 'button', onclick: () => copy(c.code) }, 'Copy'), ' ', h('button', { class: 'btn small', type: 'button', onclick: async () => { await POST('/api/owner/codes/' + c.id + '/toggle'); reload(); } }, c.active ? 'Disable' : 'Enable'))))))) : h('p', { class: 'muted' }, 'No codes yet.'));
  return box;
}
