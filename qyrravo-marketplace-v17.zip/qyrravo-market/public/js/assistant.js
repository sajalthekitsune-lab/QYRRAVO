import { h, state, POST, gmailUrl } from './core.js';

// Floating help assistant. Answers every question; says so honestly when it is not sure.
export function mountAssistant() {
  if (document.getElementById('qy-assistant')) return;
  const email = state.config.site.supportEmail;
  const history = [];
  const log = h('div', { class: 'ai-log', role: 'log', 'aria-live': 'polite' });
  const say = (who, text) => { const b = h('div', { class: 'ai-msg ' + who }, text); log.append(b); log.scrollTop = log.scrollHeight; return b; };
  const input = h('input', { type: 'text', maxlength: 1000, placeholder: 'Ask me anything…', 'aria-label': 'Your question', autocomplete: 'off' });
  const send = h('button', { class: 'btn primary small', type: 'submit' }, 'Send');
  const form = h('form', { class: 'ai-form', onsubmit: async (e) => {
    e.preventDefault(); const q = input.value.trim(); if (!q) return;
    input.value = ''; say('me', q); history.push({ role: 'user', content: q });
    const wait = say('bot', '…'); send.disabled = true;
    try { const r = await POST('/api/assistant', { messages: history }); wait.textContent = r.reply; history.push({ role: 'assistant', content: r.reply }); }
    catch (err) { wait.textContent = 'Sorry, I could not answer just now. Please email ' + email + '.'; history.pop(); }
    send.disabled = false; input.focus(); log.scrollTop = log.scrollHeight;
  } }, input, send);
  const panel = h('section', { class: 'ai-panel', hidden: true, 'aria-label': 'QYRRAVO help' },
    h('header', null, h('strong', null, '🤖 QYRRAVO helper'), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close help', onclick: () => toggle(false) }, '×')),
    log, form,
    h('p', { class: 'small muted ai-foot' }, (state.config.site.assistantAi ? 'AI assistant. ' : 'Automatic helper. ') + 'It can make mistakes. For anything important email ', h('a', { href: gmailUrl(email), target: '_blank', rel: 'noopener' }, email), '.'));
  const fab = h('button', { class: 'ai-fab', type: 'button', 'aria-label': 'Open help chat', 'aria-expanded': 'false', onclick: () => toggle(panel.hidden) }, '💬 Help');
  function toggle(open) { panel.hidden = !open; fab.setAttribute('aria-expanded', String(open)); if (open) { if (!log.children.length) say('bot', 'Hi! I am the QYRRAVO helper. Ask me anything about buying, selling, plans, photos or your account.'); input.focus(); } }
  document.body.append(h('div', { id: 'qy-assistant' }, panel, fab));
}
