// Core helpers: DOM builder (XSS-safe: strings are always text), API client, shared state, money formatting.
// Logo for every theme: the white-on-black logo for dark and future mode, the dark-on-white logo for light mode (CSS shows the right one)
export function logoImg(kind, attrs = {}) {
  const { class: cls = '', style = '', alt = 'QYRRAVO' } = attrs;
  return h('span', { class: 'lg ' + cls, style, role: 'img', 'aria-label': alt },
    h('img', { class: 'lg-d', src: '/assets/logo-' + kind + '-dark.png', alt: '', draggable: 'false' }),
    h('img', { class: 'lg-l', src: '/assets/logo-' + kind + '-light.png', alt: '', draggable: 'false' }));
}
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'hidden' || k === 'selected' || k === 'required' || k === 'multiple') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  const add = (c) => {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) return c.forEach(add);
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  };
  kids.forEach(add);
  return el;
}
// replaceChildren/append must ignore null/false and flatten arrays (the native versions print "null").
const _rc = Element.prototype.replaceChildren;
Element.prototype.replaceChildren = function (...k) { return _rc.apply(this, k.flat(Infinity).filter((x) => x !== null && x !== undefined && x !== false)); };
const _ap = Element.prototype.append;
Element.prototype.append = function (...k) { return _ap.apply(this, k.flat(Infinity).filter((x) => x !== null && x !== undefined && x !== false)); };
export const $ = (s, r = document) => r.querySelector(s);
export const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

export const state = {
  config: null, me: null, csrf: '',
  country: lsGet('qy_country', null), currency: lsGet('qy_currency', null),
};
export function lsGet(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } }
export function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked: fine */ } }

// ---------- API ----------
export class ApiError extends Error { constructor(status, body) { super((body && body.error && body.error.message) || 'Something went wrong.'); this.status = status; this.code = body && body.error && body.error.code; this.field = body && body.error && body.error.field; this.details = body && body.error; } }
export async function api(method, url, body, opts = {}) {
  const headers = {};
  if (state.csrf && method !== 'GET') headers['x-csrf-token'] = state.csrf;
  let payload;
  if (body !== undefined && !opts.raw) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); } else if (opts.raw) payload = body;
  let r;
  try { r = await fetch(url, { method, headers, body: payload, credentials: 'same-origin' }); } catch (e) { throw new ApiError(0, { error: { code: 'network', message: 'Cannot reach QYRRAVO. Check your connection and try again.' } }); }
  let j = null;
  try { j = await r.json(); } catch { /* not json */ }
  if (j && j.csrfToken) state.csrf = j.csrfToken;
  if (!r.ok) throw new ApiError(r.status, j);
  return j;
}
export const GET = (u) => api('GET', u);
export const POST = (u, b) => api('POST', u, b === undefined ? {} : b);
export const PATCH = (u, b) => api('PATCH', u, b);
export const DEL = (u, b) => api('DELETE', u, b);
// Upload with progress (fetch has no upload progress, so XHR)
export function upload(url, file, onProgress) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('POST', url);
    x.setRequestHeader('x-csrf-token', state.csrf);
    x.setRequestHeader('content-type', 'application/octet-stream');
    x.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
    x.onerror = () => reject(new ApiError(0, { error: { message: 'Upload failed. Check your connection.' } }));
    x.onload = () => { let j = null; try { j = JSON.parse(x.responseText); } catch { /* */ } if (x.status >= 200 && x.status < 300) resolve(j); else reject(new ApiError(x.status, j)); };
    x.send(file);
  });
}

// ---------- session ----------
export async function loadMe() {
  const j = await GET('/api/me');
  state.me = j.user ? { ...j.user, permissions: j.permissions || [], seller: j.seller, unread: j.unreadNotifications } : null;
  if (j.csrfToken) state.csrf = j.csrfToken;
  return state.me;
}
export const can = (p) => !!(state.me && state.me.permissions.includes(p));

// ---------- money ----------
const EXP = {};
export function exponent(cur) { if (cur in EXP) return EXP[cur]; try { EXP[cur] = new Intl.NumberFormat('en', { style: 'currency', currency: cur }).resolvedOptions().maximumFractionDigits; } catch { EXP[cur] = 2; } return EXP[cur]; }
export function fmt(minor, cur) { try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: cur }).format(minor / Math.pow(10, exponent(cur))); } catch { return (minor / 100).toFixed(2) + ' ' + cur; } }
export function rateOf(cur) { const r = state.config && state.config.rates.find((x) => x.currency === cur); return r || null; }
// Convert using the stored rates (units per 1 USD). Returns null when no rate is known.
export function convert(minor, from, to) {
  if (from === to) return minor;
  const a = from === 'USD' ? { ratePerUsd: 1 } : rateOf(from); const b = to === 'USD' ? { ratePerUsd: 1 } : rateOf(to);
  if (!a || !b) return null;
  const major = minor / Math.pow(10, exponent(from));
  return Math.round((major / a.ratePerUsd) * b.ratePerUsd * Math.pow(10, exponent(to)));
}
// Price: the seller's own price is ALWAYS shown (it is what you pay). A converted figure is a labelled estimate.
export function priceEl(minor, cur, { size = '' } = {}) {
  const show = state.currency || 'USD';
  const main = h('span', { class: 'price-main' }, fmt(minor, cur));
  if (show === cur) return h('span', { class: 'price ' + size }, main);
  const c = convert(minor, cur, show);
  const r = rateOf(show);
  return h('span', { class: 'price ' + size }, main, c === null ? null : h('span', { class: 'price-est', title: 'Estimate using stored rate (' + (r ? r.source : '') + '). The seller charges in ' + cur + '. Your bank may use a different rate.' }, ' ≈ ', fmt(c, show), ' est.'));
}
export const countryName = (code) => { const c = state.config && state.config.countries.find((x) => x.code === code); return c ? c.name : code; };
export const flag = (code) => (code && code.length === 2 ? String.fromCodePoint(...[...code.toUpperCase()].map((ch) => 127397 + ch.charCodeAt(0))) : '🌐');
export const dt = (s) => { try { return new Date(s).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); } catch { return s || ''; } };
export const dOnly = (s) => { try { return new Date(s).toLocaleDateString(undefined, { dateStyle: 'medium' }); } catch { return s || ''; } };

// ---------- UI atoms ----------
export function toast(msg, kind = 'info') {
  const t = h('div', { class: 'toast ' + kind, role: kind === 'error' ? 'alert' : 'status' }, msg);
  $('#toasts').append(t); setTimeout(() => t.remove(), kind === 'error' ? 8000 : 4500);
}
export function fieldErr(form, err) {
  form.querySelectorAll('.field-error').forEach((e) => e.remove());
  if (err && err.field) { const inp = form.querySelector('[name="' + err.field + '"]'); if (inp) { inp.setAttribute('aria-invalid', 'true'); inp.after(h('div', { class: 'field-error', role: 'alert' }, err.message)); inp.focus(); return true; } }
  return false;
}
export function modal(title, body, { wide = false, onClose = null } = {}) {
  const root = $('#modal-root'); const prev = document.activeElement; let closed = false;
  const close = () => { if (closed) return; closed = true; if (onClose) onClose(); overlay.remove(); document.removeEventListener('keydown', onKey); if (prev && prev.focus) prev.focus(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const box = h('div', { class: 'modal' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, h('div', { class: 'modal-head' }, h('h2', null, title), h('button', { class: 'icon-btn', 'aria-label': 'Close', onclick: close }, '✕')), body);
  const overlay = h('div', { class: 'overlay', onclick: (e) => { if (e.target === overlay) close(); } }, box);
  root.append(overlay); document.addEventListener('keydown', onKey);
  const f = box.querySelector('input,button.primary,button'); if (f) f.focus();
  return { close, box };
}
export const skeletonGrid = (n = 8) => h('div', { class: 'grid' }, Array.from({ length: n }, () => h('div', { class: 'card skel' }, h('div', { class: 'skel-img' }), h('div', { class: 'skel-line' }), h('div', { class: 'skel-line short' }))));
export const empty = (title, text, action) => h('div', { class: 'empty' }, h('h3', null, title), text ? h('p', null, text) : null, action || null);
export const errorBox = (e, retry) => h('div', { class: 'errorbox', role: 'alert' }, h('strong', null, 'Something went wrong. '), e.message || String(e), retry ? h('button', { class: 'btn', onclick: retry }, 'Try again') : null);
export function pill(text, kind = '') { return h('span', { class: 'pill ' + kind }, text); }
export const STATUS = {
  draft: ['Draft', ''], submitted: ['Submitted', 'info'], under_review: ['Under review', 'info'], more_info_required: ['More info required', 'warn'],
  approved: ['Approved', 'ok'], rejected: ['Rejected', 'bad'], suspended: ['Suspended', 'bad'],
  pending_payment: ['Awaiting payment', 'warn'], payment_failed: ['Payment failed', 'bad'], paid: ['Paid', 'ok'], shipped: ['Shipped', 'info'],
  delivered: ['Delivered', 'ok'], completed: ['Completed', 'ok'], cancelled: ['Cancelled', ''], refunded: ['Refunded', ''], disputed: ['Dispute open', 'bad'],
};
export const statusPill = (s) => { const [t, k] = STATUS[s] || [s, '']; return pill(t, k); };
export const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export function link(href, text, cls) { return h('a', { href, class: cls }, text); }
export function formData(form) { const o = {}; new FormData(form).forEach((v, k) => { o[k] = v; }); return o; }
export async function submitting(btn, fn) {
  if (btn.disabled) return; const t = btn.textContent; btn.disabled = true; btn.setAttribute('aria-busy', 'true'); btn.textContent = 'Please wait…';
  try { return await fn(); } finally { btn.disabled = false; btn.removeAttribute('aria-busy'); btn.textContent = t; }
}

// ---------- contact-by-email purchases ----------
// Buying an item or a paid plan is arranged by email with QYRRAVO. This shows a ready-to-send message.
export const gmailUrl = (to, subject = '', body = '') => 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(to) + (subject ? '&su=' + encodeURIComponent(subject) : '') + (body ? '&body=' + encodeURIComponent(body) : '');
export function emailPrompt({ title, intro, subject, body }) {
  const to = (state.config && state.config.site && state.config.site.supportEmail) || 'qyrravo@gmail.com';
  const full = 'Hello QYRRAVO,\n\n' + body + '\n\n' + (state.me ? 'My QYRRAVO account email: ' + state.me.email + '\n' : '') + 'My country: ' + (state.country || '(not chosen)') + '\n\nThank you.';
  const ta = h('textarea', { readonly: true, rows: 9, 'aria-label': 'Email text', style: 'width:100%;font-family:inherit' }, full);
  const copy = h('button', { class: 'btn', type: 'button', onclick: async () => { try { await navigator.clipboard.writeText('To: ' + to + '\nSubject: ' + subject + '\n\n' + full); toast('Copied. Paste it into an email to ' + to, 'ok'); } catch { ta.select(); toast('Press Ctrl+C (or copy) to copy the text.'); } } }, 'Copy text');
  const mail = h('a', { class: 'btn primary', href: gmailUrl(to, subject, full), target: '_blank', rel: 'noopener' }, '✉ Open in Gmail');
  const other = h('a', { class: 'btn', href: 'mailto:' + to + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(full) }, 'Other mail app');
  const box = h('div', null,
    h('p', null, intro || 'To continue, send this email to ', h('strong', null, to), '.'),
    h('p', { class: 'small muted' }, 'To: ', h('strong', null, to), ' · Subject: ', h('strong', null, subject)), ta,
    h('div', { class: 'actions', style: 'margin-top:10px' }, mail, other, copy),
    h('p', { class: 'small muted', style: 'margin-top:10px' }, 'QYRRAVO will reply with the next steps. Payment (cash or card) is arranged with you by email. Never send passwords or card numbers by email.'));
  return modal(title, box);
}

// ---------- owner crown ----------
export function ownerCard() {
  const o = (state.config && state.config.site && state.config.site.owner) || {};
  return modal('The owner of QYRRAVO', h('div', { class: 'owner-card' },
    logoImg('mark', { alt: 'QYRRAVO logo', class: 'owner-logo' }),
    h('h3', null, 'QYRRAVO ', h('span', { 'aria-hidden': 'true' }, '👑')),
    h('p', null, h('strong', null, o.name || 'Sajal Dhungana'), ' is the owner and founder of QYRRAVO.'),
    h('dl', { class: 'kv' }, h('dt', null, 'Role'), h('dd', null, 'Owner (👑 only this account has the crown)'), h('dt', null, 'From'), h('dd', null, o.from || 'Nepal'), h('dt', null, 'Lives in'), h('dd', null, o.livesIn || 'Qatar'), h('dt', null, 'Contact'), h('dd', null, h('a', { href: gmailUrl(o.email || 'qyrravo@gmail.com'), target: '_blank', rel: 'noopener' }, o.email || 'qyrravo@gmail.com'))),
    h('p', { class: 'muted small' }, 'If someone else uses a crown or the QYRRAVO name, it is not the owner. Report it.'),
    h('p', null, h('a', { class: 'btn small', href: '#/owner', onclick: () => document.querySelector('#modal-root .overlay') && document.querySelector('#modal-root .overlay').remove() }, 'Open owner profile'))));
}
// Renders a name; a 👑 in it becomes a hoverable, clickable crown.
export function nameTag(name) {
  const s = String(name || ''); const i = s.indexOf('👑');
  if (i < 0) return document.createTextNode(s);
  return h('span', { class: 'nametag' }, s.slice(0, i), h('button', { type: 'button', class: 'crown', title: 'Owner of QYRRAVO: click to learn about the owner', 'aria-label': 'Owner of QYRRAVO. Click to learn about the owner', onclick: (e) => { e.preventDefault(); e.stopPropagation(); ownerCard(); } }, '👑'), s.slice(i + 2));
}


// ---------- social links (footer + wiki) ----------
export const SOCIALS = [
  { name: 'YouTube', url: 'https://youtube.com/@qyrravo?si=pnC8WqoETuKhjODK', cls: 'yt', svg: '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="4" y="10" width="40" height="28" rx="9" fill="currentColor"/><path d="M20 17.5v13l11-6.5z" fill="#fff"/></svg>' },
  { name: 'Instagram', url: 'https://www.instagram.com/qyrravo/', cls: 'ig', svg: '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="6" y="6" width="36" height="36" rx="11" fill="currentColor"/><circle cx="24" cy="24" r="8" fill="none" stroke="#fff" stroke-width="3.4"/><circle cx="33.5" cy="14.5" r="2.4" fill="#fff"/></svg>' },
  { name: 'Discord', url: 'https://discord.com/invite/KEsqYURcb', cls: 'dc', svg: '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M10 12h28a4 4 0 0 1 4 4v15a4 4 0 0 1-4 4H27l-7 6v-6H10a4 4 0 0 1-4-4V16a4 4 0 0 1 4-4z" fill="currentColor"/><circle cx="18" cy="23.5" r="3.2" fill="#fff"/><circle cx="30" cy="23.5" r="3.2" fill="#fff"/></svg>' },
  { name: 'Email', url: 'https://mail.google.com/mail/?view=cm&fs=1&to=qyrravo%40gmail.com', cls: 'ml', svg: '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="5" y="10" width="38" height="28" rx="6" fill="currentColor"/><path d="M8 15l16 12 16-12" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' },
];
export function socialLinks() {
  const wrapEl = h('div', { class: 'socials' });
  for (const s of SOCIALS) {
    const a = h('a', { class: 'social ' + s.cls, href: s.url, target: '_blank', rel: 'noopener noreferrer', 'aria-label': 'QYRRAVO on ' + s.name + ' (opens in a new tab)' }, h('span', { class: 'sicon' }), h('span', { class: 'sname' }, s.name));
    a.firstChild.innerHTML = s.svg; // static markup defined above, no user input
    wrapEl.append(a);
  }
  return wrapEl;
}
