// One consistent line-icon set (24px grid). Static markup defined here, never built from user input.
const P = {
  gaming: '<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01M7.5 6h9a4.5 4.5 0 0 1 4.4 3.6l.9 4.8a2.8 2.8 0 0 1-4.9 2.3L15 14H9l-1.9 2.7a2.8 2.8 0 0 1-4.9-2.3l.9-4.8A4.5 4.5 0 0 1 7.5 6z"/>',
  phones: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
  royal: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
  budget: '<path d="M3 12.5V4h8.5L21 13.5 13.5 21 3 12.5z"/><path d="M7.5 8.5h.01"/>',
  lookalike: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16z"/>',
  giftcards: '<path d="M4 11h16v10H4zM3 7h18v4H3zM12 7v14"/><path d="M12 7S10.5 3 8 3.5 8 7 12 7zm0 0s1.5-4 4-3.5S16 7 12 7z"/>',
  tech: '<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M9.5 3v4M14.5 3v4M9.5 17v4M14.5 17v4M3 9.5h4M3 14.5h4M17 9.5h4M17 14.5h4"/>',
  home: '<path d="M3 11l9-8 9 8M5 9.5V20h14V9.5M10 20v-6h4v6"/>',
  carry: '<path d="M8 7V5a4 4 0 0 1 8 0v2M6 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2zM9 14h6"/>',
  travel: '<path d="M2.5 12.5l19-8-6.5 16-3.5-6.5-9-1.5zM11.5 14L21.5 4.5"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v12H4z"/><circle cx="12" cy="13.5" r="3.7"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3.4 3.2 14.6 0 18M12 3c-3.2 3.4-3.2 14.6 0 18"/>',
  chat: '<path d="M4 5h16v11H9.5L4 20.5z"/>',
  mail: '<rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="M3.5 7l8.5 6.5L20.5 7"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6l8-3z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
  ticket: '<path d="M3 7h18v3.2a1.8 1.8 0 0 0 0 3.6V17H3v-3.2a1.8 1.8 0 0 0 0-3.6V7z"/><path d="M14 7v10" stroke-dasharray="1.5 2.5"/>',
  gift: '<path d="M4 11h16v10H4zM3 7h18v4H3zM12 7v14"/><path d="M12 7S10.5 3 8 3.5 8 7 12 7zm0 0s1.5-4 4-3.5S16 7 12 7z"/>',
  car: '<path d="M5 16V12l2-5h10l2 5v4"/><path d="M3 16h18v3H3zM7 12h10"/><circle cx="7.5" cy="16" r=".6"/><circle cx="16.5" cy="16" r=".6"/>',
  vote: '<path d="M4 12l5-5 4 4 7-7"/><path d="M4 20h16"/>',
  book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 4-6 8-6s7.2 2 8 6"/>',
  bag: '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  tag: '<path d="M3 12.5V4h8.5L21 13.5 13.5 21 3 12.5z"/><path d="M7.5 8.5h.01"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z"/>',
  cart: '<path d="M3 4h2.5l2 11h10.5l2-8H6.5"/><circle cx="9" cy="19.5" r="1.2"/><circle cx="17" cy="19.5" r="1.2"/>',
  chevron: '<path d="M6 9l6 6 6-6"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
};
export function icon(name, size = 22) {
  const s = document.createElement('span'); s.className = 'ico'; s.setAttribute('aria-hidden', 'true');
  s.innerHTML = '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + (P[name] || P.tag) + '</svg>';
  return s;
}
