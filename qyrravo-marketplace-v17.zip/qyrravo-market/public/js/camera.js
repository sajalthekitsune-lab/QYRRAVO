// Take a photo with the device camera (back or front) and hand it back as a JPEG File.
// Uses getUserMedia (needs https:// or localhost). If that is not available or is refused,
// it falls back to the phone's own camera app through <input capture>.
import { h, modal, toast } from './core.js';

const canLive = () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) && (window.isSecureContext !== false);

export function cameraSupported() { return true; } // there is always a fallback (file picker with capture)

export function openCamera(onFile) {
  let facing = 'environment'; let stream = null; let m = null;
  const note = h('p', { class: 'hint', 'aria-live': 'polite' });
  const video = h('video', { class: 'cam', autoplay: true, playsinline: true, muted: true });
  video.muted = true;
  const stop = () => { if (stream) { stream.getTracks().forEach((t) => t.stop()); stream = null; } video.srcObject = null; };

  // fallback: the device's camera app
  const fallback = (face) => {
    const i = h('input', { type: 'file', accept: 'image/*', capture: face, hidden: true, onchange: (e) => { const f = e.target.files[0]; if (f) { m && m.close(); onFile(f); } } });
    document.body.append(i); i.click(); setTimeout(() => i.remove(), 60000);
  };

  async function start() {
    stop(); capBtn.disabled = true;
    if (!canLive()) { note.textContent = 'Live camera needs a secure (https) page. Use the button below to open your phone’s camera app instead.'; fbBtn.hidden = false; return; }
    note.textContent = 'Starting ' + (facing === 'user' ? 'front' : 'back') + ' camera…';
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
      video.srcObject = stream; await video.play().catch(() => {});
      note.textContent = ''; capBtn.disabled = false; fbBtn.hidden = true;
    } catch (e) {
      const denied = e && (e.name === 'NotAllowedError' || e.name === 'SecurityError');
      note.textContent = denied ? 'Camera permission was refused. Allow the camera for this site in your browser, or use your phone’s camera app below.' : 'No camera could be opened (none found, or another app is using it). You can use your phone’s camera app below.';
      fbBtn.hidden = false;
    }
  }
  const setFacing = (f) => { facing = f; back.setAttribute('aria-pressed', String(f === 'environment')); front.setAttribute('aria-pressed', String(f === 'user')); back.classList.toggle('on', f === 'environment'); front.classList.toggle('on', f === 'user'); start(); };
  const back = h('button', { type: 'button', class: 'chip on', 'aria-pressed': 'true', onclick: () => setFacing('environment') }, '📷 Back camera');
  const front = h('button', { type: 'button', class: 'chip', 'aria-pressed': 'false', onclick: () => setFacing('user') }, '🤳 Front camera');
  const capBtn = h('button', { type: 'button', class: 'btn primary', disabled: true, onclick: () => {
    if (!video.videoWidth) { toast('The camera is not ready yet.', 'error'); return; }
    const c = document.createElement('canvas'); c.width = video.videoWidth; c.height = video.videoHeight;
    c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
    c.toBlob((blob) => { if (!blob) { toast('Could not capture the photo. Try again.', 'error'); return; } const file = new File([blob], 'camera-' + Date.now() + '.jpg', { type: 'image/jpeg' }); m.close(); onFile(file); }, 'image/jpeg', 0.92);
  } }, '● Take photo');
  const fbBtn = h('button', { type: 'button', class: 'btn', hidden: true, onclick: () => fallback(facing) }, 'Open phone camera app');
  m = modal('Take a photo', h('div', null,
    h('div', { class: 'row', style: 'margin-bottom:10px' }, back, front),
    video, note,
    h('div', { class: 'actions' }, capBtn, fbBtn, h('button', { type: 'button', class: 'btn', onclick: () => m.close() }, 'Cancel')),
    h('p', { class: 'hint' }, 'Photos are taken inside your browser and uploaded only when you press “Take photo”. Location data is removed from the file on upload.')),
    { onClose: stop });
  start();
  return m;
}
