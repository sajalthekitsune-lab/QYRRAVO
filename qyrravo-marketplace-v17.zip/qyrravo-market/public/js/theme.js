// Theme: dark (default), light, or future (neon). Runs before the page paints so there is no flash.
(function () {
  var KEY = 'qy_theme', ALL = ['dark', 'light', 'future'], COLORS = { dark: '#080B10', light: '#f3f6fa', future: '#07020f' };
  function get() { try { var v = localStorage.getItem(KEY); if (ALL.indexOf(v) > -1) return v; } catch (e) { /* ignore */ } return 'dark'; }
  function apply(t) {
    document.documentElement.setAttribute('data-theme', t);
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute('content', COLORS[t]);
    var btns = document.querySelectorAll('[data-themebtn]'); for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', btns[i].getAttribute('data-themebtn') === t ? 'true' : 'false');
  }
  window.qyTheme = { get: get, all: ALL, set: function (t) { if (ALL.indexOf(t) < 0) return; try { localStorage.setItem(KEY, t); } catch (e) { /* ignore */ } apply(t); }, apply: function () { apply(get()); } };
  apply(get());
})();
