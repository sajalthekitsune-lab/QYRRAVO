# Known limitations and remaining work

- **No real payments.** Only the simulator exists; the Tap adapter is a placeholder. Without a provider, the site cannot take real money (by design).
- **Email delivery is unverified live.** The Resend path is written but has not been tested against the real service. Without a provider, emails are not sent (admins see them in the outbox).
- **Legal pages are drafts**; commission 5% is a placeholder; country restrictions flags are placeholders.
- **Photo review proves little.** It shows a moderator saw a code beside the item at upload time. The server cannot read the photo; the moderator types the code they see. It does not prove ownership, authenticity or honesty.
- **SQLite via `node:sqlite`** (experimental in Node; fine for a small marketplace, plan a move to PostgreSQL for scale). Single server only; rate limits are in-memory.
- Late successful payment for an order that was already cancelled/expired is flagged for a manual refund, not auto-refunded.
- Currency conversion uses stored rates (QAR/AED/SAR pegs, others from `fetch-rates`); displayed conversions are labelled estimates.
- Shipping is seller-managed (flat fee per listing); no carrier integration, tax calculation or invoices.
- Image storage is local disk; no virus scan or object storage.
- No multi-language UI; no push/SMS notifications.
- Camera capture runs in the browser and needs https:// (or localhost). On plain http the site falls back to the phone's own camera app. Camera photos are not proof of anything beyond what the moderator sees.
- Plan rules: one item for sale at a time and one unit per listing on every plan (admin can change both per plan). Upgrading starts a new paid month and does not credit unused time; downgrading mid-period is not supported.
- The original idea of a 100k+ item catalogue is not faked: the marketplace starts empty and fills with real seller listings. Each listing shows its own price.
- Automated tests: 51 backend tests + 51-check browser run on desktop and mobile widths; not load- or penetration-tested.

## v3 notes
- Purchases are manual: QYRRAVO answers emails, receives payment outside the site and switches plans on with "Give plan". No automatic payment verification exists while PAYMENT_MODE=off.
- The help bot's built-in mode matches keywords; it cannot answer everything. With ANTHROPIC_API_KEY it can, but it may still be wrong. It is labelled as such.
- Owner password lives only in .env. Choose a strong one (an email address is easy to guess).


## Q Coins payments
- Q Coins are an in-app balance (100 Q = $1). They cannot be cashed out, and there is no coin-to-money conversion.
- Coin orders are held in escrow by the platform and released or refunded by staff. There is no automatic delivery tracking.
- The coin price of an item is its USD price at the stored exchange rate; it is not re-priced if the seller edits the price after an order.
- Buying Q Coins is manual: the owner confirms the money arrived (by email) and then presses the button that adds the coins. Nothing is added automatically.

## QYRRAVO Drive (the game)
- The game is plain JavaScript + WebGL. Lua 5.1 cannot run natively in a browser, so it is not used.
- Earning is measured by the server (heartbeats every ~15 s, gaps, daily cap, one live session per account). It is a real cost to the owner: 100 Q Coins = $1 of wallet value. Defaults: 20 Q per completed lap (GAME_LAP_COINS), the server requires 900 s of active play per paid lap (GAME_MIN_LAP_SECONDS), 12 paid laps/day (GAME_DAILY_LAPS), time pay off (GAME_COINS_PER_HOUR=0), 120 min/day per account, 50,000 Q/day for everyone (env GAME_COINS_PER_HOUR, GAME_DAILY_MINUTES, GAME_GLOBAL_DAILY_COINS, GAME_ENABLED=0 to switch off).
- A determined person can still script heartbeats or use many verified accounts. The caps bound the cost but do not prevent it; watch the ledger (reason "Game rewards") and tighten the env limits if needed.
- Needs WebGL; very old devices show a message instead of the game.
- Laps are claimed by the browser; the server cannot see the car's position. It only pays if enough real active play time was recorded (default 480 s per lap) and within the daily lap limit, so a cheater can at most earn the capped amount, not unlimited coins.
- The track is about 132 km (33,000 road points) streamed in 1 km chunks. A staff-only 400 km/h car ("QYRRAVO Royale") is shown only to the owner, admins and moderators; this is a client-side check, so it is cosmetic (it does not change what is paid).
- All normal cars are capped at 800 km/h. The staff F1 car (10,000 km/h) has no walls and can fly anywhere; the Tesla Roadster (1,000 Q, charged by the server and saved per account) can fly above the track. Which car is driven is decided in the browser, so a technical person could use the Tesla or F1 without paying; this only changes how the game looks, not what is paid (lap rewards are not given for flying or the F1 car, and laps are checked by the server's play-time rule).
