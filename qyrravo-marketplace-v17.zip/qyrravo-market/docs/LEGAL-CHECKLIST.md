# Legal and compliance checklist (not legal advice)

The legal pages in the site are **drafts** written to match how the software behaves. A qualified lawyer in Qatar must review them before launch.

## Guardian / age
The founder is under 18. This project does not bypass age or identity rules of any provider or authority. Before any real business activity, a parent or guardian (or other lawful adult) must help decide and sign for: who legally owns the business, the legal structure, the payment-provider account, hosting and domain accounts, and the contracts with sellers and buyers.

## Qatar (as understood from public sources — verify)
- Ministry of Commerce and Industry Decision No. 25 of 2026 reportedly requires an e-commerce licence. Reported requirements: commercial registration, one licence per website, displaying CR/licence numbers, a support contact and a return policy. Effective date, fees, penalties and how marketplaces are treated were **not found** — ask the Ministry.
- Consumer protection: returns, refunds, accurate pricing and descriptions.
- Personal data: Qatar's data-protection law (PDPPL) — privacy notice, lawful basis, deletion/export on request, breach process.
- Payments: provider KYC for the business and for each seller.
- Tax/VAT and invoicing: confirm obligations with an accountant.

## Sellers and listings
- Prohibited-items list is admin-editable (seed list is a starting point, not complete).
- Cross-border: customs, restricted goods per country (`restricted` flag in `countries.json` is a placeholder — fill it with legal advice).

## Before launch
[ ] Guardian + legal entity  [ ] E-commerce licence, CR/licence numbers shown in the footer  [ ] Lawyer-reviewed terms, seller agreement, privacy, subscription terms, commission policy, refunds, disputes  [ ] Real commission rate chosen  [ ] Provider approved + adapter built + sandbox-tested  [ ] Email provider + verified sender domain  [ ] HTTPS, backups, monitoring  [ ] A human process for moderation and support
