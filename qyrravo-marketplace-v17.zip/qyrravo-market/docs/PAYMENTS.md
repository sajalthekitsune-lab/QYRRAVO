# Payments

## What exists
A provider-adapter interface (`server/payments/index.js`): createCheckout, refund, cancelSubscription, startSellerOnboarding, requestPayout, verifyWebhook.
- `test` provider = SIMULATOR (`server/payments/test.js`). It shows a "Payment simulator" page and sends a **signed** webhook (`X-QY-Signature: t=<unix>,v1=<HMAC-SHA256("t.body")>`, 5-minute tolerance), just as a real provider would. Orders and Premium change state only when that webhook verifies — never because of a click, screenshot or receipt.
- `tap` provider = **not implemented**. The file exists as a placeholder and refuses to run. Live mode with it fails at startup rather than pretending.
- Safety rules in code: `PAYMENT_MODE=live` refuses the simulator; `NODE_ENV=production` refuses the simulator; no card data ever touches this server (hosted checkout only); webhook events are de-duplicated (`UNIQUE(provider,event_id)`); amounts and currency in each event are compared with our records and mismatches are rejected and alert admins; ledger entries have unique idempotency keys.

## Provider research (verify before relying on it)
Findings from public documentation at the time of building; confirm with the provider's sales/support before committing.
- **Tap Payments (Qatar/GCC):** has a marketplace model — the Charges API accepts `destinations` to split a payment, and sellers are onboarded as sub-accounts with KYC (commercial registration/trade licence, owner ID, IBAN). Payouts to sellers stay off until Tap reviews them. Liability for the marketplace sits with the platform. Tap lists recurring billing and local Qatari bank payouts. **Not published:** fees, exact supported currencies/countries per merchant, approval timelines.
- **Stripe:** direct onboarding in Qatar was unclear; a common workaround is an entity in a supported country. This needs legal advice.
- Whichever provider: you need a **registered business** (an adult/guardian-owned legal structure — see the legal checklist), a provider account approved for marketplace/split payments, and the webhook secret.

## To go live (in order)
1. Parent/guardian + legal structure + e-commerce licence (see `LEGAL-CHECKLIST.md`).
2. Provider account approved for marketplaces. Ask in writing: fees, currencies, payout countries, KYC for sellers, chargeback/dispute rules, test sandbox.
3. Implement `server/payments/<provider>.js` against the provider docs, using the simulator as the reference for behavior and `test/payments.test.js` as the checklist. Verify the real webhook signature scheme.
4. Test in the provider's sandbox end-to-end (checkout, failed payment, refund, dispute, subscription renewal/failure, payout).
5. Set `PAYMENT_MODE=live`, `PAYMENT_PROVIDER=<name>`, `PAYMENT_SECRET_KEY`, `PAYMENT_WEBHOOK_SECRET` on the server only. Keep keys out of git and out of `public/`.
6. Set the real commission in Admin → Settings and untick the placeholder flag; set `payout_countries`.

## Test-mode instructions
`PAYMENT_MODE=test` (default in development). Register a seller → onboarding → simulated payout set-up → list an item → moderator approves (code from the photo) → buyer checks out → simulator page → "Pay" → signed webhook marks the order paid. Premium and VIP work the same way (Seller → Plan → Choose plan).
