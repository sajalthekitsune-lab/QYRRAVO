# Deploy

Needs a host with Node 22.13+ and a **persistent disk** (SQLite database and uploaded images live on disk; free hosts that wipe disks will lose data). A single small VPS or a platform with a mounted volume works.

1. Copy the project, `cp .env.example .env`, set `NODE_ENV=production`, `APP_URL=https://your.domain`, `DATABASE_PATH`, `UPLOAD_DIR` (both on the persistent volume), `TRUST_PROXY=1` if behind your own proxy.
2. Put a reverse proxy with HTTPS (Caddy/nginx) in front. Cookies are Secure when `APP_URL` is https.
3. `npm start` under a process manager (systemd/pm2). Migrations run at start.
4. `node scripts/create-admin.js <email> admin`.
5. `npm run fetch-rates` daily (cron) so conversions and plan limits use current rates (needs internet from the server).
6. Back up the database file and uploads folder daily; test a restore.

## Required external services
- Domain + HTTPS certificate (you must buy these; a `.com` cannot be created by this project).
- Payment provider (see PAYMENTS.md) — required for real money.
- Email provider (set `EMAIL_PROVIDER`/`EMAIL_API_KEY`/`EMAIL_FROM`; otherwise emails are only logged and shown as "not configured") — needed for verification and reset emails to reach people.
- Hosting with persistent storage; optional error monitoring.
